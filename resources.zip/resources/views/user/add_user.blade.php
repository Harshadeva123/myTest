@include('includes.header_start')

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css"
      integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
<meta name="csrf-token" content="{{ csrf_token() }}"/>
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/validations')}}'"></script>--}}
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/common')}}'"></script>--}}


@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">


        <form class="" method="post" enctype="multipart/form-data" action="{{ route('createUser') }}"
              id="createUserForm">


            <div class="row">

                <div class="col-lg-6">
                    <div class="card m-b-20">
                        <div class="card-body">
                            @if(count($errors)>0)
                                <div class="alert alert-danger alert-dismissible ">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div><br/>
                            @endif
                            @if (\Session::has('success'))
                                <div class="alert alert-info alert-dismissible ">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <p>{{ \Session::get('success') }}</p>
                                </div><br/>
                            @endif

                            <h4 class="mt-0 header-title">User Info</h4>
                            {{--<p class="text-muted m-b-30 font-14">Parsley is a javascript form validation--}}
                            {{--library. It helps you provide your users with feedback on their form--}}
                            {{--submission before sending it to your server.</p>--}}


                            <div class="form-group">
                                <label>Title</label>
                                <input type="hidden" name="company" value="1">
                                <select class="form-control" required id="uTitle" name="uTitle">
                                    <option value="" disabled selected>Select Title</option>
                                    <option value="Mr.">Mr.</option>
                                    <option value="Miss.">Miss.</option>
                                    <option value="Mrs.">Mrs.</option>

                                </select>
                            </div>

                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" class="form-control" name="fName" id="fName" required
                                       placeholder="First Name"/>
                                <small class="text-danger">{{ $errors->first('fName') }}</small>
                            </div>
                            <input type="hidden" name="_token" value="{{ Session::token() }}">

                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" class="form-control" required name="lName" id="lName"
                                       placeholder="Last Name"/>
                                <small class="text-danger">{{ $errors->first('lName') }}</small>
                            </div>


                                <div class="form-group">
                                    <label for="example-text-input" class="col-form-label">Agency</label>
                                    <select class="form-control " name="agency"
                                            id="agency" required>
                                        <option value="" disabled selected>Select Agency
                                        </option>
                                        @if(isset($agencies))
                                            @foreach($agencies as $agency)
                                                <option value="{{"$agency->idCompanyInfo"}}">{{"$agency->companyName"}}</option>
                                            @endforeach
                                        @endif

                                    </select>
                                </div>


                            <div class="form-group">
                                <label for="dob" >Date of Birth</label>
                                <div>
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                                        </div>
                                        <input type="text" class="form-control datepickerAutoclose"  required name="dob"
                                               placeholder="mm/dd/yyyy"
                                               id="dob">
                                        <small class="text-danger">{{ $errors->first('dob') }}</small>
                                    </div><!-- input-group -->
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Gender</label>

                                <select class="form-control" name="gender" id="gender" required>
                                    <option value="" disabled selected>Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <small class="text-danger">{{ $errors->first('gender') }}</small>

                                </select>

                            </div>
                            <div class="form-group">
                                <label>Contact No</label>
                                <input type="number" name="contactNo" id="contactNo" required class="form-control"
                                       placeholder="Eg: 07XXXXXXXX"/>
                                <small class="text-danger">{{ $errors->first('contactNo') }}</small>
                            </div>


                            <label>User Image</label>
                            <div class="row">

                                <div class="col-md-4"></div>
                                <div class="col-md-4">
                                    <img onclick="openProUploader()" id="MyImage" class="rounded-circle" alt="200x200"
                                         src="{{ URL::asset('assets/images/users/avatar-4.jpg')}}"
                                         data-holder-rendered="true" width="150" height="150">
                                    <input onchange="setProImage(this)" type="file" name="proImage" id="proImage"
                                           style="display:none">

                                </div>
                                <div class="col-md-4"></div>
                            </div>


                            <br>


                            <hr>
                            <div class="form-group">
                                <label>User Type</label>

                                <select class="form-control" id="utype" name="utype" required>
                                    <option disabled value="" selected>Select User</option>
                                    @if(isset($userroles))
                                        @foreach($userroles as $role)
                                            <option value="{{ $role->idUserRole }}">{{ $role->role }}</option>
                                        @endforeach
                                    @endif
                                </select>

                                <small class="text-danger">{{ $errors->first('utype') }}</small>

                            </div>

                            <div class="form-group">
                                <label>Email | Username</label>
                                <input type="email" required name="username" onchange="checkAvailability()" id="username" class="form-control"
                                       placeholder="abc@example.com"/>
                                <small id="msg_username" class="text-danger">{{ $errors->first('username') }}</small>
                            </div>
                            <div class="form-group">
                                <label>Password </label>
                                <div>
                                    <input type="password" name="pass2" id="pass2" class="form-control" oninput="checkLenght()" required title="Please enter atleast 8 charactes"
                                           placeholder="12345678"/>
                                    <small id="msg_password" class="text-danger">{{ $errors->first('pass2') }}</small>
                                </div>
                                <div class="m-t-10">
                                    <input type="password" class="form-control" required
                                           data-parsley-equalto="#pass2"
                                           placeholder="Re-Type Password"/>
                                </div>
                            </div>

                            <div class="form-group">
                                <div>
                                    <button type="reset" onclick="clearAll()" class="btn btn-danger waves-effect m-l-5">
                                        Reset
                                    </button>
                                    <button type="submit"  id="createUserBtn"
                                            class="btn btn-primary waves-effect waves-light">
                                        Add User
                                    </button>

                                </div>
                            </div>





                        </div>
                    </div>
                </div> <!-- end col -->


            </div> <!-- end row -->
        </form>

    </div><!-- container -->

</div> <!-- Page content Wrapper -->

</div> <!-- content -->

@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min')}}'"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min')}}'"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min')}}'" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min')}}'" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min')}}'" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min')}}'" type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced')}}'"></script>


<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min')}}'"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify')}}'"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts')}}'"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<script type="text/javascript">
    function openProUploader() {
        $("#proImage").click();
    }
    function setProImage(input) {

        if (input.files[0] !== null) {
            var reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById("MyImage").setAttribute("src", e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
            // document.getElementById("myUp1").submit();
        }
    }

    function initializeDate() {
        jQuery('.datepickerAutoclose').datepicker({
            autoclose: true
        });

    }

    $( document ).on( 'focus', ':input', function(){
        $( this ).attr( 'autocomplete', 'off' );
    });


    $(document).ready(function () {
        $('form').parsley();
        $('input').attr('autocomplete','off');
        $('select').attr('autocomplete','off');
        initializeDate();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });


    function checkAvailability() {

        var uname = $('#username').val();
        $.ajax({

            type: 'POST',

            url: "{{ route('checkUsername') }}",

            data: {username: uname},

            success: function (data) {
                if (data == 1) {

                    $('#msg_username').html('Username already taken');
                    return false;
                } else {
                    $('#msg_username').html('');
                    return true;
                }
            }
        })
    }




    function clearAll() {
        $('input').val('');
        $('select').val('');
        $('small').html('');
        $('.parsley-required').html('');
        $('.parsley-type').html('');
        $('.parsley-error').removeClass('parsley-error');
        document.getElementById("MyImage").setAttribute("src", '{{ URL::asset('assets/images/users/avatar-4.jpg')}}');
    }

    function checkLenght(ln) {
        if($('#pass2').val().length<8){
            $('#msg_password').html('The Password must be at least 8 characters.');
            return false;
        }else{
            $('#msg_password').html('');
          return true;
        }
    }
</script>


@include('includes.footer_end')