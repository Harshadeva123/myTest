@include('includes.header_start')

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">

@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->
<div class="page-content-wrapper">

    <div class="container-fluid">

        <div class="col-lg-12">
            <div class="card m-b-20">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <form action="{{ route('bankAccounts') }}" method="GET">
                                {{csrf_field()}}

                                <div class="input-group">
                                    <input type="search" name="Sbranch" id="Sbranch" class="form-control"
                                           placeholder="Search branch here">
                                    <span class="input-group-append">
                                      <button class="btn btn-info btn-block" type="submit"><i
                                                  class="fa fa-search"></i> Search</button>
                                        </span>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-6">
                            <button type="button"
                                    class="btn btn-md btn-primary  waves-effect waves-light float-right" data-toggle="modal"
                                    data-target="#addModal">Add Account
                            </button>
                        </div>
                    </div>
                    <br>
                    <div class="table-rep-plugin">
                        <div class="table-responsive b-0" data-pattern="priority-columns">
                            <table id="datatable-buttons" class="table table-striped table-bordered"
                                   cellspacing="0"
                                   width="100%">
                                <thead>
                                <tr>
                                    <th>BANK</th>
                                    <th>BRANCH</th>
                                    <th>ACCOUNT NO</th>
                                    <th>STATUS</th>
                                    <th>LAST UPDATE</th>
                                    <th>CREATED AT</th>
                                    <th>ACTION</th>
                                </tr>
                                </thead>
                                <tbody>
                                @if(isset($accounts))
                                    @foreach($accounts as $account)
                                        <tr>
                                            <td>{{strtoupper($account->bank->bank)}}</td>
                                            <td>{{strtoupper($account->branch)}}</td>
                                            <td>{{$account->accNo}}</td>
                                           @if ($account->status == 1)

                                           <td>
                                               <input type='checkbox' class='btn  btn-sm btn-danger' onchange="bankAccountStatus('{{$account->idbank_meta}}')" id='c{{ $account->idbank_meta }}' checked switch='none'/>
                                              <label for='c{{ $account->idbank_meta }}' data-on-label='On' data-off-label='Off'></label>
                                               </td>

                                            @else
                                            <td>
                                            <input type='checkbox' class='btn  btn-sm btn-danger' onchange="bankAccountStatus('{{$account->idbank_meta}}')" id='c{{ $account->idbank_meta }}'  switch='none'/>
                                            <label for='c{{ $account->idbank_meta }}' data-on-label='On' data-off-label='Off'></label>
                                            </td>
                                            @endif

                                            <td>{{$account->updated_at}}</td>
                                            <td>{{$account->created_at}}</td>
                                            <td><div class="button-items">
                                                    <button type="button" class="btn btn-sm btn-warning  waves-effect waves-light"
                                                     onclick="showUpdateModal({{$account->idbank_meta}})">
                                                    <i class="fa fa-edit"></i></button>
                                                </div>
                                            </td>
                                            </tr>
                                    @endforeach
                                @endif
                                </tbody>
                            </table>
                            @if(isset($measurementViews))
                            {{$measurementViews->links()}}
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Add Account</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlertAdd" style="display:none">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="bank">Banks</label>
                    <select class="form-control select2 tab"  name="bank"
                            id="bank" required>
                        <option value="" disabled selected>Select Bank
                        </option>
                        @if(isset($banks))
                            @foreach($banks as $bank)
                                <option value="{{"$bank->idbank"}}">{{$bank->bank}} </option>
                            @endforeach
                        @endif

                    </select>
                </div>
                <div class="form-group">
                    <label for="branch">Branch</label>
                    <input class="form-control"  name="branch"
                           id="branch" type="text">
                </div>
                <div class="form-group">
                    <label for="account">Account No</label>
                    <input class="form-control"  name="account"
                            id="account" type="number">
                </div>
                <div class="form-group">
                    <div>
                        <button type="submit" onclick="save()"
                                class="btn btn-primary waves-effect waves-light">
                            Add Account
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--update measurement-->
<div class="modal fade" id="updateModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <input type="hidden" name="hiddenMID" id="hiddenMID">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Edit Account</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">


                <div class="row">

                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlertUpdate" style="display:none">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="Ubank">Banks</label>
                    <select class="form-control select2 tab"  name="Ubank"
                            id="Ubank" required>
                        <option value="" disabled selected>Select Bank
                        </option>
                        @if(isset($banks))
                            @foreach($banks as $bank)
                                <option value="{{"$bank->idbank"}}">{{$bank->bank}} </option>
                            @endforeach
                        @endif

                    </select>
                </div>
                <input type="hidden" id="hiddenID">
                <div class="form-group">
                    <label for="Ubranch">Branch</label>
                    <input class="form-control"  name="Ubranch"
                           id="Ubranch" type="text">
                </div>
                <div class="form-group">
                    <label for="Uaccount">Account</label>
                    <input class="form-control"  name="Uaccount"
                           id="Uaccount" type="number">
                </div>

                <div class="form-group">
                    <div>
                        <button type="submit" onclick="update()"
                                class="btn btn-warning waves-effect waves-light">
                            Update Account
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}" type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>
<script type="text/javascript">
    $(document).ready(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    $(document).on("wheel", "input[type=number]", function (e) {
        $(this).blur();
    });

    function save() {
        $('.notify').empty();
        $('.alert').hide();
        $('.alert').html('');

        var bank = $("#bank").val();
        var account = $("#account").val();
        var branch = $("#branch").val();


        $.post('saveBankAccount', {
            bank: bank,
            account: account,
            branch: branch
        }, function (data) {
            if (data.errors != null) {
                $('#errorAlertAdd').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlertAdd').append('<p>' + value + '</p>');
                });
                $('html, body').animate({
                    scrollTop: $("#errorAlertAdd").offset().top
                }, 1000);
            }
            if (data.success != null) {

                notify({
                    type: "success", //alert | success | error | warning | info
                    title: 'ACCOUNT SAVED',
                    autoHide: true, //true | false
                    delay: 2500, //number ms
                    position: {
                        x: "right",
                        y: "top"
                    },
                    icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                    message:'Bank account saved successfully.',
                });
                $('#branch').val('');
                $('#account').val('');
                $('#bank').val('').trigger('change');

               $('#addModal').modal('hide');
            }
            showAccountDetails();
        });
    }


    function showUpdateModal(id) {

        $.post('getBankAccountById', {id:id}, function (data) {
            $("#Ubank").val(data.bank_idbank).trigger('change');
            $("#Ubranch").val(data.branch);
            $("#hiddenID").val(id);
            $("#Uaccount").val(data.accNo);
            $('#updateModal').modal('show');

        });
    }

    function update() {
        $('.notify').empty();
        $('.alert').hide();
        $('.alert').html("");

       let bank = $("#Ubank").val();
       let branch = $("#Ubranch").val();
       let id = $("#hiddenID").val();
       let account = $("#Uaccount").val();
        $.post('updateBankAccount', {
            bank: bank,
            branch: branch,
            id: id,
            account: account,
        }, function (data) {
            if (data.errors != null) {
                $('#errorAlertUpdate').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlertUpdate').append('<p>' + value + '</p>');
                });
                $('html, body').animate({
                    scrollTop: $("#errorAlertUpdate").offset().top
                }, 1000);
            }
            if (data.success != null) {

                notify({
                    type: "success", //alert | success | error | warning | info
                    title: 'ACCOUNT UPDATED',
                    autoHide: true, //true | false
                    delay: 2500, //number ms
                    position: {
                        x: "right",
                        y: "top"
                    },
                    icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                    message: 'Bank account updated successfully.',
                });

                $('#updateModal').modal('hide');

            }

            showAccountDetails();

        });
    }

    function showAccountDetails() {
        $.post('getBankAccountData', function (data) {
           $('tbody').html(data);
        });
    }

    $( document ).on( 'focus', ':input', function(){
        $( this ).attr( 'autocomplete', 'off' );
    });

    function bankAccountStatus(id) {
        $.ajax({
            type: 'POST',

            url: 'bankAccountStatus',

            data: {id: id},

            success: function () {

            }
        });

    }

</script>


@include('includes.footer_end')