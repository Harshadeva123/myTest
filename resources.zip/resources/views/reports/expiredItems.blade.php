@include('includes.header_start')

<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->
<link href="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">


<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
{{--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css')}}"--}}
      {{--integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">--}}
{{--<link href="{{ URL::asset('assets/css/custom_checkbox.css')}}" rel="stylesheet" type="text/css"/>--}}
<meta name="csrf-token" content="{{ csrf_token() }}"/>
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/validations.js')}}"></script>--}}
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/common.js')}}"></script>--}}


@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card m-b-20">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">


                                <form action="{{ route('searchExpireReportStock') }}" class="col-md-12" method="GET" id="form1">


                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <input type="text" class="form-control " placeholder="Search Item name or code here" name="item" id="item">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <select class="form-control  select2"  name="type" onchange="feedCategory(this)"
                                                        id="type" >
                                                    <option disabled selected>Select item type
                                                    </option>
                                                    @if(isset($types))
                                                        @foreach($types as $type)
                                                            <option value="{{"$type->idItem_Type"}}">{{"$type->type"}}</option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <select class="form-control select2"  name="category"
                                                        id="category" >
                                                    <option disabled selected>Select category
                                                    </option>
                                                    <option disabled > - Select Item Type First -
                                                    </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <select class="form-control  select2"  name="status"  id="status" >
                                                    <option disabled  value="" selected>Select item status</option>
                                                    <option value="1">Active</option>
                                                    <option value="0">Deactivate</option>
                                                </select>
                                            </div>
                                        </div>


                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <button class="btn btn-primary btn-block"
                                                        type="submit"><em class="fa fa-search"></em> Search
                                                </button>
                                            </div>
                                        </div>
                                        <input type="hidden" value="" name="rows" id="rows">

                                    </div>

                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">

                                <div class="table-rep-plugin">
                                    <div class="table-responsive b-0" data-pattern="priority-columns">
                                        <table  id="execelTable"  class="table table-striped table-bordered"  cellspacing="0"  width="100%">
                                            <thead>
                                            <tr>
                                                <th>ITEM</th>
                                                <th>TYPE</th>
                                                <th>CATEGORY</th>
                                                <th style="text-align: right;">RATE</th>
                                                <th style="text-align: center;">AVAILABLE QTY</th>
                                            </tr>
                                            </thead>
                                            <tbody id="stockDetails">
                                            @if(count($paginator)>0)
                                                @foreach($paginator as $pg)
                                                    <tr >
                                                        <td>{{$pg->itemCode}} - {{$pg->item}} </td>
                                                        <td>{{$pg->type}}</td>
                                                        <td>{{$pg->category}}</td>
                                                        <td style="text-align: right;">{{number_format($pg->rate,2)}}</td>
                                                        <td style="text-align: right;"><a class="qtyAv text-danger" id="qty-{{$pg->itemId}}" data-id="{{$pg->itemId}}" href="#">{{$pg->available}} &nbsp; {{$pg->measurement}}</a></td>
                                                    </tr>
                                                @endforeach
                                            @else
                                                <tr><td  style="text-align: center;"  colspan="9">No records.</td></tr>
                                            @endif
                                            </tbody>
                                        </table>

                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-12 ">
                                        <div class="form-group pull-right mr-3">
                                            @if($start == false)
                                                <a class="btn btn-primary  btn-sm" href="{{$startLink}}">Start</a>
                                                <a class="btn btn-primary  btn-sm" href="{{$prevLink}}">Prev</a>
                                            @else
                                                <a class="btn btn-secondary  btn-sm" href="#">Start</a>
                                                <a class="btn btn-secondary  btn-sm" href="#">Prev</a>
                                            @endif
                                            @if($end == false)
                                                <a class="btn btn-primary  btn-sm" href="{{$nextLink}}">Next</a>
                                                <a class="btn btn-primary  btn-sm" href="{{$lastLink}}">Last</a>
                                            @else
                                                <a class="btn btn-secondary btn-sm"  disabled="true" href="#">End</a>
                                                <a class="btn btn-secondary btn-sm" disabled="true" href="#">Last</a>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{--save GRN moal--}}
<div class="modal fade" id="viewModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Stock in Detail</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">


                <div class="row">
                    <div class="col-md-12">


                        <table class="table table-striped table-bordered"
                               cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>STORE</th>
                                <th>BASE</th>
                                <th>BASE REF</th>
                                <th> A. QTY</th>
                                <th>MANF DATE</th>
                                <th>EXP DATE</th>
                                <th>SELLING P.</th>
                                <th style="text-align: right;display: none">BUYING PRICE</th>
                            </tr>
                            </thead>
                            <tbody id="modalTableData">
                            </tbody>
                        </table>

                    </div>
                </div>


            </div>
        </div>
    </div>
</div>
@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>

<script src="{{ URL::asset('assets/plugins/exportExcel/table2csv.js')}}"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
{{--<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>--}}
{{--<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>--}}

<script type="text/javascript">


    $(document).ready(function () {
//        $('form').parsley();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#execelTable').DataTable( {
            responsive: true,
            "bFilter": false,
            'bInfo': false,
            // "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
            dom: 'Bfrtip',
            "bPaginate": false,
            buttons: [
                //     // 'pageLength',
                {
                    extend:'print',
                    title: 'Expire Items Report',
                    exportOptions: {
                        columns: ':visible'
                    }

                },
                {
                    extend: 'excelHtml5',
                    autoFilter: true,
                    sheetName: 'Expire Items Report',
                    filename: 'Expire Items Report',
                    exportOptions: {
                        columns: ':visible'
                    }
                },
                {
                    extend: 'pdfHtml5',
                    orientation: 'landscape',
                    pageSize: 'LEGAL',
                    filename: 'Expire Items Report',
                    title:'Expire Items',
                    exportOptions: {
                        columns: ':visible'
                    }


                },
                {
                    extend: 'colvis',
                    text: 'Columns'
                }

            ]
        } );

        $('.dt-buttons').append(" <select  aria-controls=\"execelTable\" class=\"bg-secondary text-white btn\" onchange=\"rowsChange(this)\"  name=\"rowsCount\" id=\"rowsCount\" >\n" +
            "                                            <option class=\"bg-secondary  text-white\" value=\"10\" selected>10 rows </option>\n" +
            "                                            <option class=\"bg-secondary  text-white\" value=\"25\">25 rows </option>\n" +
            "                                            <option class=\"bg-secondary  text-white\" value=\"50\">50 rows </option>\n" +
            "                                            <option class=\"bg-secondary  text-white\" value=\"100\">100 rows </option>\n" +
            "                                            <option class=\"bg-secondary  text-white\" value=\"all\">All rows</option>\n" +
            "                                        </select>");

        let rows = getUrlParameter('rows');
        if(!rows){
            $('#rowsCount').val(10);
        }
        else {
            $('#rowsCount').val(rows);

        }
    });

    // $("#excelExport").click(function(){
    //     $("#execelTable").table2csv({
    //         file_name: 'Stock_report.csv'
    //     });
    //
    // });

    function rowsChange(el) {
        let rows = el.value;
        let category = getUrlParameter('category');
        let status = getUrlParameter('status');
        let item = getUrlParameter('item');
        let type = getUrlParameter('type');
        $('#rows').val(rows);
        $('#status').val(status);
        $('#category').val(category);
        $('#item').val(item);
        $('#type').val(type);

        $('#form1').submit();
    }

    function feedCategory(el) {
        let type = el.value;
        $.ajax({
            type:'GET',

            url:'feedCategory',

            data:{type:type},

            success:function(data){
                $('#category').html(data);
            }
        });
    }

    function getNextStock(el){
        let skip = $(el).val();
        $.ajax({
            type:'GET',

            url:'active_stock',

            data:{skip:skip},

            success:function(data){
                $('#stockDetails').html(data);
            }
        });
    }

    function viewStockMore(ele) {
        let id = $(ele).attr('data-id');
        $.ajax({
            type:'POST',

            url:'viewStockMore',

            data:{id:id},

            success:function(data){
                $('#modalTableData').html(data);
                $('#viewModal').modal('show');

            }
        });

    }

    function feedStores(ele) {
        let company = $(ele).val();
        $.ajax({
            type:'POST',

            url:'feedStores',

            data:{company:company},

            success:function(data){

                $('#store').html(data);

            }
        });
    }

    function renderSearchInput(el) {
        $(".search").hide().attr('name','');

        $(".searchD").hide();
        let searchBy = el.value;
        if(searchBy == 1 ){
            alert('in item');
            $('#item').show();
            $('#item').attr('name','search');
        }
        if(searchBy == 2){
            $('#type').show();
            $('#type').attr('name','search');
        }
        if(searchBy == 3){
            $('#category').show();
            $('#category').attr('name','search');
        }
    }

    $(".qtyAv").click(function() {

        let company = getUrlParameter('company');
        let store = getUrlParameter('store');
        let id = $(this).attr('data-id');
        $.ajax({
            type:'POST',

            url:'viewExpireStockMore',

            data:{id:id,company:company,store:store},

            success:function(data){
                $('#modalTableData').html(data);
                $('#viewModal').modal('show');

            }
        });
    });

    var getUrlParameter = function getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;

        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');

            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
    };

</script>


@include('includes.footer_end')