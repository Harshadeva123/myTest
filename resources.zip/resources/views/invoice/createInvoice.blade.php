@include('includes.header_start')


<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">
@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <em class="ion-navicon"></em>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                    <div class="card m-b-20">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-4 col-md-4">
                                    <div class="form-group">
                                        <label for="name">Customer Name</label>
                                        <select class="form-control select2" name="name"
                                                id="name" required>
                                            @if(isset($customers))
                                                @foreach($customers as $customer)
                                                    @if($loop->first)
                                                        <option selected value="{{$customer->idCustomer}}">{{$customer->fname.' '.$customer->lname}}</option>
                                                    @else
                                                        <option value="{{$customer->idCustomer}}">{{$customer->fname.' '.$customer->lname}}</option>
                                                    @endif

                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Invoice No</label>
                                        <input class="form-control" type="number" placeholder="Invoice No" id="invoiceNo" name="invoiceNo">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Order No</label>
                                        <input class="form-control" type="text" placeholder="Order No" id="orderNo" name="orderNo">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <div class="row">
                <div class="col-lg-12" id="nonScales">
                    <div class="card m-b-20">
                        <div class="card-body">

                            <div class="row">

                                <div class="col-md-12">
                                    <div class="alert alert-danger alert-dismissible " id="errorAlert" style="display:none">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
<div class="col-lg-4">
    <div class="form-group">
        <label for="item">Item Name</label>
        <select onchange="availableItemCount(this)" class="form-control select2" name="item"
                id="item" required>
            <option value="" disabled selected>Select Item
            </option>
            @if(isset($items))
                @foreach($items as $item)
                    <option value="{{"$item->idItems"}}">{{$item->itemcode}} - {{"$item->itemName"}} </option>

                @endforeach
            @endif
        </select>
    </div>
</div>
                                <div class="col-lg-2">
                                    <div class="form-group">
                                        <label for="available">Available Qty</label>
                                        <input type="number" class="form-control" readonly name="available" id="available" min="0" oninput="this.value = Math.abs(this.value)"
                                               placeholder="0.00"/>
                                        <small class="text-danger">{{ $errors->first('qtyGrn') }}</small>
                                    </div>
                                </div>




                                <div class="col-lg-2 nonScale">
                                    <div class="form-group">
                                        <label for="rate"> Rate</label>
                                        <div class="panel-body"><input type="number" class="form-control" readonly
                                                                       name="rate"
                                                                       id="rate"  min="0" oninput="calTotal();this.value = Math.abs(this.value)"
                                                                       placeholder="0.00"/>
                                            <small class="text-danger">{{ $errors->first('bPrice') }}</small>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-lg-2 nonScale" >
                                    <div class="form-group">
                                        <label for="qty">Qty</label>
                                        <div class="input-group mb-2">
                                            <input type="number" class="form-control"  name="qty" id="qty" min="0" oninput="calTotal()"
                                                   placeholder="0.00"/>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-2" style="padding-top: 28px">
                                    <button  type="button" id="addBtn" onclick="addItem()"
                                             class="btn btn-md btn-primary waves-effect waves-light " >
                                        Add Item
                                    </button>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
        </div>
        <div class="row">
                <div class="col-lg-12">
                    <div class="card m-b-20">
                        <div class="card-body">
                            <div class="table-rep-plugin">
                                <div class="table-responsive b-0" data-pattern="priority-columns">
                                    <table class="table table-striped table-bordered"
                                           cellspacing="0"
                                           width="100%">
                                        <thead>
                                        <tr>
                                            <th>ITEM </th>
                                            <th>QTY</th>
                                            <th style="text-align: right">RATE</th>
                                            <th style="text-align: right">TOTAL</th>
                                            <th>DELETE</th>
                                        </tr>
                                        </thead>
                                        <tbody id="tableData">

                                        </tbody>
                                    </table>

                                </div>
                            </div>

                        </div>

                    </div>
                </div>
        </div>
            </div>
        </div>



<div class="row">
    <div class="col-md-12">
        <div class="card m-b-20">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-3 col-md-3">
                        <div class="form-group">
                            <label>Date</label>
                            <div>
                                <div class="input-group">
                                    <input type="text" class="form-control datepicker-autoclose'" placeholder="mm/dd/yyyy" id="datepicker-autoclose">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                    </div>
                                </div><!-- input-group -->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="total">Total</label>
                            <input class="form-control"  type="number" readonly  min="0"   id="total" name="total">
                        </div>
                    </div>
                    <div class="col-lg-4" style="padding-top: 28px">
                            <button class="btn btn-primary" id="saveBtn" onclick="showSaveModal()">Save Invoice </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="saveInvoice" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered modal-lg">
        <div class="modal-content">
{{--            <div class="modal-header">--}}
{{--                <h5 class="modal-title mt-0">Save Invoice</h5>--}}
{{--                <button type="button" class="close" data-dismiss="modal"--}}
{{--                        aria-hidden="true">×--}}
{{--                </button>--}}
{{--            </div>--}}
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info alert-dismissible " id="successAlert2" style="display:none">


                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert2" style="display:none">

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="form-group">
                            <label for="item">Payment Type</label>
                            <select class="form-control select2" name="payment" onchange="paymentTypeChanged(this)"
                                    id="payment" required>
                                @if(isset($paymentTypes))
                                    @foreach($paymentTypes as $paymentType)
                                        @if(\Illuminate\Support\Facades\Auth::user()->companyInfo->isShop == 1)
                                            <option value="{{"$paymentType->idpayment_type"}}">{{$paymentType->type}}</option>
                                        @else
                                            @if($paymentType->idpayment_type != 7)
                                                <option value="{{"$paymentType->idpayment_type"}}">{{$paymentType->type}}</option>
                                            @endif
                                        @endif
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="item">Bill Total</label>
                        <div class="input-group ">
                                <div class="input-group-prepend">
                                    <div class="input-group-text text-black-50">RS.</div>
                                </div>
                                <input class="form-control text-black-50"  type="number"   id="totalAmount" readonly>
                            </div>
                    </div>
                </div>
                <div class="row discountDiv">
                    <div class="col-lg-6 col-md-6">
                        <div class="form-group">
                            <label for="discount">Discount</label>
                            <div class="input-group">
                                <input class="form-control col-md-8 " type="number"  min="0" oninput="this.value = Math.abs(this.value);countNet()" onchange="countNet()" id="discount" name="discount">
                                <div class="input-group-append col-md-4">
                                    <select class="form-control select2 doNotClear" name="discountType" onchange="$('#discount').val('0');countNet();"
                                            id="discountType" required>
                                        <option  value="1" selected>% &nbsp;</option>
                                        <option  value="2">RS &nbsp;</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="item">Net Total</label>
                        <div class="input-group ">
                            <div class="input-group-prepend">
                                <div class="input-group-text text-black-50">RS.</div>
                            </div>
                            <input class="form-control text-black-50"  type="number" id="net" readonly>
                        </div>
                    </div>
                </div>
                <hr/>
                <div class="row">
                    <div style="display: none" id="paidDueDiv" class="col-lg-12 col-md-12">
                        <h6>CASH PAYMENTS</h6>
                        <div class="form-group row">
                        <label class="col-md-3" for="paidDue">Paid Amount</label>
                        <div class="input-group mb-2 col-md-9">
                            <div class="input-group-prepend">
                                <div class="input-group-text">RS.</div>
                            </div>
                            <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="paid" name="paid">
                        </div>
                        </div>
                    </div>
                    <div style="display: none" id="visaBillDiv" class="col-lg-12 col-md-12">
                        <h6>CARD PAYMENTS</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="visaBill">Card No.</label>
                            <div class="col-md-9">
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="visaBill" name="visaBill">
                            </div>
                        </div>
                        <div class="form-group row" id="cardAmountDiv"  style="display: none;">
                            <label class="col-md-3" for="cardAmount">Card Amount.</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="cardAmount" name="cardAmount">
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="chequeDiv" class="col-lg-12 col-md-12">
                        <h6>CHEQUE PAYMENTS</h6>
                        <div class="row">
                            <div class="form-group col-md-6" id="chequeAmountDiv" >
                                <label for="chequeAmount">Cheque Amount</label>
                                <div class="input-group mb-2">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">RS.</div>
                                    </div>
                                    <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="chequeAmount" name="chequeAmount">
                                </div>
                            </div>
                            <div class="form-group col-md-6" >
                                <label  for="name">Bank Name</label>
                                <div >
                                    <select class="form-control select2" name="chequeBankName"
                                            id="chequeBankName" required>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label  for="chequeNo">Cheque No.</label>
                                <div>
                                    <input class="form-control "  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="chequeNo" name="chequeNo">
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="chequeDate">Cheque Date</label>
                                <div >
                                    <div class="input-group">
                                        <input type="text" class="form-control datepicker-autoclose'" placeholder="mm/dd/yyyy" id="chequeDate">
                                        <div class="input-group-append">
                                            <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                        </div>
                                    </div><!-- input-group -->
                                </div>
                            </div>
                            <div class="form-group col-md-2 mt-4 pt-1">
                                <button onclick="addChequeDetailsTemp()" class="btn">Add</button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-rep-plugin">
                                    <div class="table-responsive" data-pattern="priority-columns">
                                        <table class="table table-striped table-bordered"
                                               cellspacing="0"
                                               width="100%">
                                            <thead>
                                            <tr>
                                                <th>BANK NAME</th>
                                                <th>CHEQUE NO</th>
                                                <th>CHEQUE DATE</th>
                                                <th>AMOUNT</th>
                                                <th>DELETE</th>
                                            </tr>
                                            </thead>
                                            <tbody id="chequeDetailsTableData">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="bankDiv" class="col-lg-12 col-md-12">
                        <div class="row">
                            <div class="col-md-12">
                            <h6 >BANK PAYMENTS</h6>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bankName">Bank Name</label>
                                    <select class="form-control select2" name="bankName"
                                            id="bankName" >
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4" id="bankAmountDiv" >
                                <div class="form-group ">
                                    <label for="bankAmount">Amount</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">RS.</div>
                                        </div>
                                        <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="bankAmount" name="bankAmount">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group mt-4 pt-1">
                                    <button class="btn btn-secondary" onclick="addBankDetails(this)" >Add</button>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-rep-plugin">
                                            <div class="table-responsive" data-pattern="priority-columns">
                                                <table class="table table-striped table-bordered"
                                                       cellspacing="0"
                                                       width="100%">
                                                    <thead>
                                                    <tr>
                                                        <th>BANK NAME</th>
                                                        <th>AMOUNT</th>
                                                        <th>DELETE</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="bankDetailsTableData">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class = "col-md-12">
                        <button type="button" onclick="saveInvoice()"
                                class="btn btn-md btn-info waves-effect pull-right waves-light">
                            Save Invoice
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<iframe style="display: none;" id="iframeprint" src=""></iframe>
@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
        <script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>
<script type="text/javascript">

    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        jQuery('.datepicker-autoclose').datepicker({
            autoclose: true,
            todayHighlight: true
        });

        showTableData();
    });

    function addBankDetails(el) {
        $(el).attr('disabled',true);
        let bankName = $('#bankName').val();
        let amount = $('#bankAmount').val();
        // $('#bankDetailsTableData tr:last').after('<tr><td>'+bankName+'</td></tr>');
        $.ajax({
            type:'POST',

            url:'addBankDetailsTemp',

            data:{bankName:bankName,amount:amount},

            success:function(){
               loadBankPaymentstemp();
                $(el).attr('disabled',false);


            }
        });

    }

    function loadBankPaymentstemp() {
        $.ajax({
            type:'POST',

            url:'loadBankDetailsTemp',

            data:{},

            success:function(data){
                $('#bankDetailsTableData').html(data.tableData);
            }
        });

    }

    function addItem() {

        $('.notify').empty();
        $('#errorAlert').hide();
        $('#errorAlert').html("");

        if(calTotal()){

            let item = $("#item").val();
            let qty = $("#qty").val();
            let rate = $("#rate").val();
            let discount = $('#discount').val();

            $.post('addItemToInvoice',
            {       item: item,
                     qty: qty,
                    rate: rate,
                    discount: discount,
                },
                function (data) {
                    if (data.errors != null) {
                        $('#errorAlert').show();
                        $.each(data.errors, function (key, value) {
                            $('#errorAlert').append('<p>' + value + '</p>');
                        });
                    }
                    if (data.success != null) {

                        notify({
                            type: "warning", //alert | success | error | warning | info
                            title: 'SAVED',
                            autoHide: true, //true | false
                            delay: 2500, //number ms
                            position: {
                                x: "right",
                                y: "top"
                            },
                            icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                            message: 'Tempory item successfully added.'
                        });

                        showTableData();
                        setTimeout(function () {
                            $('#item').focus();
                        }, 100);
                    }
                });
        }
    }

    function showTableData() {
        $.ajax({
            type:'POST',

            url:'getInvoiceTemp',

            data:{},

            success:function(data){

                if(data.total == 0){
                  $('#saveBtn').hide();
                }
                else{
                    $('#saveBtn').show();
                }
                $('input').val("");
                $(".select2").val('').trigger('change');
                $('#tableData').html(data.tableData);
                $('#total').val((data.total).toFixed(2));
                $('#qty_mes').html('');
                $("#payment").val('1').trigger('change');
                $("#name").val('1').trigger('change');
                $("#datepicker-autoclose").datepicker().datepicker("setDate", new Date());
            }
        });

    }

    function deleteTempInvoice(ele) {
        let id = $(ele).attr("data-id");
        $.ajax({
            type:'POST',

            url:'deleteTempInvoice',

            data:{id:id},

            success:function(){

                $('#'+id).remove();

            }
        });

    }

    function paymentTypeChanged(el) {
    let payment = $(el).val();
        $('#paidDue').val('');
        $('#paidDueDiv').hide();
        $('#visaBill').val('');
        $('#visaBillDiv').hide();
        $('#bankName').val('');
        $('#bankDiv').hide();
        $('#chequeNo').val('');
        $('#chequeDate').val('');
        $('#chequeDiv').hide();
        $('#chequeAmount').val('');
        $('#chequeAmountDiv').hide();
        $('#bankAmount').val('');
        $('#bankAmountDiv').hide();
        $('#cardAmount').val('');
        $('#cardAmountDiv').hide();
        $('#discountDiv').show();

        $.ajax({
            type:'POST',

            url:'paymentTypeChangedDelete',

            data:{},

            success:function(){
               loadBankPaymentstemp();
               loadChequeDetailsTemp();
            }
        });

        if(payment == 2 || payment == 1){
            $('#paidDue').val('');
            $('#paidDueDiv').show();
        }
        if(payment == 4){
            $('#visaBill').val('');
            $('#visaBillDiv').show();
        }
        if(payment == 3){
            $.ajax({
                type:'POST',

                url:'getBankDetails',

                data:{},

                success:function(data){
                    $('#bankName').html(data);
                    $('#bankAmountDiv').show();
                    $('#bankAmount').val('');
                    $('#bankDiv').show();
                }
            });
        }
        if(payment == 5){
            $('#chequeNo').val('');
            $('#chequeDate').datepicker().datepicker("setDate", new Date());
            $.ajax({
                type:'POST',

                url:'getBankDetails',

                data:{},

                success:function(data){
                    $('#chequeBankName').html(data);
                    $('#chequeDiv').show();
                    $('#chequeAmountDiv').show();

                }
            });
        }
        if(payment == 6) {
            $('#paidDueDiv').show();
            $('#visaBillDiv').show();
            $('#bankDiv').show();
            $('#chequeDate').datepicker().datepicker("setDate", new Date());
            $('#chequeAmountDiv').show();
            $('#bankAmountDiv').show();
            $('#cardAmountDiv').show();
            $('#chequeDiv').show();
            $.ajax({
                type: 'POST',

                url: 'getBankDetails',

                data: {},

                success: function (data) {
                    $('#chequeBankName').html(data);
                    $('#bankName').html(data);
                }
            });
        }
        if(payment == 7) {
            $('.discountDiv').hide();
            $('#discount').val('0');

        }


    }

    function showSaveModal() {
        $('#paidDue').val('');
        $('#paidDueDiv').hide();
        $('#visaBill').val('');
        $('#visaBillDiv').hide();
        $('#bankName').val('');
        $('#bankDiv').hide();
        $('#chequeNo').val('');
        $('#chequeDate').val('');
        $('#chequeDiv').hide();
        $('#chequeAmount').val('');
        $('#chequeAmountDiv').hide();
        $('#bankAmount').val('');
        $('#bankAmountDiv').hide();
        $('#cardAmount').val('');
        $('#cardAmountDiv').hide();
        $('#payment').val('1').trigger('change');
        $('#totalAmount').val($('#total').val());
        $('#discountType').val('1').trigger('change');
        countNet();
        $('#saveInvoice').modal('show');
    }

    function saveInvoice() {
        $('#successAlert2').hide();
        $('#errorAlert').hide();
        $('#successAlert1').html("");
        $('#errorAlert2').html("");



        let orderNo = $("#orderNo").val();
        let payment = $("#payment").val();
        let name = $("#name").val();
        let date = $("#datepicker-autoclose").val();
        let paid = $("#paid").val();
        let visaBill = $("#visaBill").val();
        let bankId = $('#bankName').val();
        let chequeNo = $('#chequeNo').val();
        let chequeDate = $('#chequeDate').val();
        let chequeBankName = $('#chequeBankName').val();
        let chequeAmount = $('#chequeAmount').val();
        let bankAmount = $('#bankAmount').val();
        let cardAmount = $('#cardAmount').val();
        let disType = $('#discountType').val();
        let disInput = $('#discount').val();



        $.post('saveInvoice', {
            // company: company,
            orderNo: orderNo,
            disType: disType,
            disInput: disInput,
            payment: payment,
            name: name,
            paid: paid,
            date: date,
            visaBill: visaBill,
            bankId: bankId,
            chequeNo: chequeNo,
            chequeDate: chequeDate,
            chequeBankName: chequeBankName,
            chequeAmount: chequeAmount,
            bankAmount: bankAmount,
            cardAmount: cardAmount,
        }, function (data) {
            if (data.errors != null) {
                $('#errorAlert2').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlert2').append('<p>' + value + '</p>');
                });
            }
            if (data.success != null) {
                $('#successAlert2').show();
                $('#successAlert2').show().fadeOut(2000);
                $('#successAlert2').append('<p>' + data.success + '</p>');

                $('#saveInvoice').modal('hide');
                print(data.id);

                notify({
                    type: "warning", //alert | success | error | warning | info
                    title: 'SAVED',
                    autoHide: true, //true | false
                    delay: 2500, //number ms
                    position: {
                        x: "right",
                        y: "top"
                    },
                    icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                    message: 'Invoice saved successfully..'
                });

                showTableData();
            }
        });
    }

    $( document ).on( 'focus', ':input', function(){
        $( this ).attr( 'autocomplete', 'off' );
    });

    function print(id)
    {
        let _this = this,
            iframeId = 'iframeprint',
            $iframe = $('iframe#iframeprint');
        $iframe.attr('src', 'PrintInvoice/'+id);

        $iframe.load(function() {
            _this.callPrint(iframeId);
        });
    }

    //initiates print once content has been loaded into iframe
    function callPrint(iframeId) {
        let PDF = document.getElementById(iframeId);
        PDF.focus();
        PDF.contentWindow.print();
    }

    function availableItemCount(el) {
        $('#qty').val('');
        let item = el.value;
        $.ajax({
            type:'POST',

            url:'availableItemCount',

            data:{item:item},

            success:function(data){

                if(data.isScale){
                    $('#qty').attr('readonly',true);
                    $('#addBtn').attr('disabled',true);
                    $('#nonScales').hide();
                }
                else {
//                    $('.nonScale').show();
//                    $('.Scale').hide();
//
                    $('#qty').attr('readonly',false);
                    $('#addBtn').attr('disabled',false);
                    $('#nonScales').show();


                    $('#available').val(data.count);
                    $('#rate').val(data.rate);
                    $('#measurement').val(data.measurement);
                    $('#qty_mes').html(data.measurement);
                    $('#qty').focus();
                }


            }
        });
    }

    function calTotal() {
        let qty = parseFloat($('#qty').val());
        let rate = parseFloat($('#rate').val());
        let discount = parseFloat($('#discount').val()) || 0;
        let available = parseFloat($('#available').val());
        let pass = true;

        if(qty <= 0){
            $('#qty').val(0);
        }else {



            if (qty > available) {
                $('#qty_msg').html('Qty can not be grater than available qty.');
                $('#qty').val(available);
                qty = available;
                pass = false;

            }
            else {
                $('#qty_msg').html('');
            }

            if (discount > (qty * rate)) {
                $('#discount_msg').html('Discount can not be grater than total amount.');
                $('#discount').val(qty * rate);
                discount = qty * rate;
                pass = false;

            }
            else {
                $('#discount_msg').html('');
            }

            $('#ItemTotal').val((qty * rate) - discount);
            return pass;
        }
    }

    $('#qty').keypress(function(event){

        let keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            if ( $(this).val().length > 0) {
                addItem();
            }

        }
        event.stopPropagation();
    });

    $(document).on('keypress', function(e) {
        if ( e.ctrlKey && ( e.which === 98 ) ) {
            console.log( "You pressed CTRL + Del" );
        }
        let tag = e.target.tagName.toLowerCase();
        if ( e.which === 015 && tag != 'input' && tag != 'textarea' && tag != 'select') {
            $('#item').focus();
        }

        // if ( e.keyCode === 8  ) {
        //     alert('f10');
        //     // let total = $('#total').val();
        //     // if(total >0){
        //     //     showSaveModal();
        //     // }
        // }
    });

    function addChequeDetailsTemp(){
        let chequeNo = $('#chequeNo').val();
        let chequeAmount = $('#chequeAmount').val();
        let chequeDate = $('#chequeDate').val();
        let bankName = $('#chequeBankName').val();

        $.ajax({
            type:'POST',

            url:'addChequeDetailsTemp',

            data:{chequeDate:chequeDate,chequeAmount:chequeAmount,chequeNo:chequeNo,bankName:bankName},

            success:function(){
                loadChequeDetailsTemp();
            }
        });
    }

    function loadChequeDetailsTemp() {
        $.ajax({
            type:'POST',

            url:'loadChequeDetailsTemp',

            data:{},

            success:function(data){
                $('#chequeDetailsTableData').html(data.tableData);
            }
        });

    }

    function ChequePaymentTempDelete(el) {
        let id = $(el).attr('data-id');
        $.ajax({
            type:'POST',

            url:'ChequePaymentTempDelete',

            data:{id:id},

            success:function(data){
                $('#'+id).remove();
            }
        });

    }

    function BankPaymentsTempDelete(el) {
        let id = $(el).attr('data-id');
        $.ajax({
            type:'POST',

            url:'BankPaymentsTempDelete',

            data:{id:id},

            success:function(data){
                $('#'+id).remove();
            }
        });

    }

    function countNet() {

        let discoutInput =  parseFloat($('#discount').val());
        let total = parseFloat($('#totalAmount').val());
        let discountType = $("#discountType").val();
        if(discountType == 1){
            discount = parseFloat(total*(discoutInput/100));
            if(discoutInput>100){
                $('#discount').val(100);
            }

            let NewdiscountInput = parseFloat($('#discount').val());
            let Newtotal = parseFloat($('#totalAmount').val());
            Newdiscount = parseFloat(Newtotal*(NewdiscountInput/100));
            $('#net').val(parseFloat(Newtotal-Newdiscount).toFixed(2));
        }
        if(discountType == 2){
            discount = discoutInput;
            if(discount>total){
                $('#discount').val(parseFloat(total));
            }

            let Newdiscount = parseFloat($('#discount').val());
            let Newtotal = parseFloat($('#totalAmount').val());
            $('#net').val(parseFloat(Newtotal-Newdiscount).toFixed(2));
        }
    }

    $("#barcode").keyup(function (event) {
        if (event.keyCode == 13) {
            if ( $(this).val().length == 10  ) {
               let barcode = $(this).val();
               let itemcode = barcode.slice(0,5);
               let weight = barcode.slice(5,10);

               $.post('addBarcodeItemToInvoiceTemp',
                    {  item: itemcode,
                        qty: weight
                    },
                    function (data) {
                        $('#errorAlert').hide();
                        $('#successAlert').hide();
                        $('#errorAlert').html('');
                        $('#successAlert').html('');

                        if (data.errors != null) {
                            $('#errorAlert').show();
                            $.each(data.errors, function (key, value) {
                                $('#errorAlert').append('<p>' + value + '</p>');
                            });
                        }
                        if (data.success != null) {
                                    $('#successAlert').show();
                                    $('#successAlert').show().fadeOut(3000);
                                    $('#successAlert').append('<p>' + data.success + '</p>');

                                    showTableData();
                                    setTimeout(function () {
                                        $(this).focus();
                                    }, 100);
                        }
                    });


            }
            event.preventDefault();
            return false;
        }
    });

    $( "#barcode" ).focus(function() {
        $('#qty').attr('readonly',true);
        $('#addBtn').attr('disabled',true);
    });

    $( "#barcode" ).blur(function() {
        $('#qty').attr('readonly',false);
        $('#addBtn').attr('disabled',false);
        $(this).val('');
    });

</script>


@include('includes.footer_end')