@include('includes.header_start')

<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/validations.js')}}"></script>--}}
<script type="text/javascript" src="{{ URL::asset('assets/ajax/common.js')}}"></script>/
<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">


@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card m-b-20">
                    <div class="card-body">

                        <form action="{{route('POHistory')}}" method="GET">
                            <div class="row">
                                {{ csrf_field() }}

                                <div class="form-group col-md-2">
                                    <label for="grnId" class="form-label">PO No</label>
                                    <input class="form-control" oninput="this.value = Math.abs(this.value)" autocomplete="off" type="number" name="po"  id="po">
                                </div>

                                <div class="form-group  col-md-3">
                                    <label for="supplier">Supplier</label>
                                    <select class="form-control select2" name="supplier"
                                            id="supplier" >
                                        <option value="" disabled selected>Select a supplier
                                        </option>
                                        @if(isset($suppliers))
                                            @foreach($suppliers as $supplier)
                                                <option value="{{"$supplier->idSupplier"}}">{{"$supplier->companyName"}}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>

                                <div class="form-group col-md-4">
                                    <label>Date</label>
                                    <div>
                                        <div class="input-daterange input-group" id="date-range">
                                            <input type="text" autocomplete="off" class="form-control" value=""  id="startDate" name="start" />
                                            <input type="text" autocomplete="off" class="form-control" value=""  id="endDate" name="end" />
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group col-md-3">
                                    <button type="submit"  class="btn form-control btn-info waves-effect waves-light" style="margin-top: 25px">Search</button>
                                </div>

                            </div>
                        </form>


                        <br/>

                        <div class="row">

                            <div class="col-lg-12">
                                <div class="table-rep-plugin">
                                    <div class="table-responsive b-0" data-pattern="priority-columns">
                                        <table class="table table-striped table-bordered"
                                               cellspacing="0"
                                               width="100%">
                                            <thead>
                                            <tr>
                                                <th>PO NO</th>
                                                <th>SUPPLIER</th>
                                                <th style="text-align: right">TOTAL</th>
                                                <th>PAYMENT TYPE</th>
                                                <th>DATE</th>
                                                <th>LAST UPDATE</th>
                                                <th>OPTION</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @if(isset($orders) && count($orders)>0)
                                                @foreach($orders as $order)
                                                    <tr id="{{$order->idPO}}" >

                                                        <td>{{str_pad($order->poNo,5,'0',STR_PAD_LEFT)}}</td>
                                                        <td>{{$order->supplier->companyName}}</td>
                                                        <td style="text-align: right">{{number_format($order->total,2)}}</td>
                                                        <td>{{$order->payment->type}}</td>
                                                        <td>{{$order->date}}</td>
                                                        <td>{{$order->updated_at}}</td>
                                                        <td>
                                                            <div class="dropdown">
                                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    Option
                                                                </button>
                                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                                                                    <a href="#" onclick='viewPurchaseReg({{$order->idPO}})' class="dropdown-item">View Items</i>
                                                                    </a>
                                                                    <a href="#" onclick='addToGrn({{$order->idPO}})' class="dropdown-item">Add to GRN</i>
                                                                    </a>
                                                                    <a href="#" onclick='deletePO({{$order->idPO}})' class="dropdown-item">Delete</i>
                                                                    </a>

                                                                </div>

                                                            </div>
                                                        </td>
                                                    </tr>

                                                @endforeach
                                                @else
                                                <tr><td style="text-align: center;" colspan="7">No Records.</td> </tr>
                                            @endif
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @if(isset($orders))
                            {{$orders->links()}}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


{{--save GRN moal--}}
<div class="modal fade" id="regModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Purchase Order Items</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">


                <div class="row">
                    <div class="col-md-12">

                        <table class="table table-striped table-bordered"
                               cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>ITEM</th>
                                <th>QTY</th>
                                <th style="text-align: right">BUYING PRICE</th>
                            </tr>
                            </thead>
                            <tbody id="modalTableData">
                            </tbody>
                        </table>

                    </div>
                </div>


            </div>
        </div>
    </div>
</div>


{{--save GRN moal--}}
<div class="modal fade" id="addGrnModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Add To GRN</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert" style="display:none">

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="stock">Store</label>
                            <select class="form-control select2 tab"  name="store"
                                    id="store" required>
                                <option value="" disabled selected>Select Store
                                </option>
                                @if(isset($stockTypes))
                                    @foreach($stockTypes as $stockType)
                                        <option value="{{"$stockType->idStore"}}">{{$stockType->type}} </option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-12">
                        <div class="form-group ">
                            <label for="binNo">Bin No</label>
                            <input type="number" class="form-control tab" name="binNo" id="binNo" min="0" oninput="this.value = Math.abs(this.value)"
                                   placeholder="Bin No"/>
                            <small class="text-danger">{{ $errors->first('binNo') }}</small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                            <div class="form-group">

                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input doNotClear tab"  id="defaultChecked2"
                                           onclick="expDate()">
                                    <label class="custom-control-label" for="defaultChecked2">Expire Date</label>
                                </div>
                                <div style="margin-top: 5px" class="hideExpDate" id="hideExpDate">
                                </div>
                                <small class="text-danger">{{ $errors->first('eDate') }}</small>
                            </div>
                    </div>
                </div>
                <input type="hidden" id="hiddenIdG">
                <div class="row pull-right">
                    <div class="col-md-12 col-md-12">
                        <button type="button" onclick="saveToGrn()"
                                class="btn btn-md btn-primary waves-effect waves-light">
                            Add to GRN
                        </button>
                    </div>
                </div>

                </div>

            </div>
        </div>
    </div>
@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>

<script type="text/javascript">


    $(document).ready(function () {
//        $('form').parsley();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });



    });

    $('.modal').on('hidden.bs.modal', function () {

        $('input').val('').prop('checked',false);
        $('select').val('').trigger('change');
        expDate();
    });

    function expDate() {
        if($('#defaultChecked2').prop("checked"))
        {
            var date = '';
            date += "<div  >\n" +
                "      <div class=\"input-group\">\n" +
                "                                        <input type=\"text\" class=\"form-control datepicker-autoclose tab\"  placeholder=\"mm/dd/yyyy\"  name=\"eDate\" id=\"eDate\">\n" +
                "                                        <div class=\"input-group-append\">\n" +
                "                                            <span class=\"input-group-text\"><em class=\"mdi mdi-calendar\"></em></span>\n" +
                "                                        </div>\n" +
                "       </div>\n" +
                "     </div>";

            $("#hideExpDate").html(date);
            initializeDate();
        }
        else{
            $("#hideExpDate").html("");
        }

    }
    function initializeDate() {
        jQuery('.datepicker-autoclose').datepicker({
            autoclose: true,
            todayHighlight: true
        });

    }

    function viewPurchaseReg(id) {
        $.ajax({
            type:'POST',

            url:'viewPurchaseReg',

            data:{id:id},

            success:function(data){
              $('#modalTableData').html(data);
              $('#regModal').modal('show');
            }
        });
    }

    function addToGrn(id) {
        $('#hiddenIdG').val(id);
        $('#addGrnModal').modal('show');
    }

    function saveToGrn() {
       let id =  $('#hiddenIdG').val();
       let bin =  $('#binNo').val();
       let store =  $('#store').val();
       let exp =  $('#eDate').val();
       $('.alert').html('');
       $('.alert').hide();

        $.ajax({

            type: 'POST',

            url: " {{ route('poTransferToGrn') }}",

            data: {id:id,bin:bin,store:store,exp:exp},

            success: function (data) {
                if (data.errors != null) {
                    $('#errorAlert').show();
                    $.each(data.errors, function (key, value) {
                        $('#errorAlert').append('<p>' + value + '</p>');
                    });
                    $('html, body').animate({
                        scrollTop: $("#errorAlert").offset().top
                    }, 1000);
                }
                if (data.success != null) {
                    {{--notify({--}}
                        {{--type: "success", //alert | success | error | warning | info--}}
                        {{--title: 'ORDER TRANSFERRED',--}}
                        {{--autoHide: true, //true | false--}}
                        {{--delay: 2500, //number ms--}}
                        {{--position: {--}}
                            {{--x: "right",--}}
                            {{--y: "top"--}}
                        {{--},--}}
                        {{--icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',--}}

                        {{--message: 'Order transferred to GRN Successfully.'--}}
                    {{--});--}}
//                    $('#addGrnModal').modal('hide');
                    window.location.href = "{{route('grn_management')}}";

//                    showTableData();
                }

            }
        })
    }

    function deletePO(id) {
        swal({
            title: 'Do you want to delete this order?',
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Delete!',
            cancelButtonText: 'Cancel!',
            confirmButtonClass: 'btn btn-danger waves-effect m-l-10',
            cancelButtonClass: 'btn btn-success waves-effect m-l-10',
            buttonsStyling: false
        }).then(function () {
            $.ajax({

                type: 'POST',

                url: " {{ route('deletePO') }}",

                data: {id:id},

                success: function () {
                    $('#'+id).remove();
                }
            })


        }), function () {
            // dismiss can be 'cancel', 'overlay',
            // 'close', and 'timer'
        }
    }

</script>


@include('includes.footer_end')