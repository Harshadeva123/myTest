@include('includes.header_start')

<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet')}}" type="text/css"/>
<!-- Responsive datatable examples -->

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">

<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">


@include('includes.header_end')


<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">


    <div class="container-fluid">
        <div class="row">
        </div>
        {{csrf_field()}}
        <div class="row">

            <div class="col-lg-6">
                <div class="card m-b-20">
                    <div class="card-body">
                        <div class="row">

                            <div class="col-md-12">
                                <div class="alert alert-danger alert-dismissible " id="errorAlert" style="display:none">

                                </div>
                            </div>
                        </div>

                        <h5>Personal Details</h5>
                        <div class="form-group">
                            <label for="client_name">Title</label>
                            <div class="panel-body">
                                <select class="form-control" id="cTitle" name="cTitle">
                                    <option value="" disabled selected>Select Title</option>
                                    <option value="Mr.">Mr.</option>
                                    <option value="Miss.">Miss.</option>
                                    <option value="Mrs.">Mrs.</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">First Name</label>
                            <div class="panel-body"><input type="text" class="form-control" name="cfName"
                                                           maxlength="255"
                                                           id="cfName" placeholder="First Name" required/>
                                <small class="text-danger">{{ $errors->first('cfName') }}</small>
                            </div>
                            <input type="hidden" name="_token" value="{{ Session::token() }}">
                            <input type="hidden" name="hiddenCID" id="hiddenCID">
                        </div>
                        <div class="form-group">
                            <label for="client_surname">Last Name</label>
                            <div class="panel-body"><input type="text" class="form-control" name="clName"
                                                           maxlength="255"
                                                           id="clName" placeholder="Last Name" required/>
                                <small class="text-danger">{{ $errors->first('clName') }}</small>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Gender</label>

                            <select class="form-control" name="cGender" id="cGender">
                                <option value="" disabled selected>Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>

                            </select>

                        </div>
                        <div class="form-group">
                            <label for="client_surname">Birth Day</label>
                            <div class="panel-body"><input type="date" class="form-control" name="cBirthDay"
                                                           id="cBirthDay" placeholder="Last Name" required/>
                                <small class="text-danger">{{ $errors->first('cBirthDay') }}</small>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="card m-b-20">
                    <div class="card-body">
                        <div class="form-group">
                            <h5>Tax Information</h5>
                            <label for="client_name">Vat ID</label>
                            <input type="number" name="cVAtId" id="cVAtId" class="form-control"  oninput="this.value = Math.abs(this.value)"
                                   placeholder="Vat ID"/>
                            <small class="text-danger">{{ $errors->first('cVAtId') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">Tax Code</label>
                            <input type="text" name="cTaxesCode" id="cTaxesCode" class="form-control"  oninput="this.value = Math.abs(this.value)"
                                   placeholder="Tax Code "/>
                            <small class="text-danger">{{ $errors->first('cTaxesCode') }}</small>
                        </div>


                        <div class="form-group">
                            <label for="client_surname">Credit Limit</label>
                            <input type="number" name="creditLimit" id="creditLimit" class="form-control"  oninput="this.value = Math.abs(this.value)"
                                   placeholder="Credit Limit"/>
                            <small class="text-danger">{{ $errors->first('creditLimit') }}</small>
                        </div>

                        <div class="form-group">
                            <label for="client_surname">Balance</label>
                            <input type="number" name="balance" id="balance" class="form-control"  oninput="this.value = Math.abs(this.value)"
                                   placeholder="Balance"/>
                            <small class="text-danger">{{ $errors->first('balance') }}</small>
                        </div>



                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card m-b-20">
                    <div class="card-body">
                        <h5>Contact Information</h5>
                        <div class="form-group">
                            <label for="client_name">Contact No 1</label>
                            <input type="number" name="cNumber" id="cNumber"
                                   oninput="this.value = Math.abs(this.value)" class="form-control" maxlength="15"
                                   placeholder="Contact No 1" required/>
                            <small class="text-danger">{{ $errors->first('cNumber') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">Contact No 2</label>
                            <input type="number" name="cNumber2" oninput="this.value = Math.abs(this.value)"
                                   maxlength="15"
                                   id="cNumber2" class="form-control"
                                   placeholder="Contact No 2"/>
                            <small class="text-danger">{{ $errors->first('cNumber2') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">Email</label>
                            <input type="email" class="form-control" name="cEmail" id="cEmail" maxlength="255"
                                   placeholder="Eg:abc@gmail.com"/>
                            <small class="text-danger">{{ $errors->first('cEmail') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">Website</label>
                            <input type="text" class="form-control" name="cWebsite" id="cWebsite" maxlength="255"
                                   placeholder="www.abc.com"/>
                            <small class="text-danger">{{ $errors->first('cWebsite') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_name">Street Address</label>
                            <input type="text" name="cAddress1" id="cAddress1" class="form-control" maxlength="255"
                                   placeholder="Street Address" required/>
                            <small class="text-danger">{{ $errors->first('cAddress1') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">Street Address 2</label>
                            <input type="text" name="cAddress2" id="cAddress2" class="form-control" maxlength="255"
                                   placeholder="Street Address 2"/>
                            <small class="text-danger">{{ $errors->first('cAddress2') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">City</label>
                            <input type="text" class="form-control" name="cCity" id="cCity" maxlength="45" placeholder="City"/>
                            <small class="text-danger">{{ $errors->first('cCity') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">State</label>
                            <input type="text" class="form-control" name="cState" maxlength="45" id="cState" placeholder="State"/>
                            <small class="text-danger">{{ $errors->first('cState') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">Zip Code/Postal Code </label>
                            <input type="text" class="form-control" oninput="this.value = Math.abs(this.value)"
                                   value="0" name="cZipCode" id="cZipCode" maxlength="45"
                                   placeholder="Zip Code/Postal Code"/>
                            <small class="text-danger">{{ $errors->first('cZipCode') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="client_surname">Fax</label>
                            <input type="number" class="form-control" oninput="this.value = Math.abs(this.value)"
                                   maxlength="25"   value="0" name="cFax" id="cFax" placeholder="Fax"/>
                            <small class="text-danger">{{ $errors->first('cFax') }}</small>
                        </div>

                    </div>

                </div>

            </div>
            <div class="col-lg-12">
                <div class="card m-b-20">
                    <div class="card-body">
                        <div class="form-group">
                            <div>
                                <button type="submit" id="" onclick="saveCustomer()"
                                        class="btn btn-primary waves-effect waves-light">
                                    Add Customer
                                </button>
                                <button type="reset" onclick="clearAll()" class="btn btn-danger waves-effect m-l-5">
                                    Reset All
                                </button>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!--Modal End-->


@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}" type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
{{--<script src="{{ URL::asset('assets/home_assets/js/dashboard_js.js')}}"></script>--}}
<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>
<script type="text/javascript">
    $(document).ready(function () {
//        $('form').parsley();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    function saveCustomer() {

        $('.notify').empty();
        $('#errorAlert').hide();
        $('#errorAlert').html("");

        var cTitle = $("#cTitle").val();
        var cfName = $("#cfName").val();
        var clName = $("#clName").val();
        var cGender = $("#cGender").val();
        var cBirthDay = $("#cBirthDay").val();
        var cVAtId = $("#cVAtId").val();
        var cTaxesCode = $("#cTaxesCode").val();
        var cNumber = $("#cNumber").val();
        var cNumber2 = $("#cNumber2").val();
        var cEmail = $("#cEmail").val();
        var cWebsite = $("#cWebsite").val();
        var cAddress1 = $("#cAddress1").val();
        var cAddress2 = $("#cAddress2").val();
        var cState = $("#cState").val();
        var cZipCode = $("#cZipCode").val();
        var cFax = $("#cFax").val();
        var cCity = $("#cCity").val();
        var creditLimit = $("#creditLimit").val();
        var balance = $("#balance").val();

        $.post('saveCustomer', {
            cTitle: cTitle,
            cfName: cfName,
            clName: clName,
            cGender: cGender,
            cBirthDay: cBirthDay,
            cVAtId: cVAtId,
            cTaxesCode: cTaxesCode,
            cNumber: cNumber,
            cNumber2: cNumber2,
            cEmail: cEmail,
            cWebsite: cWebsite,
            cAddress1: cAddress1,
            cAddress2: cAddress2,
            cState: cState,
            cZipCode: cZipCode,
            cFax: cFax,
            creditLimit: creditLimit,
            balance: balance,
            cCity: cCity

        }, function (data) {
            if (data.errors != null) {
                $('#errorAlert').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlert').append('<p>' + value + '</p>');
                });
                $('html, body').animate({
                    scrollTop: $("#errorAlert").offset().top - 100
                }, 1000);
            }
            if (data.success != null) {

               $('input').val('');
                $('select').val('');
                notify({
                    type: "success", //alert | success | error | warning | info
                    title: 'CUSTOMER SAVED',
                    autoHide: true, //true | false
                    delay: 2500, //number ms
                    position: {
                        x: "right",
                        y: "top"
                    },
                    icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                    message:'Customer saved successfully.'
                });

            }
        });

    }

    function clearAll() {
        $('input').val('');
        $('select').val('');
    }

    $( document ).on( 'focus', ':input', function(){
        $( this ).attr( 'autocomplete', 'off' );
    });


    $(document).on("wheel", "input[type=number]", function (e) {
        $(this).blur();
    });

</script>


@include('includes.footer_end')