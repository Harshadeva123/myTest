@include('includes.header_start')


<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
{{--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css')}}"--}}
{{--integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">--}}
<meta name="csrf-token" content="{{ csrf_token() }}"/>
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/validations.js')}}"></script>--}}
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/common.js')}}"></script>--}}

<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">
@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card m-b-20">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="alert alert-info alert-dismissible " id="successAlert" style="display:none">

                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="alert alert-success alert-dismissible " id="successAlert1" style="display:none">

                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="alert alert-danger alert-dismissible " id="errorAlert" style="display:none">

                                        </div>
                                    </div>
                                </div>

                                <div class="row">

                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <label for="store">Section Name</label>
                                            <select  class="form-control select2 notClear" name="section" onchange="$(this).attr('disabled',true)"
                                                     id="section" required>
                                                <option value="" disabled selected> Select section </option>
                                                @if(isset($sections))
                                                    @foreach($sections as $section)
                                                        <option value="{{"$section->idSection"}}">{{$section->sectionName}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <label for="item">Product Name</label>
                                            <select onchange="itemChanged(this.value)" class="form-control select2 notChangeOnAdd" name="item"
                                                    id="item" required>
                                                <option value="" disabled selected>Select product
                                                </option>
                                                @if(isset($products))
                                                    @foreach($products as $item)
                                                        <option value="{{"$item->idItems"}}">{{$item->itemcode}} - {{"$item->itemName"}}</option>
                                                    @endforeach
                                                @endif


                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="qty">Qty</label>
                                            <div class="input-group mb-2">
                                                <input type="number" class="form-control" data-available="0" name="qty" id="qty" min="0"
                                                       placeholder="0.00"/>
                                                <div class="input-group-prepend">
                                                    <div id="measurement" class="input-group-text"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <small id="qtyMsg" class="text-danger">{{ $errors->first('qty') }}</small>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Manufacture Date</label>
                                            <div>
                                                <div class="input-group">
                                                    <input type="text" class="form-control datepicker-autoclose tab" placeholder="mm/dd/yyyy" name="mFDate" id="mFDate">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                                    </div>
                                                </div><!-- input-group -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">

                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input doNotClear tab"  id="defaultChecked2"
                                                       onclick="expDate()">
                                                <label class="custom-control-label" for="defaultChecked2">Expire Date</label>
                                            </div>
                                            <div style="margin-top: 5px" class="hideExpDate" id="hideExpDate">
                                            </div>
                                            <small class="text-danger">{{ $errors->first('eDate') }}</small>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <label for="store">Store Name</label>
                                            <select  class="form-control select2 notClear " name="store"
                                                     id="store" required>
                                                @if(isset($stores))
                                                    @foreach($stores as $store)
                                                        @if($loop->first)
                                                            <option selected value="{{"$store->idStock_Type"}}">{{$store->type}}</option>
                                                        @else
                                                            <option value="{{"$store->idStock_Type"}}">{{$store->type}}</option>
                                                        @endif
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-2 " >
                                        <div class="col-lg-2 " >
                                            <button  type="button" onclick="addItem(this)"
                                                     class="btn btn-md btn-info waves-effect waves-light " style="margin-top: 25px">
                                                Add Item
                                            </button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    </div>
                </div>

            </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card m-b-20">
                    <div class="card-body">
                        <div class="table-responsive b-0" data-pattern="priority-columns">

                            <table class="table table-striped table-bordered" >
                                <thead>
                                <tr>
                                    <th>PRODUCT NAME</th>
                                    <th>QTY</th>
                                    <th>STORE NAME</th>
                                    <th>SECTION NAME</th>
                                    <th>MNF DATE</th>
                                    <th>EXP DATE</th>
                                    <th>DELETE</th>
                                </tr>
                                </thead>
                                <tbody id="tableData">

                                </tbody>
                            </table>

                        </div>
                        <div class="row pull-right">
                            <div class="col-lg-2">
                                <button  type="button" onclick="save(this)"
                                         class="btn btn-success waves-effect waves-light " style="margin-top: 25px">
                                    Save
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
{{--<script src="{{ URL::asset('assets/home_assets/js/dashboard_js.js')}}"></script>--}}

<script type="text/javascript">

    $(document).ready(function () {
        // $('form').parsley();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        initializeDate();
        deleteAll();
        $('#store').attr('diabled',false);
    });

    function deleteAll() {
        $.ajax({


            type: 'POST',

            url: 'deleteProductionOutAll',

            success: function () {

                showTableData();

            }
        });
    }

    function addItem(el) {
        $(el).attr('disabled',true);
        $('#successAlert').hide();
        $('#errorAlert').hide();
        $('#successAlert').html("");
        $('#errorAlert').html("");
        $('#qtyMsg').html("");

        let item = parseFloat($("#item").val());
        let qty = parseFloat($("#qty").val());
        let store = $("#store").val();
        let section = $("#section").val();
        let eDate = $("#eDate").val() ;
        let mFDate = $("#mFDate").val();
        let eHave = $("#defaultChecked2").is(':checked');

        let pass = true;
        if(qty == 0 || !qty){
            pass = false;
            $('#qtyMsg').html('Qty must be gather than 0.');
            $(el).attr('disabled',false);
        }

        if(pass) {
            $.post('addItemProductionOutputTemp',
                {
                    item: item,
                    qty: qty,
                    store: store,
                    mFDate: mFDate,
                    eDate: eDate,
                    eHave: eHave,
                    section: section,
                },
                function (data) {
                    $(el).attr('disabled', false);
                    if (data.errors != null) {
                        $('#errorAlert').show();
                        $.each(data.errors, function (key, value) {
                            $('#errorAlert').append('<p>' + value + '</p>');
                        });
                    }
                    if (data.success != null) {
                        $('#successAlert').show();
                        $('#successAlert').show().fadeOut(3000);
                        $('#successAlert').append('<p>' + data.success + '</p>');
                        $(".select2").not('.notClear').val('').trigger('change');
                        $("input").val('');
                        $("input").attr('checked',false);
                        $(".expDateDiv").hide();

                        showTableData();
                    }

                });
        }
    }

    function getItemMeasurement(id) {
        if(id) {
            $('#expected').val('');
            $.ajax({


                type: 'POST',

                url: 'getItemMeasurement',

                data: {id: id},

                success: function (data) {

                    $('#expectedMeasuremet').val(data.measurement);

                }
            });
        }
    }

    function deleteTempItem(ele) {
        $.ajax({
            type:'POST',

            url:'deleteTempProductionOut',

            data:{id:ele},

            success:function(){

                $('#'+ele).remove();

            }
        });

    }

    function expDate() {
        if($('#defaultChecked2').prop("checked"))
        {
            var date = '';
            date += "<div  >\n" +
                "      <div class=\"input-group expDateDiv\">\n" +
                "                                        <input type=\"text\" class=\"form-control datepicker-autoclose tab\"  placeholder=\"mm/dd/yyyy\"  name=\"eDate\" id=\"eDate\">\n" +
                "                                        <div class=\"input-group-append\">\n" +
                "                                            <span class=\"input-group-text\"><em class=\"mdi mdi-calendar\"></em></span>\n" +
                "                                        </div>\n" +
                "       </div>\n" +
                "     </div>";

            $("#hideExpDate").html(date);
            initializeDate();
        }
        else{
            $("#hideExpDate").html("");
        }

    }
    function initializeDate() {
        jQuery('.datepicker-autoclose').datepicker({
            autoclose: true,
            todayHighlight: true
        });

    }

    function showTableData() {
        $.ajax({
            type:'POST',

            url:'getProductionOutTemp',

            data:{},

            success:function(data){
                $('#tableData').html(data);
            }
        });

    }


    function save() {
        $('#successAlert1').hide();
        $('#successAlert').hide();
        $('#errorAlert').hide();
        $('#errorAlert').html("");
        $('#successAlert1').html("");
        $('#errorAlert').html("");
        $('#qtyMsg').html("");

        $.post('saveProductionOutput',
            function (data) {
            if (data.errors != null) {
                $('#errorAlert').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlert').append('<p>' + value + '</p>');
                });
            }
            if (data.success != null) {
                $(".select2").val('').trigger('change');
                $("input").val('');
                $("input").attr('checked',false);
                $(".select2").attr('disabled',false);
                $(".expDateDiv").hide();
                $("#store").val($("#store option:first").val()).trigger('change');

                swal({
                    title: 'Saved!',
                    text: 'Material issued successfully.',
                    type: "success"

                }).then(function () {

                });
            }
            showTableData();
        });
    }


    function itemChanged(id) {

        $.ajax({
            type: 'POST',

            url: 'getItemMeasurement',

            data: {id: id},

            success: function (data) {
                $('#measurement').html(data.measurement);
            }
        });

    }


</script>


@include('includes.footer_end')