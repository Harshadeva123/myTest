@include('includes.header_start')

<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
      type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}"
      rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">

<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">


@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="col-lg-12">
            <div class="card m-b-20">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">


                            <form action="{{ route('category') }}" method="GET">
                                {{csrf_field()}}

                                <div class="input-group">

                                    <input type="search" name="search" id="search" class="form-control"
                                           placeholder="Search Category">
                                    <span class="input-group-append">
                                        <button class="btn btn-info btn-block" type="submit"><i
                                                    class="fa fa-search"></i> Search
                                        </button>
                                    </span>

                                </div>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <button type="button"
                                        class="btn btn-md btn-primary  waves-effect waves-light float-right"
                                        data-toggle="modal" data-target="#myModal1">Add New Category
                                </button>

                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="table-rep-plugin">
                        <div class="table-responsive b-0" data-pattern="priority-columns">
                            <table class="table table-striped table-bordered" id="mainCat"
                                   cellspacing="0"
                                   width="100%">
                                <thead>
                                <tr>
                                    <th>CATEGORY</th>
                                    <th>USER</th>
                                    <th>CREATED AT</th>
                                    <th>LAST UPDATED</th>
                                    <th>STATUS</th>
                                    <th>EDIT</th>
                                </tr>
                                </thead>

                                <tbody class="content">
                                @if(isset($categories))
                                    @if(count($categories) === 0)
                                        <tr class="no-result-td">
                                            <td colspan="6" style="text-align: center"><b>Sorry No results Found.</b>
                                            </td>
                                        </tr>
                                    @endif
                                    @foreach($categories as $category)
                                        <tr>
                                            <td>{{$category->catName}}</td>
                                            <td>{{$category->User->fName}}</td>
                                            <td>{{$category->created_at}}</td>
                                            <td>{{$category->updated_at}}</td>
                                            @if($category->status == 1)

                                                <td>
                                                    <p>
                                                        <input type="checkbox"
                                                               onchange="adMethod('{{ $category->idItem_Category}}')"
                                                               id="{{"c".$category->idItem_Category}}" checked
                                                               switch="none"/>
                                                        <label for="{{"c".$category->idItem_Category}}"
                                                               data-on-label="On"
                                                               data-off-label="Off"></label>
                                                    </p>
                                                </td>
                                            @else
                                                <td>
                                                    <p>
                                                        <input type="checkbox"
                                                               onchange="adMethod('{{ $category->idItem_Category}}')"
                                                               id="{{"c".$category->idItem_Category}}"
                                                               switch="none"/>
                                                        <label for="{{"c".$category->idItem_Category}}"
                                                               data-on-label="On"
                                                               data-off-label="Off"></label>
                                                    </p>
                                                </td>
                                            @endif
                                            <td>
                                                <p>
                                                    <button type="button"
                                                            class="btn btn-sm btn-warning  waves-effect waves-light"
                                                            data-toggle="modal"
                                                            data-name="{{ $category->catName }}"
                                                            data-id="{{ $category->idItem_Category }}"
                                                            id="mainCategoryId"
                                                            data-target="#mainCatUpdate"><i class="fa fa-edit"></i>
                                                    </button>
                                                </p>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                                </tbody>
                            </table>
                            <div>
                                {{$categories->links()}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- container -->

</div> <!-- Page content Wrapper -->

<!--Modal Start-->
<div class="modal fade" id="myModal1" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Add Category</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <div class="row">


                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlertAdd"
                             style="display:none">

                        </div>
                    </div>
                </div>

                <input type="hidden" name="hiddenMCID" id="hiddenMCID">
                <div class="form-group">
                    <label>Category Name</label>
                    <input type="text" class="form-control" maxlength="25"
                           name="categoryName" id="categoryName" required
                           placeholder="Category Name"/>
                    <small class="text-danger">{{ $errors->first('cName') }}</small>
                </div>

                <input type="hidden" name="_token" value="{{ Session::token() }}">

                <div class="form-group">
                    <div>
                        <button type="submit" onclick="addCategory()"
                                class="btn btn-primary btn-md waves-effect waves-light">
                            Add Category
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- /.modal -->
<!--update modal-->
<div class="modal fade" id="mainCatUpdate" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Edit Category</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <div class="row">

                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible" id="errorAlertUpdate"
                             style="display:none">

                        </div>
                    </div>
                </div>
                <input type="hidden" name="mainCatID" id="mainCatID">
                <div class="form-group">
                    <label>Category Name</label>
                    <input type="text" class="form-control" maxlength="25"
                           name="uCategoryName" id="uCategoryName" required
                           placeholder="Category Name"/>
                    <small class="text-danger">{{ $errors->first('uCategoryName') }}</small>
                </div>
                <input type="hidden" name="_token" value="{{ Session::token() }}">

                <div class="form-group">
                    <div>
                        <button type="submit" onclick="updateMainCategory()"
                                class="btn btn-warning btn-md waves-effect waves-light">
                            Update Category
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div> <!-- content -->

@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}"
        type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}"
        type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>

<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>

<script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>

<script type="text/javascript">

    $(document).ready(function () {
//        $('form').parsley();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

    });

    $(document).on('focus', ':input', function () {
        $(this).attr('autocomplete', 'off');
    });

    function adMethod(dataID) {

        $.post('changeCategoryStatus', {id: dataID}, function () {

        });
    }

    $('.modal').on('hidden.bs.modal', function () {

        $('.alert').hide();
        $('.alert').html('');

        $('input').val('');
        $('#title').val('');

    });

    function addCategory() {
        $('.notify').empty();
        $('.alert').hide();
        $('.alert').html('');


        var categoryName = $("#categoryName").val();

        $.post('saveMainCategory', {
            categoryName: categoryName,

        }, function (data) {
            if (data.errors != null) {
                $('#errorAlertAdd').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlertAdd').append('<p>' + value + '</p>');
                });
                $('html, body').animate({
                    scrollTop: $("#errorAlertAdd").offset().top
                }, 1000);
            }
            if (data.success != null) {


                notify({
                    type: "success", //alert | success | error | warning | info
                    title: 'CATEGORY SAVED',
                    autoHide: true, //true | false
                    delay: 2500, //number ms
                    position: {
                        x: "right",
                        y: "top"
                    },
                    icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                    message: 'Category saved successfully.'
                });

                $("#categoryName").val("");

                $('#myModal1').modal('hide');
            }
            $('tbody').html(data.tableData);

        });

    }


    $(document).on('click', '#mainCategoryId', function () {
        $("#mainCatID").val($(this).data("id"));
        $("#uCategoryName").val($(this).data("name"));
        $('#mainCatUpdate').modal('show');
    });


    $('.modal').on('hidden.bs.modal', function () {
        $("#uItemType").val('').trigger('change');
        $('input').val('');
        $('.alert').hide();
        $('.alert').html('');

    });


    function updateMainCategory() {

        $('.notify').empty();
        $('.alert').hide();
        $('.alert').html('');

        var mainCatID = $("#mainCatID").val();
        var uCategoryName = $("#uCategoryName").val();


        $.post('mainCatUpdate', {
            mainCatID: mainCatID,
            uCategoryName: uCategoryName,

        }, function (data) {
            if (data.errors != null) {
                $.each(data.errors, function (key, value) {
                    $('#errorAlertUpdate').show();
                    $.each(data.errors, function (key, value) {
                        $('#errorAlertUpdate').append('<p>' + value + '</p>');
                    });
                });
                $('html, body').animate({
                    scrollTop: $("#errorAlertUpdate").offset().top
                }, 1000);
            }
            if (data.success != null) {
                notify({
                    type: "success", //alert | success | error | warning | info
                    title: 'CATEGORY UPDATED',
                    autoHide: true, //true | false
                    delay: 2500, //number ms
                    position: {
                        x: "right",
                        y: "top"
                    },
                    icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                    message: 'Category updated successfully.'
                });


                $("#uCategoryName").val("");
                $('#mainCatUpdate').modal('hide');
            }
            $('tbody').html(data.tableData);
        });
    }

</script>
@include('includes.footer_end')