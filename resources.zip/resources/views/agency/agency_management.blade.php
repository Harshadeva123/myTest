@include('includes.header_start')

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
{{--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css')}}"--}}
      {{--integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">--}}
<meta name="csrf-token" content="{{ csrf_token() }}"/>
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/validations.js')}}"></script>--}}
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/common.js')}}"></script>--}}
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">


@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->
<div class="page-content-wrapper">

    <div class="container-fluid">

        <div class="col-lg-12">
            <div class="card m-b-20">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <form action="{{ route('searchAgency') }}" method="GET">
                                {{csrf_field()}}
                                <div class="input-group">
                                    <input type="search" name="search" id="search" class="form-control"
                                           placeholder="Search Agency Here">
                                    <span class="input-group-append">
                                      <button class="btn btn-primary btn-block" type="submit"><i
                                                  class="fa fa-search"></i> Search</button>
                                        </span>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-6">
                            <button type="button"
                                    class="btn btn-md btn-info pull-right waves-effect waves-light" data-toggle="modal"
                                    data-target="#addCompany">Add Agency
                            </button>
                        </div>
                    </div>
                    <br>
                    <div class="table-rep-plugin">
                        <div class="table-responsive b-0" data-pattern="priority-columns">
                            <table id="datatable-buttons" class="table table-striped table-bordered"
                                   cellspacing="0"
                                   width="100%">
                                <thead>
                                <tr>
                                    <th>AGENCY NAME</th>
{{--                                    <th>REG NO</th>--}}
{{--                                    <th>ADDRESS</th>--}}
                                    <th>CITY</th>
                                    <th>EMAIL</th>
                                    <th>PHONE NO</th>
                                    <th>COMMISION (%)</th>
                                    <th>STATUS</th>
                                    <th>UPDATE</th>
                                </tr>
                                </thead>
                                <tbody>
                                @if(isset($viewAllAgencies))
                                    @if(count($viewAllAgencies) === 0)
                                        <tr class="no-result-td">
                                            <td colspan="8" style="text-align: center">No records.
                                            </td>
                                        </tr>
                                    @endif
                                    @foreach($viewAllAgencies as $viewAllAgency)
                                        <tr>
                                            <td>{{$viewAllAgency->companyName}}</td>
{{--                                            <td>{{$viewAllAgency->regNo}}</td>--}}
{{--                                            <td>{{$viewAllAgency->addressLine1."".$viewAllAgency->addressLine2}}</td>--}}
                                            <td>{{strtoupper($viewAllAgency->city)}}</td>
                                            <td>{{$viewAllAgency->email}}</td>
                                            <td>{{$viewAllAgency->contactNo1}}</td>
                                            <td>{{$viewAllAgency->commission}}</td>
                                            @if($viewAllAgency->status == 1)

                                                <td>
                                                    <p>
                                                        <input type="checkbox"
                                                               onchange="adMethod('{{ $viewAllAgency->idCompanyInfo}}','companyinfomaster')"
                                                               id="{{"c".$viewAllAgency->idCompanyInfo}}" checked
                                                               switch="none"/>
                                                        <label for="{{"c".$viewAllAgency->idCompanyInfo}}"
                                                               data-on-label="On"
                                                               data-off-label="Off"></label>
                                                    </p>
                                                </td>
                                            @else
                                                <td>
                                                    <p>
                                                        <input type="checkbox"
                                                               onchange="adMethod('{{ $viewAllAgency->idCompanyInfo}}','companyinfomaster')"
                                                               id="{{"c".$viewAllAgency->idCompanyInfo}}"
                                                               switch="none"/>
                                                        <label for="{{"c".$viewAllAgency->idCompanyInfo}}"
                                                               data-on-label="On"
                                                               data-off-label="Off"></label>
                                                    </p>
                                                </td>
                                            @endif
                                            <td>
                                                <p>
                                                    <button type="button"
                                                            class="btn btn-sm btn-warning  waves-effect waves-light"
                                                            data-toggle="modal"
                                                            data-id="{{ $viewAllAgency->idCompanyInfo }}"
                                                            id="uAgencyId"
                                                            data-target="#updateAgencyModal"><i class="fa fa-edit"></i>
                                                    </button>
                                                </p>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            {{$viewAllAgencies->links()}}
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addCompany" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Add Agency</h5>
                <button type="button" class="close " data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">


                <div class="form-group">
                    <label>Agency Name</label>
                    <input type="text" class="form-control" name="comName" id="comName" required  maxlength="255"
                           placeholder="Agency Name"/>
                    <small class="text-danger">{{ $errors->first('comName') }}</small>
                </div>
                <div class="form-group">
                    <label>Reg Number</label>
                    <input type="text" class="form-control" required name="comRegNumber" maxlength="15"
                           id="comRegNumber"
                           placeholder="Reg Number"/>
                    <small class="text-danger">{{ $errors->first('comRegNumber') }}</small>
                </div>
                <div class="form-group">
                    <label for="commission">Commission (%)</label>
                    <input type="number" class="form-control" required name="commission"
                           id="commission"
                           placeholder="%"/>
                    <small class="text-danger">{{ $errors->first('comRegNumber') }}</small>
                </div>
                <div class="form-group">
                    <label>Address Line</label>
                    <input type="text" class="form-control" required name="comAddLine1" maxlength="255"
                           id="comAddLine1"
                           placeholder="Address Line"/>
                    <small class="text-danger">{{ $errors->first('comAddLine1') }}</small>
                </div>
                <div class="form-group">
                    <label>Address Line 2</label>
                    <input type="text" class="form-control" required name="comAddLine2" maxlength="255"
                           id="comAddLine2"
                           placeholder="Address Line"/>
                    <small class="text-danger">{{ $errors->first('comAddLine2') }}</small>
                </div>
                <div class="form-group">
                    <label>City</label>
                    <input type="text" class="form-control" required name="comCity" maxlength="25"
                           id="comCity"
                           placeholder="City"/>
                    <small class="text-danger">{{ $errors->first('comCity') }}</small>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email"   class="form-control" required name="comEmail" maxlength="255"
                           id="comEmail"
                           placeholder="Email"/>
                    <small class="text-danger">{{ $errors->first('comEmail') }}</small>
                </div>
                <div class="form-group">
                    <label>Mobile Number</label>
                    <input type="number" class="form-control" required name="comNumb1" maxlength="25"
                           id="comNumb1"
                           placeholder="Mobile Number"/>
                    <small class="text-danger">{{ $errors->first('comNumb1') }}</small>
                </div>
                <div class="form-group">
                    <label>Land Line Number</label>
                    <input type="number" class="form-control" required name="comNumb2" maxlength="25"
                            id="comNumb2"
                           placeholder="Land Line"/>
                    <small class="text-danger">{{ $errors->first('comNumb2') }}</small>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12">
                            <label>Is Shop</label>
                            <p >
                                <input type="checkbox"
                                       id="isShop" checked
                                       switch="none"/>
                                <label for="isShop"
                                       data-on-label="On"
                                       data-off-label="Off"></label>
                            </p>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info alert-dismissible " id="successAlert" style="display:none">
                            {{--<button type="button" class="close" data-dismiss="alert" aria-label="Close">--}}
                            {{--<span aria-hidden="true">&times;</span>--}}
                            {{--</button>--}}

                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert" style="display:none">
                            {{--<button type="button" class="close" data-dismiss="alert" aria-label="Close">--}}
                            {{--<span aria-hidden="true">&times;</span>--}}
                            {{--</button>--}}

                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" onclick="saveAgency()"
                            class="btn btn-info btn-sm waves-effect waves-light">
                        Add Agency
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--update-->
<div class="modal fade" id="updateAgencyModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <input type="hidden" name="hiddenAgID" id="hiddenAgID">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Update Agency</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Agency Name</label>
                    <input type="text" class="form-control" name="uComName" id="uComName" required maxlength="255"
                           placeholder="Agency Name"/>
                    <small class="text-danger">{{ $errors->first('uComName') }}</small>
                </div>
                <div class="form-group">
                    <label>Reg Number</label>
                    <input type="number" class="form-control" required name="uComRegNumber" maxlength="15"
                           oninput="this.value = Math.abs(this.value)" id="uComRegNumber"
                           placeholder="Reg Number"/>
                    <small class="text-danger">{{ $errors->first('uComRegNumber') }}</small>
                </div>
                <div class="form-group">
                    <label for="commission">Commission</label>
                    <input type="text" class="form-control" required name="Ucommission"
                           id="Ucommission"
                           placeholder="%"/>
                </div>
                <div class="form-group">
                    <label>Address Line</label>
                    <input type="text" class="form-control" required name="uComAddLine1" maxlength="255"
                           id="uComAddLine1"
                           placeholder="Address Line"/>
                    <small class="text-danger">{{ $errors->first('uComAddLine1') }}</small>
                </div>
                <div class="form-group">
                    <label>Address Line 2</label>
                    <input type="text" class="form-control" required name="uComAddLine2" maxlength="255"
                           id="uComAddLine2"
                           placeholder="Address Line"/>
                    <small class="text-danger">{{ $errors->first('uComAddLine2') }}</small>
                </div>
                <div class="form-group">
                    <label>City</label>
                    <input type="text" class="form-control" required name="uComCity"  maxlength="25"
                           id="uComCity"
                           placeholder="City"/>
                    <small class="text-danger">{{ $errors->first('uComCity') }}</small>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" required name="uComEmail" maxlength="255"
                           id="uComEmail"
                           placeholder="Email"/>
                    <small class="text-danger">{{ $errors->first('uComEmail') }}</small>
                </div>
                <div class="form-group">
                    <label>Mobile Number</label>
                    <input type="number" class="form-control" required name="uComNumb1" maxlength="25"
                         id="uComNumb1"
                           placeholder="Mobile Number"/>
                    <small class="text-danger">{{ $errors->first('uComNumb1') }}</small>
                </div>
                <div class="form-group">
                    <label>Land Line Number</label>
                    <input type="number" class="form-control" required name="uComNumb2" maxlength="25"
                           id="uComNumb2"
                           placeholder="Land Line Number"/>
                    <small class="text-danger">{{ $errors->first('uComNumb2') }}</small>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12">
                            <label>Is Shop</label>
                            <p >
                                <input type="checkbox"
                                       id="UisShop" checked
                                       switch="none"/>
                                <label for="UisShop"
                                       data-on-label="On"
                                       data-off-label="Off"></label>
                            </p>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info alert-dismissible " id="successAlert1" style="display:none">
                            {{--<button type="button" class="close" data-dismiss="alert" aria-label="Close">--}}
                            {{--<span aria-hidden="true">&times;</span>--}}
                            {{--</button>--}}

                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert1" style="display:none">
                            {{--<button type="button" class="close" data-dismiss="alert" aria-label="Close">--}}
                            {{--<span aria-hidden="true">&times;</span>--}}
                            {{--</button>--}}

                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" onclick="updateAgency()"
                            class="btn btn-info btn-sm waves-effect waves-light">
                        Update Agency
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}" type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
{{--<script src="{{ URL::asset('assets/home_assets/js/dashboard_js.js')}}"></script>--}}

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script type="text/javascript">


    $(document).ready(function () {
//        $('form').parsley();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


    });

    function adMethod(dataID, tableName) {

        $.post('activateDeactivate', {id: dataID, table: tableName}, function (data) {

        });
    }
    $('[data-dismiss=modal]').on('click', function (e) {
        var $t = $(this),
            target = $t[0].href || $t.data("target") || $t.parents('.modal') || [];

        $(target)
            .find("input,textarea,select")
            .val('')
            .end()
            .find("input[type=checkbox], input[type=radio]")
            .prop("checked", "")
            .end();
        $('#errorAlert').hide();
    });

    $('.modal').on('hidden.bs.modal', function () {

        $("input").val('');

        $('#errorAlert').html('');

        $('#errorAlert').hide();

        $('select').val('').trigger('change') ;



    });

    function saveAgency() {
        $('#successAlert').hide();
        $('#errorAlert').hide();
        $('#successAlert').html("");
        $('#errorAlert').html("");

        var comName = $("#comName").val();
        var comRegNumber = $("#comRegNumber").val();
        var comAddLine1 = $("#comAddLine1").val();
        var comAddLine2 = $("#comAddLine2").val();
        var comCity = $("#comCity").val();
        var comEmail = $("#comEmail").val();
        var comNumb1 = $("#comNumb1").val();
        var commission = $("#commission").val();
        var comNumb2 = $("#comNumb2").val();
        var isShop = $("#isShop").prop("checked");

        $.post('saveCompany', {
            comName: comName,
            comRegNumber: comRegNumber,
            comAddLine1: comAddLine1,
            comAddLine2: comAddLine2,
            comCity: comCity,
            comEmail: comEmail,
            comNumb1: comNumb1,
            comNumb2: comNumb2,
            isShop: isShop,
            commission: commission,


        }, function (data) {
            if (data.errors != null) {
                $('#errorAlert').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlert').append('<p>' + value + '</p>');
                });
            }
            if (data.success != null) {
                swal({
                    title: 'Saved!',
                    text: 'Agency details saved successfully.',
                    type: "success"

                });

                $("#comName").val("");
                $("#comRegNumber").val("");
                $("#comNumb1").val("");
                // setTimeout(function () {
                    $('#addCompany').modal('hide');
                // }, 3000);
            }
            $('tbody').html(data.tableData);
        });
    }

    $(document).on('click', '#uAgencyId', function () {
        var agencyId = $(this).data("id");
        $.get('getAgencyByID', {agencyById: agencyId}, function (data) {
            $("#hiddenAgID").val(agencyId);

            $("#uComName").val(data.companyName);
            $("#uComRegNumber").val(data.regNo);
            $("#uComAddLine1").val(data.addressLine1);
            $("#uComAddLine2").val(data.addressLine2);
            $("#uComCity").val(data.city);
            $("#uComEmail").val(data.email);
            $("#Ucommission").val(data.commission);
            $("#uComNumb1").val(data.contactNo1);
            $("#uComNumb2").val(data.contactNo2);
            $("#UisShop").prop("checked", data.isShop);

        });
    });
    function updateAgency() {

        $('#successAlert1').hide();
        $('#errorAlert1').hide();
        $('#successAlert1').html("");
        $('#errorAlert1').html("");

        var hiddenAgID = $("#hiddenAgID").val();
        var uComName = $("#uComName").val();
        var uComRegNumber = $("#uComRegNumber").val();
        var uComAddLine1 = $("#uComAddLine1").val();
        var uComAddLine2 = $("#uComAddLine2").val();
        var uComCity = $("#uComCity").val();
        var uComEmail = $("#uComEmail").val();
        var uComNumb1 = $("#uComNumb1").val();
        var uComNumb2 = $("#uComNumb2").val();
        var Ucommission = $("#Ucommission").val();
        var isShop =  $("#UisShop").prop("checked");


        $.post('updateAgency', {
            hiddenAgID: hiddenAgID,
            uComName: uComName,
            uComRegNumber: uComRegNumber,
            uComAddLine1: uComAddLine1,
            uComAddLine2: uComAddLine2,
            uComCity: uComCity,
            uComEmail: uComEmail,
            uComNumb1: uComNumb1,
            uComNumb2: uComNumb2,
            Ucommission: Ucommission,
            isShop: isShop

        }, function (data) {
            if (data.errors != null) {
                $('#errorAlert1').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlert1').append('<p>' + value + '</p>');
                });
            }
            if (data.success != null) {
                swal({
                    title: 'Saved!',
                    text: 'Agency details updated successfully.',
                    type: "success"

                });
                $('#updateAgencyModal').modal('hide');
                // $("#uComName").val("");
                // $("#uComRegNumber").val("");
                // $("#uComNumb1").val("");
                // setTimeout(location.reload.bind(location), 1000);
            }
            $('tbody').html(data.tableData);
        });
        $('#errorAlert').modal('hide');
    }

</script>


@include('includes.footer_end')