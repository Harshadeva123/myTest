<?php
/**
 * Created by PhpStorm.
 * User: Harshadeva
 * Date: 7/31/2019
 * Time: 8:24 PM
 */
//call the FPDF library
require( base_path().'/public/pdf/fpdf.php');

$pdf = new FPDF();

//A4 size : 210x297mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm
$leftMargin = 10;
$rightMargin = 5;
$pageWidth = 74;
$width= $pageWidth-$rightMargin-$leftMargin;
$height = 5;
$pageHeight = 75;
$aditionalHeight = 0;
$separatorHeight = 5;

class Dash extends FPDF{
    function printDash($w,$h){
        for($i=0;$i< $w-2 ;$i = $i+2 ){
            $this->Cell(2,$h,'-','0',0,'L');
        }
        $this->Cell(2,$h,'-','',1,'L');
    }
}

$regs = \App\InvoiceRegItems::where('invoice_idInvoice',$invoice->idInvoice)->where('status',1)->get();
$regHeight = count($regs)*$height*2;
foreach ($regs as $reg){

    $lenght = strlen($reg->item->itemName);
    $lines = $lenght/45;
    if($lines>1){
        $aditionalHeight += $lines*5;
    }
}

$actualHeight = $pageHeight+$aditionalHeight+$regHeight+$separatorHeight;
//create pdf object
//$pdf = new FPDF('P','mm',[$width,80+($noofitems*5)]);
$pdf = new Dash('P','mm',array($pageWidth,$actualHeight));
$pdf->SetMargins($leftMargin, 0 , $rightMargin);
$pdf->SetAutoPageBreak(true,0);

//add new page
$pdf->AddPage();
$pdf->SetFont('Arial','B',10);

//Cell(width , height , text , border , end line , [align] )

$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space

$pdf->Cell($width,$height,\Illuminate\Support\Facades\Auth::user()->companyInfo->companyName,'0',1,'C');

$pdf->SetFont('Arial','',8);//set font to arial, regular, 8pt

$pdf->Cell($width,$height,\Illuminate\Support\Facades\Auth::user()->companyInfo->addressLine1.','.\Illuminate\Support\Facades\Auth::user()->companyInfo->addressLine2.','.\Illuminate\Support\Facades\Auth::user()->companyInfo->city,'0',1,'C');
if(\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo2 !=null && \Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo1 !=null){
    $pdf->Cell($width,$height,'Tel: '.\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo1.' | '.\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo2,'0',1,'C');
}
elseif(\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo1 !=null){
    $pdf->Cell($width,$height,'Tel: '.\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo1,'0',1,'C');
}
iF(\Illuminate\Support\Facades\Auth::user()->companyInfo->email != null){
$pdf->Cell($width,$height,'Email: '.\Illuminate\Support\Facades\Auth::user()->companyInfo->email,'0',1,'C');//end of line
    }
$pdf->Cell($width,$height/10,'','T',1,'T');//Horizontal Line

$pdf->Cell($width/4*2,$height,'INVOICE NO : '.sprintf('%06d', $invoice->invoiceNo),'0',0,'L');
$pdf->Cell($width/4*2,$height,$invoice->created_at->format('d-m-Y'),'0',1,'R');

$pdf->Cell($width/4*2,$height,'USER            : '.strtoupper($invoice->user->fName),'0',0,'L');
$pdf->Cell($width/4*2,$height,$invoice->created_at->format('H:i:s'),'0',1,'R');

$pdf->Cell($width,$height/2,'','T',1,'T');//Horizontal space

$pdf->SetFont('Arial','B',8);//set font to arial, regular, 6pt
$pdf->Cell($width/4*2,$height,'ITEM','0',0,'L');
$pdf->Cell($width/4,$height,'QTY x RATE','0',0,'R');
//$pdf->Cell($width/4,$height,'Discount','0',0,'R');
$pdf->Cell($width/4,$height,'TOTAL','0',1,'R');
//$pdf->Cell($width,$height,'','T',1,'L');
$billTotal = 0;
$discountTotal = 0;
$netTotal = 0;
$pdf->SetFont('Arial','',8);//set font to arial, regular, 6pt
foreach ($regs as $reg){

    $qty = floatval($reg->qty)-floatval($reg->returnQty);

    $current_y = $pdf->GetY();
    $current_x = $pdf->GetX();

    $pdf->MultiCell($width/4*2,$height,$reg->item->itemName,'0','L',0);

    $after_y = $pdf->GetY();
    $after_x = $pdf->GetX();

    $pdf->SetXY($current_x+ $width/4*2, $current_y);

    $pdf->Cell($width/4,$height,$qty.' x '.$reg->rate,'0',0,'R');
    $pdf->Cell($width/4,$height,number_format(floatval(($reg->rate*$qty)-$reg->discount),2),'0',1,'R');
    $pdf->SetXY($leftMargin, $after_y);

    $pdf->printDash($width,$separatorHeight);
//    $pdf->Cell($width,$height,'','T',1,'L');


    $billTotal += floatval(($reg->rate*$qty));
//    $discountTotal += floatval($reg->discount);
//    $netTotal += floatval(($reg->rate*$qty)-$reg->discount);
}

$netTotal = $invoice->net_total;
$discountTotal = $invoice->discount;

$pdf->Cell($width,$height/2,'','0',1,'T');//Horizontal space
$pdf->SetFont('Arial','B',10);//set font to arial, Bold, 10pt


$pdf->Cell($width/2,$height,'PAYMENT TYPE  ','0',0,'L');
$pdf->Cell($width/2,$height,$invoice->paymentT->type,'0',1,'R');


$pdf->Cell($width/2,$height,'SUB TOTAL  ','0',0,'L');
$pdf->Cell($width/2,$height,number_format($billTotal,2),'0',1,'R');

if($invoice->discount > 0){
$pdf->Cell($width/2,$height,'DISCOUNT  ','0',0,'L');
$pdf->Cell($width/2,$height,number_format($invoice->discount,2),'0',1,'R');
}
//$pdf->Cell($width/2,$height,'Total Discount : ','0',0,'L');
//$pdf->Cell($width/2,$height,number_format($discountTotal,2),'0',1,'R');

$pdf->Cell($width/2,$height,'NET TOTAL  ','0',0,'L');
$pdf->Cell($width/2,$height,number_format($netTotal,2),'0',1,'R');

if($invoice->paymentType == '1' ){

$pdf->Cell($width,$height/2,'','0',1,'T');//Horizontal space
$pdf->SetFont('Arial','',6);//set font to arial, Bold, 10pt
$pdf->printDash($width,$separatorHeight/10);

$pdf->SetFont('Arial','B',10);//set font to arial, Bold, 10pt


$pdf->Cell($width/2,$height,'PAID  AMOUNT','0',0,'L');
$pdf->Cell($width/2,$height,number_format($invoice->paid,2),'0',1,'R');

$pdf->Cell($width/2,$height,'BALANCE','0',0,'L');
$pdf->Cell($width/2,$height,number_format(floatval($invoice->paid)-floatval($netTotal),2),'0',1,'R');

}

if($invoice->paymentType == '2' ){

    $pdf->Cell($width,$height/2,'','0',1,'T');//Horizontal space
    $pdf->SetFont('Arial','',6);//set font to arial, Bold, 10pt
    $pdf->printDash($width,$separatorHeight/10);

    $pdf->SetFont('Arial','B',10);//set font to arial, Bold, 10pt

    $pdf->Cell($width/2,$height,'PAID  AMOUNT','0',0,'L');
    $pdf->Cell($width/2,$height,number_format($invoice->paidDue,2),'0',1,'R');

    $pdf->Cell($width/2,$height,'DUE','0',0,'L');
    $pdf->Cell($width/2,$height,number_format(floatval($invoice->due)-floatval($invoice->paidDue),2),'0',1,'R');

}

if($invoice->paymentType == '6' && $invoice->due > 0){

    $pdf->Cell($width,$height/2,'','0',1,'T');//Horizontal space
    $pdf->SetFont('Arial','',6);//set font to arial, Bold, 10pt
    $pdf->printDash($width,$separatorHeight/10);

    $pdf->SetFont('Arial','B',10);//set font to arial, Bold, 10pt

    $pdf->Cell($width/2,$height,'PAID  AMOUNT','0',0,'L');
    $pdf->Cell($width/2,$height,number_format($invoice->paidDue,2),'0',1,'R');

    $pdf->Cell($width/2,$height,'DUE','0',0,'L');
    $pdf->Cell($width/2,$height,number_format(floatval($invoice->due)-floatval($invoice->paidDue),2),'0',1,'R');

}

$pdf->Cell($width,$height/2,'','0',1,'T');//Horizontal space

$pdf->SetFont('Arial','',6);//set font to arial, Bold, 10pt
$pdf->printDash($width,$separatorHeight/10);
$pdf->Cell($width,$height,'Solution By VGS | www.visirogs.com','0',1,'C');
//output the result
//$pdf->AutoPrint();
$pdf->Output();
exit();
?>