<?php
/**
 * Created by PhpStorm.
 * User: Harshadeva
 * Date: 7/31/2019
 * Time: 8:24 PM
 */

//call the FPDF library
require( base_path().'/public/pdf/fpdf.php');
header('Content-type: application/x-pdf;filename="example.pdf"');

$pdf = new FPDF();

class Dash extends FPDF{
    function printDash($w,$h,$lm='0',$rm = '0'){
        for($i=0;$i< $w-2 ;$i = $i+2 ){
            if($i == 0){
                $this->Cell(2,$h,'-',$lm,0,'L');
            }
            else{
                $this->Cell(2,$h,'-','0',0,'L');
            }
        }
        $this->Cell(2,$h,'-',$rm,1,'L');
    }
}


//A4 size : 210x297mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm
$leftMargin = 10;
$rightMargin = 10;
$pageWidth = 210;
$width= $pageWidth-$rightMargin-$leftMargin;
$height = 5;
$separatorHeight = 1;

    if($payment->isBulk == 0){
        $rowsHeight = $height;
        $totalSeparatorHeight = $separatorHeight;
    }
    else{
        $references = \App\PaymentRefference::where('payment_idpayment', $payment->idpayment)->where('status', 1)->get();
        $rowsHeight = count($references)*$height;
        $totalSeparatorHeight = count($references)*$separatorHeight;
    }

$pageHeight = 210 + $rowsHeight + $totalSeparatorHeight;

$pdf = new Dash('P','mm',array($pageWidth,$pageHeight));
$pdf->SetMargins($leftMargin, 0 , $rightMargin);
$pdf->SetAutoPageBreak(true,0);

//add new page
$pdf->AddPage();
$pdf->SetFont('Arial','B',12);


$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space
$pdf->SetFont('Arial','B',13);//set font to arial, regular, 8pt
if($payment->isBulk == 0){

    $transfer  = \App\StockTransfer::find(intval($payment->id));
    if($transfer->companyType == 1){
        $pdf->Cell($width,$height,"Peoples Bakers",'0',1,'C');
    }
    else{
        $pdf->Cell($width,$height,"New Peoples Bakers",'0',1,'C');

    }
}
else{

    $references = \App\PaymentRefference::where('payment_idpayment', $payment->idpayment)->where('status', 1)->get();
    $transfer  = \App\StockTransfer::find(intval($references[0]->ref_no));
    if($transfer->companyType == 1){
        $pdf->Cell($width,$height,"Peoples Bakers",'0',1,'C');
    }
    else{
        $pdf->Cell($width,$height,"New Peoples Bakers",'0',1,'C');

    }
}

$pdf->SetFont('Arial','',10);//set font to arial, regular, 8pt
$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space
$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space

$pdf->Cell($width/3,$height,'','0',0,'L');
$pdf->Cell($width/3,$height,'','0',0,'L');
$pdf->Cell($width/3,$height,'PAYMENT RECEIPT','0',1,'R');//end of line


$pdf->Cell($width/3,$height,'REF NO : PAY/'.$payment->created_at->format('Y') .'/'.$payment->idpayment,'0',0,'L');
//$pdf->Cell($width/3,$height,'From:','0',0,'L');
$pdf->Cell($width/3,$height,'','0',0,'L');
$pdf->Cell($width/3,$height,'PAID BY:','0',1,'L');//end of line

$pdf->Cell($width/3,$height,'DATE / TIME : '.$payment->created_at->format('Y-m-d') .' '.$payment->created_at->format('H:i'),'0',0,'L');
$pdf->SetFont('Arial','B',10);
//$pdf->Cell($width/3,$height,$transfer->FromCompany->companyName,'0',0,'L');
$pdf->Cell($width/3,$height,'','0',0,'L');
$pdf->Cell($width/3,$height,$transfer->ToCompany->companyName,'0',1,'L');//end of line

$pdf->SetFont('Arial','',10);
$pdf->Cell($width/3,$height,'PAYMENT TYPE : '.$payment->payment->type,'0',0,'L');
//$pdf->Cell($width/3,$height,$transfer->FromCompany->addressLine1,'0',0,'L');
$pdf->Cell($width/3,$height,'','0',0,'L');
$pdf->Cell($width/3,$height,$transfer->ToCompany->addressLine1,'0',1,'L');//end of line

$pdf->Cell($width/3,$height,'CREATED  BY : '.$payment->user->fName.' '.$payment->user->Lname,'0',0,'L');
//$pdf->Cell($width/3,$height,$transfer->FromCompany->contactNo1,'0',0,'L');
$pdf->Cell($width/3,$height,'','0',0,'L');
$pdf->Cell($width/3,$height,$transfer->ToCompany->contactNo1,'0',1,'L');//end of line

$pdf->Cell($width,$height,'','B',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','',1,'L');//Horizontal Space
$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space

$pdf->SetFont('Arial','B',10);
$pdf->Cell($width/10/2,$height,'NO','BTL',0,'C');
$pdf->Cell($width/10*5,$height,'DESCRIPTION','BT',0,'L');
//$pdf->Cell($width/10,$height,'NET TOTAL','0',0,'R');
$pdf->Cell($width/10,$height,'','BT',0,'R');
//$pdf->Cell($width/10*1.5,$height,'PAID TOTAL','0',0,'R');
$pdf->Cell($width/10*1.5,$height,'','BRT',0,'R');
//$pdf->Cell($width/10*2,$height,'DUE','0',1,'R');//end of line
$pdf->Cell($width/10*2,$height,'AMOUNT ','BTR',1,'R');//end of line

$pdf->SetFont('Arial','',9);

$pdf->Cell($width/10/2,$height,'','L',0,'L');
$pdf->Cell($width/10*5,$height,'','0',0,'L');
$pdf->Cell($width/10,$height,'','0',0,'R');
$pdf->Cell($width/10*1.5,$height,'','R',0,'R');
$pdf->Cell($width/10*2,$height,'','R',1,'R');//end of line

$paidTotal = 0;
$netTotal = 0;
$dueTotal = 0;
$totalSetOff = 0;

if($payment->isBulk == 0){

    $pdf->Cell($width/10/2,$height,1,'L',0,'C');
    $pdf->Cell($width/10*5,$height,'TRNS ID : '.sprintf('%06d', $transfer->idStock_Transfer),'0',0,'L');
//    $pdf->Cell($width/10,$height,'Rs. '.number_format($transfer->netTotal,2),'0',0,'R');
    $pdf->Cell($width/10,$height,'','0',0,'R');
//    $pdf->Cell($width/10*1.5,$height,'Rs. '.number_format($transfer->paidTotal,2),'0',0,'R');
    $pdf->Cell($width/10*1.5,$height,'','R',0,'R');
//    $pdf->Cell($width/10*2,$height,'Rs. '.number_format(floatval($transfer->netTotal - $transfer->paidTotal),2),'0',1,'R');//end of line
    $pdf->Cell($width/10*2,$height,'Rs. '.number_format(floatval($payment->totalAmount),2).' ','R',1,'R');//end of line

    $paidTotal = $transfer->paidTotal;
    $netTotal = $transfer->netTotal;
    $dueTotal = $transfer->netTotal - $transfer->paidTotal;
    $totalSetOff = $payment->totalAmount;
}
else{
    $rowNo = 1;
    foreach ($references as $reference){
        $transfer2 = \App\StockTransfer::find(intval($reference->ref_no));
        $pdf->Cell($width/10/2,$height,$rowNo,'L',0,'C');
        $pdf->Cell($width/10*5,$height,'TRNS ID : '.sprintf('%06d', $transfer2->idStock_Transfer),'0',0,'L');
        $pdf->Cell($width/10,$height,'','0',0,'R');
//        $pdf->Cell($width/10,$height,'Rs. '.number_format($transfer2->netTotal,2),'0',0,'R');
        $pdf->Cell($width/10*1.5,$height,'','R',0,'R');
//        $pdf->Cell($width/10*1.5,$height,'Rs. '.number_format($transfer2->paidTotal,2),'0',0,'R');
//        $pdf->Cell($width/10*2,$height,'Rs. '.number_format(floatval($transfer2->netTotal - $transfer2->paidTotal),2),'0',1,'R');//end of line
        $pdf->Cell($width/10*2,$height,'Rs. '.number_format(floatval($reference->amount),2).' ','R',1,'R');//end of line

        $pdf->Cell($width/10/2,$height,'','L',0,'L');
        $pdf->Cell($width/10*5,$height,'DATE : '.$transfer2->created_at->format('y-m-d'),'0',0,'L');
        $pdf->Cell($width/10,$height,'','0',0,'R');
        $pdf->Cell($width/10*1.5,$height,'','R',0,'R');
        $pdf->Cell($width/10*2,$height,'','R',1,'R');//end of line

        $paidTotal += $transfer2->paidTotal;
        $netTotal += $transfer2->netTotal;
        $dueTotal += $transfer2->netTotal - $transfer2->paidTotal;
        $totalSetOff += $reference->amount;

        $pdf->printDash($width,$separatorHeight,'L','R');

        $rowNo++;
    }

}

$pdf->SetFont('Arial','B',10);

//$pdf->Cell($width/10/2,$height,'TOTAL','0',0,'L');
//$pdf->Cell($width/10*5,$height,'','0',0,'L');
////$pdf->Cell($width/10,$height,'Rs. '.number_format($netTotal,2),'0',0,'R');
////$pdf->Cell($width/10*1.5,$height,'Rs. '.number_format($paidTotal,2),'0',0,'R');
//$pdf->Cell($width/10,$height,'','0',0,'R');
//$pdf->Cell($width/10*1.5,$height,'','0',0,'R');
//$pdf->Cell($width/10*2,$height,'Rs. '.number_format($dueTotal,2),'0',1,'R');//end of line
//

$pdf->Cell($width/10/2,$height*1.5,'','L',0,'L');
$pdf->Cell($width/10*5,$height*1.5,'TOTAL SET OFF AMOUNT','0',0,'L');
$pdf->Cell($width/10,$height*1.5,'','0',0,'R');
$pdf->Cell($width/10*1.5,$height*1.5,'','R',0,'R');
$pdf->Cell($width/10*2,$height*1.5,'Rs. '.number_format($totalSetOff,2).' ','R',1,'R');//end of line

$pdf->Cell($width,1,'','1',1,'L');//Horizontal

$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line




$pdf->Cell($width/10*5,$height,'_ _ _ _ _ _ _ _ _ _ _ _ _','0',0,'L');
$pdf->Cell($width/10/2,$height,'','0',0,'L');
$pdf->Cell($width/10,$height,'','0',0,'R');
$pdf->Cell($width/10*1.5,$height,'','0',0,'R');
$pdf->Cell($width/10*2,$height,'_ _ _ _ _ _ _ _ _ _ _ _ _ _ _','0',1,'R');//end of line

$pdf->Cell($width/10*5,$height,'CASHIER SIGNATURE','0',0,'L');
$pdf->Cell($width/10/2,$height,'','0',0,'L');
$pdf->Cell($width/10,$height,'','0',0,'R');
$pdf->Cell($width/10*1.5,$height,'','0',0,'R');
$pdf->Cell($width/10*2,$height,'CUSTOMER SIGNATURE','0',1,'R');//end of line

$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Line

$pdf->Cell($width,$height,'Solution By VGS | www.visirogs.com |  +94 77 713 7957 | +94 11 276 4488','TB',1,'C');//Horizontal Space


//
//
//
//
//$pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
//$pdf->Cell(($width/6)+10,$height,'SET OFF AMOUNT',0,0,'L');
//$pdf->Cell(1,$height,':','0',0,'L');
//$pdf->Cell($width/6,$height,number_format(floatval($payment->totalAmount),2),'',2,'R');//end of line

//$pdf->Cell($width,$height/10,'','',1,'L');//Horizontal Line
//
//$pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
//$pdf->Cell(($width/6)+10,$height,'BILL TOTAL',0,0,'L');
//$pdf->Cell(1,$height,':','0',0,'L');
//$pdf->Cell($width/6,$height,number_format(floatval($netTotal),2),'',2,'R');//end of line
//
//$pdf->Cell($width,$height/10,'','',1,'L');//Horizontal Line
//
//$pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
//$pdf->Cell(($width/6)+10,$height,'BALANCE',0,0,'L');
//$pdf->Cell(1,$height,':','0',0,'L');
//$pdf->Cell($width/6,$height,number_format(max(floatval($payment->totalAmount - $netTotal),0),2),'',2,'R');//end of line//


//output the result
//$pdf->AutoPrint();
$pdf->Output();
exit();
?>