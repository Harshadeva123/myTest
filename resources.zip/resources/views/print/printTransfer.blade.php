<?php
/**
 * Created by PhpStorm.
 * User: Harshadeva
 * Date: 7/31/2019
 * Time: 8:24 PM
 */

//call the FPDF library
require( base_path().'/public/pdf/fpdf.php');
header('Content-type: application/x-pdf;filename="example.pdf"');

$pdf = new FPDF();

class Dash extends FPDF{
    function printDash($w,$h){
        for($i=0;$i< $w-2 ;$i = $i+2 ){
            $this->Cell(2,$h,'-','0',0,'L');
        }
        $this->Cell(2,$h,'-','',1,'L');
    }
}


//A4 size : 210x297mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm
$items =  \App\TransferItem::with('stock')->where('idStock_Transfer',$transfer->idStock_Transfer)->where('status',1)->orderBy('Stock_idStock')->get()->groupBy('stock.Items_idItems');
$leftMargin = 10;
$rightMargin = 10;
$pageWidth = 210;
$width= $pageWidth-$rightMargin-$leftMargin;
$height = 5;
$separatorHeight = 3;

$rowHeight = count($items)*$height;
$totalSeparatorHeight = count($items)*$separatorHeight;
$pageHeight = 210 + $rowHeight + $totalSeparatorHeight;

$pdf = new Dash('P','mm',array($pageWidth,$pageHeight));
$pdf->SetMargins($leftMargin, 0 , $rightMargin);
$pdf->SetAutoPageBreak(true,0);

//add new page
$pdf->AddPage();
$pdf->SetFont('Arial','B',12);


$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space
$pdf->SetFont('Arial','B',13);//set font to arial, regular, 8pt
if($transfer->companyType == 1){
    $pdf->Cell($width,$height,"Peoples Bakers",'0',1,'C');
}
else{
    $pdf->Cell($width,$height,"New Peoples Bakers",'0',1,'C');

}


$pdf->SetFont('Arial','',10);//set font to arial, regular, 8pt
$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space
$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space

$pdf->Cell($width/3,$height,'Ref No : TRNS/'.$transfer->created_at->format('Y') .'/'.$transfer->idStock_Transfer,'0',0,'L');
$pdf->Cell($width/3,$height,'From:','0',0,'L');
$pdf->Cell($width/3,$height,'To:','0',1,'L');//end of line

$pdf->Cell($width/3,$height,'Date/Time : '.$transfer->created_at->format('Y-m-d') .' '.$transfer->created_at->format('H:i'),'0',0,'L');
$pdf->SetFont('Arial','B',10);
$pdf->Cell($width/3,$height,$transfer->FromCompany->companyName,'0',0,'L');
$pdf->Cell($width/3,$height,$transfer->ToCompany->companyName,'0',1,'L');//end of line

$pdf->SetFont('Arial','',10);
$pdf->Cell($width/3,$height,'Payment Type : '.$transfer->payment->type,'0',0,'L');
$pdf->Cell($width/3,$height,$transfer->FromCompany->addressLine1,'0',0,'L');
$pdf->Cell($width/3,$height,$transfer->ToCompany->addressLine1,'0',1,'L');//end of line

$pdf->Cell($width/3,$height,'Created by : '.$transfer->user->fName.' '.$transfer->user->Lname,'0',0,'L');
$pdf->Cell($width/3,$height,$transfer->FromCompany->contactNo1,'0',0,'L');
$pdf->Cell($width/3,$height,$transfer->ToCompany->contactNo1,'0',1,'L');//end of line

$pdf->Cell($width,$height,'','B',1,'L');//Horizontal Line
$pdf->Cell($width,$height,'','',1,'L');//Horizontal Space
$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space

$pdf->SetFont('Arial','B',8);
$pdf->Cell($width/10/2,$height,'NO','0',0,'L');
$pdf->Cell($width/10*5,$height,'ITEM NAME','0',0,'L');
//$pdf->Cell($width/6,$height,'Stock No','0',0,'L');
$pdf->Cell($width/10,$height,'QTY','0',0,'R');
$pdf->Cell($width/10*1.5,$height,'UNIT PRICE','0',0,'R');
$pdf->Cell($width/10*2,$height,'SUBTOTAL','0',1,'R');//end of line

$pdf->SetFont('Arial','',8);
$rowNo = 1;
$billTotal = 0;
//for($i=0;$i<10;$i++){
foreach ($items as $key=>$item){
    $itemDetails = \App\Item::find($key);
    $qtySum = $item->sum('qty');
    $unitPrice = $item[0]->unitPrice;

    $pdf->Cell($width/10/2,$height,$rowNo,'0',0,'L');
    $pdf->Cell($width/10*5,$height,$itemDetails->itemcode.' - '.$itemDetails->itemName,'0',0,'L');
    $pdf->Cell($width/10,$height,$qtySum.' '.$itemDetails->measurement->mian,'0',0,'R');
    $pdf->Cell($width/10*1.5,$height,number_format($unitPrice,2),'0',0,'R');
    $pdf->Cell($width/10*2,$height,number_format($qtySum*$unitPrice,2),'0',1,'R');//end of line
    $pdf->printDash($width,$separatorHeight);
    $rowNo += 1;
    $billTotal += $qtySum*$unitPrice;
    }
//$i++;
//}
$pdf->Cell($width,$height/2,'','0',1,'L');//Horizontal Space



$returnTotal = 0;

if($returns != null && count($returns)){
    $pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space
    $pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space

    $pdf->SetFont('Arial','',10);
    $pdf->Cell(($width/5)*2,$height,'','0',0,'C');
    $pdf->Cell($width/5,$height,'Previous Returns','B',0,'C');
    $pdf->Cell(($width/5)*2,$height,'','0',1,'C');

    $pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space

    $pdf->SetFont('Arial','B',8);
    $pdf->Cell($width/10/2,$height,'NO','0',0,'L');
    $pdf->Cell($width/10*5,$height,'ITEM NAME','0',0,'L');
    //$pdf->Cell($width/6,$height,'Stock No','0',0,'L');
    $pdf->Cell($width/10,$height,'RETURN QTY','0',0,'R');
    $pdf->Cell($width/10*1.5,$height,'UNIT PRICE','0',0,'R');
    $pdf->Cell($width/10*2,$height,'RETURN TOTAL','0',1,'R');//end of line

    $pdf->SetFont('Arial','',8);

    $rowNo2=1;
    foreach ($returns as $return){
        $qtySum = $return->qty;
        $unitPrice = $return->returns->item->unitPrice;

        $pdf->Cell($width/10/2,$height,$rowNo2,'0',0,'L');
        $pdf->Cell($width/10*5,$height,$return->returns->item->itemcode.' - '.$return->returns->item->itemName,'0',0,'L');
        $pdf->Cell($width/10,$height,$qtySum.' '.$return->returns->item->measurement->mian,'0',0,'R');
        $pdf->Cell($width/10*1.5,$height,number_format($unitPrice,2),'0',0,'R');
        $pdf->Cell($width/10*2,$height,number_format($qtySum*$unitPrice,2),'0',1,'R');//end of line
        $pdf->printDash($width,$separatorHeight);
        $rowNo2 += 1;
        $returnTotal += $qtySum*$unitPrice;

    }
}

$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Space
$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Space

$pdf->SetFont('Arial','',12);//set font arial, bold , 10pt

$pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
$pdf->Cell(($width/6)+10,$height,'SUB TOTAL','0',0,'L');
$pdf->Cell(1,$height,':','0',0,'L');
$pdf->Cell($width/6,$height,number_format($billTotal,2),'0',1,'R');//end of line



$pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
$pdf->Cell(($width/6)+10,$height,'RETURNS','0',0,'L');
$pdf->Cell(1,$height,':','0',0,'L');
if($returnTotal>0){
$pdf->Cell($width/6,$height,'- '.number_format($returnTotal,2),'0',1,'R');//end of line
}
else{
    $pdf->Cell($width/6,$height,'0.00','0',1,'R');//end of line

}

if($transfer->commission > 0){
$pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
$pdf->Cell(($width/6)+10,$height,'COMMISSION ('.$transfer->commissionRate.'%)','0',0,'L');
$pdf->Cell(1,$height,':','0',0,'L');
$pdf->Cell($width/6,$height,number_format($transfer->commission,2),'0',1,'R');//end of line
}

$pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
$pdf->Cell(($width/6)+10,$height,'NET TOTAL ',0,0,'L');
$pdf->Cell(1,$height,':','0',0,'L');
$netTotal = $transfer->netTotal;
$pdf->Cell($width/6,$height,number_format(floatval($netTotal),2),'',2,'R');//end of line


$pdf->Cell($width/6,$height,'','',1,'L');//Horizontal Line

$pdf->SetFont('Arial','B',12);//set font arial, bold , 12pt

$pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
$pdf->Cell(($width/6)+10,$height,'PAID TOTAL','0',0,'L');
$pdf->Cell(1,$height,':','0',0,'L');
$pdf->Cell($width/6,$height,number_format($transfer->paidTotal,2),'0',1,'R');//end of line

if($netTotal - $transfer->paidTotal >= 0){
$pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
$pdf->Cell(($width/6)+10,$height,'DUE TOTAL','0',0,'L');
$pdf->Cell(1,$height,':','0',0,'L');
$pdf->Cell($width/6,$height,number_format(($netTotal - $transfer->paidTotal),2),'0',1,'R');//end of line

    }
if($transfer->paidTotal - $netTotal > 0 ){
    $pdf->Cell(($width/6)*4-10,$height,'','0',0,'R');
    $pdf->Cell(($width/6)+10,$height,'BALANCE','0',0,'L');
    $pdf->Cell(1,$height,':','0',0,'L');
    $pdf->Cell($width/6,$height,number_format(($transfer->paidTotal - $netTotal),2),'0',1,'R');//end of line
}
$pdf->SetFont('Arial','',8);//set font to arial, regular, 8pt

$pdf->Cell($width,$height,'NOTE','0',1,'L');
$pdf->printDash($width,$height);
$pdf->printDash($width,$height);
$pdf->printDash($width,$height);

$pdf->Cell($width,$height,'','0',1,'L');//Horizontal Space

$pdf->Cell($width/4,$height,'Checked by : ','0',0,'L');
$pdf->Cell($width/4,$height,'','0',0,'L');
$pdf->Cell($width/4,$height,'','0',0,'L');
$pdf->Cell($width/4,$height,'Certified by : ','0',1,'L');

//output the result
//$pdf->AutoPrint();
$pdf->Output();
exit();
?>