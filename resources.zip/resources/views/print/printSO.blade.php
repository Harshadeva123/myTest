<?php
/**
 * Created by PhpStorm.
 * User: Harshadeva
 * Date: 7/31/2019
 * Time: 8:24 PM
 */
//call the FPDF library
require( base_path().'/public/pdf/fpdf.php');

$pdf = new FPDF();

//A4 size : 210x297mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm
$leftMargin = 10;
$rightMargin = 5;
$pageWidth = 75;
$width= $pageWidth-$rightMargin-$leftMargin;
$height = 5;
$pageHeight = 95;
$aditionalHeight = 0;
$separatorHeight = 5;

class Dash extends FPDF{
    function printDash($w,$h){
        for($i=0;$i< $w-2 ;$i = $i+2 ){
            $this->Cell(2,$h,'-','0',0,'L');
        }
        $this->Cell(2,$h,'-','',1,'L');
    }
}


//$regHeight = count($regs)*$height*2;
//foreach ($regs as $reg){
//
//    $lenght = strlen($reg->item->itemName);
//    $lines = $lenght/45;
//    if($lines>1){
//        $aditionalHeight += $lines*5;
//    }
//}

$actualHeight = $pageHeight+$aditionalHeight+$separatorHeight;
//create pdf object
//$pdf = new FPDF('P','mm',[$width,80+($noofitems*5)]);
$pdf = new Dash('P','mm',array($pageWidth,$actualHeight));
$pdf->SetMargins($leftMargin, 0 , $rightMargin);
$pdf->SetAutoPageBreak(true,0);

//add new page
$pdf->AddPage();
$pdf->SetFont('Arial','B',12);

//Cell(width , height , text , border , end line , [align] )

$pdf->Cell($width,$height,'',0,1,'L');//Horizontal Space

$pdf->Cell($width,$height,\Illuminate\Support\Facades\Auth::user()->companyInfo->companyName,'0',1,'C');

$pdf->SetFont('Arial','',8);//set font to arial, regular, 8pt

$pdf->Cell($width,$height,\Illuminate\Support\Facades\Auth::user()->companyInfo->addressLine1.','.\Illuminate\Support\Facades\Auth::user()->companyInfo->addressLine2.','.\Illuminate\Support\Facades\Auth::user()->companyInfo->city,'0',1,'C');
if(\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo2 !=null && \Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo1 !=null){
    $pdf->Cell($width,$height,'Tel: '.\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo1.' | '.\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo2,'0',1,'C');
}
elseif(\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo1 !=null){
    $pdf->Cell($width,$height,'Tel: '.\Illuminate\Support\Facades\Auth::user()->companyInfo->contactNo1,'0',1,'C');
}
iF(\Illuminate\Support\Facades\Auth::user()->companyInfo->email != null){
    $pdf->Cell($width,$height,'Email: '.\Illuminate\Support\Facades\Auth::user()->companyInfo->email,'0',1,'C');//end of line
}
$pdf->Cell($width,$height/10,'','T',1,'T');//Horizontal Line

$pdf->Cell($width/4*2,$height,'ORDER NO : SP-'.$order->idOrder,'0',0,'L');
$pdf->Cell($width/4*2,$height,$order->created_at->format('d-m-Y'),'0',1,'R');

$pdf->Cell($width/4*2,$height,'USER           : '.strtoupper($order->user->fName),'0',0,'L');
$pdf->Cell($width/4*2,$height,$order->created_at->format('H:i:s'),'0',1,'R');

$pdf->Cell($width,$height/5,'','T',1,'T');//Horizontal line

$pdf->SetFont('Arial','B',6);//set font to arial, Bold, 10pt
$pdf->MultiCell($width,$height/2,'CUSTOMER DETAILS','','L');
$pdf->Cell($width,$height/4,'','0',1,'T');//Horizontal line

$pdf->SetFont('Arial','',6);//set font to arial, Bold, 10pt

$pdf->MultiCell($width,$height/2,strtoupper($order->CustomerName),'','L');
$pdf->Cell($width,$height/5,'','0',1,'T');//Horizontal line

$pdf->MultiCell($width,$height/2,strtoupper($order->contactNo),'','L');
$pdf->Cell($width,$height/5,'','0',1,'T');//Horizontal space

$pdf->printDash($width,$separatorHeight/10);
$pdf->Cell($width,$height/5,'','0',1,'T');//Horizontal space

$pdf->SetFont('Arial','B',6);//set font to arial, Bold, 10pt
$pdf->MultiCell($width,$height/2,'ORDER DETAILS','','L');
$pdf->Cell($width,$height/4,'','0',1,'T');//Horizontal line

$pdf->SetFont('Arial','',6);//set font to arial, Bold, 10pt

$pdf->MultiCell($width,$height/2,'DELIVERY DATE     : '.strtoupper($order->deliveryDate),'','L');
$pdf->Cell($width,$height/8,'','0',1,'T');//Horizontal line
$pdf->MultiCell($width,$height/2,'AMOUNT                  : '.strtoupper($order->amount),'','L');
$pdf->Cell($width,$height/8,'','0',1,'T');//Horizontal line
$pdf->MultiCell($width,$height/2,'SPECIAL NOTE       : '.strtoupper($order->specialNote),'','L');
$pdf->Cell($width,$height/8,'','0',1,'T');//Horizontal line
$pdf->MultiCell($width,$height/2,'REMARKS               : '.strtoupper($order->remarks),'','L');

$pdf->Cell($width,$height/5,'','0',1,'T');//Horizontal space
$pdf->printDash($width,$separatorHeight/2);

$pdf->SetFont('Arial','B',6);//set font to arial, Bold, 10pt
$pdf->MultiCell($width,$height/2,'PAYMENT DETAILS','','L');
$pdf->Cell($width,$height/4,'','0',1,'T');//Horizontal line

$pdf->SetFont('Arial','',6);//set font to arial, Bold, 6pt

$pdf->Cell(($width/2),$height/1.5,"PAYMENT TYPE",'0',0,'L');
$pdf->Cell(($width/2),$height/1.5,$order->paymentType->type,'0',1,'R');

$pdf->Cell(($width/2),$height/1.5,"TOTAL AMOUNT",'0',0,'L');
$pdf->Cell(($width/2),$height/1.5,number_format($order->amount,2),'0',1,'R');

$pdf->Cell(($width/2),$height/1.5,"ADVANCED PAYMENT",'0',0,'L');
$pdf->Cell(($width/2),$height/1.5,number_format($order->advanced,2),'0',1,'R');

$pdf->Cell(($width),$height/5,'','0',1,'T');//Horizontal space

$pdf->SetFont('Arial','B',7);//set font to arial, Bold, 6pt
$pdf->Cell(($width/2),$height/1.5,"TOTAL PAID",'0',0,'L');
$pdf->SetFont('Arial','B',7);//set font to arial, Bold, 6pt
$pdf->Cell(($width/2),$height/1.5, number_format($order->advanced + $order->paidDue ,2),'0',1,'R');

if($order->due - $order->paidDue > 0){
    $pdf->SetFont('Arial','B',7);//set font to arial, Bold, 6pt
    $pdf->Cell(($width/2),$height/1.5,"DUE AMOUNT",'0',0,'L');
    $pdf->Cell(($width/2),$height/1.5, number_format($order->due - $order->paidDue,2),'0',1,'R');
}


//
//$pdf->Cell($width,$height/2,'','B',1,'T');//Horizontal space

$pdf->Cell($width,$height/2,'','0',1,'T');//Horizontal space
$pdf->SetFont('Arial','',6);//set font to arial, Bold, 10pt
$pdf->printDash($width,$separatorHeight/10);
$pdf->Cell($width,$height,'Solution By VGS | www.visirogs.com','0',1,'C');
//output the result
//$pdf->AutoPrint();
$pdf->Output();
exit();
?>