@include('includes.header_start')


<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
      type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}"
      rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">
@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card m-b-20">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="alert alert-danger alert-dismissible " id="errorAlertAdd"
                                     style="display:none">

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Store</label>
                                    <select class="form-control select2 tab" name="stock"
                                            id="stock" required>
                                        <option value="" disabled selected>Select Store
                                        </option>
                                        @if(isset($stockTypes))
                                            @foreach($stockTypes as $stockType)
                                                <option value="{{"$stockType->idStore"}}">{{$stockType->type}} </option>
                                            @endforeach
                                        @endif

                                    </select>
                                </div>
                            </div>

                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>Item</label>
                                    <select class="form-control select2 tab" data-measurement="#measurement"
                                            data-qty="#qtyGrn" name="item" onchange="itemChanged(this)"
                                            id="item" required>
                                        <option value="" disabled selected>Select Item
                                        </option>
                                        @if(isset($items))
                                            @foreach($items as $item)
                                                <option value="{{"$item->idItems"}}">{{$item->itemcode}}
                                                    - {{"$item->itemName"}} </option>
                                            @endforeach
                                        @endif

                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Qty</label>
                                    <input type="number" class="form-control tab" name="qtyGrn" id="qtyGrn" min="0"
                                           data-measurement="#measurement"
                                           placeholder="Qty"/>
                                    <small id="qtyMsg" class="text-danger">{{ $errors->first('qtyGrn') }}</small>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label>Bin No</label>
                                    <input type="number" class="form-control tab" name="binNo" id="binNo" min="0"
                                           oninput="this.value = Math.abs(this.value)"
                                           placeholder="Bin No"/>
                                    <small class="text-danger">{{ $errors->first('binNo') }}</small>
                                </div>
                            </div>

                        </div>
                        <div class="row">

                            <div class="col-md-3">
                                <label>Buying Price</label>
                                <input type="number" class="form-control tab"
                                       name="bPrice"
                                       id="bPrice" min="0" oninput="this.value = Math.abs(this.value)"
                                       placeholder="Buying Price"/>
                                <small class="text-danger">{{ $errors->first('sPrice') }}</small>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Manufacture Date</label>
                                    <div>
                                        <div class="input-group">
                                            <input type="text" class="form-control datepicker-autoclose tab"
                                                   placeholder="mm/dd/yyyy" name="mFDate" id="mFDate">
                                            <div class="input-group-append">
                                                <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                            </div>
                                        </div><!-- input-group -->
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">

                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input doNotClear tab"
                                               id="defaultChecked2"
                                               onclick="expDate()">
                                        <label class="custom-control-label" for="defaultChecked2">Expire Date</label>
                                    </div>
                                    <div style="margin-top: 5px" class="hideExpDate" id="hideExpDate">
                                    </div>
                                    <small class="text-danger">{{ $errors->first('eDate') }}</small>
                                </div>
                            </div>
                            <div class="col-md-3" style="padding-top: 28px">
                                <button type="button" onclick="addItem(this)" id="addBtn"
                                        class="btn btn-md btn-primary waves-effect waves-light  tab pull-right">
                                    Add to Table
                                </button>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card m-b-20">
                    <div class="card-body">
                        <div class="row">

                            <div class="col-md-12">
                                <div class="alert alert-danger alert-dismissible " id="errorAlert2"
                                     style="display:none">

                                </div>
                            </div>
                        </div>
                        <div class="table-rep-plugin">
                            <div class="table-responsive b-0" data-pattern="priority-columns">
                                <table class="table table-striped table-bordered"
                                       cellspacing="0"
                                       width="100%">
                                    <thead>
                                    <tr>
                                        <th>ITEM NAME</th>
                                        <th>QTY</th>
                                        <th>PO</th>
                                        <th>STORE NAME</th>
                                        <th style="text-align: right;">BUYING PRICE</th>
                                        <th style="text-align: right;">TOTAL PRICE</th>
                                        <th>OPTION</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn  pull-right btn-primary
" onclick="saveStock()">Save Stock
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


{{--update modal--}}
<div class="modal fade" id="updateModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Update Item</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="_token" value="{{ Session::token() }}">
                <input type="hidden" name="hiddenGrnID" id="hiddenGrnID">

                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert1" style="display:none">

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Item Name</label>
                            <select class="form-control select2" name="Uitem" data-measurement="#Umeasurement"
                                    data-qty="#UqtyGrn"
                                    id="Uitem" required>
                                <option value="" disabled selected>Select Item
                                </option>
                                @if(isset($items))
                                    @foreach($items as $item)
                                        <option value="{{"$item->idItems"}}">{{$item->itemcode}}
                                            - {{"$item->itemName"}} </option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Store</label>
                            <select class="form-control select2" name="UsType"
                                    id="UsType" required>
                                <option disabled value="" selected>Select Stock Type
                                </option>
                                @if(isset($stockTypes))
                                    @foreach($stockTypes as $stockType)
                                        <option value="{{"$stockType->idStore"}}">{{$stockType->type}} </option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Qty</label>
                            <input type="number" class="form-control" min="0" data-measurement="#Umeasurement"
                                   oninput="qtyInput(this)" name="UqtyGrn" id="UqtyGrn"
                                   placeholder="Qty GRN"/>
                            <small class="text-danger">{{ $errors->first('qtyGrn') }}</small>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="client_surname">Buying Price</label>
                            <div class="panel-body">
                                <input type="number" class="form-control"
                                       name="UbPrice" min="0" oninput="this.value = Math.abs(this.value)"
                                       id="UbPrice"
                                       placeholder="Buying Price"/>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Bin No</label>
                            <input type="text" class="form-control" name="UbinNo" id="UbinNo" maxlength="25"
                                   placeholder="Bin No"/>
                            <small class="text-danger">{{ $errors->first('binNo') }}</small>
                        </div>
                    </div>


                </div>
                <div class="row">

                    <div class="col-md-4">
                        <div class="form-group">
                            <!-- Default checked -->
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="hasExp"
                                       onchange="UexpDate()">

                                <label class="custom-control-label" for="hasExp">Expire Date</label>
                            </div>
                            <input style="display: none;" type="date" class="form-control mt-1" name="UexpDate"
                                   id="UexpDate" maxlength="25"
                                   placeholder="Exp Date"/>
                            <small class="text-danger">{{ $errors->first('eDate') }}</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Manufacture Date</label>
                            <div>
                                <div class="input-group">
                                    <input type="text" class="form-control datepicker-autoclose"
                                           placeholder="mm/dd/yyyy" name="UmFDate" id="UmFDate">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                    </div>
                                </div><!-- input-group -->
                            </div>
                        </div>
                    </div>
                    <div style="margin-top: 5px;" class="col-md-4 align-content-center">
                        <button type="button" onclick="updateGrn()"
                                class="btn btn-md mt-4 pt-1 btn-warning waves-effect  waves-light">
                            Update GRN
                        </button>
                    </div>
                </div>
                <input type="hidden" id="hiddenIdUpdate">
            </div>
        </div>
    </div>
</div>
{{--end fo update modal--}}


@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}"
        type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}"
        type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>
<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>
<script type="text/javascript">

    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        initializeDate();
        showGrnTempTable();
        $('#datepicker-autoclose').datepicker('setDate', 'today');
    });

    function initializeDate() {
        jQuery('.datepicker-autoclose').datepicker({
            autoclose: true,
            todayHighlight: true
        });

    }

    function clearGrnTempTable() {

        $.ajax({

            type: 'POST',

            url: 'clearGrnTempTable',

            data: {},

            success: function () {


            }

        });
    }

    function deleteRecord(id) {
        $.ajax({
            type: 'POST',

            url: 'deleteTempGrn',

            data: {id: id},

            success: function () {
                showGrnTempTable();

            }
        });

    }

    function expDate() {
        if ($('#defaultChecked2').prop("checked")) {
            var date = '';
            date += "<div  >\n" +
                "      <div class=\"input-group\">\n" +
                "                                        <input type=\"text\" class=\"form-control datepicker-autoclose\" placeholder=\"mm/dd/yyyy\"  name=\"eDate\" id=\"eDate\">\n" +
                "                                        <div class=\"input-group-append\">\n" +
                "                                            <span class=\"input-group-text\"><em class=\"mdi mdi-calendar\"></em></span>\n" +
                "                                        </div>\n" +
                "       </div>\n" +
                "     </div>";

            $("#hideExpDate").html(date);
            initializeDate();
        }
        else {
            $("#hideExpDate").html("");
        }

    }

    function saveStock() {

        $('.alert').hide();
        $('.alert').html("");

        $.post('saveOpeningStock', {}, function (data) {
            if (data.errors != null) {
                $('#errorAlertAdd').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlertAdd').append('<p>' + value + '</p>');
                });
                $('html, body').animate({
                    scrollTop: $("#errorAlertAdd").offset().top
                }, 1000);
            }
            if (data.success != null) {
                $('#saveGrn').modal('hide');
                notify({
                    type: "success", //alert | success | error | warning | info
                    title: 'STOCK SAVED',
                    autoHide: true, //true | false
                    delay: 2500, //number ms
                    position: {
                        x: "right",
                        y: "top"
                    },
                    icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                    message: 'Openning stock saved successfully.'
                });
            }
            showGrnTempTable();

        });
    }

    $(document).on('focus', ':input', function () {
        $(this).attr('autocomplete', 'off');
    });
    function showGrnTempTable() {
        $('#defaultChecked2').prop('checked', false);
        $("#hideExpDate").html("");


        $.ajax({

            type: 'POST',

            url: 'getTempTableDataGrn',

            data: {},

            success: function (data) {

                $('tbody').html(data.tableData);
                $('#payment').val(1).trigger('change');
                $('#datepicker-autoclose').datepicker('setDate', 'today');


            }

        });
    }


    $('.modal').on('hidden.bs.modal', function () {

        $("input").not('.doNotClear').val('');

        $("input").not('.doNotClear').attr('checked', false);


        $('.alert').html('');

        $('.alert').hide();

        $('select').val('').trigger('change');
        $('#company').val(1).trigger('change');
        $('#payment').val(1).trigger('change');

    });

    function showUpdateModal(item) {
        var id = $(item).attr('data-id');
        $.ajax({

            type: 'POST',

            url: 'getGrnTempDataById',

            data: {id: id},

            success: function (data) {

                $('#UsType').val(data.store).trigger('change');
                $('#Uitem').val(data.Items_idItems).trigger('change');
                $('#Umeasurement').val(data.idMeasurement).trigger('change');
                $('#UbinNo').val(data.binNo);
                if (!data.expHave) {
                    $('#hasExp').prop("checked", false);
                    $("#UexpDate").val("").hide();
                }
                else {
                    $("#hasExp").prop("checked", true);
                    $("#UexpDate").val(data.expDate).show();
                }
                $('#UmFDate').val(data.mnfDate);
                $('#UbPrice').val(data.bp);
                $('#UwSPrice').val(data.wp);
                $('#UqtyGrn').val(data.qty_grn);
                $('#UsPrice').val(data.sp);
                $('#hiddenIdUpdate').val(id);

                $('#updateModal').modal('show');


            }

        });
    }


    function addItem() {

        $('.notify').empty();
        $('.alert').hide();
        $('.alert').html("");

        var stock = $("#stock").val();
        var item = $("#item").val();
        var binNo = $("#binNo").val();
        var eDate = $("#eDate").val();
        var mFDate = $("#mFDate").val();
        var bPrice = $("#bPrice").val();
        var qtyGrn = $("#qtyGrn").val();

        $('#qtyMsg').html('');
        $.post('addItemToGRN',
            {
                sType: stock,
                item: item,
                binNo: binNo,
                mFDate: mFDate,
                bPrice: bPrice,
                eDate: eDate,
                qtyGrn: qtyGrn
            },
            function (data) {
                if (data.errors != null) {
                    $('#errorAlertAdd').show();
                    $.each(data.errors, function (key, value) {
                        $('#errorAlertAdd').append('<p>' + value + '</p>');
                    });
                    $('html, body').animate({
                        scrollTop: $("#errorAlertAdd").offset().top
                    }, 1000);
                }
                if (data.success != null) {

                    notify({
                        type: "success", //alert | success | error | warning | info
                        title: 'ITEM ADDED',
                        autoHide: true, //true | false
                        delay: 2500, //number ms
                        position: {
                            x: "right",
                            y: "top"
                        },
                        icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                        message: 'Temporary item  successfully added.'
                    });

                    $('input').val("");
                    $(".select2").val('').trigger('change');
                    $(".custom-control-input").prop("checked", false);
                    setTimeout(function () {
                        $('#item').focus().click();
                    }, 100);
                }
                showGrnTempTable();
            });
    }

    function updateGrn() {

        $('.notify').empty();
        var id = $('#hiddenIdUpdate').val();
        var UsType = $('#UsType').val();
        var Uitem = $('#Uitem').val();
        var UbinNo = $('#UbinNo').val();
        if ($('#hasExp').prop("checked")) {
            var expHave = 1;
            var expDate = $("#UexpDate").val();
        }
        else {
            var expHave = 0;
            var expDate = null;
        }
        var UmFDate = $('#UmFDate').val();
        var UbPrice = $('#UbPrice').val();
        var UwSPrice = $('#UwSPrice').val();
        var UqtyGrn = $('#UqtyGrn').val();
        var UsPrice = $('#UsPrice').val();

        $.ajax({

            type: 'POST',

            url: 'updateTempGrn',

            data: {
                id: id,
                UsType: UsType,
                Uitem: Uitem,
                UbinNo: UbinNo,
                expHave: expHave,
                expDate: expDate,
                UmFDate: UmFDate,
                UbPrice: UbPrice,
                UwSPrice: UwSPrice,
                UqtyGrn: UqtyGrn,
                UsPrice: UsPrice
            },

            success: function (data) {
                if (data.errors != null) {
                    $('#successAlert1').html("");
                    $('#successAlert1').hide();
                    $('#errorAlert1').html('');
                    $('#errorAlert1').show();
                    $.each(data.errors, function (key, value) {
                        $('#errorAlert1').append('<p>' + value + '</p>');
                    });
                }
                if (data.success != null) {
                    $('#errorAlert1').html('');
                    $('#errorAlert1').hide();
                    $('#successAlert1').html("");

                    notify({
                        type: "success", //alert | success | error | warning | info
                        title: 'ITEM UPDATED',
                        autoHide: true, //true | false
                        delay: 2500, //number ms
                        position: {
                            x: "right",
                            y: "top"
                        },
                        icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                        message: 'Item updated successfully.',
                    });
                    $('#updateModal').modal('hide');
                    showGrnTempTable();


                }
            }
        });


    }


    function UexpDate() {
        if ($('#hasExp').prop("checked")) {
            $('#UexpDate').show();
        }
        else {
            $('#UexpDate').hide();
        }
    }


    //keypress functions
    $(".tab").keyup(function (event) {
        if (event.keyCode == 13) {
            textboxes = $(".tab");
            currentBoxNumber = textboxes.index(this);
            if ($(this).val().length > 0 || this.id == 'binNo') {
                if (textboxes[currentBoxNumber + 1] != null) {
                    nextBox = textboxes[currentBoxNumber + 1];
                    nextBox.focus();
                    nextBox.select();
                }
            }
            event.preventDefault();
            return false;
        }
    });


    $(document).on('keypress', function (e) {
        var tag = e.target.tagName.toLowerCase();
        if (e.which === 015 && tag != 'input' && tag != 'textarea' && tag != 'select')
            $('#item').focus();
    });

    function itemChanged(el) {

        let item = el.value;

        $.ajax({
            type: 'POST',

            url: 'getBuyingPrice',

            data: {item: item},

            success: function (data) {
                $('#bPrice').val(data);

            }
        });

    }
</script>


@include('includes.footer_end')