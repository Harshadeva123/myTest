@include('includes.header_start')

<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->
<link href="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">


<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
<link href="{{ URL::asset('assets/css/custom_checkbox.css')}}" rel="stylesheet" type="text/css"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/validations.js')}}"></script>--}}
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/common.js')}}"></script>--}}

@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card m-b-20">
                    <div class="card-body">

                        <form action="receive_payment" method="GET">
                            <div class="row">
                                {{ csrf_field() }}

                                <div class="form-group col-md-2">
                                    <label for="id" class="form-label">Trans ID</label>
                                    <input class="form-control" oninput="this.value = Math.abs(this.value)" min="1" autocomplete="off" type="number" name="id"  id="id">
                                </div>
                                <div class="form-group col-md-3">
                                    <div class="form-group">
                                        <label for="list">To company</label>
                                        <select class="form-control select2 notChangeOnAdd" name="company"
                                                id="company" >
                                            <option value="" disabled selected>
                                            </option>
                                            @if(isset($companies))
                                                @foreach($companies as $company)
                                                    <option value="{{"$company->idCompanyInfo"}}">{{$company->companyName}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-md-5">
                                    <label>Date Range</label>
                                    <div>
                                        <div class="input-daterange input-group" id="date-range">
                                            <input type="text" autocomplete="off" class="form-control" value=""  id="startDate" name="str" />
                                            <input type="text" autocomplete="off" class="form-control" value=""  id="endDate" name="end" />
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group col-md-2">
                                    <button type="submit"  class="btn form-control btn-info waves-effect waves-light" style="margin-top: 25px">Search</button>
                                </div>

                            </div>
                        </form>

                        <div class="row">


                            <div class="col-lg-12">
                                <div class="table-rep-plugin">
                                    <div class="table-responsive b-0" data-pattern="priority-columns">
                                        <table class="table table-striped table-bordered"
                                               cellspacing="0"
                                               width="100%">
                                            <thead>
                                            <tr>
                                                <th>PAYMENT ID</th>
                                                <th>FROM COMPANY</th>
                                                <th>BASE</th>
                                                <th>REF NO</th>
                                                <th>DATE</th>
                                                <th style="text-align: right;">TOTAL AMOUNT</th>
                                                <th>TYPE</th>
                                                <th>VIEW</th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                            @if(isset($payments))
                                                @if(count($payments)>0)
                                                    @foreach($payments as $payment)
                                                        <tr id="{{$payment->idpayment}}" >
                                                            <td>{{sprintf('%06d', $payment->idpayment)}}</td>
                                                            <td>{{$payment->company->companyName}}</td>
                                                            @if($payment->base == 1)
                                                                <td>INVOICE</td>
                                                            @elseif($payment->base == 2)
                                                                <td>GRN</td>
                                                            @elseif($payment->base == 3)
                                                                <td>SPECIAL ORDER</td>
                                                            @elseif($payment->base == 4)
                                                                <td>TRANSFER </td>
                                                            @endif
                                                            @if($payment->id)
                                                                <td>{{sprintf('%06d', $payment->id)}}</td>
                                                            @else
                                                                <td>BULK</td>
                                                            @endif
                                                            <td>{{$payment->created_at->format('Y-m-d')}}</td>
                                                            <td style="text-align: right;">{{number_format($payment->totalAmount,2)}}</td>
                                                            <td >{{$payment->payment->type}}</td>
                                                            <td >
                                                                <div class='button-items'>
                                                                    <button type='button'
                                                                            class='btn btn-sm btn-info  waves-effect waves-light'
                                                                            onclick='viewPaymentsTransfer({{$payment->idpayment}})'>
                                                                        <em class='fa fa-eye'></em>
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                @else
                                                    <tr><td colspan="10" style="text-align: center;">No records.</td></tr>
                                                @endif
                                            @endif
                                            </tbody>
                                        </table>
                                        <button type='button' id="bulkBtn" style="display: none;"
                                                class='btn  btn-primary pull-right waves-effect waves-light'
                                                onclick="doBulkPayment()">
                                            Do Bulk Payment
                                        </button>
                                    </div></div></div>

                        </div>
                        @if(isset($payments))
                            {{$payments->links()}}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="paymenthistory" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Payment History</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">


                <div class="row">
                    <div class="col-md-12">


                        <table class="table table-striped table-bordered"
                               cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th style="text-align: center;">PAYMENT DATE</th>
                                <th style="text-align: center;">CASH</th>
                                <th style="text-align: center;">CHEQUE</th>
                                <th style="text-align: center;">BANK</th>
                                <th style="text-align: center;">VISA</th>
                            </tr>
                            </thead>
                            <tbody id="paymentModalTableBody">
                            </tbody>
                        </table>

                    </div>
                </div>


            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="paymentModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info alert-dismissible " id="successAlert2" style="display:none">


                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert2" style="display:none">

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="form-group">
                            <label for="item">Payment Type</label>
                            <select class="form-control select2" name="payment" onchange="paymentTypeChanged(this)"
                                    id="payment" required>
                                <option disabled value="">Select Payment Type</option>
                                @if(isset($paymentTypes))
                                    @foreach($paymentTypes as $paymentType)
                                        @if( $paymentType->idpayment_type != 7 && $paymentType->idpayment_type != 2)
                                            <option value="{{"$paymentType->idpayment_type"}}">{{$paymentType->type}}</option>
                                        @endif
                                    @endforeach
                                @endif
                            </select>
                        </div>
                        <input type="hidden" id="trasferId">
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="item">Due Amount</label>
                        <div class="input-group ">
                            <div class="input-group-prepend">
                                <div class="input-group-text text-black-50">RS.</div>
                            </div>
                            <input class="form-control text-black-50"  type="number"   id="dueTotal" readonly>
                        </div>
                    </div>

                    <div class="col-md-6 form-group">
                        <label for="item">Paid Amount</label>
                        <div class="input-group ">
                            <div class="input-group-prepend">
                                <div class="input-group-text text-black-50">RS.</div>
                            </div>
                            <input class="form-control text-black-50"  type="number"   id="paidAmount" readonly>
                        </div>
                    </div>

                    <div class="col-md-6 form-group">
                        <label for="item">Net Total</label>
                        <div class="input-group ">
                            <div class="input-group-prepend">
                                <div class="input-group-text text-black-50">RS.</div>
                            </div>
                            <input class="form-control text-black-50"  type="number"   id="netTotal" readonly>
                        </div>
                    </div>
                </div>
                <hr/>
                <div class="row">
                    <div style="display: none" id="paidDueDiv" class="col-lg-12 col-md-12">
                        <h6>CASH PAYMENTS</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="paidDue">Paid Amount</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value);checkMax(this);"  id="paid" name="paid">
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="visaBillDiv" class="col-lg-12 col-md-12">
                        <h6>CARD PAYMENTS</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="visaBill">Card No.</label>
                            <div class="col-md-9">
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="visaBill" name="visaBill">
                            </div>
                        </div>
                        <div class="form-group row" id="cardAmountDiv" >
                            <label class="col-md-3" for="cardAmount">Card Amount.</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="cardAmount" name="cardAmount">
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="chequeDiv" class="col-lg-12 col-md-12">
                        <h6>CHEQUE PAYMENTS</h6>
                        <div class="row">
                            <div class="form-group col-md-6" id="chequeAmountDiv" >
                                <label for="chequeAmount">Cheque Amount</label>
                                <div class="input-group mb-2">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">RS.</div>
                                    </div>
                                    <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="chequeAmount" name="chequeAmount">
                                </div>
                            </div>
                            <div class="form-group col-md-6" >
                                <label  for="name">Bank Name</label>
                                <div >
                                    <select class="form-control select2" name="chequeBankName"
                                            id="chequeBankName" required>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label  for="chequeNo">Cheque No.</label>
                                <div>
                                    <input class="form-control "  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="chequeNo" name="chequeNo">
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="chequeDate">Cheque Date</label>
                                <div >
                                    <div class="input-group">
                                        <input type="text" class="form-control datepicker-autoclose'" placeholder="mm/dd/yyyy" id="chequeDate">
                                        <div class="input-group-append">
                                            <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                        </div>
                                    </div><!-- input-group -->
                                </div>
                            </div>
                            <div class="form-group col-md-2 mt-4 pt-1">
                                <button onclick="addChequeDetailsTemp()" class="btn">Add</button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-rep-plugin">
                                    <div class="table-responsive" data-pattern="priority-columns">
                                        <table class="table table-striped table-bordered"
                                               cellspacing="0"
                                               width="100%">
                                            <thead>
                                            <tr>
                                                <th>BANK NAME</th>
                                                <th>CHEQUE NO</th>
                                                <th>CHEQUE DATE</th>
                                                <th>AMOUNT</th>
                                                <th>DELETE</th>
                                            </tr>
                                            </thead>
                                            <tbody id="chequeDetailsTableData">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="bankDiv" class="col-lg-12 col-md-12">
                        <div class="row">
                            <div class="col-md-12">
                                <h6 >BANK PAYMENTS</h6>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bankName">Bank Name</label>
                                    <select class="form-control select2" name="bankName"
                                            id="bankName" >
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4" id="bankAmountDiv" >
                                <div class="form-group ">
                                    <label for="bankAmount">Amount</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">RS.</div>
                                        </div>
                                        <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="bankAmount" name="bankAmount">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group mt-4 pt-1">
                                    <button class="btn btn-secondary" onclick="addBankDetails(this)" >Add</button>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-rep-plugin">
                                            <div class="table-responsive" data-pattern="priority-columns">
                                                <table class="table table-striped table-bordered"
                                                       cellspacing="0"
                                                       width="100%">
                                                    <thead>
                                                    <tr>
                                                        <th>BANK NAME</th>
                                                        <th>AMOUNT</th>
                                                        <th>DELETE</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="bankDetailsTableData">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class = "col-md-12">
                        <button type="button" onclick="savePayment()"
                                class="btn btn-md btn-info waves-effect pull-right waves-light">
                            Save Payment
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<div class="modal fade" id="bulk_paymentModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info alert-dismissible " id="bulk_successAlert2" style="display:none">


                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="bulk_errorAlert2" style="display:none">

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="form-group">
                            <label for="item">Payment Type</label>
                            <select class="form-control select2" name="bulk_payment" onchange="bulk_paymentTypeChanged(this)"
                                    id="bulk_payment" required>
                                <option disabled value="">Select Payment Type</option>
                                @if(isset($paymentTypes))
                                    @foreach($paymentTypes as $paymentType)
                                        {{--@if(\Illuminate\Support\Facades\Auth::user()->companyInfo->isShop == 1)--}}
                                        {{--<option value="{{"$paymentType->idpayment_type"}}">{{$paymentType->type}}</option>--}}
                                        {{--@else--}}
                                        @if( $paymentType->idpayment_type != 7 && $paymentType->idpayment_type != 2)
                                            <option value="{{"$paymentType->idpayment_type"}}">{{$paymentType->type}}</option>
                                        @endif
                                        {{--@endif--}}
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="item">Due Amount</label>
                        <div class="input-group ">
                            <div class="input-group-prepend">
                                <div class="input-group-text text-black-50">RS.</div>
                            </div>
                            <input class="form-control text-black-50"  type="text"   id="bulk_dueTotal" readonly >
                        </div>
                    </div>

                    <div class="col-md-6 form-group">
                        <label for="item">Paid Amount</label>
                        <div class="input-group ">
                            <div class="input-group-prepend">
                                <div class="input-group-text text-black-50">RS.</div>
                            </div>
                            <input class="form-control text-black-50"  type="text"   id="bulk_paidAmount" readonly>
                        </div>
                    </div>

                    <div class="col-md-6 form-group">
                        <label for="item">Net Total</label>
                        <div class="input-group ">
                            <div class="input-group-prepend">
                                <div class="input-group-text text-black-50">RS.</div>
                            </div>
                            <input class="form-control text-black-50"  type="text"   id="bulk_netTotal" readonly>
                        </div>
                    </div>
                </div>
                <hr/>
                <div class="row">
                    <div style="display: none" id="bulk_paidDueDiv" class="col-lg-12 col-md-12">
                        <h6>CASH PAYMENTS</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="bulk_paidDue">Paid Amount</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value);bulk_checkMax(el)"  id="bulk_paid" name="bulk_paid">
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="bulk_visaBillDiv" class="col-lg-12 col-md-12">
                        <h6>CARD PAYMENTS</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="visaBill">Card No.</label>
                            <div class="col-md-9">
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="bulk_visaBill" name="bulk_visaBill">
                            </div>
                        </div>
                        <div class="form-group row" id="bulk_cardAmountDiv" >
                            <label class="col-md-3" for="cardAmount">Card Amount.</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value);bulk_checkMax(el)"  id="bulk_cardAmount" name="bulk_cardAmount">
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="bulk_chequeDiv" class="col-lg-12 col-md-12">
                        <h6>CHEQUE PAYMENTS</h6>
                        <div class="row">
                            <div class="form-group col-md-6" id="bulk_chequeAmountDiv" >
                                <label for="chequeAmount">Cheque Amount</label>
                                <div class="input-group mb-2">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">RS.</div>
                                    </div>
                                    <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value);bulk_checkMax(el)"  id="bulk_chequeAmount" name="bulk_chequeAmount">
                                </div>
                            </div>
                            <div class="form-group col-md-6" >
                                <label  for="name">Bank Name</label>
                                <div >
                                    <select class="form-control select2" name="bulk_chequeBankName"
                                            id="bulk_chequeBankName" required>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label  for="bulk_chequeNo">Cheque No.</label>
                                <div>
                                    <input class="form-control "  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="bulk_chequeNo" name="bulk_chequeNo">
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="chequeDate">Cheque Date</label>
                                <div >
                                    <div class="input-group">
                                        <input type="text" class="form-control datepicker-autoclose'" placeholder="mm/dd/yyyy" id="bulk_chequeDate">
                                        <div class="input-group-append">
                                            <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                        </div>
                                    </div><!-- input-group -->
                                </div>
                            </div>
                            <div class="form-group col-md-2 mt-4 pt-1">
                                <button onclick="bulk_addChequeDetailsTemp()" class="btn">Add</button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-rep-plugin">
                                    <div class="table-responsive" data-pattern="priority-columns">
                                        <table class="table table-striped table-bordered"
                                               cellspacing="0"
                                               width="100%">
                                            <thead>
                                            <tr>
                                                <th>BANK NAME</th>
                                                <th>CHEQUE NO</th>
                                                <th>CHEQUE DATE</th>
                                                <th>AMOUNT</th>
                                                <th>DELETE</th>
                                            </tr>
                                            </thead>
                                            <tbody id="bulk_chequeDetailsTableData">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="bulk_bankDiv" class="col-lg-12 col-md-12">
                        <div class="row">
                            <div class="col-md-12">
                                <h6 >BANK PAYMENTS</h6>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bankName">Bank Name</label>
                                    <select class="form-control select2" name="bulk_bankName"
                                            id="bulk_bankName" >
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4" id="bulk_bankAmountDiv" >
                                <div class="form-group ">
                                    <label for="bankAmount">Amount</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">RS.</div>
                                        </div>
                                        <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value);bulk_checkMax(el)"  id="bulk_bankAmount" name="bulk_bankAmount">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group mt-4 pt-1">
                                    <button class="btn btn-secondary" onclick="bulk_addBankDetails(this)" >Add</button>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-rep-plugin">
                                            <div class="table-responsive" data-pattern="priority-columns">
                                                <table class="table table-striped table-bordered"
                                                       cellspacing="0"
                                                       width="100%">
                                                    <thead>
                                                    <tr>
                                                        <th>BANK NAME</th>
                                                        <th>AMOUNT</th>
                                                        <th>DELETE</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="bulk_bankDetailsTableData">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class = "col-md-12" style="text-align: center;">
                        <h6>COMPLETING ORDER</h6>
                    </div>
                </div>

                <div class="row">
                    <div class = "col-md-12">
                        <div class="table-rep-plugin">
                            <div class="table-responsive" data-pattern="priority-columns">
                                <table class="table table-striped table-bordered"
                                       cellspacing="0"
                                       width="100%">
                                    <thead>
                                    <tr>
                                        <th>TRNS ID</th>
                                        <th>TOTAL DUE AMOUNT</th>
                                    </tr>
                                    </thead>
                                    <tbody id="BulkTableData">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class = "col-md-12">
                        <button type="button" onclick="bulk_savePayment()"
                                class="btn btn-md btn-info waves-effect pull-right waves-light">
                            Save Payment
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<iframe style="display: none;" id="iframeprint" src=""></iframe>

@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script type="text/javascript">


    $(document).ready(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


    });

    let bulkPayments = [];

    $('.modal').on('hidden.bs.modal', function () {

        $('#payment').val('').trigger('change');
        $('#paid').val('');
        $('#paidDue').val('');
        $('#paidDueDiv').hide();
        $('#visaBill').val('');
        $('#visaBillDiv').hide();
        $('#bankName').val('');
        $('#bankDiv').hide();
        $('#chequeNo').val('');
        $('#chequeDate').val('');
        $('#chequeDiv').hide();
        $('#chequeAmount').val('');
        $('#chequeAmountDiv').hide();
        $('#bankAmount').val('');
        $('#bankAmountDiv').hide();
        $('#cardAmount').val('');
        $('#cardAmountDiv').hide();
        $('#discountDiv').show();
    });


    function viewPaymentModal(id) {
        $.ajax({
            type:'POST',

            url:'viewPaymentModalTransfer',

            data:{id:id},

            success:function(data){
                $('#trasferId').val(id);
                $('#dueTotal').val(data.dueTotal);
                $('#paidAmount').val(data.paidTotal);
                $('#netTotal').val(data.netTotal);
                $('#payment').val('1').trigger('change');
                $('#paymentModal').modal('show');

            }
        });

    }

    function viewPaymentsTransfer(id) {
        $.ajax({
            type:'POST',

            url:'viewPaymentsTransfer',

            data:{id:id},

            success:function(data){
                $('#paymentModalTableBody').html(data);
                $('#paymenthistory').modal('show');

            }
        });
    }


    function addBankDetails(el) {
        $(el).attr('disabled',true);
        let bankName = $('#bankName').val();
        let amount = $('#bankAmount').val();
        // $('#bankDetailsTableData tr:last').after('<tr><td>'+bankName+'</td></tr>');
        $.ajax({
            type:'POST',

            url:'addBankDetailsTemp',

            data:{bankName:bankName,amount:amount},

            success:function(){
                loadBankPaymentstemp();
                $(el).attr('disabled',false);


            }
        });

    }

    function loadBankPaymentstemp() {
        $.ajax({
            type:'POST',

            url:'loadBankDetailsTemp',

            data:{},

            success:function(data){
                $('#bankDetailsTableData').html(data.tableData);
            }
        });

    }

    function paymentTypeChanged(el) {
        let payment = $(el).val();
        $('#paid').val('');
        $('#paidDue').val('');
        $('#paidDueDiv').hide();
        $('#visaBill').val('');
        $('#visaBillDiv').hide();
        $('#bankName').val('');
        $('#bankDiv').hide();
        $('#chequeNo').val('');
        $('#chequeDate').val('');
        $('#chequeDiv').hide();
        $('#chequeAmount').val('');
        $('#chequeAmountDiv').hide();
        $('#bankAmount').val('');
        $('#bankAmountDiv').hide();
        $('#cardAmount').val('');

        $.ajax({
            type:'POST',

            url:'paymentTypeChangedDelete',

            data:{},

            success:function(){
                loadBankPaymentstemp();
                loadChequeDetailsTemp();
            }
        });

        if(payment == 2 || payment == 1){
            $('#paidDue').val('');
            $('#paidDueDiv').show();
        }
        if(payment == 4){
            $('#visaBill').val('');
            $('#visaBillDiv').show();
        }
        if(payment == 3){
            $.ajax({
                type:'POST',

                url:'getBankDetails',

                data:{},

                success:function(data){
                    $('#bankName').html(data);
                    $('#bankAmountDiv').show();
                    $('#bankAmount').val('');
                    $('#bankDiv').show();
                }
            });
        }
        if(payment == 5){
            $('#chequeNo').val('');
            $('#chequeDate').datepicker().datepicker("setDate", new Date());
            $.ajax({
                type:'POST',

                url:'getBankDetails',

                data:{},

                success:function(data){
                    $('#chequeBankName').html(data);
                    $('#chequeDiv').show();
                    $('#chequeAmountDiv').show();

                }
            });
        }
        if(payment == 6) {
            $('#paidDueDiv').show();
            $('#visaBillDiv').show();
            $('#bankDiv').show();
            $('#chequeDate').datepicker().datepicker("setDate", new Date());
            $('#chequeAmountDiv').show();
            $('#bankAmountDiv').show();
            $('#cardAmountDiv').show();
            $('#chequeDiv').show();
            $.ajax({
                type: 'POST',

                url: 'getBankDetails',

                data: {},

                success: function (data) {
                    $('#chequeBankName').html(data);
                    $('#bankName').html(data);
                }
            });
        }
        if(payment == 7) {
            $('.discountDiv').hide();
            $('#discount').val('0');

        }


    }

    function calTotal() {
        let qty = parseFloat($('#qty').val());
        let rate = parseFloat($('#rate').val());
        let discount = parseFloat($('#discount').val()) || 0;
        let available = parseFloat($('#available').val());
        let pass = true;
        let measurement = $('#measurement').val().toLowerCase();

        if(qty <= 0){
            $('#qty').val(0);
        }else {

            if (measurement == 'nos') {
                qty = Math.floor(qty);
                $('#qty').val(qty);
            }

            if (qty > available) {
                $('#qty_msg').html('Qty can not be grater than available qty.');
                $('#qty').val(available);
                qty = available;
                pass = false;

            }
            else {
                $('#qty_msg').html('');
            }

            if (discount > (qty * rate)) {
                $('#discount_msg').html('Discount can not be grater than total amount.');
                $('#discount').val(qty * rate);
                discount = qty * rate;
                pass = false;

            }
            else {
                $('#discount_msg').html('');
            }

            $('#ItemTotal').val((qty * rate) - discount);
            return pass;
        }
    }

    $('#qty').keypress(function(event){

        let keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            if ( $(this).val().length > 0) {
                addItem();
            }

        }
        event.stopPropagation();
    });

    function addChequeDetailsTemp(){
        let chequeNo = $('#chequeNo').val();
        let chequeAmount = $('#chequeAmount').val();
        let chequeDate = $('#chequeDate').val();
        let bankName = $('#chequeBankName').val();

        $.ajax({
            type:'POST',

            url:'addChequeDetailsTemp',

            data:{chequeDate:chequeDate,chequeAmount:chequeAmount,chequeNo:chequeNo,bankName:bankName},

            success:function(){
                loadChequeDetailsTemp();
            }
        });
    }

    function loadChequeDetailsTemp() {
        $.ajax({
            type:'POST',

            url:'loadChequeDetailsTemp',

            data:{},

            success:function(data){
                $('#chequeDetailsTableData').html(data.tableData);
            }
        });

    }

    function ChequePaymentTempDelete(el) {
        let id = $(el).attr('data-id');
        $.ajax({
            type:'POST',

            url:'ChequePaymentTempDelete',

            data:{id:id},

            success:function(data){
                $('#'+id).remove();
            }
        });

    }

    function BankPaymentsTempDelete(el) {
        let id = $(el).attr('data-id');
        $.ajax({
            type:'POST',

            url:'BankPaymentsTempDelete',

            data:{id:id},

            success:function(data){
                $('#'+id).remove();
            }
        });

    }

    function showTableData() {
        $.ajax({
            type:'POST',

            url:'showTableDataTransfer',

            success:function(){
            }
        });

    }

    function countNet() {

        let discoutInput =  parseFloat($('#discount').val());
        let total = parseFloat($('#totalAmount').val());
        let discountType = $("#discountType").val();
        if(discountType == 1){
            discount = parseFloat(total*(discoutInput/100));
            if(discoutInput>100){
                $('#discount').val(100);
            }

            let NewdiscountInput = parseFloat($('#discount').val());
            let Newtotal = parseFloat($('#totalAmount').val());
            Newdiscount = parseFloat(Newtotal*(NewdiscountInput/100));
            $('#net').val(parseFloat(Newtotal-Newdiscount).toFixed(2));
        }
        if(discountType == 2){
            discount = discoutInput;
            if(discount>total){
                $('#discount').val(parseFloat(total));
            }

            let Newdiscount = parseFloat($('#discount').val());
            let Newtotal = parseFloat($('#totalAmount').val());
            $('#net').val(parseFloat(Newtotal-Newdiscount).toFixed(2));
        }
    }

    function savePayment(el) {
        $('#successAlert2').hide();
        $('#errorAlert').hide();
        $('#successAlert1').html("");
        $('#errorAlert2').html("");
        $(el).attr('disabled',true);

        let payment = $("#payment").val();
        let paid = $("#paid").val();
        let visaBill = $("#visaBill").val();
        let cardAmount = $('#cardAmount').val();
        let id = $('#trasferId').val();

        $.post('addPaymentTransfer', {
            payment: payment,
            id: id,
            paid: paid,
            visaBill: visaBill,
            cardAmount: cardAmount,
        }, function (data) {
            $(el).attr('disabled',false);
            if (data.errors != null) {
                $('#errorAlert2').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlert2').append('<p>' + value + '</p>');
                });
            }
            if (data.success != null) {
                $('#successAlert2').show();
                $('#successAlert2').show().fadeOut(2000);
                $('#successAlert2').append('<p>' + data.success + '</p>');

                if(data.isComplete){
                    $('#'+id).remove();
                }
                else{
                    $('#paidTotalAmount-'+id).html(data.paidTotal);
                }
                $('#paymentModal').modal('hide');
                print(data.id);
                // window.location = 'PrintInvoice/'+data.id+'';
//                 swal({
//                     title: 'Saved!',
//                     text: 'Payment added successfully.',
//                     type: "success"
//                 });

            }
        });
    }

    function print(id)    {
        var _this = this,
            iframeId = 'iframeprint',
            $iframe = $('iframe#iframeprint');
        $iframe.attr('src',  'printTransferStockBulk/'+id+'');

        $iframe.load(function() {
            _this.callPrint(iframeId);
        });
    }

    //initiates print once content has been loaded into iframe
    function callPrint(iframeId) {
        var PDF = document.getElementById(iframeId);
        PDF.focus();
        PDF.contentWindow.print();
    }

    function bulkPaymentSelect(id) {
        let bulk = $('#bulk-'+id).prop("checked");
        if(bulk == true){
            if($.inArray( id, bulkPayments ) == -1){

                bulkPayments.push(id);
            }
        }
        else{
            bulkPayments = jQuery.grep(bulkPayments, function(value) {
                return value != id;
            });
        }

        if(bulkPayments.length > 1 ){

            $('#bulkBtn').show();
        }
        else{
            $('#bulkBtn').hide();

        }

    }

    function doBulkPayment() {
        if(bulkPayments.length > 1 ){
            $.ajax({
                type:'POST',

                url:'viewBulkPaymentModalTransfer',

                data:{bulkPayments:bulkPayments},

                success:function(data){
                    $('#bulk_dueTotal').val(data.dueTotal);
                    $('#bulk_dueTotal').attr('data-value',data.dueTotalP);
                    $('#bulk_paidAmount').val(data.paidTotal);
                    $('#bulk_netTotal').val(data.netTotal);
                    $('#bulk_payment').val('1').trigger('change');
                    $('#BulkTableData').html(data.tableData);
                    $('#bulk_paymentModal').modal('show');

                }
            });

        }
    }

    function bulk_paymentTypeChanged(el) {
        let payment = $(el).val();
        $('#bulk_paid').val('');
        $('#bulk_paidDue').val('');
        $('#bulk_paidDueDiv').hide();
        $('#bulk_visaBill').val('');
        $('#bulk_visaBillDiv').hide();
        $('#bulk_bankName').val('');
        $('#bulk_bankDiv').hide();
        $('#bulk_chequeNo').val('');
        $('#bulk_chequeDate').val('');
        $('#bulk_chequeDiv').hide();
        $('#bulk_chequeAmount').val('');
        $('#bulk_chequeAmountDiv').hide();
        $('#bulk_bankAmount').val('');
        $('#bulk_bankAmountDiv').hide();
        $('#bulk_cardAmount').val('');

        $.ajax({
            type:'POST',

            url:'paymentTypeChangedDelete',

            data:{},

            success:function(){
                bulk_loadBankPaymentstemp();
                bulk_loadChequeDetailsTemp();
            }
        });

        if(payment == 2 || payment == 1){
            $('#bulk_paidDue').val('');
            $('#bulk_paidDueDiv').show();
        }
        if(payment == 4){
            $('#bulk_visaBill').val('');
            $('#bulk_visaBillDiv').show();
        }
        if(payment == 3){
            $.ajax({
                type:'POST',

                url:'getBankDetails',

                data:{},

                success:function(data){
                    $('#bulk_bankName').html(data);
                    $('#bulk_bankAmountDiv').show();
                    $('#bulk_bankAmount').val('');
                    $('#bulk_bankDiv').show();
                }
            });
        }
        if(payment == 5){
            $('#bulk_chequeNo').val('');
            $('#bulk_chequeDate').datepicker().datepicker("setDate", new Date());
            $.ajax({
                type:'POST',

                url:'getBankDetails',

                data:{},

                success:function(data){
                    $('#bulk_chequeBankName').html(data);
                    $('#bulk_chequeDiv').show();
                    $('#bulk_chequeAmountDiv').show();

                }
            });
        }
        if(payment == 6) {
            $('#bulk_paidDueDiv').show();
            $('#bulk_visaBillDiv').show();
            $('#bulk_bankDiv').show();
            $('#bulk_chequeDate').datepicker().datepicker("setDate", new Date());
            $('#bulk_chequeAmountDiv').show();
            $('#bulk_bankAmountDiv').show();
            $('#bulk_cardAmountDiv').show();
            $('#bulk_chequeDiv').show();
            $.ajax({
                type: 'POST',

                url: 'getBankDetails',

                data: {},

                success: function (data) {
                    $('#bulk_chequeBankName').html(data);
                    $('#bulk_bankName').html(data);
                }
            });
        }
        if(payment == 7) {
            $('.discountDiv').hide();
            $('#bulk_discount').val('0');

        }


    }

    function bulk_addChequeDetailsTemp(){
        let chequeNo = $('#bulk_chequeNo').val();
        let chequeAmount = $('#bulk_chequeAmount').val();
        let chequeDate = $('#bulk_chequeDate').val();
        let bankName = $('#bulk_chequeBankName').val();

        $.ajax({
            type:'POST',

            url:'addChequeDetailsTemp',

            data:{chequeDate:chequeDate,chequeAmount:chequeAmount,chequeNo:chequeNo,bankName:bankName},

            success:function(){
                bulk_loadChequeDetailsTemp();
            }
        });
    }

    function bulk_loadChequeDetailsTemp() {
        $('#bulk_chequeNo').val('');
        $('#bulk_chequeAmount').val('');

        $.ajax({
            type:'POST',

            url:'loadChequeDetailsTemp',

            data:{},

            success:function(data){
                $('#bulk_chequeDetailsTableData').html(data.tableData);
            }
        });

    }

    function bulk_loadBankPaymentstemp() {

        $('#bulk_bankAmount').val('');

        $.ajax({
            type:'POST',

            url:'loadBankDetailsTemp',

            data:{},

            success:function(data){
                $('#bulk_bankDetailsTableData').html(data.tableData);
            }
        });

    }

    function bulk_addBankDetails(el) {
        $(el).attr('disabled',true);
        let bankName = $('#bulk_bankName').val();
        let amount = $('#bulk_bankAmount').val();
        // $('#bankDetailsTableData tr:last').after('<tr><td>'+bankName+'</td></tr>');
        $.ajax({
            type:'POST',

            url:'addBankDetailsTemp',

            data:{bankName:bankName,amount:amount},

            success:function(){
                bulk_loadBankPaymentstemp();
                $(el).attr('disabled',false);


            }
        });
    }


    function bulk_savePayment(el) {
        $('#bulk_successAlert2').hide();
        $('#bulk_errorAlert').hide();
        $('#bulk_successAlert1').html("");
        $('#bulk_errorAlert2').html("");
        $(el).attr('disabled',true);


        let visaBill = $("#bulk_visaBill").val();
        let payment = parseInt($('#bulk_payment').val());
        let paid = parseFloat($('#bulk_paid').val());
        let cardAmount = parseFloat($('#bulk_cardAmount').val());
        let total = parseFloat($('#bulk_dueTotal').attr('data-value'));
        let bankTotal  = 0;
        let chequeTotal  = 0;
        let pass = true;
        if(payment == 6) {

            $.ajax({
                type:'POST',

                url:'totalChequeAmountTemp',

                data:{},

                success:function(data){
                    chequeTotal = parseFloat(data);

                }
            });

            $.ajax({
                type:'POST',

                url:'totalBankAmountTemp',

                data:{},

                success:function(data){
                    bankTotal = parseFloat(data);
                }
            });


        }

        if(total < paid + cardAmount + bankTotal + chequeTotal){
            pass = false;
        }

        if(pass) {

            $.post('bulk_addPaymentTransfer', {
                payment: payment,
                bulkPayments: bulkPayments,
                paid: paid,
                visaBill: visaBill,
                cardAmount: cardAmount,
            }, function (data) {
                $(el).attr('disabled', false);
                if (data.errors != null) {
                    $('#bulk_errorAlert2').show();
                    $.each(data.errors, function (key, value) {
                        $('#bulk_errorAlert2').append('<p>' + value + '</p>');
                    });
                }
                if (data.success != null) {
                    $('#bulk_successAlert2').show();
                    $('#bulk_successAlert2').show().fadeOut(2000);
                    $('#bulk_successAlert2').append('<p>' + data.success + '</p>');

                    $('#bulk_paymentModal').modal('hide');
                    printBulk(data.id);

                    for (let i = 0; i < bulkPayments.length; i++) {
                        if (data.paidTotal[bulkPayments[i]][1]) {
                            $('#' + bulkPayments[i]).remove();
                        }
                        else {
                            $('#paidTotalAmount-' + bulkPayments[i]).html(data.paidTotal[bulkPayments[i]][0]);
                        }
                    }


//                 window.location = 'PrintInvoice/'+data.id+'';
//                 swal({
//                     title: 'Saved!',
//                     text: 'Payment added successfully.',
//                     type: "success"
//                 });

                }
            });
        }
        else{
            $('#bulk_errorAlert2').html('Paid amount is grater than due amount.').show();
            $(el).attr('disabled',true);

        }
    }

    function printBulk(id)    {
        var _this = this,
            iframeId = 'iframeprint',
            $iframe = $('iframe#iframeprint');
        $iframe.attr('src', 'printTransferStockBulk/'+id+'');

        $iframe.load(function() {
            _this.callPrint(iframeId);
        });
    }

    function bulk_checkMax(el) {
        let payment = parseInt($('#bulk_payment').val());
        let paid = parseFloat($('#bulk_paid').val());
        let card = parseFloat($('#bulk_cardAmount').val());
        let cheque = parseFloat($('#bulk_chequeAmount').val());
        let bank = parseFloat($('#bulk_bankAmount').val());
        let total = parseFloat($('#bulk_dueTotal').attr('data-value'));

        if(payment == 1) {
            if (total < paid) {
                $('#bulk_paid').val(total);
            }
        }
        if(payment == 3) {

            $.ajax({
                type:'POST',

                url:'totalBankAmountTemp',

                data:{},

                success:function(data){
                    if (total < parseFloat(data) + bank) {
                        $('#bulk_bankAmount').val(total - parseFloat(data));
                    }
                }
            });

        }

        if(payment == 5) {
            $.ajax({
                type:'POST',

                url:'totalChequeAmountTemp',

                data:{},

                success:function(data){
                    if (total < parseFloat(data) + cheque) {
                        $('#bulk_chequeAmount').val(total - parseFloat(data));
                    }
                }
            });

        }
        if(payment == 4) {
            if (total < card) {
                $('#bulk_cardAmount').val(total);
            }
        }

        if(payment == 6) {

            $.ajax({
                type:'POST',

                url:'totalChequeAmountTemp',

                data:{},

                success:function(data){
                    if (total < parseFloat(data) + cheque) {
                        $('#bulk_chequeAmount').val(total - parseFloat(data));
                    }
                }
            });

            $.ajax({
                type:'POST',

                url:'totalBankAmountTemp',

                data:{},

                success:function(data){
                    if (total < parseFloat(data) + cheque) {
                        $('#bulk_chequeAmount').val(total - parseFloat(data));
                    }
                }
            });


        }
    }

</script>


@include('includes.footer_end')