@include('includes.header_start')

<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
      type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->
<link href="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.css')}}" rel="stylesheet"
      type="text/css"/>
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">


<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}"
      rel="stylesheet"/>
<link href="{{ URL::asset('assets/css/custom_checkbox.css')}}" rel="stylesheet" type="text/css"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>


@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">


    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card m-b-20">
                    <div class="card-body">
                        <form action="{{route('grnSearch')}}" method="GET">
                            <div class="row">
                                {{ csrf_field() }}



                                <div class="form-group col-md-3 ">
                                    <label for="id">Search By</label>
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <select class="form-control  " name="idType"
                                                    id="idType" required>
                                                <option  value="idGRN " selected>GRN NO</option>
                                                <option  value="invNo">INVOICE NO</option>
                                                <option  value="poNo">PO NO</option>
                                            </select>
                                        </div>
                                        <input class="form-control " type="number"  min="0"  id="id" name="id">

                                    </div>
                                </div>

                                <div class="form-group col-md-4">
                                    <label>By Date Range</label>

                                        <div class="input-daterange input-group" id="date-range">
                                            <input placeholder="dd/mm/yy" type="text" autocomplete="off"
                                                   class="form-control" value="" id="startDate" name="start"/>
                                            <input placeholder="dd/mm/yy" type="text" autocomplete="off"
                                                   class="form-control" value="" id="endDate" name="end"/>

                                    </div>
                                </div>

                                <div class="form-group col-md-3">
                                    <label for="supplier">By Supplier</label>
                                    <div class="form-group">
                                        <select class="form-control select2" name="supplier"
                                                id="supplier" >
                                            <option value="" disabled selected>Select supplier
                                            </option>
                                            @if(isset($suppliers))
                                                @foreach($suppliers as $supplier)
                                                    <option value="{{"$supplier->idSupplier"}}">{{"$supplier->companyName"}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-md-2">
                                    <button type="submit" class="btn form-control btn-info waves-effect waves-light"
                                            style="margin-top: 28px">Search
                                    </button>
                                </div>

                            </div>
                        </form>


                        <br/>

                        <div class="row">
                            <div class="col-md-12">

                                <div class="table-rep-plugin">
                                    <div class="table-responsive b-0" data-pattern="priority-columns">
                                        <table class="table table-striped table-bordered"
                                               cellspacing="0"
                                               width="100%">
                                            <thead>
                                            <tr>
                                                <th>GRN NO</th>
                                                {{--<th>COMPANY</th>--}}
                                                <th>SUPPLIER</th>
                                                <th style="text-align: right">TOTAL</th>
                                                <th style="text-align: right">DISCOUNT</th>
                                                <th style="text-align: right">NET TOTAL</th>
                                                <th>DATE</th>
                                                <th>USER</th>
                                                <TH>CREATED AT</TH>
                                                <TH>LAST UPDATED</TH>
                                                <th>OPTION</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @if(isset($grns))
                                                @if(count($grns) > 0)
                                                    @foreach($grns as $grn)
                                                        <tr id="{{$grn->idGRN}}">
                                                            <td>{{str_pad($grn->idGRN,5,'0',STR_PAD_LEFT)}}</td>
                                                            {{--<td>{{$grn->CompanyInfo->companyName}}</td>--}}
                                                            <td>{{$grn->supplier->companyName}}</td>
                                                            <td style="text-align: right">{{number_format($grn->total,2)}}</td>
                                                            <td style="text-align: right">{{number_format($grn->discount,2)}}</td>
                                                            <td style="text-align: right">{{number_format($grn->net_total,2)}}</td>
                                                            <td>{{$grn->date}}</td>

                                                            <td>{{$grn->User->fName}}</td>
                                                            <td>{{$grn->created_at}}</td>
                                                            <td>{{$grn->updated_at}}</td>

                                                            <td>
                                                                <div class="dropdown">
                                                                    <button class="btn btn-secondary dropdown-toggle"
                                                                            type="button" id="dropdownMenuButton"
                                                                            data-toggle="dropdown" aria-haspopup="true"
                                                                            aria-expanded="false">
                                                                        Option
                                                                    </button>
                                                                    <div class="dropdown-menu"
                                                                         aria-labelledby="dropdownMenuButton">
                                                                        <a href="#" class="dropdown-item"
                                                                           onclick='viewStock(this)' data-toggle="modal"
                                                                           data-id="{{$grn->idGRN}}" id="invoiceId">View
                                                                            Items
                                                                        </a>
                                                                        <a href="#"
                                                                           class='dropdown-item'
                                                                           data-id='{{$grn->idGRN}}'
                                                                           onclick='viewMoreGrn(this)'>
                                                                            More
                                                                        </a>
                                                                    </div>

                                                                </div>
                                                            </td>
                                                            </td>
                                                        </tr>

                                                    @endforeach
                                                @else
                                                    <tr>
                                                        <td colspan="10" style="text-align: center;font-weight: 500">Sorry No Results Found.</td>
                                                    </tr>
                                                @endif
                                            @endif
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @if(isset($grns))
                            {{$grns->links()}}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


{{--save GRN moal--}}
<div class="modal fade" id="regModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">More</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">


                <div class="row">
                    <div class="col-md-12">

                        <table class="table table-striped table-bordered"
                               cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>

                            </tr>
                            </thead>
                            <tbody id="modalTableData">
                            </tbody>
                        </table>

                    </div>
                </div>


            </div>
        </div>
    </div>
</div>

{{--save GRN moal--}}
<div class="modal fade" id="stockModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">GRN Items</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">


                <div class="row">
                    <div class="col-md-12">

                        <div class="table-rep-plugin">
                            <div class="table-responsive b-0" data-pattern="priority-columns">
                                <table class="table table-striped table-bordered"
                                       cellspacing="0"
                                       width="100%">
                                    <thead>
                                    <tr>
                                        <th>ITEM NAME</th>
                                        <th>BASE REF</th>
                                        <th>BASE</th>
                                        <th  style="text-align: right;">QTY</th>
                                        <th style="text-align: right;">MANF DATE</th>
                                        <th style="text-align: right;">EXP DATE</th>
                                        <th style="text-align: right;">BUYING PRICE</th>

                                    </tr>
                                    </thead>
                                    <tbody id="stockModalTableData">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
</div>
@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}"
        type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}"
        type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script type="text/javascript">


    $(document).ready(function () {
        $('form').parsley();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

//        loadGrnItemTempTable();

    });


    function loadGrnMainCategory() {
        var grnMainItemType = $("#grnMainItemType").val();
        $.post('mainCategoryGrn', {
            grnMainItemType: grnMainItemType,

        }, function (data) {

            var content = "";
            for (var x = 0; x < data.length; x++) {
                content += "<option value='" + data[x].idItem_Category + "'>" + data[x].catName + "</option>";
            }
            $('#grnMainCategory').html(content);
        });
    }

    function loadGrnSubCategory() {
        var grnMainCategory = $("#grnMainCategory").val();
        $.post('subCategoryGrn', {
            grnMainCategory: grnMainCategory,

        }, function (data) {
            //alert(data);
            var content = "";
            for (var x = 0; x < data.length; x++) {
                content += "<option value='" + data[x].idItem_Sub_Category + "'>" + data[x].subCatName + "</option>";
            }
            $('#grnSubCategory').html(content);
            loadGrnItemName();
        });
    }


    $('#chTable').on('click', function () {
        if ($(this).is(":checked")) {
            $("#datepicker-autoclose").removeAttr("disabled", "disabled");
        } else {
            $("#datepicker-autoclose").attr("disabled", "disabled");
        }
    });

    $('#updateExpHave').on('click', function () {
        if ($(this).is(":checked")) {
            $("#updateGrnExpDate").removeAttr("disabled", "disabled");
        } else {
            $("#updateGrnExpDate").attr("disabled", "disabled");
        }
    });


    jQuery('#updateGrnExpDate').datepicker({
        autoclose: true,
        todayHighlight: true
    });

    $('#updateExpHave').on('click', function () {
        if ($(this).is(":checked")) {
//            alert("gfgfgfgfgffgfg");
            $("#updateGrnDate").removeAttr("disabled", "disabled");
        } else {
            $("#updateGrnDate").attr("disabled", "disabled");
        }
    });


    function addGrnItemTemp() {

        $('#successAlert1').hide();
        $('#errorAlert1').hide();
        $('#successAlert1').html("");
        $('#errorAlert1').html("");

        var grnItemName = $("#grnItemName").val();
        var grnMeasurement = $("#grnMeasurement").val();
        var grnQty = $("#grnQty").val();
        var grnMinQty = $("#grnMinQty").val();
        var grnBinNo = $("#grnBinNo").val();
        var grnBuyPrice = $("#grnBuyPrice").val();
        var grnSelling = $("#grnSelling").val();
        var expDate = $("#datepicker-autoclose").val();
        var chTable = 1;

        if ($('#chTable').is(':checked')) {
            chTable = 1;
        } else {
            chTable = 0;
        }

        if (chTable == 1 && (expDate == "" || expDate == null)) {
            $('#errorAlert1').show();
            $('#errorAlert1').append('<p>Please provide valid Expiry Date.</p>');
            $('#errorAlert1').append("<p><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span> </button></p>");
            return;
        }


        $.post('saveGrnItemTemp', {

            grnItemName: grnItemName,
            grnMeasurement: grnMeasurement,
            grnQty: grnQty,
            grnMinQty: grnMinQty,
            grnBinNo: grnBinNo,
            grnBuyPrice: grnBuyPrice,
            grnSelling: grnSelling,
            expDate: expDate,
            chTable: chTable

        }, function (data) {
            //alert(data);
            if (data.errors != null) {
                $('#errorAlert1').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlert1').append('<p>' + value + '</p>');
                    $('#errorAlert1').append("<p><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span> </button></p>");

                });
            }
            if (data.success != null) {
                $('#successAlert1').show();
                $('#successAlert1').append('<p>' + data.success + '</p>');
                $('#successAlert1').append("<p><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span> </button></p>");
                $("#grnMeasurement").val("");
                $("#grnQty").val("");
                $("#grnMinQty").val("");
                $("#grnBinNo").val("");
                $("#grnBuyPrice").val("");
                $("#grnSelling").val("");
                $("#datepicker-autoclose").val("");
                $("#chTable").val("");

//                loadGrnItemTempTable();
            }
        });
    }

    function addGRN() {

        $('#successAlert2').hide();
        $('#errorAlert2').hide();
        $('#successAlert2').html("");
        $('#errorAlert2').html("");
        $('#successAlert1').hide();
        $('#errorAlert1').hide();
        $('#successAlert1').html("");
        $('#errorAlert1').html("");

        var save_GrnNo = $("#save_GrnNo").val();
        var save_GrnSupplier = $("#save_GrnSupplier").val();
        var save_GrnPoNo = $("#save_GrnPoNo").val();
        var save_InvoiceNo = $("#save_InvoiceNo").val();
        var save_Total = $("#save_Total").val();
        var save_NetTotal = $("#save_NetTotal").val();
        var save_PaymentType = $("#save_PaymentType").val();
        var datepicker = $("#datepicker").val();


        $.post('saveGrn', {

            save_GrnNo: save_GrnNo,
            save_GrnSupplier: save_GrnSupplier,
            save_GrnPoNo: save_GrnPoNo,
            save_InvoiceNo: save_InvoiceNo,
            save_Total: save_Total,
            save_NetTotal: save_NetTotal,
            save_PaymentType: save_PaymentType,
            datepicker: datepicker

        }, function (data) {
//            alert(data);
            if (data.errors != null) {
                $('#errorAlert2').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlert2').append('<p>' + value + '</p>');
                    $('#errorAlert2').append("<p><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span> </button></p>");
                });
            }
            if (data.success != null) {
//                $('#successAlert2').show();
//                $('#successAlert2').append('<p>' + data.success + '</p>');
//                $('#successAlert2').append("<p><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span> </button></p>");
                $("#save_GrnNo").val("");
                $("#save_GrnSupplier").val("");
                $("#save_GrnPoNo").val("");
                $("#save_InvoiceNo").val("");
                $("#save_Total").val("");
                $("#save_NetTotal").val("");
                $("#save_PaymentType").val("");
                $("#datepicker").val("");
                $('#myModal').modal('hide');

                swal(
                    'Saved!',
                    'GRN saved successfully.',
                    'success'
                )
                loadGrnItemTempTable();
            }
        });
    }

    function editGrnItemtemp() {

        $('#successAlert1').hide();
        $('#errorAlert1').hide();
        $('#successAlert1').html("");
        $('#errorAlert1').html("");

        var hiddenGID = $("#hiddenGID").val();
        var updateGrnUom = $("#updateGrnUom").val();
        var updateGrnQty = $("#updateGrnQty").val();
        var updateGrnMinQty = $("#updateGrnMinQty").val();
        var updateGrnBinNo = $("#updateGrnBinNo").val();
        var updateGrnBuyPrice = $("#updateGrnBuyPrice").val();
        var updateGrnSelling = $("#updateGrnSelling").val();
        var updateGrnExpDate = $("#updateGrnExpDate").val();

        $.post('updateGrnItemTemp', {

            hiddenGID: hiddenGID,
            updateGrnUom: updateGrnUom,
            updateGrnQty: updateGrnQty,
            updateGrnMinQty: updateGrnMinQty,
            updateGrnBinNo: updateGrnBinNo,
            updateGrnBuyPrice: updateGrnBuyPrice,
            updateGrnSelling: updateGrnSelling,
            updateGrnExpDate: updateGrnExpDate

        }, function (data) {
//            alert(data);
            if (data.errors != null) {
                $('#errorAlert1').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlert1').append('<p>' + value + '</p>');
                    $('#errorAlert1').append("<p><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span> </button></p>");
                });
            }
            if (data.success != null) {
                $('#successAlert1').show();
                $('#successAlert1').append('<p>' + data.success + '</p>');
                $('#successAlert1').append("<p><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span> </button></p>");
                $("#hiddenGID").val("");
                $("#updateGrnUom").val("");
                $("#updateGrnQty").val("");
                $("#updateGrnMinQty").val("");
                $("#updateGrnBinNo").val("");
                $("#updateGrnBuyPrice").val("");
                $("#updateGrnSelling").val("");
                $("#updateGrnExpDate").val();
                $('#myModal1').modal('hide');
                loadGrnItemTempTable();
            }
        });
    }

    //    function loadGrnItemTempTable() {
    //        $.post('viewGrnItemTemp', {}, function (data) {
    //            var content = "";
    //            for (var x = 0; x < data.length; x++) {
    //
    //                content += "<tr>";
    //                content += "<td>" + data[x].grnItemName + "</td>";
    //                content += "<td>" + data[x].measName + "</td>";
    //                content += "<td>" + data[x].gty_grn + "</td>";
    //                content += "<td>" + data[x].qty_min + "</td>";
    //                if (data[x].expHave == 1) {
    //                    content += "<td>" + data[x].expDate + "</td>";
    //                } else {
    //                    content += "<td></td>";
    //                }
    //                content += "<td>" + data[x].bp.toFixed(2) + "</td>";
    //                content += "<td>" + data[x].sp.toFixed(2) + "</td>";
    //                content += "<td>" + parseFloat(data[x].bp * data[x].gty_grn).toFixed(2) + "</td>";
    //                content += "<td>";
    //                content += "<p style='text-align: center'>";
    //                content += "<button type='button' data-gid='" + data[x].idGRn_Temp + "' data-toggle='modal' data-target='#myModal1' class='btn btn-sm btn-warning waves-effect waves-light'>";
    //                content += "<i class='fa fa-edit'></i>"
    //                content += "</button>";
    //                content += "</p>";
    //                content += "</td>";
    //                content += "<td>";
    //                content += "<p style='text-align: center'>";
    //                content += "<button type='button' onclick='removeGrn(" + data[x].idGRn_Temp + ")'  class='btn btn-sm btn-danger waves-effect waves-light'>";
    //                content += "<i class='ion-close-circled'></i>"
    //                content += "</button>";
    //                content += "</p>";
    //                content += "</td>";
    //                content += "</tr>";
    //
    //            }
    //            $('#grnTempTableBody').html(content);
    //
    //
    //            if (data.length > 0) {
    //                $('#viewSaveGRNButton').show();
    //            } else {
    //                $('#viewSaveGRNButton').hide();
    //            }
    //
    //
    //        });
    //    }

    $('#myModal1').on('show.bs.modal', function (event) {

        $('#successAlert1').hide();
        $('#errorAlert1').hide();
        $('#successAlert1').html("");
        $('#errorAlert1').html("");

        var button = $(event.relatedTarget);
        var gid = button.data('gid');

        $.post('getgrnitemtempById', {gid: gid}, function (data) {

            $('#hiddenGID').val(data['idGRn_Temp']);
//            alert(data['idGRn_Temp']);
            $('#updateGrnItemName').val(data['GrnItemName']);
            $('#updateGrnUom').val(data['idMeasurement']);
            $('#updateGrnQty').val(data['gty_grn']);
            $('#updateGrnMinQty').val(data['qty_min']);
            $('#updateGrnBinNo').val(data['binNo']);
            $('#updateGrnBuyPrice').val(data['bp']);
            $('#updateGrnSelling').val(data['sp']);
            if (data['expHave'] == 1) {
                $('#updateExpHave').prop('checked', true);
            } else {
                $('#updateExpHave').prop('checked', false);
            }
            $('#updateGrnExpDate').val(data['expDate']);
        });

    });


    function removeGrn(rid) {

        swal({
            title: 'Do you want to delete this Item?',
            text: "You won't be able to revert this!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, Delete it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success',
            cancelButtonClass: 'btn btn-danger m-l-10',
            buttonsStyling: false
        }).then(function () {


            $.post('removeGrnItemTable', {rid: rid}, function (data) {

                if (data == "1") {
                    swal(
                        'Deleted!',
                        'Item deleted successfully.',
                        'success'
                    )
                    loadGrnItemTempTable();
                } else {
                    swal(
                        'Failed!',
                        'Invalid info or Invalid Item!',
                        'error'
                    )
                }


            });

        }, function (dismiss) {
            // dismiss can be 'cancel', 'overlay',
            // 'close', and 'timer'
            if (dismiss === 'cancel') {
                swal(
                    'Cancelled',
                    'Process has been cancelled',
                    'error'
                )
            }
        })

    }

    function ViewSaveGrnModal() {
        $('#successAlert2').hide();
        $('#errorAlert2').hide();
        $('#successAlert2').html("");
        $('#errorAlert2').html("");

        $.post('getGrnId', {}, function (data) {
            $("#save_GrnNo").val(data);

        });
        $.post('getGrnTotal', {}, function (data) {
            $("#save_Total").val(parseFloat(data).toFixed(2));
            $("#save_NetTotal").val(parseFloat(data).toFixed(2));
            $("#save_Discount").val("0");
        });

    }
    function addDiscount(discountValue) {
        var totalAmount = $('#save_Total').val();

        if (parseInt($('#discountType').val()) == 1) {
            var netTotal = totalAmount - (totalAmount / 100 * discountValue)
            $('#save_NetTotal').val(netTotal.toFixed(2));
        } else if (parseInt($('#discountType').val()) == 2) {
            var netTotal = totalAmount - discountValue;
            $('#save_NetTotal').val(netTotal.toFixed(2));
        }
    }

    function viewMoreGrn(ele) {
        let id = $(ele).attr('data-id');
        $.ajax({
            type: 'POST',

            url: 'viewMoreGrn',

            data: {id: id},

            success: function (data) {
                $('#modalTableData').html(data);
                $('#regModal').modal('show');

            }
        });
    }

    function viewStock(ele) {
        let id = $(ele).attr('data-id');
        $.ajax({
            type: 'POST',

            url: 'viewStockGrn',

            data: {id: id},

            success: function (data) {
                $('#stockModalTableData').html(data);
                $('#stockModal').modal('show');

            }
        });
    }
</script>


@include('includes.footer_end')