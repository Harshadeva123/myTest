@include('includes.header_start')


<!-- DataTables -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
{{--<script type="text/javascript" src="{{ URL::asset('assets/ajax/validations.js')}}"></script>--}}
<script type="text/javascript" src="{{ URL::asset('assets/ajax/common.js')}}"></script>/
<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">
@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card m-b-20">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="alert alert-danger alert-dismissible " id="errorAlertAdd" style="display:none">

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Store</label>
                                    <select class="form-control select2 tab"  name="stock"
                                            id="stock" required>
                                        <option value="" disabled selected>Select Store
                                        </option>
                                        @if(isset($stockTypes))
                                            @foreach($stockTypes as $stockType)
                                                <option value="{{"$stockType->idStore"}}">{{$stockType->type}} </option>
                                            @endforeach
                                        @endif

                                    </select>
                                </div>
                            </div>

                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>Item</label>
                                    <select class="form-control select2 tab" data-measurement="#measurement" data-qty="#qtyGrn"  name="item" onchange="itemChanged(this)"
                                            id="item" required>
                                        <option value="" disabled selected>Select Item
                                        </option>
                                        @if(isset($items))
                                            @foreach($items as $item)
                                                <option value="{{"$item->idItems"}}">{{$item->itemcode}} - {{"$item->itemName"}} </option>
                                            @endforeach
                                        @endif

                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Qty</label>
                                    <input type="number" class="form-control tab" name="qtyGrn" id="qtyGrn" min="0" data-measurement="#measurement"
                                           placeholder="Qty"/>
                                    <small id="qtyMsg" class="text-danger">{{ $errors->first('qtyGrn') }}</small>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label>Bin No</label>
                                    <input type="number" class="form-control tab" name="binNo" id="binNo" min="0" oninput="this.value = Math.abs(this.value)"
                                           placeholder="Bin No"/>
                                    <small class="text-danger">{{ $errors->first('binNo') }}</small>
                                </div>
                            </div>

                        </div>
                        <div class="row">

                            <div class="col-md-3">
                                <label>Buying Price</label>
                                <input type="number" class="form-control tab"
                                       name="bPrice"
                                       id="bPrice"  min="0" oninput="this.value = Math.abs(this.value)"
                                       placeholder="Buying Price"/>
                                <small class="text-danger">{{ $errors->first('sPrice') }}</small>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Manufacture Date</label>
                                    <div>
                                        <div class="input-group">
                                            <input type="text" class="form-control datepicker-autoclose tab" placeholder="mm/dd/yyyy" name="mFDate" id="mFDate">
                                            <div class="input-group-append">
                                                <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                            </div>
                                        </div><!-- input-group -->
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">

                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input doNotClear tab"  id="defaultChecked2"
                                               onclick="expDate()">
                                        <label class="custom-control-label" for="defaultChecked2">Expire Date</label>
                                    </div>
                                    <div style="margin-top: 5px" class="hideExpDate" id="hideExpDate">
                                    </div>
                                    <small class="text-danger">{{ $errors->first('eDate') }}</small>
                                </div>
                            </div>
                            <div class="col-md-3" style="padding-top: 28px">
                                <button  type="button" onclick="addItem(this)" id="addBtn"
                                         class="btn btn-md btn-primary waves-effect waves-light  tab pull-right">
                                    Add to Table
                                </button>
                            </div>
                        </div>



                    </div>
                </div>
            </div>
        </div>
       <div class="row">
           <div class="col-md-12">
               <div class="card m-b-20">
                   <div class="card-body">

                       <div class="table-rep-plugin">
                           <div class="table-responsive b-0" data-pattern="priority-columns">
                               <table class="table table-striped table-bordered"
                                      cellspacing="0"
                                      width="100%">
                                   <thead>
                                   <tr>
                                       <th>ITEM NAME</th>
                                       <th>QTY</th>
                                       <th>PO</th>
                                       <th>STORE NAME</th>
                                       <th style="text-align: right;">BUYING PRICE</th>
                                       <th style="text-align: right;">TOTAL PRICE</th>
                                       <th>OPTION</th>
                                   </tr>
                                   </thead>
                                   <tbody>
                                   </tbody>
                               </table>
                           </div>
                       </div>
                       <div class="col-md-12">
                           <div class="form-group mt-4 ">
                               <div class="row pull-right">
                                   <button class="btn  btn-primary" onclick="showSaveModal()">Save GRN</button>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
    </div>
</div>

{{--update modal--}}
<div class="modal fade" id="updateModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Update GRN</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="_token" value="{{ Session::token() }}">
                <input type="hidden" name="hiddenGrnID" id="hiddenGrnID">

                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlertUpdate" style="display:none">

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Item Name</label>
                            <select class="form-control select2" name="Uitem" data-measurement="#Umeasurement" data-qty="#UqtyGrn" onchange="itemChanged(this)"
                                    id="Uitem" required>
                                <option value="" disabled selected>Select Item
                                </option>
                                @if(isset($items))
                                    @foreach($items as $item)
                                        <option value="{{"$item->idItems"}}">{{$item->itemcode}} - {{"$item->itemName"}} </option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Qty</label>
                            <input type="number" class="form-control"  min="0" data-measurement="#Umeasurement" oninput="qtyInput(this)" name="UqtyGrn" id="UqtyGrn"
                                   placeholder="Qty GRN"/>
                            <small class="text-danger">{{ $errors->first('qtyGrn') }}</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Store</label>
                            <select class="form-control select2" name="UsType"
                                    id="UsType" required>
                                <option disabled value="" selected>Select Store
                                </option>
                                @if(isset($stockTypes))
                                    @foreach($stockTypes as $stockType)
                                        <option value="{{"$stockType->idStore"}}">{{"$stockType->type"}}</option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Bin No</label>
                            <input type="text" class="form-control" name="UbinNo" id="UbinNo" maxlength="25"
                                   placeholder="Bin No"/>
                            <small class="text-danger">{{ $errors->first('binNo') }}</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label>Buying Price</label>
                        <input type="number" class="form-control"
                               name="uBPrice"
                               id="uBPrice"  min="0" oninput="this.value = Math.abs(this.value)"
                               placeholder="Buying Price"/>
                        <small class="text-danger">{{ $errors->first('uBPrice') }}</small>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <!-- Default checked -->
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="hasExp"
                                       onchange="UexpDate()">

                                <label class="custom-control-label" for="hasExp">Expire Date</label>
                            </div>
                            <input style="display: none;" type="date" class="form-control mt-1" name="UexpDate" id="UexpDate" maxlength="25"
                                   placeholder="Exp Date"/>
                            <small class="text-danger">{{ $errors->first('eDate') }}</small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Manufacture Date</label>
                            <div>
                                <div class="input-group">
                                    <input type="text" class="form-control datepicker-autoclose" placeholder="mm/dd/yyyy" name="UmFDate" id="UmFDate">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                    </div>
                                </div><!-- input-group -->
                            </div>
                        </div>
                    </div>
                    <div style="margin-top: 4px;" class="col-md-4 align-content-center">
                        <button type="button" onclick="updateGrn()"
                                class="btn btn-md mt-4 pt-1 btn-warning waves-effect  waves-light">
                            Update GRN
                        </button>
                    </div>
                </div>

                <input type="hidden" id="hiddenIdUpdate">
            </div>
        </div>
    </div>
</div>
{{--end fo update modal--}}

{{--view modal--}}
<div class="modal fade" id="viewModal" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">View GRN</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">

                <div class="row">

                </div>
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Item</label>
                            <select class="form-control select2" disabled name="Vitem"
                                    id="Vitem" required>
                                <option value="" disabled selected>Select Item
                                </option>
                                @if(isset($items))
                                    @foreach($items as $item)
                                        <option value="{{"$item->idItems"}}">{{$item->itemcode}} - {{"$item->itemName"}} </option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Measurement</label>
                            <select class="form-control select2" disabled name="Vmeasurement"
                                    id="Vmeasurement" required>
                                <option disabled value="" selected>Select Measurement
                                </option>
                                @if(isset($measurements))
                                    @foreach($measurements as $measurement)
                                        <option value="{{"$measurement->idMeasurement"}}">{{"$measurement->measurement"}}</option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                    </div>

                </div>


                <div class="row">

                </div>
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Qty</label>
                            <input type="number" class="form-control" name="VqtyGrn" readonly id="VqtyGrn"  placeholder="Qty GRN"/>
                        </div>
                    </div>


                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Bin No</label>
                            <input type="number" class="form-control" name="VbinNo" id="VbinNo"  readonly maxlength="25"  placeholder="Bin No"/>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Store</label>
                            <select class="form-control select2" disabled name="VsType"
                                    id="VsType" required>
                                <option disabled value="" selected>Select Store
                                </option>
                                @if(isset($stockTypes))
                                    @foreach($stockTypes as $stockType)
                                        <option value="{{"$stockType->idStore"}}">{{"$stockType->type"}}</option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="client_surname">Buying Price</label>
                            <div class="panel-body">
                                <input type="number" class="form-control" style="text-align: right"
                                       name="VbPrice"  min="0" oninput="this.value = Math.abs(this.value)"
                                       id="VbPrice" readonly
                                       placeholder="Buying Price"/>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Wholesale Price</label>
                            <input type="number" class="form-control" style="text-align: right"
                                   name="VwSPrice" readonly
                                   id="VwSPrice"  min="0" oninput="this.value = Math.abs(this.value)"
                                   placeholder="Wholesale Price"/>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label>Supplier Price</label>
                        <input type="number" class="form-control"  style="text-align: right"
                               name="VsPrice"  min="0" oninput="this.value = Math.abs(this.value)"
                               id="VsPrice" readonly
                               placeholder="Supplier Price"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Manufacture Date</label>
                            <input type="text" class="form-control" readonly  name="VmFDate" id="VmFDate"  placeholder="Manufacture Date"/>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group" id="VhideExpDateDiv" style="display: none;">
                            <label for="VhideExpDate">Expire Date</label>
                            <input name="VhideExpDate"  readonly class="form-control" id="VhideExpDate">
                        </Div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
{{--end of view modal--}}


{{--save GRN moal--}}
<div class="modal fade" id="saveGrn" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Save GRN</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="_token" value="{{ Session::token() }}">
                <input type="hidden" name="hiddenGrnID" id="hiddenGrnID">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlertSave" style="display:none">

                        </div>
                    </div>
                </div>
                <div class="row">

                    <Div class="col-md-6 col-md-6">
                        <div class="form-group">
                            <label for="supplier">Supplier</label>
                            <select class="form-control select2" name="supplier"
                                    id="supplier" required>
                                <option disabled value="" selected>Select supplier
                                </option>
                                @if(isset($allSuppliers))
                                    @foreach($allSuppliers as $supplier)
                                        <option value="{{"$supplier->idSupplier"}}">{{"$supplier->companyName"}}</option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                    </Div>
                </div>
                <div class="row">


                    <div class="col-md-4 col-md-4">
                        <div class="form-group">
                            <label>Date</label>
                            <div>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="mm/dd/yyyy" id="datepicker-autoclose">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                    </div>
                                </div><!-- input-group -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-md-4">
                        <div class="form-group">
                            <label for="poNo">PO No</label>
                            <input class="form-control doNotClear" type="number"  min="0" oninput="this.value = Math.abs(this.value)" id="poNo" name="poNo">
                        </div>
                    </div>
                    <div class="col-md-4 col-md-4">
                        <div class="form-group">
                            <label for="invNo">INV No</label>
                            <input class="form-control" type="number"  min="0" oninput="this.value = Math.abs(this.value)" id="invNo" name="invNo">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 col-md-4">
                        <div class="form-group">
                            <label for="total">Total</label>
                            <input class="form-control"  type="number"  min="0" readonly  oninput="this.value = Math.abs(this.value);countNet()" onchange="countNet()"  id="total" name="total">
                        </div>
                    </div>

                    <div class="col-md-4 col-md-4">
                        <div class="form-group">
                            <label for="discount">Discount</label>
                            <div class="input-group">
                                <input class="form-control" type="number"  min="0" oninput="this.value = Math.abs(this.value);countNet()" onchange="countNet()" id="discount" name="discount">
                                <div class="input-group-append">
                                    <select class="form-control select2 doNotClear" name="discountType" onchange="$('#discount').val('0');countNet();"
                                            id="discountType" required>
                                        <option  value="1" selected>% &nbsp;</option>
                                        <option  value="2">RS &nbsp;</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-md-4">
                        <div class="form-group">
                            <label for="net">Net</label>
                            <input class="form-control"  min="0"  readonly type="number" id="net" name="net">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label>Payment Type</label>
                        <select class="form-control select2" name="payment"  onchange="paymentTypeChanged(this)"
                                id="payment" required>
                            <option disabled value="" selected>Payment Type
                            </option>
                            @if(isset($payments))
                                @foreach($payments as $paymentType)
                                        <option value="{{$paymentType->paymentType->idmeta_payment}}">{{$paymentType->paymentType->type}}</option>
                                @endforeach
                            @endif

                        </select>
                    </div>
                </div>

                <div class="row">
                    <div style="display: none" id="paidDueDiv" class="col-md-12 col-md-12">
                        <h6>CASH PAYMENTS</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="paidDue">Paid Amount</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="paid" name="paid">
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="visaBillDiv" class="col-md-12 col-md-12">
                        <h6>CARD PAYMENTS</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="visaBill">Card No.</label>
                            <div class="col-md-9">
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="visaBill" name="visaBill">
                            </div>
                        </div>
                        <div class="form-group row" id="cardAmountDiv" >
                            <label class="col-md-3" for="cardAmount">Card Amount.</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="cardAmount" name="cardAmount">
                            </div>
                        </div>
                    </div>

                    <div style="display: none" id="chequeDiv" class="col-md-12 col-md-12">
                        <h6>CHEQUE PAYMENTS</h6>
                        <div class="row">
                            <div class="form-group col-md-4" id="chequeAmountDiv" >
                                <label for="chequeAmount">Cheque Amount</label>
                                <div class="input-group mb-2">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">RS.</div>
                                    </div>
                                    <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="chequeAmount" name="chequeAmount">
                                </div>
                            </div>
                            <div class="form-group col-md-4" >
                                <label  for="name">Bank Name</label>
                                <div >
                                    <select class="form-control select2" name="chequeBankName" onchange="getBankAccounts(this.value)"
                                            id="chequeBankName" required>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="bankAccount">Account</label>
                                    <select class="form-control select2" name="bankAccountCheque"
                                            id="bankAccountCheque" >
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label  for="chequeNo">Cheque No.</label>
                                <div>
                                    <input class="form-control "  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="chequeNo" name="chequeNo">
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="chequeDate">Cheque Date</label>
                                <div >
                                    <div class="input-group">
                                        <input type="text" class="form-control datepicker-autoclose'" placeholder="mm/dd/yyyy" id="chequeDate">
                                        <div class="input-group-append">
                                            <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                        </div>
                                    </div><!-- input-group -->
                                </div>
                            </div>
                            <div class="form-group col-md-2 mt-4 pt-1">
                                <button onclick="addChequeDetailsTemp()" class="btn">Add</button>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-rep-plugin">
                                    <div class="table-responsive" data-pattern="priority-columns">
                                        <table class="table table-striped table-bordered"
                                               cellspacing="0"
                                               width="100%">
                                            <thead>
                                            <tr>
                                                <th>BANK NAME</th>
                                                <th>ACCOUNT</th>
                                                <th>CHEQUE NO</th>
                                                <th>CHEQUE DATE</th>
                                                <th>AMOUNT</th>
                                                <th>DELETE</th>
                                            </tr>
                                            </thead>
                                            <tbody id="chequeDetailsTableData">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div style="display: none" id="bankDiv" class="col-md-12 col-md-12">
                        <div class="row">

                            <div class="col-md-12">
                                <h6 >BANK PAYMENTS</h6>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bankName">Bank Name</label>
                                    <select class="form-control select2" name="bankName" onchange="getBankAccounts(this.value)"
                                            id="bankName" >
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bankAccount">Account</label>
                                    <select class="form-control select2" name="bankAccount"
                                            id="bankAccount" >
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4" id="bankAmountDiv" >
                                <div class="form-group ">
                                    <label for="bankAmount">Amount</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">RS.</div>
                                        </div>
                                        <input class="form-control"  type="number"  min="0" oninput="this.value = Math.abs(this.value)"  id="bankAmount" name="bankAmount">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group mt-4 pt-1">
                                    <button class="btn btn-secondary " onclick="addBankDetails(this)" >Add</button>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-rep-plugin">
                                            <div class="table-responsive" data-pattern="priority-columns">
                                                <table class="table table-striped table-bordered"
                                                       cellspacing="0"
                                                       width="100%">
                                                    <thead>
                                                    <tr>
                                                        <th>BANK NAME</th>
                                                        <th>ACCOUNT</th>
                                                        <th>AMOUNT</th>
                                                        <th>DELETE</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="bankDetailsTableData">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div  style="display: none;"   id="voucherDiv" class="col-md-12 col-md-12">
                        <h6>GIFT VOUCHER</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="voucherNo">Voucher No.</label>
                            <div class="col-md-9">
                                <input class="form-control"  type="number"  min="0"  id="voucherNo" name="voucherNo">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3" for="voucherAmount">Voucher Amount</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control"  type="number"  min="0"  id="voucherAmount" name="voucherAmount">
                            </div>
                        </div>
                    </div>

                    <div style="display: none;"  id="easyDiv" class="col-md-12 col-md-12">
                        <h6>EASY PAYMENT</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="voucherNo">Eas No.</label>
                            <div class="col-md-9">
                                <input class="form-control"  type="number"  min="0"  id="voucherNo" name="voucherNo">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3" for="voucherAmount">Voucher Amount</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control"  type="number"  min="0"  id="voucherAmount" name="voucherAmount">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info alert-dismissible " id="successAlert" style="display:none">


                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert" style="display:none">

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info alert-dismissible " id="successAlert2" style="display:none">

                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert2" style="display:none">

                        </div>
                    </div>
                </div>

                <div class="row pull-right">
                    <div class="col-md-12 col-md-12">
                        <button type="button" onclick="saveGrn()"
                                class="btn btn-md btn-primary waves-effect waves-light">
                            Save GRN
                        </button>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>
<script type="text/javascript">

    $(document).ready(function () {
        // $('form').parsley();

        initializeDate();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        showGrnTempTable();
        $('#datepicker-autoclose').datepicker('setDate', 'today');
        expDate();
    });

    function initializeDate() {
        jQuery('.datepicker-autoclose').datepicker({
            autoclose: true,
            todayHighlight: true
        });

    }

    function adMethod(dataID, tableName) {

        $.post('activateDeactivate', {id: dataID, table: tableName}, function (data) {

        });
    }

    $('[data-dismiss=modal]').on('click', function (e) {
        var $t = $(this),
            target = $t[0].href || $t.data("target") || $t.parents('.modal') || [];

        $(target)
            .find("input,textarea,select")
            .val('')
            .end()
            .find("input[type=checkbox], input[type=radio]")
            .prop("checked", "")
            .end();
        $('#errorAlert').hide();
    });

    function expDate() {
        if($('#defaultChecked2').prop("checked"))
        {
            var date = '';
            date += "<div  >\n" +
                "      <div class=\"input-group\">\n" +
                "                                        <input type=\"text\" class=\"form-control datepicker-autoclose tab\" onchange=\"$('#bPrice').focus()\" placeholder=\"mm/dd/yyyy\"  name=\"eDate\" id=\"eDate\">\n" +
                "                                        <div class=\"input-group-append\">\n" +
                "                                            <span class=\"input-group-text\"><em class=\"mdi mdi-calendar\"></em></span>\n" +
                "                                        </div>\n" +
                "       </div>\n" +
                "     </div>";

            $("#hideExpDate").html(date);
            initializeDate();
        }
        else{
            $("#hideExpDate").html("");
        }

    }

    function UexpDate(){
        if($('#hasExp').prop("checked"))
        {
            $('#UexpDate').show();
        }
        else{
            $('#UexpDate').hide();
        }
    }

    function saveGrn() {
        $('.notify').empty();
        $('.alert').hide();
        $('.alert').html("");


        var uGrnNo = $("#grnNo").val();
//        var company = $("#company").val();
        var uPurchaseOrderNo = $("#poNo").val();
        var uInvoiceNo = $("#invNo").val();
        var uTotal = $("#total").val();
        var uDiscount = $("#discount").val();
        var uNetTotal = $("#net").val();
        var uPaymentType = $("#payment").val();
        var uDate = $("#datepicker-autoclose").val();
        var uSupplier = $("#supplier").val();

        var paid = $("#paid").val();
        var visaBill = $("#visaBill").val();
        var bankId = $('#bankName').val();
        var chequeNo = $('#chequeNo').val();
        var chequeDate = $('#chequeDate').val();
        var chequeBankName = $('#chequeBankName').val();
        var chequeAmount = $('#chequeAmount').val();
        var bankAmount = $('#bankAmount').val();
        var cardAmount = $('#cardAmount').val();
        let discountType = $("#discountType").val();
        var hiddenGrnID = $("#hiddenGrnID").val();

        if(discountType == 1){
            uDiscount = parseFloat(uTotal*(uDiscount/100));
        }

        $.post('saveUpdateGrn', {
            hiddenGrnID: hiddenGrnID,
            uGrnNo: uGrnNo,
            uPurchaseOrderNo: uPurchaseOrderNo,
            uInvoiceNo: uInvoiceNo,
            uTotal: uTotal,
            uDiscount: uDiscount,
            uNetTotal: uNetTotal,
            uPaymentType: uPaymentType,
            uDate: uDate,
            uSupplier: uSupplier,
//            company:company,
            paid: paid,
            visaBill: visaBill,
            bankId: bankId,
            chequeNo: chequeNo,
            chequeDate: chequeDate,
            chequeBankName: chequeBankName,
            chequeAmount: chequeAmount,
            bankAmount: bankAmount,
            cardAmount: cardAmount,
        }, function (data) {
            if (data.errors != null) {
                $('#errorAlertSave').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlertSave').append('<p>' + value + '</p>');
                });
                $('html, body').animate({
                    scrollTop: $("#errorAlertSave").offset().top
                }, 1000);
            }
            if (data.success != null) {

                $('#saveGrn').modal('hide');
                notify({
                    type: "success", //alert | success | error | warning | info
                    title: 'GRN  SAVED',
                    autoHide: true, //true | false
                    delay: 2500, //number ms
                    position: {
                        x: "right",
                        y: "top"
                    },
                    icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                    message:'GRN Saved successfully.'
                });
            }
            showGrnTempTable();

        });
    }

    $(document).on("wheel", "input[type=number]", function (e) {
        $(this).blur();
    });

    function showGrnTempTable(){
        $('#defaultChecked2').prop('checked',false);
        $("#hideExpDate").html("");

        $.ajax({

            type:'POST',

            url:'getTempTableDataGrn',

            data:{},

            success:function(data){

                $('tbody').html(data.tableData);
                $('#poNo').val(data.po);
                $('#payment').val(1).trigger('change') ;
                $('#datepicker-autoclose').datepicker('setDate', 'today');


            }

        });
    }

    function clearGrnTempTable(){

        $.ajax({

            type:'POST',

            url:'clearGrnTempTable',

            data:{},

            success:function(data){



            }

        });
    }

    $('.modal').on('hidden.bs.modal', function () {

        $("input").not('.doNotClear').val('');

        $("input").not('.doNotClear').attr('checked',false);


        $('.alert').html('');

        $('.alert').hide();

        $('select').not('.doNotClear').val('').trigger('change') ;
        $('#discountType').val('1').trigger('change') ;
        $('#payment').val(1).trigger('change') ;
        $('#datepicker-autoclose').datepicker('setDate', 'today');


    });

    function showUpdateModal(item) {
        var id= $(item).attr('data-id');
        $.ajax({

            type:'POST',

            url:'getGrnTempDataById',

            data:{id: id},

            success:function(data){

                $('#UsType').val(data.store).trigger('change');
                $('#Uitem').val(data.Items_idItems).trigger('change');
                $('#Umeasurement').val(data.idMeasurement).trigger('change');
                $('#UbinNo').val(data.binNo);
                if(!data.expHave){
                    $('#hasExp').prop("checked",false);
                    $("#UexpDate").val("").hide();
                }
                else{
                    $("#hasExp").prop("checked", true);
                    $("#UexpDate").val(data.expDate).show();
                }
                $('#UmFDate').val(data.mnfDate);
                $('#uBPrice').val(data.bp);
                $('#UwSPrice').val(data.wp);
                $('#UqtyGrn').val(data.qty_grn);
                $('#UsPrice').val(data.sp);
                $('#hiddenIdUpdate').val(id);

                $('#updateModal').modal('show');


            }

        });
    }


    function showSaveModal() {
        var totalPrice = 0;
        $.ajax({

            type:'POST',

            url:'getTempTableTotal',

            data:{},

            success:function(data){

               totalPrice = data;

                $('#total').val(totalPrice);
                $('#discount').val(0);
                $('#net').val(totalPrice);

                $('#paidDue').val('');
                $('#paidDueDiv').hide();
                $('#visaBill').val('');
                $('#visaBillDiv').hide();
                $('#bankName').val('');
                $('#bankDiv').hide();
                $('#chequeNo').val('');
                $('#chequeDate').val('');
                $('#chequeDiv').hide();
                $('#chequeAmount').val('');
                $('#chequeAmountDiv').hide();
                $('#bankAmount').val('');
                $('#bankAmountDiv').hide();
                $('#cardAmount').val('');
                $('#cardAmountDiv').hide();
                $('#payment').val('1').trigger('change');
                $('#discountType').val('1').trigger('change');
                $('#totalAmount').html($('#total').val());
                $('#saveGrn').modal('show');
            }

        });

    }

    function addBankDetails(el) {
        $(el).attr('disabled',true);
        let bankName = $('#bankName').val();
        let amount = $('#bankAmount').val();
        let bankAccount = $('#bankAccount').val();
        $.ajax({
            type:'POST',

            url:'addBankDetailsTemp',

            data:{bankName:bankName,amount:amount,bankAccount:bankAccount},

            success:function(){
                loadBankPaymentstemp();
                $(el).attr('disabled',false);


            }
        });

    }

    function loadBankPaymentstemp() {
        $.ajax({
            type:'POST',

            url:'loadBankDetailsTemp',

            data:{},

            success:function(data){
                $('#bankDetailsTableData').html(data.tableData);
            }
        });

    }

    function paymentTypeChanged(el) {

        let payment = $(el).val();

        $('#paidDue').val('');
        $('#paidDueDiv').hide();

        $('#cardAmount').val('');
        $('#visaBill').val('');
        $('#visaBillDiv').hide();

        $('#bankName').val('');
        $('#bankDiv').hide();

        $('#chequeNo').val('');
        $('#chequeDate').val('');
        $('#chequeDiv').hide();

        $('#chequeAmount').val('');
        $('#chequeAmountDiv').hide();

        $('#bankAmount').val('');
        $('#bankAmountDiv').hide();



        $.ajax({
            type:'POST',

            url:'paymentTypeChangedDelete',

            data:{},

            success:function(){
                loadBankPaymentstemp();
                loadChequeDetailsTemp();
            }
        });

        if(payment == 2 || payment == 1){
            $('#paidDue').val('');
            $('#paidDueDiv').show();
        }

        if(payment == 3){
            $('#visaBill').val('');
            $('#visaBillDiv').show();
            $('#cardAmountDiv').show();
        }

        if(payment == 4){
            $.ajax({
                type:'POST',

                url:'getBankDetails',

                data:{},

                success:function(data){
                    $('#bankName').html(data);
                    $('#bankAmountDiv').show();
                    $('#bankAmount').val('');
                    $('#bankDiv').show();
                    getBankAccounts($('#bankName').val());
                }
            });

        }

        if(payment == 5){
            $('#chequeNo').val('');
            $('#chequeDate').datepicker().datepicker("setDate", new Date());
            $.ajax({
                type:'POST',

                url:'getBankDetails',

                data:{},

                success:function(data){
                    $('#chequeBankName').html(data);
                    $('#chequeDiv').show();
                    $('#chequeAmountDiv').show();
                    getBankAccounts($('#chequeBankName').val());

                }
            });
        }

        if(payment == 11) {
            $('#paidDueDiv').show();
            $('#visaBillDiv').show();
            $('#bankDiv').show();
            $('#chequeDate').datepicker().datepicker("setDate", new Date());
            $('#chequeAmountDiv').show();
            $('#bankAmountDiv').show();
            $('#cardAmountDiv').show();
            $('#chequeDiv').show();
            $.ajax({
                type: 'POST',

                url: 'getBankDetails',

                data: {},

                success: function (data) {
                    $('#chequeBankName').html(data);
                    $('#bankName').html(data);
                }
            });
        }

    }

    function getBankAccounts(id) {
        $.ajax({
            type:'POST',

            url:'getBankAccounts',

            data:{bank:id},

            success:function(data){
                $('#bankAccount').html(data);
                $('#bankAccountCheque').html(data);
            }
        });
    }

    function addChequeDetailsTemp(){
        let chequeNo = $('#chequeNo').val();
        let chequeAmount = $('#chequeAmount').val();
        let chequeDate = $('#chequeDate').val();
        let bankName = $('#chequeBankName').val();
        let bankAccount = $('#bankAccountCheque').val();

        $.ajax({
            type:'POST',

            url:'addChequeDetailsTemp',

            data:{chequeDate:chequeDate,chequeAmount:chequeAmount,chequeNo:chequeNo,bankName:bankName,bankAccount:bankAccount},

            success:function(){
                loadChequeDetailsTemp();
            }
        });
    }

    function loadChequeDetailsTemp() {
        $.ajax({
            type:'POST',

            url:'loadChequeDetailsTemp',

            data:{},

            success:function(data){
                $('#chequeDetailsTableData').html(data.tableData);
            }
        });

    }

    function ChequePaymentTempDelete(el) {
        let id = $(el).attr('data-id');
        $.ajax({
            type:'POST',

            url:'ChequePaymentTempDelete',

            data:{id:id},

            success:function(data){
                $('#'+id).remove();
            }
        });

    }

    function BankPaymentsTempDelete(el) {
        let id = $(el).attr('data-id');
        $.ajax({
            type:'POST',

            url:'BankPaymentsTempDelete',

            data:{id:id},

            success:function(data){
                $('#'+id).remove();
            }
        });

    }

    function addItem() {

        $('.notify').empty();
        $('.alert').hide();
        $('.alert').html("");

        var stock = $("#stock").val();
        var item = $("#item").val();
        var binNo = $("#binNo").val();
        var eDate = $("#eDate").val();
        var mFDate = $("#mFDate").val();
        var bPrice = $("#bPrice").val();
        var qtyGrn = $("#qtyGrn").val();

            $('#qtyMsg').html('');
            $.post('addItemToGRN',
                {
                    sType: stock,
                    item: item,
                    binNo: binNo,
                    mFDate: mFDate,
                    bPrice: bPrice,
                    eDate: eDate,
                    qtyGrn: qtyGrn
                },
                function (data) {
                    if (data.errors != null) {
                        $('#errorAlertAdd').show();
                        $.each(data.errors, function (key, value) {
                            $('#errorAlertAdd').append('<p>' + value + '</p>');
                        });
                        $('html, body').animate({
                            scrollTop: $("#errorAlertAdd").offset().top
                        }, 1000);
                    }
                    if (data.success != null) {

                        notify({
                            type: "success", //alert | success | error | warning | info
                            title: 'ITEM SAVED',
                            autoHide: true, //true | false
                            delay: 2500, //number ms
                            position: {
                                x: "right",
                                y: "top"
                            },
                            icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                            message:'Temporary item  successfully added.'
                        });

                        $('input').val("");
                        $(".select2").val('').trigger('change');
                        $(".custom-control-input").prop("checked", false);
                        setTimeout(function () {
                            $('#item').focus().click();
                        }, 100);


                    }

                    showGrnTempTable();

                });


    }

    function updateGrn() {

        $('.notify').empty();
        $('.alert').html('');
        $('.alert').hide();

        var id = $('#hiddenIdUpdate').val();
        var UsType = $('#UsType').val();
        var Uitem = $('#Uitem').val();
        var UbinNo = $('#UbinNo').val();
        if($('#hasExp').prop("checked")){
            var expHave = 1;
            var expDate =    $("#UexpDate").val();
        }
        else {
            var expHave = 0;
            var expDate = null;
        }
        var UmFDate = $('#UmFDate').val();
        var UbPrice = $('#uBPrice').val();
        var UwSPrice = $('#UwSPrice').val();
        var UqtyGrn = $('#UqtyGrn').val();
        var UsPrice = $('#UsPrice').val();

        $.ajax({

            type: 'POST',

            url: 'updateTempGrn',

            data: {
                id:id,
                UsType: UsType,
                Uitem:Uitem,
                UbinNo:UbinNo,
                expHave:expHave,
                expDate:expDate,
                UmFDate:UmFDate,
                UbPrice:UbPrice,
                UwSPrice:UwSPrice,
                UqtyGrn:UqtyGrn,
                UsPrice:UsPrice
            },

            success: function (data) {
                if (data.errors != null) {

                    $('#errorAlertUpdate').show();
                    $.each(data.errors, function (key, value) {
                        $('#errorAlertUpdate').append('<p>' + value + '</p>');
                    });
                    $('html, body').animate({
                        scrollTop: $("#errorAlertUpdate").offset().top
                    }, 1000);
                }
                if (data.success != null) {

                    notify({
                        type: "success", //alert | success | error | warning | info
                        title: 'ITEM UPDATED',
                        autoHide: true, //true | false
                        delay: 2500, //number ms
                        position: {
                            x: "right",
                            y: "top"
                        },
                        icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                        message:'Temporary item  successfully updated.'
                    });

                    $('#updateModal').modal('hide');
                    showGrnTempTable();


                }
            }
        });
    }

    function deleteRecord(id) {
            $.ajax({
                type: 'POST',

                url: 'deleteTempGrn',

                data: {id: id},

                success: function () {
                   showGrnTempTable();

                }
            });

    }


    function itemChanged(el) {

        let item =  el.value;
        if(item != '') {

            $.ajax({
                type: 'POST',

                url: 'getBuyingPrice',

                data: {item: item},

                success: function (data) {
                    $('#bPrice').val(data);

                }
            });
        }
    }


    function countNet() {

        let discoutInput =  parseFloat($('#discount').val());
        let total = parseFloat($('#total').val());
        let discountType = $("#discountType").val();
        if(discountType == 1){
            discount = parseFloat(total*(discoutInput/100));
            if(discoutInput>100){
                $('#discount').val(100);
            }

            let NewdiscountInput = parseFloat($('#discount').val());
            let Newtotal = parseFloat($('#total').val());
            Newdiscount = parseFloat(Newtotal*(NewdiscountInput/100));
            $('#net').val(parseFloat(Newtotal-Newdiscount).toFixed(2));
        }
        if(discountType == 2){
            discount = discoutInput;
            if(discount>total){
                $('#discount').val(parseFloat(total));
            }

            let Newdiscount = parseFloat($('#discount').val());
            let Newtotal = parseFloat($('#total').val());
            $('#net').val(parseFloat(Newtotal-Newdiscount).toFixed(2));
        }


    }


    //keypress functions
    $(".tab").keyup(function (event) {
        if (event.keyCode == 13) {
            textboxes = $(".tab");
            currentBoxNumber = textboxes.index(this);
            if ( $(this).val().length > 0 || this.id == 'binNo') {
                if (textboxes[currentBoxNumber + 1] != null) {
                    nextBox = textboxes[currentBoxNumber + 1];
                    nextBox.focus();
                    nextBox.select();
                }
            }
            event.preventDefault();
            return false;
        }
    });

    function storeChange() {

        setTimeout(function () {
            $('#addBtn').focus();
        }, 100);
    }

    $(document).ready(function(){
        $( document ).on( 'focus', ':input', function(){
            $( this ).attr( 'autocomplete', 'off' );
        });
    });

    $(document).on('keypress', function(e) {
        var tag = e.target.tagName.toLowerCase();
        if ( e.which === 13 && tag != 'input' && tag != 'textarea' && tag != 'select')
            $('#item').focus();
    });
</script>


@include('includes.footer_end')