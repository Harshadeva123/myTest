@include('includes/header_start')

<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
      type="text/css"/>
<link href="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css"/>
<!-- Responsive datatable examples -->
<link href="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.css')}}" rel="stylesheet"
      type="text/css"/>
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">


<!-- Plugins css -->
<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}"
      rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">
@include('includes/header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{$title}}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="">
            <div class="card m-b-20">
                <div class="card-body">

                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Voucher Type</label>
                                <select class="form-control select2 tab" name="voucherType"
                                        id="voucherType" required>
                                    <option value="" disabled selected>Voucher Type
                                    </option>
                                    @foreach($voucherTypes as $voucherType)
                                        <option value="{{$voucherType->idvoucher_type_meta}}" >{{$voucherType->type}}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Amount</label>
                                <input type="number" class="form-control" name="amount"
                                       oninput="this.value = Math.abs(this.value)"
                                       id="amount" required placeholder="Amount"/>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="example-text-input" class="col-form-label">Amount in words</label>
                                <textarea class="form-control" rows="3" readonly name="amountWord" id="amountWord"
                                          placeholder="Amount in words"></textarea>
                                <small class="text-danger">{{ $errors->first('description') }}</small>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" id="amountInWord">


                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Paid To</label>
                                <input type="text" class="form-control" name="paidTo" id="paidTo" required
                                       placeholder="Paid To"/>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Date</label>
                                <div>
                                    <div class="input-group">
                                        <input type="text" autocomplete="off" class="form-control datepicker-autoclose"
                                               placeholder="mm/dd/yyyy" name="voucherDate" id="voucherDate">

                                        <div class="input-group-append">
                                            <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                        </div>
                                    </div><!-- input-group -->
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-lg-4">
                            <button type="button" class="btn btn-md btn-primary waves-effect waves-light"
                                    onclick="showSaveModal()">Create Voucher
                            </button>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>

</div><!-- container -->


</div> <!-- Page content Wrapper -->

</div> <!-- content -->


<div class="modal fade" id="saveInvoice" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Save Voucher</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="_token" value="{{ Session::token() }}">
                <input type="hidden" name="hiddenGrnID" id="hiddenGrnID">

                <div class="row">
                    <div class="col-lg-6 col-md-4">
                        <div class="form-group">
                            <label for="total">Total</label>
                            <input class="form-control" type="number" min="0" readonly
                                   oninput="this.value = Math.abs(this.value);countNet()" onchange="countNet()"
                                   id="totalAmount" name="totalAmount">
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label>Payment Type</label>
                        <select class="form-control " name="payment" onchange="paymentTypeChanged(this)"
                                id="payment" required>
                            <option disabled selected>Payment Type
                            </option>
                            @if(isset($paymentTypes))
                                @foreach($paymentTypes as $paymentType)
                                    <option value="{{"$paymentType->idPayment_Type"}}">{{"$paymentType->type"}}</option>
                                @endforeach
                            @endif

                        </select>
                    </div>
                </div>

                <div class="row">
                    <div style="display: none" id="paidDueDiv" class="col-lg-12 col-md-12">
                        <h6>CASH PAYMENTS</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="paidDue">Paid Amount</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control" type="number" min="0"
                                       oninput="this.value = Math.abs(this.value)" id="paid" name="paid">
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="visaBillDiv" class="col-lg-12 col-md-12">
                        <h6>CARD PAYMENTS</h6>
                        <div class="form-group row">
                            <label class="col-md-3" for="visaBill">Card No.</label>
                            <div class="col-md-9">
                                <input class="form-control" type="number" min="0"
                                       oninput="this.value = Math.abs(this.value)" id="visaBill" name="visaBill">
                            </div>
                        </div>
                        <div class="form-group row" id="cardAmountDiv" style="display: none;">
                            <label class="col-md-3" for="cardAmount">Card Amount.</label>
                            <div class="input-group mb-2 col-md-9">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">RS.</div>
                                </div>
                                <input class="form-control" type="number" min="0"
                                       oninput="this.value = Math.abs(this.value)" id="cardAmount" name="cardAmount">
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="chequeDiv" class="col-lg-12 col-md-12">
                        <h6>CHEQUE PAYMENTS</h6>
                        <div class="row">
                            <div class="form-group col-md-6" id="chequeAmountDiv">
                                <label for="chequeAmount">Cheque Amount</label>
                                <div class="input-group mb-2">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">RS.</div>
                                    </div>
                                    <input class="form-control" type="number" min="0"
                                           oninput="this.value = Math.abs(this.value)" id="chequeAmount"
                                           name="chequeAmount">
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="name">Bank Name</label>
                                <div>
                                    <select class="form-control select2" name="chequeBankName"
                                            id="chequeBankName" required>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="chequeNo">Cheque No.</label>
                                <div>
                                    <input class="form-control " type="number" min="0"
                                           oninput="this.value = Math.abs(this.value)" id="chequeNo" name="chequeNo">
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="chequeDate">Cheque Date</label>
                                <div>
                                    <div class="input-group">
                                        <input type="text" class="form-control datepicker-autoclose'"
                                               placeholder="mm/dd/yyyy" id="chequeDate">
                                        <div class="input-group-append">
                                            <span class="input-group-text"><em class="mdi mdi-calendar"></em></span>
                                        </div>
                                    </div><!-- input-group -->
                                </div>
                            </div>
                            <div class="form-group col-md-2 mt-4 pt-1">
                                <button onclick="addChequeDetailsTemp()" class="btn">Add</button>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-rep-plugin">
                                    <div class="table-responsive" data-pattern="priority-columns">
                                        <table class="table table-striped table-bordered"
                                               cellspacing="0"
                                               width="100%">
                                            <thead>
                                            <tr>
                                                <th>BANK NAME</th>
                                                <th>CHEQUE NO</th>
                                                <th>CHEQUE DATE</th>
                                                <th>AMOUNT</th>
                                                <th>DELETE</th>
                                            </tr>
                                            </thead>
                                            <tbody id="chequeDetailsTableData">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div style="display: none" id="bankDiv" class="col-lg-12 col-md-12">
                        <div class="row">

                            <div class="col-md-12">
                                <h6>BANK PAYMENTS</h6>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bankName">Bank Name</label>
                                    <select class="form-control select2" name="bankName"
                                            id="bankName">
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4" id="bankAmountDiv">
                                <div class="form-group ">
                                    <label for="bankAmount">Amount</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">RS.</div>
                                        </div>
                                        <input class="form-control" type="number" min="0"
                                               oninput="this.value = Math.abs(this.value)" id="bankAmount"
                                               name="bankAmount">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group mt-4 pt-1">
                                    <button class="btn btn-secondary " onclick="addBankDetails(this)">Add</button>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-rep-plugin">
                                            <div class="table-responsive" data-pattern="priority-columns">
                                                <table class="table table-striped table-bordered"
                                                       cellspacing="0"
                                                       width="100%">
                                                    <thead>
                                                    <tr>
                                                        <th>BANK NAME</th>
                                                        <th>AMOUNT</th>
                                                        <th>DELETE</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="bankDetailsTableData">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-lg-4">
                    </div>
                    <div class="col-lg-4">

                    </div>
                    <div class="col-lg-4">
                        <button type="button" class="btn btn-md btn-primary pull-right waves-effect waves-light"
                                data-toggle="modal" onclick="saveVoucher()">Save Voucher
                        </button>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info alert-dismissible " id="successAlert" style="display:none">


                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert" style="display:none">

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info alert-dismissible " id="successAlert2" style="display:none">

                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlert2" style="display:none">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<iframe style="display: none;" id="iframeprint" src=""></iframe>
@include('includes/footer_start')

<!-- Plugins js -->

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}"
        type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}"
        type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}"
        type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>
<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>

<script src="assets/js/bootstrap-notify.js"></script>
<script type="text/javascript" src="assets/js/my_alerts.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        initializeDate();
        $('#datepicker-autoclose').datepicker('setDate', 'today');
    });

    $(document).on("wheel", "input[type=number]", function (e) {
        $(this).blur();
    });
    function initializeDate() {
        jQuery('.datepicker-autoclose').datepicker({
            autoclose: true,
            todayHighlight: true
        });

    }


    var a = ['', 'one ', 'two ', 'three ', 'four ', 'five ', 'six ', 'seven ', 'eight ', 'nine ', 'ten ', 'eleven ', 'twelve ', 'thirteen ', 'fourteen ', 'fifteen ', 'sixteen ', 'seventeen ', 'eighteen ', 'nineteen '];
    var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

    function inWords(num) {
        if ((num = num.toString()).length > 9) return 'overflow';
        n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
        if (!n) return;
        var str = '';
        str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
        str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
        str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
        str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
        str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
        return str;
    }


    document.getElementById('amount').onkeyup = function () {
        var amountInWord = inWords(document.getElementById('amount').value);

        document.getElementById("amountWord").value = amountInWord;
        document.getElementById("amountInWord").value = amountInWord;
    };


    $(document).ready(function () {
        $(document).on('focus', ':input', function () {
            $(this).attr('autocomplete', 'off');
        });
    });

</script>
@include('includes/footer_end')