       
        <!-- App js -->
        <script src="{{ URL::asset('assets/js/app.js')}}"></script>

    </body>
</html>