@include('includes.copyrights')

</div>
<!-- End Right content here -->

</div>
<!-- END wrapper -->


<!-- jQuery  -->
<script src="{{ URL::asset('assets/js/jquery.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/popper.min.js')}}"></script><!-- Popper for Bootstrap -->
<script src="{{ URL::asset('assets/js/bootstrap.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/modernizr.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.slimscroll.js')}}"></script>
<script src="{{ URL::asset('assets/js/waves.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.nicescroll.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.scrollTo.min.js')}}"></script>
{{--<script src="assets/js/validations.js"></script>--}}
{{--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.js"></script>--}}


