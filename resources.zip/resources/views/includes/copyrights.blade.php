


<footer class="footer">
    <p> © 2013  - <?php echo date('Y') ?> Powered By<a href="http://visirogs.com" target="_blank"> VISIRO</a>  in  <img  style="padding-bottom: 3px;min-height: 15px;" src="{{ URL::asset('assets/images/resources/flag.png') }}"/></p>
</footer>