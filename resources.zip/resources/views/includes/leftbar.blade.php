<!-- Loader -->
<div id="preloader">
    <div id="status">
        <div class="spinner"></div>
    </div>
</div>

<!-- Begin page -->
<div id="wrapper">

    <!-- ========== Left Sidebar Start ========== -->
    <div class="left side-menu">

        <!-- LOGO -->
        <div class="topbar-left">
            <div class="">
                <a href="" class="logo"><img src="{{ URL::asset('assets/images/logo.png')}}" height="45" alt="logo"></a>
            </div>
        </div>

        <div class="sidebar-inner slimscrollleft">
            <div id="sidebar-menu">

                <ul>

                    <li class="menu-title">Main</li>

                    <li>
                        <a href="{{ url('/') }}" class="waves-effect"><i class="dripicons-device-desktop"></i><span>Dashboard </span></a>
                    </li>
                    {{--<li>--}}
                    {{--<a href="petty_cash" class="waves-effect"><i class="mdi mdi-wallet"></i><span>Petty Cash </span></a>--}}
                    {{--</li>--}}

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i
                                    class="dripicons-suitcase"></i><span>GRN<span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="{{route('grn_management')}}">Add GRN</a></li>
                            <li><a href="{{route('grnSearch')}}">View History</a></li>

                        </ul>
                    </li>


                    {{--<li class="has_sub">--}}
                    {{--<a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Invoice<span--}}
                    {{--class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>--}}
                    {{--<ul class="list-unstyled">--}}
                    {{--<li><a href="create_invoice">Create Invoice</a></li>--}}
                    {{--<li><a href="invoice_history">Invoice History</a></li>--}}
                    {{--<li><a href="invoice_return">Invoice Return</a></li>--}}
                    {{--<li><a href="invoice_return_history">Invoice Return History</a></li>--}}
                    {{--</ul>--}}
                    {{--</li>--}}

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Stock<span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="{{route('openingStock')}}">Opening Stock</a></li>
                            <li><a href="{{route('activeStock')}}">Active Stock</a></li>
                            <li><a href="{{route('deactivateStock')}}">Deactivated Stock</a></li>
                            <li><a href="{{route('lowStock')}}">Low Stock</a></li>
                            <li><a href="{{route('maxStock')}}">Max Stock</a></li>
                            <li><a href="{{route('storeChange')}}">Store Change</a></li>
                            <li><a href="{{route('stores')}}">Stores</a></li>
                            <li><a href="{{route('stockOverview')}}">Stock Overview</a></li>
                            {{--<li><a href="{{route('binCard')}}">Bin Card</a></li>--}}


                        </ul>
                    </li>

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="ion-person-stalker"></i><span>Purchase Orders <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="{{route('createPO')}}">Create PO</a></li>
                            <li><a href="{{route('POHistory')}}">PO History</a></li>
                            <li><a href="{{route('cancelledPo')}}">Cancelled PO</a></li>

                        </ul>
                    </li>


                    {{--</li>--}}
                    {{--<li>--}}
                    {{--<a href="receipt_history" class="waves-effect"><i class="mdi mdi-clipboard-outline"></i><span>Receipts History</span></a>--}}
                    {{--</li>--}}
                    {{----}}
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Payment<span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="{{route('bankAccounts')}}">Bank Accounts</a></li>


                        </ul>
                    </li>

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Products<span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="{{route('addProduct')}}">Add Product</a></li>
                            <li><a href="products">View Products</a></li>
                            <li><a href="{{route('category')}}">Categories</a></li>
                            <li><a href="{{route('brands')}}">Brands</a></li>
                            <li><a href="measurements">Measurements</a></li>


                        </ul>
                    </li>


                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="ion-person-stalker"></i><span>Suppliers <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="{{route('add_suppliers')}}">Add Supplier</a></li>
                            <li><a href="{{route('view_suppliers')}}">View Suppliers</a></li>

                        </ul>
                    </li>

                    <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="ion-person-stalker"></i><span>Customers <span
                    class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                    <ul class="list-unstyled">
                    <li><a href="{{route('addCustomer')}}">Add Customer</a></li>
                    <li><a href="{{route('viewCustomer')}}">View Customers</a></li>
                    </ul>
                    </li>


                    {{--<li class="has_sub">--}}
                    {{--<a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-clipboard-text"></i><span>Voucher<span--}}
                    {{--class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>--}}
                    {{--<ul class="list-unstyled">--}}
                    {{--<li>--}}
                    {{--<a href="create_voucher" class="waves-effect"><span>Create Voucher</span></a>--}}
                    {{--</li>--}}
                    {{--<li>--}}
                    {{--<a href="voucher_history" class="waves-effect"><span>Voucher History</span></a>--}}
                    {{--</li>--}}
                    {{--</ul>--}}
                    {{--</li>--}}


                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Users<span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="add_user">Add User </a></li>
                            <li><a href="view_users">View Users</a></li>
                        </ul>
                    </li>

                    {{--<li class="has_sub">--}}
                    {{--<a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Setting <span--}}
                    {{--class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>--}}
                    {{--<ul class="list-unstyled">--}}

                    {{----}}

                    {{--</ul>--}}
                    {{--</li>--}}


                </ul>
            </div>
            <div class="clearfix"></div>
        </div> <!-- end sidebarinner -->
    </div>
    <!-- Left Sidebar End -->