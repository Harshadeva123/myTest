<!-- Loader -->
<div id="preloader">
    <div id="status">
        <div class="spinner"></div>
    </div>
</div>

<!-- Begin page -->
<div id="wrapper">

    <!-- ========== Left Sidebar Start ========== -->
    <div class="left side-menu">

        <!-- LOGO -->
        <div class="topbar-left">
            <div class="">
                <!--<a href="index" class="logo text-center">Fonik</a>-->
                <a href="" class="logo"><img src="assets/images/logo.png" height="40" alt="logo"></a>
            </div>
        </div>

        <div class="sidebar-inner slimscrollleft">
            <div id="sidebar-menu">

                <ul>

                    <li class="menu-title">Main</li>

                    <li>
                        <a href="{{ url('/') }}" class="waves-effect"><i class="dripicons-device-desktop"></i><span>Dashboard </span></a>
                    </li>


                    @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) &&  \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 9)
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>GRN<span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="grn_management">Create GRN</a></li>
                            <li><a href="grn_history">GRN History</a></li>
                            <li><a href="issue_materials">Issue Materials</a></li>
                            <li><a href="issue_materials_history">Issue History</a></li>
                        </ul>
                    </li>
                    @endif
                    @if( \Illuminate\Support\Facades\Auth::user()->UserRole == 4 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 6)
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Invoice<span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="create_invoice">Create Invoice</a></li>
                            <li><a href="invoice_history">Invoice History</a></li>
                            <li><a href="invoice_return">Invoice Return</a></li>
                            <li><a href="invoice_return_history">Invoice Return History</a></li>
                        </ul>
                    </li>
                    @endif


                    @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) &&   \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 8)

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Transfer <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="new_transfer">New Transfer</a></li>
                            <li><a href="pending_transfer">Pending Transfer</a></li>

                            <li><a href="view_transfer">Transfer History</a></li>
                                <li><a href="transfer_returns">Transfer Returns</a></li>
                                <li><a href="returns_history">Returns History</a></li>
                        </ul>
                    </li>
                    @endif

                    @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) &&   \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 9)

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Production <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="issue_production">Issue Production</a></li>
                            {{--<li><a href="on_going">On-Going Production</a></li>--}}
                            <li><a href="production_input">Production Input</a></li>
                            <li><a href="issued_history">Issued History</a></li>
                            <li><a href="Output_history">Output History</a></li>
                        </ul>
                    </li>
                    @endif

                    @if(\Illuminate\Support\Facades\Auth::user()->UserRole ==1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 || \Illuminate\Support\Facades\Auth::user()->UserRole == 3 || \Illuminate\Support\Facades\Auth::user()->UserRole == 4 || \Illuminate\Support\Facades\Auth::user()->UserRole == 5  )

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Stock<span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                                 <li><a href="opening_stock">Opening Stock</a></li>
                                <li><a href="active_stock">Active Stock</a></li>
                                <li><a href="deactivate_stock">Deactivated Stock</a></li>
                            @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) &&  \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3 )
                                <li><a href="low_stock">Low Stock</a></li>
                                <li><a href="max_stock">Max Stock</a></li>
                                <li><a href="store_change">Store Change</a></li>
                            @endif
                        @if(\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 1)
                                {{--<li><a href="item_return">Item Return</a></li>--}}
                            @endif

                        </ul>
                    </li>
                    @endif

                    @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) &&   \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3 )

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Purchasing <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="create_po">Purchase Order</a></li>
                            <li><a href="view_po">Purchase History</a></li>
                        </ul>
                    </li>
                    @endif

                    @if(\Illuminate\Support\Facades\Auth::user()->UserRole ==1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 || \Illuminate\Support\Facades\Auth::user()->UserRole == 3 || \Illuminate\Support\Facades\Auth::user()->UserRole == 4 || \Illuminate\Support\Facades\Auth::user()->UserRole == 5  )
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Daily Order <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="create_do">Daily Order</a></li>
                            <li><a href="pending_do">Pending Orders</a></li>
                            <li><a href="approved_do">Approved Orders</a></li>
                        </ul>
                    </li>

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Special Order <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="create_so">Special Order</a></li>
                            @if(\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0)
                                <li><a href="pending_so">Pending Special Orders</a></li>
                            @endif
                            <li><a href="approved_so">Approved Special Orders</a></li>
                            <li><a href="view_so">Special Orders History</a></li>
                        </ul>
                    </li>
                    @endif
                    @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) &&   \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3 )

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Payments <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="receive_payment">Receive Payment</a></li>
                            {{--<li><a href="payment_history">Payment History</a></li>--}}
                        </ul>
                    </li>
                    @endif

                    @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) &&   \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3 )
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Setting <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="store">Stores</a></li>
                            <li><a href="measurement">Measurement</a></li>
                            <li>
                                <a href="section_management" class="waves-effect">Sections</a>
                            </li>
                        </ul>
                    </li>


                    @if(\Illuminate\Support\Facades\Auth::user()->UserRole != 3)
                    <li>
                        <a href="agency_management" class="waves-effect"><i class="dripicons-device-desktop"></i><span>Agencies</span></a>
                    </li>
                    @endif

                    <li>
                        <a href="main_category" class="waves-effect"><i class="dripicons-device-desktop"></i><span>Categories</span></a>
                    </li>
                    @endif

                    @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) &&   \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3 )
                    <li>
                        <a href="product" class="waves-effect"><i class="dripicons-device-desktop"></i><span>Products</span></a>
                    </li>
                    @endif


                    @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) &&   \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3 )
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="ion-person-stalker"></i><span>Suppliers <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="add_suppliers">Add Suppliers</a></li>
                            <li><a href="view_suppliers">View Suppliers</a></li>

                        </ul>
                    </li>
                    @endif
                    @if( \Illuminate\Support\Facades\Auth::user()->UserRole == 1 || \Illuminate\Support\Facades\Auth::user()->UserRole == 2 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3  ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 4  ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 5)
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="ion-person-stalker"></i><span>Customers <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="add_customer">Add Customer</a></li>
                            <li><a href="view_customer">View Customer</a></li>

                        </ul>
                    </li>
                    @endif

                    @if(\Illuminate\Support\Facades\Auth::user()->UserRole == 1)
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Users<span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="add_user">Add User </a></li>
                            <li><a href="view_users">View Users</a></li>
                        </ul>
                    </li>
                    @endif


                @if((\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0  &&  \Illuminate\Support\Facades\Auth::user()->UserRole != 8) || (\Illuminate\Support\Facades\Auth::user()->UserRole == 4  &&  \Illuminate\Support\Facades\Auth::user()->UserRole != 8))

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>Reports <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                        <ul class="list-unstyled">
                            <li><a href="stock_reports">Stock Report</a></li>
                            <li><a href="product_reports">Product Report</a></li>
                            <li><a href="daily_production_report">Daily Production Report</a></li>
                            <li><a href="invoice_sales_reports">Invoice Sales Report</a></li>
                            <li><a href="free_issue_reports">Free Issue Report</a></li>
                            <li><a href="special_order_report">Special Order Report</a></li>
                            <li><a href="stock_over_view">Stock Overview</a></li>
                            <li><a href="expired_items_report">Expired Stock Report</a></li>
                            <li><a href="product_selling_report">Product Selling Report</a></li>
                            <li><a href="product_issue_report">Product Issue Report</a></li>
                            <li><a href="item_material_issue_report">Item/Material Issue Report</a></li>
                        </ul>
                    </li>
                    @endif


                </ul>
            </div>
            <div class="clearfix"></div>
        </div> <!-- end sidebarinner -->
    </div>
    <!-- Left Sidebar End -->