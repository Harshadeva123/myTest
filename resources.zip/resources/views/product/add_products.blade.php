@include('includes.header_start')

<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/dropzone/dist/dropzone.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">

@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="card m-b-20">
            <div class="card-body">

                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlertAdd" style="display:none">

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-7">
                        <div class="form-group">
                            <label>Product Name</label>
                            <input type="text" class="form-control" name="itemName" id="itemName"

                                   placeholder="Product Name"/>
                            <small class="text-danger">{{ $errors->first('itemName') }}</small>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="form-group">
                            <label>Product Code</label>
                            <input type="text" class="form-control"  name="itemCode"
                                   id="itemCode"
                                   placeholder="Product Code"/>
                            <small class="text-danger">{{ $errors->first('itemCode') }}</small>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="iType">Brand</label>
                            <select class="form-control select2" name="iType"
                                    id="iType" data-main="MainCat" >
                                <option  value=""  disabled selected>Select Brand
                                </option>
                                @if(isset($types) && count($types)>0)
                                    @foreach($types as $type)
                                        <option value="{{"$type->idItem_Type"}}">{{"$type->type"}}</option>
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Category</label>
                            <select  class="form-control select2" data-sub="subCat"  name="MainCat"
                                     id="MainCat" >
                                <option  value=""  disabled selected>Select category
                                </option>
                                @if(isset($categories ))
                                    @foreach($categories as $category)
                                        <option value="{{"$category->idItem_Category"}}">{{"$category->catName"}}</option>
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="measurement">Measurement</label>
                            <select class="form-control select2" name="measurement"
                                    id="measurement" >
                                <option value="" disabled selected>Select measurement
                                </option>
                                @if(isset($measurements))
                                    @foreach($measurements as $measurement)
                                        <option value="{{"$measurement->idMeasurement"}}">{{"$measurement->measurement"}}</option>
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control" rows="3"  name="description"
                                      id="description"
                                      placeholder="Write some description here"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card m-b-20">
            <div class="card-body">
                <div class="row">

                    <div class="col-lg-3">
                        <div class="form-group">
                            <label>Buying Price</label>
                            <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control"  name="pPrice"
                                   id="pPrice"
                                   placeholder="Buying Price"/>
                            <small class="text-danger">{{ $errors->first('pPrice') }}</small>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label>Unit Price</label>
                            <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control"  name="unitPrice"
                                   id="unitPrice" placeholder="Unit Price"/>
                            <small class="text-danger">{{ $errors->first('unitPrice') }}</small>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group ">
                            <label for="minQty">Min Qty</label>
                            <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control  "  name="minQty"
                                   id="minQty" placeholder="Min Qty"/>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="maxQty">Max Qty</label>
                            <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control "  name="maxQty"
                                   id="maxQty" placeholder="Max Qty"/>
                        </div>
                    </div>

                </div>
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label>Product Bin</label>
                                <input type="text" class="form-control"  name="itemBin"
                                       id="itemBin"
                                       placeholder="Product Bin"/>
                                <small class="text-danger">{{ $errors->first('itemPlace') }}</small>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label>VAT  (%)</label>
                                <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                       class="form-control"  name="vat"
                                       id="vat"
                                       placeholder="VAT"/>
                                <small class="text-danger">{{ $errors->first('itemRate') }}</small>
                            </div>
                        </div>


                        <div class="col-lg-3">
                            <div class="form-group">
                                <label>Tax Rate (%)</label>
                                <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                       class="form-control"  name="taxRate"
                                       id="taxRate"
                                       placeholder="Tax Rate"/>
                                <small class="text-danger">{{ $errors->first('taxRate') }}</small>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <div class="card m-b-20">
            <div class="card-body">


                <div class="row">
                    <div class="col-md-6 text-center  col-sm-12">
                        <form class="" method="post" enctype="multipart/form-data" action="{{ route('saveItemImage') }}"
                              id="uploadItemImage">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label>Image Upload</label>
                                    {{csrf_field()}}
                                    <div class="fallback">
                                        <img onclick="itemImageUploader()" id="MyImage" class="rounded-circle" alt="200x200"
                                             src="{{ URL::asset('assets/images/items/default.jpg')}}"
                                             data-holder-rendered="true" width="150" height="150">
                                        <input onchange="setProImage(this)" name="selected" id="selected" type="file" style="display: none"/>
                                    </div>
                                    <input type="hidden" name="hiddenItemId" id="hiddenItemId">
                                </div>
                            </div>

                        </form>
                    </div>
                    <div class="col-lg-6  col-sm-12 pt-5">
                        <div class="form-group">
                            <label >Product Color</label>

                            <input type="hidden" value="Red" name="hiddencolor" id="hiddencolor">

                            <div class="well well-sm text-center">


                                <div class="btn-group col-lg-12 col-sm-6" data-toggle="buttons">

                                    <label class="btn btn-primary waves-effect waves-light">
                                        <input type="radio" name="itemColor" id="itemColor1" checked value="btn-primary"

                                        >C-1
                                    </label>

                                    <label class="btn btn-secondary waves-effect">
                                        <input  type="radio" name="itemColor" id="itemColor2" value="btn-secondary"

                                        >C-2
                                    </label>
                                    <label class="btn btn-success waves-effect">
                                        <input   type="radio" name="itemColor" value="btn-success" id="itemColor3"

                                        >C-3
                                    </label>

                                    <label class="btn btn-info waves-effect waves-light">
                                        <input   type="radio" name="itemColor" value="btn-info" id="itemColor4"

                                        >C-4
                                    </label>
                                </div>
                                <div class="btn-group col-lg-12 col-sm-6" data-toggle="buttons">
                                    <label class="btn btn-warning waves-effect waves-light">
                                        <input   type="radio" name="itemColor" value="btn-warning" id="itemColor5"

                                        >C-5
                                    </label>
                                    <label class="btn btn-danger waves-effect waves-light">
                                        <input   type="radio" id="itemColor6" name="itemColor" value="btn-danger"

                                        >C-6
                                    </label>
                                    <label class="btn btn-dark waves-effect waves-light">
                                        <input   type="radio" value="btn-dark" name="itemColor" id="itemColor7"

                                        >C-7
                                    </label>
                                </div>


                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="card m-b-20">
            <div class="card-body">



                <div class="row">
                    <div class="col-lg-12">
                        <div class="button-items">
                            <button type="button" onclick="saveItem()"
                                    class="btn btn-md btn-primary waves-effect waves-light pull-right">
                                Save Product
                            </button>
                            <button type="button" onclick="clearInput()"
                                    class="btn btn-md btn-danger waves-effect waves-light pull-right">
                                Clear All
                            </button>
                        </div>
                    </div>
                </div>



                <div class="row" style="display: none">
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Vat Type</label>
                            <input type="number" class="form-control"  name="vatType"
                                   id="vatType"
                                   placeholder="Vat Type"/>
                            <small class="text-danger">{{ $errors->first('vatType') }}</small>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div><!-- container -->

</div> <!-- Page content Wrapper -->


@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/dropzone/dist/dropzone.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}" type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>
<script type="text/javascript">

    $(document).ready(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    $(document).on("wheel", "input[type=number]", function (e) {
        $(this).blur();
    });

    function adMethod(dataID, tableName) {

        $.post('changeItemStatus', {id: dataID}, function () {

        });
    }

    function openProUploader() {
        $("#proImage").click();
    }

    function setProImage(input) {

        if (input.files[0] !== null) {
            var reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById("MyImage").setAttribute("src", e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
            document.getElementById("myUp1").submit();
        }
    }

    function saveItem() {
        $('.notify').empty();
        $('.alert').hide();
        $('.alert').html("");

        var iType = $("#iType").val();
        var MainCat = $("#MainCat").val();
        var itemName = $("#itemName").val();
        var itemCode = $("#itemCode").val();
        var description = $("#description").val();
        var pPrice = $("#pPrice").val();
        var unitPrice = $("#unitPrice").val();
        // var iImage = $("#iImage").val();
        var measurement = $("#measurement").val();
        var minQty = $("#minQty").val();
        var maxQty = $("#maxQty").val();
        var itemColor;


        if (document.getElementById('itemColor1').checked) {

            itemColor = document.getElementById('itemColor1').value;

        }
        else if (document.getElementById('itemColor2').checked) {


            itemColor = document.getElementById('itemColor2').value;


        }
        else if (document.getElementById('itemColor3').checked) {


            itemColor = document.getElementById('itemColor3').value;


        }
        else if (document.getElementById('itemColor4').checked) {


            itemColor = document.getElementById('itemColor4').value;


        }
        else if (document.getElementById('itemColor5').checked) {
            itemColor = document.getElementById('itemColor5').value;
        }
        else if (document.getElementById('itemColor6').checked) {
            itemColor = document.getElementById('itemColor6').value;
        }
        else if (document.getElementById('itemColor7').checked) {
            itemColor = document.getElementById('itemColor7').value;
        }


        var vat = $("#vat").val();
        var vatType = $("#vatType").val();
        var taxRate = $("#taxRate").val();
        var itemBin = $("#itemBin").val();

        $.post('saveMainItem', {
            iType: iType,
            MainCat: MainCat,
            itemName: itemName,
            itemCode: itemCode,
            description: description,
            pPrice: pPrice,
            unitPrice: unitPrice,
            itemColor: itemColor,
            vat: vat,
            vatType: vatType,
            minQty:minQty,
            maxQty:maxQty,
            taxRate: taxRate,
            itemBin: itemBin,
            measurement: measurement,


        }, function (data) {
            if (data.errors != null) {
                $('#errorAlertAdd').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlertAdd').append('<p>' + value + '</p>');
                });
                $('html, body').animate({
                    scrollTop: $("#errorAlertAdd").offset().top
                }, 1000);
            }
            if (data.success != null) {
                $('#hiddenItemId').val(data.itemId);
                $('#uploadItemImage').submit();
            }
        });
    }

    function itemImageUploader() {
        $("#selected").click();
    }

    function setProImage(input) {

        if (input.files[0] !== null) {
            var reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById("MyImage").setAttribute("src", e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $('#uploadItemImage').on('submit',function (event) {
        event.preventDefault();
        $.ajax({
            type:'POST',

            url:"{{route('saveItemImage') }}",

            data:new FormData(this),
            dataType:'JSON',
            contentType:false,
            cache:false,
            processData:false,
            success:function(data){
                if (data.errors != null) {
                    $('#errorAlertAdd').show();
                    $.each(data.errors, function (key, value) {
                        $('#errorAlertAdd').append('<p>' + value + '</p>');
                    });
                    $('html, body').animate({
                        scrollTop: $("#errorAlertAdd").offset().top
                    }, 1000);
                }
                if (data.success != null) {
                    notify({
                        type: "success", //alert | success | error | warning | info
                        title: 'PRODUCT SAVED',
                        autoHide: true, //true | false
                        delay: 2500, //number ms
                        position: {
                            x: "right",
                            y: "top"
                        },
                        icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                        message:'Product saved successfully.'
                    });

                    clearInput();
                }
            }
        });
    })

    function clearInput() {
        $('input').not(':radio').val('');
        $('input').prop('checked',false);
        $('textarea').val('');
        $('#MyImage').attr('src','{{ URL::asset('assets/images/items/default.jpg')}}');
        $('select').val('').trigger('change');
    }

</script>



@include('includes.footer_end')