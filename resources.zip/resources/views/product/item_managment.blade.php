@include('includes.header_start')

<link href="{{ URL::asset('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/dropzone/dist/dropzone.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css')}}" rel="stylesheet"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
<link href="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ URL::asset('assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">

@include('includes.header_end')

<!-- Page title -->
<ul class="list-inline menu-left mb-0">
    <li class="list-inline-item">
        <button type="button" class="button-menu-mobile open-left waves-effect">
            <i class="ion-navicon"></i>
        </button>
    </li>
    <li class="hide-phone list-inline-item app-search">
        <h3 class="page-title">{{ $title }}</h3>
    </li>
</ul>

<div class="clearfix"></div>
</nav>

</div>
<!-- Top Bar End -->

<!-- ==================
     PAGE CONTENT START
     ================== -->

<div class="page-content-wrapper">

    <div class="container-fluid">
        <div class="card m-b-20">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form action="{{ route('product') }}" method="GET">
                            {{csrf_field()}}
                            <div class="row">


                                <div class="form-group col-md-4">
                                        <label for="search">Product Name</label>
                                        <input type="search" name="search" id="search" class="form-control" placeholder="Search product here">
                                </div>

                                <div class="form-group col-md-3">
                                    <div class="form-group">
                                        <label for="list">Brand</label>
                                        <select class="form-control select2 notChangeOnAdd" name="type"
                                                id="type" >
                                            <option value="" disabled selected>Select brand
                                            </option>
                                            @if(isset($types))
                                                @foreach($types as $type)
                                                    <option value="{{"$type->idItem_Type"}}">{{$type->type}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-md-3">
                                    <div class="form-group">
                                        <label for="list">Category</label>
                                        <select class="form-control select2 " name="main"
                                                id="main" >
                                            <option value="" disabled selected>Select category
                                            </option>
                                            @if(isset($cats))
                                                @foreach($cats as $cat)
                                                    <option value="{{"$cat->idItem_Category"}}">{{$cat->catName}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-2 " >
                                              <button class="btn btn-info btn-block" type="submit" style="margin-top:27px;"> Search</button>
                                 </div>

                            </div>
                        </form>
                    </div>

                </div>


                <div class="table-rep-plugin">
                    <div class="table-responsive b-0" data-pattern="priority-columns">
                        <table class="table table-striped table-bordered"
                               cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>PRODUCT NAME</th>
                                <th>BRAND</th>
                                <th >CATEGORY</th>
                                <th style="text-align: right;">UNIT PRICE</th>
                                <TH>USER</TH>
                                <TH>CREATED AT</TH>
                                <TH>LAST UPDATED</TH>
                                <th  style="text-align: center;">STATUS</th>
                                <th>OPTION</th>

                            </tr>
                            </thead>
                            <tbody>
                            @if(isset($getItemViews))
                                @if(count($getItemViews) === 0)
                                    <tr class="no-result-td">
                                        <td colspan="9" style="text-align: center;font-weight: 500">Sorry No Results Found.</td>
                                    </tr>
                                @endif
                                @foreach($getItemViews as $getView)
                                    <tr>
                                        <td>{{$getView->itemcode}} - {{$getView->itemName}}</td>
                                        <td >{{strtoupper($getView->Brand->type)}}</td>
                                        <td>{{strtoupper($getView->MainCategory->catName)}}</td>
                                        <td style="text-align: right;">{{number_format($getView->unitPrice,2)}}</td>

                                        <td style="text-align: right;">{{$getView->User->fName}}</td>
                                        <td >{{$getView->created_at}}</td>
                                        <td >{{$getView->updated_at}}</td>

                                        @if($getView->status == 1)

                                            <td style="text-align: center;">
                                                <p>
                                                    <input type="checkbox" class="status"
                                                           onchange="adMethod('{{ $getView->idItems}}')"
                                                           id="{{"c".$getView->idItems}}" checked
                                                           switch="none"/>
                                                    <label for="{{"c".$getView->idItems}}"
                                                           data-on-label="On"
                                                           data-off-label="Off"></label>
                                                </p>
                                            </td>
                                        @else
                                            <td style="text-align: center;">
                                                <p>
                                                    <input type="checkbox" class="status"
                                                           onchange="adMethod('{{ $getView->idItems}}')"
                                                           id="{{"c".$getView->idItems}}"
                                                           switch="none"/>
                                                    <label for="{{"c".$getView->idItems}}"
                                                           data-on-label="On"
                                                           data-off-label="Off"></label>
                                                </p>
                                            </td>
                                        @endif
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary btn-sm dropdown-toggle"
                                                        type="button" id="dropdownMenuButton"
                                                        data-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">Option
                                                </button>
                                                <div class="dropdown-menu"
                                                     aria-labelledby="dropdownMenuButton">
                                                    @if(\Illuminate\Support\Facades\Auth::user()->UserRole == 2 || \Illuminate\Support\Facades\Auth::user()->UserRole == 1 ||  \Illuminate\Support\Facades\Auth::user()->UserRole == 3  )
                                                    <a class="dropdown-item" href="#" data-toggle="modal"
                                                       data-id="{{$getView->idItems}}" id="itemUpdate"
                                                       data-target="#updateItem">Edit</a>
                                                    @endif

                                                    <a class="dropdown-item" href="#" data-toggle="modal"
                                                       data-id="{{$getView->idItems}}" id="itemView"
                                                       data-target="#myModal1">View</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{$getItemViews->links()}}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div><!-- container -->

</div> <!-- Page content Wrapper -->

<
<!--view item-->
<div class="modal fade" id="myModal1" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <input type="hidden" name="_token" value="{{ Session::token() }}">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">View Product</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="hiddenIID" id="hiddenIID">

                <div class="row">
                    <div class="col-lg-7">
                        <div class="form-group">
                            <label>Product Name</label>
                            <input type="text" disabled class="form-control" name="vItemName" id="vItemName"
                                   required
                                   placeholder="Product Name"/>
                            <small class="text-danger">{{ $errors->first('itemName') }}</small>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="form-group">
                            <label>Product Code</label>
                            <input type="text" disabled class="form-control" required name="vItemCode"
                                   id="vItemCode"
                                   placeholder="Product Code"/>
                            <small class="text-danger">{{ $errors->first('itemCode') }}</small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Brand</label>
                            <select class="form-control " disabled name="vIType"
                                    id="vIType" required>
                                <option VALUE="" disabled selected>Brand not selected
                                </option>
                                @if(isset($types) && count($types)>0)
                                    @foreach($types as $type)
                                        <option value="{{"$type->idItem_Type"}}">{{"$type->type"}}</option>
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Category</label>
                            <select class="form-control " disabled name="vMainCat"
                                    id="vMainCat" required>
                                <option disabled  VALUE=""  selected>Category not selected
                                </option>
                                @if(isset($cats))
                                    @foreach($cats as $cat)
                                        <option value="{{"$cat->idItem_Category"}}">{{$cat->catName}}</option>
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="Vmeasurement">Measurement</label>
                            <select class="form-control " disabled name="Vmeasurement" readonly="true"
                                    id="Vmeasurement" >
                                @if(isset($measurements))
                                    @foreach($measurements as $measurement)
                                        <option value="{{"$measurement->idMeasurement"}}">{{"$measurement->measurement"}}</option>
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Buying Price</label>
                            <input type="number" disabled value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control" required name="vPPrice"
                                   id="vPPrice"
                                   placeholder="Buying Price"/>
                            <small class="text-danger">{{ $errors->first('pPrice') }}</small>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Unit Price</label>
                            <input type="number" disabled value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control" required name="vUnitPrice"
                                   id="vUnitPrice" placeholder="Unit Price"/>
                            <small class="text-danger">{{ $errors->first('unitPrice') }}</small>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Product Bin</label>
                            <input type="text" disabled class="form-control" required name="vItemBin"
                                   id="vItemBin"
                                   placeholder="Product Bin"/>
                            <small class="text-danger">{{ $errors->first('itemPlace') }}</small>
                        </div>
                    </div>
                </div>

                <div class="row">
                        <div class="col-md-3">
                            <img  id="Vimage" class="rounded-circle" alt="200x200"
                                 src="{{ URL::asset('assets/images/items/default.jpg')}}"
                                 data-holder-rendered="true" width="150" height="150">
                        </div>
                    <div class="col-lg-5 col-sm-12 ">
                        <div class="form-group">
                            <div>
                                <label>Product Color</label>
                            </div>

                            <input type="hidden" value="Red" name="hiddencolor" id="hiddencolor">

                            <div class="well well-sm text-center">

                            <div class="btn-group col-lg-12 col-sm-6" data-toggle="buttons">
                                    <label class="btn btn-primary waves-effect waves-light">
                                        <input type="radio" name="viewColor" id="btn-primary" disabled value="btn-primary"

                                        >C-1
                                    </label>
                                    <label class="btn btn-secondary waves-effect">
                                        <input type="radio" name="viewColor" id="btn-secondary"  disabled  value="btn-secondary"

                                        >C-2
                                    </label>
                                    <label class="btn btn-success waves-effect">
                                        <input type="radio" name="viewColor" value="btn-success"  disabled id="itemColor3"

                                        >C-3
                                    </label>
                                    <label class="btn btn-info waves-effect waves-light">
                                        <input type="radio" name="viewColor" value="btn-info"  disabled id="itemColor4"

                                        >C-4
                                    </label>
                            </div>
                            <div class="btn-group col-lg-12 col-sm-6" data-toggle="buttons">
                                    <label class="btn btn-warning waves-effect waves-light">
                                        <input type="radio" name="viewColor" value="btn-warning" disabled  id="itemColor5"

                                        >C-5
                                    </label>
                                    <label class="btn btn-danger waves-effect waves-light">
                                        <input type="radio" id="itemColor6" name="viewColor" disabled  value="btn-danger"

                                        >C-6
                                    </label>
                                    <label class="btn btn-dark waves-effect waves-light">
                                        <input type="radio" value="btn-dark" name="viewColor" disabled  id="itemColor7"

                                        >C-7
                                    </label>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <div class="row">
                            <div class="col-md-12">
                            <div class="form-group ">
                                <label for="VminQty">Min Qty</label>
                                <input type="number" value="0" readonly oninput="this.value = Math.abs(this.value)"
                                       class="form-control  " required name="VminQty"
                                       id="VminQty" placeholder="Min Qty"/>
                            </div>
                            </div>
                            <div class="col-md-12">
                            <div class="form-group">
                                <label for="VmaxQty">Max Qty</label>
                                <input type="number" value="0" readonly oninput="this.value = Math.abs(this.value)"
                                       class="form-control " required name="VmaxQty"
                                       id="VmaxQty" placeholder="Max Qty"/>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="vDescription">Description</label>
                            <textarea type="text" disabled class="form-control" row="3" required name="vDescription"
                                   id="vDescription"
                                   placeholder="Description"></textarea>
                            <small class="text-danger">{{ $errors->first('description') }}</small>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>VAT</label>
                            <input type="number" disabled value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control" required name="vVat"
                                   id="vVat"
                                   placeholder="VAT"/>
                            <small class="text-danger">{{ $errors->first('itemRate') }}</small>
                        </div>
                    </div>
                    <div style="display: none" class="col-lg-4">
                        <div class="form-group">
                            <label>Vat Type</label>
                            <input type="number" disabled class="form-control"
                                   oninput="this.value = Math.abs(this.value)" required name="vVatType"
                                   id="vVatType"
                                   placeholder="Vat Type"/>
                            <small class="text-danger">{{ $errors->first('vatType') }}</small>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Tax Rate</label>
                            <input type="number" disabled value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control" required name="vTaxRate"
                                   id="vTaxRate"
                                   placeholder="Tax Rate"/>
                            <small class="text-danger">{{ $errors->first('taxRate') }}</small>
                        </div>
                    </div>


                </div>

            </div>
        </div>
    </div>
</div>
<!--update-->
<div class="modal fade" id="updateItem" tabindex="-1"
     role="dialog"
     aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <input type="hidden" name="_token" value="{{ Session::token() }}">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Edit Product</h5>
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible " id="errorAlertUpdate" style="display:none">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-8">
                        <div class="form-group">
                            <label>Product Name</label>
                            <input type="text" class="form-control" name="uItemName" id="uItemName"
                                   required
                                   placeholder="Product Name"/>
                            <small class="text-danger">{{ $errors->first('uItemName') }}</small>
                        </div>


                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Product Code</label>
                            <input type="text" class="form-control" required name="uItemCode"
                                   id="uItemCode"
                            placeholder="Product Code"/>
                            <small class="text-danger">{{ $errors->first('uItemCode') }}</small>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Brand</label>
                            <select class="form-control " data-main="uMainCat"  name="uIType"
                                        id="uIType" required>
                                    <option disabled selected>Select Brand
                                    </option>
                                @if(isset($types ) && count($types)>0)
                                    @foreach($types as $type)
                                        <option value="{{"$type->idItem_Type"}}">{{"$type->type"}}</option>
                                    @endforeach
                                @endif
                                </select>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Category</label>
                            <select  data-sub="uSubCat" class="form-control " name="uMainCat"
                                    id="uMainCat" required>
                                <option disabled selected>Select Category
                                </option>
                                @if(isset($cats))
                                    @foreach($cats as $cat)
                                        <option value="{{"$cat->idItem_Category"}}">{{$cat->catName}}</option>
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="Umeasurement">Measurement</label>
                            <select class="form-control" name="Umeasurement"
                                    id="Umeasurement" data-main="MainCat" >
                                <option disabled selected>Select measurement
                                </option>
                                @if(isset($measurements))
                                    @foreach($measurements as $measurement)
                                        <option value="{{"$measurement->idMeasurement"}}">{{"$measurement->measurement"}}</option>
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>

                </div>
                <div class="row">


                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Buying Price</label>
                            <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control" required name="uPPrice"
                                   id="uPPrice"
                                   placeholder="Buying Price"/>
                            <small class="text-danger">{{ $errors->first('uPPrice') }}</small>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Unit Price</label>
                            <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control" required name="uUnitPrice"
                                   id="uUnitPrice" placeholder="Unit Price"/>
                            <small class="text-danger">{{ $errors->first('uUnitPrice') }}</small>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Product Bin</label>
                            <input type="text" class="form-control" required name="uItemBin"
                                   id="uItemBin"
                                   placeholder="Product Bin"/>
                            <small class="text-danger">{{ $errors->first('uItemBin') }}</small>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-3">
                        <form class="" method="post" enctype="multipart/form-data" action="{{ route('updateItemImage') }}"
                              id="updateItemImage">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <input type="hidden" name="hiddenUID" id="hiddenUID">
                                    <label>Image Upload</label>
                                    {{csrf_field()}}
                                    <div class="fallback">
                                        <img onclick="updateImageUploader()" id="updateImage" class="rounded-circle" alt="200x200"
                                             src="{{ URL::asset('assets/images/items/default.jpg')}}"
                                             data-holder-rendered="true" width="150" height="150">
                                        <input onchange="setUpdateImage(this)" name="updatedImage" id="updatedImage" type="file" style="display: none"/>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>

                    <div class="col-lg-5 col-sm-12 pt-5">
                        <div class="form-group">
                            <div>
                                <label>Product Color</label>
                            </div>

                            <input type="hidden" value="Red" name="hiddencolor" id="hiddencolor">


                            <div class="well well-sm text-center">
                            <div class="btn-group col-lg-12 col-sm-6" data-toggle="buttons">

                                    <label class="btn btn-primary  colors waves-effect waves-light">
                                        <input type="radio" name="updateColor" id="UitemColor1" value="btn-primary"

                                        >C-1
                                    </label>

                                    <label class="btn btn-secondary  colors waves-effect">
                                        <input type="radio" name="updateColor" class=" colors" id="UitemColor2" value="btn-secondary"

                                        >C-2
                                    </label>
                                    <label class="btn btn-success colors  waves-effect">
                                        <input type="radio" name="updateColor" class=" colors"  value="btn-success" id="UitemColor3"

                                        >C-3
                                    </label>
                                    <label class="btn btn-info  colors waves-effect waves-light">
                                        <input type="radio" name="updateColor" class=" colors"  value="btn-info" id="UitemColor4"

                                        >C-4
                                    </label>
                            </div>
                            <div class="btn-group col-lg-12 col-sm-6" data-toggle="buttons">
                                    <label class="btn btn-warning  colors waves-effect waves-light">
                                        <input type="radio" name="updateColor" class=" colors"  value="btn-warning" id="UitemColor5"

                                        >C-5
                                    </label>
                                    <label class="btn btn-danger colors  waves-effect waves-light">
                                        <input type="radio" id="UitemColor6" class=" colors"  name="updateColor" value="btn-danger"

                                        >C-6
                                    </label>
                                    <label class="btn btn-dark  colors waves-effect waves-light">
                                        <input type="radio" value="btn-dark" class=" colors "  name="updateColor" id="UitemColor7"

                                        >C-7
                                    </label>

                                </div>


                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <div class="row">
                            <div class="col-md-12">
                            <div class="form-group ">
                                <label for="uminQty">Min Qty</label>
                                <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                       class="form-control  " required name="uminQty"
                                       id="uminQty" placeholder="Min Qty"/>
                            </div>
                            </div>
                            <div class="col-md-12">
                            <div class="form-group">
                                <label for="umaxQty">Max Qty</label>
                                <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                       class="form-control " required name="umaxQty"
                                       id="umaxQty" placeholder="Max Qty"/>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="uDescription">Description</label>
                            <input type="text" class="form-control" required name="uDescription"
                                   id="uDescription"
                                   placeholder="Description"/>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label>VAT (%)</label>
                            <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control" required name="uVat"
                                   id="uVat"
                                   placeholder="VAT"/>
                            <small class="text-danger">{{ $errors->first('uVat') }}</small>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="form-group">
                            <label>Tax Rate (%)</label>
                            <input type="number" value="0" oninput="this.value = Math.abs(this.value)"
                                   class="form-control" required name="uTaxRate"
                                   id="uTaxRate"
                                   placeholder="Tax Rate"/>
                            <small class="text-danger">{{ $errors->first('uTaxRate') }}</small>
                        </div>
                    </div>
                    <div class="col-lg-4" style="padding-top:25px;">
                        <div class="form-group">
                            <button type="button" onclick="updateItem()"
                                    class="btn btn-md btn-warning waves-effect waves-light">
                                Update Product
                            </button>
                        </div>
                    </div>
                </div>

                <div class="row" style="display: none">
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label>Vat Type</label>
                            <input type="number" class="form-control" value="0"
                                   oninput="this.value = Math.abs(this.value)"
                                   required name="uVatType"
                                   id="uVatType"
                                   placeholder="Vat Type"/>
                            <small class="text-danger">{{ $errors->first('uVatType') }}</small>
                        </div>
                    </div>
                </div>
                <div class="row">

                </div>

            </div>
        </div>
    </div>
</div>

@include('includes.footer_start')

<!-- Plugins js -->
<script src="{{ URL::asset('assets/plugins/dropzone/dist/dropzone.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/select2/js/select2.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js')}}" type="text/javascript"></script>

<!-- Plugins Init js -->
<script src="{{ URL::asset('assets/pages/form-advanced.js')}}"></script>

<!-- Required datatable js -->
<script src="{{ URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ URL::asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

<!-- Datatable init js -->
<script src="{{ URL::asset('assets/pages/datatables.init.js')}}"></script>

<!-- Parsley js -->
<script type="text/javascript" src="{{ URL::asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-notify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/my_alerts.js')}}"></script>

<script src="{{ URL::asset('assets/plugins/sweet-alert2/sweetalert2.min.js')}}"></script>
<script src="{{ URL::asset('assets/pages/sweet-alert.init.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.notify.min.js')}}"></script>
<script type="text/javascript">

    $(document).ready(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    $(document).on("wheel", "input[type=number]", function (e) {
        $(this).blur();
    });

    function adMethod(dataID, tableName) {

        $.post('changeItemStatus', {id: dataID}, function () {

        });
    }

    function openProUploader() {
        $("#proImage").click();
    }

    function setProImage(input) {

        if (input.files[0] !== null) {
            var reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById("MyImage").setAttribute("src", e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
            document.getElementById("myUp1").submit();
        }
    }

    $(document).on('click', '#itemView', function () {
        var itemId = $(this).data("id");
        $.post('getItemByID', {itemId: itemId}, function (data) {

            $("#hiddenIID").val(itemId);
            $("#vIType").val(data.items.Item_Type);
            $("#vMainCat").val(data.items.mainCategory).trigger('change');
            $("#vSubCat").html(data.subName);
            $("#Vmeasurement").val(data.items.measurement_idMeasurement);
            $("#vItemName").val(data.items.itemName);
            $("#VminQty").val(data.items.low_qty);
            $("#VmaxQty").val(data.items.max_qty);
            if(data.items.image !== '') {
                $("#Vimage").attr('src', "{{ \Illuminate\Support\Facades\URL::asset('assets/images/items/')}}/"+data.items.image+"");
            }
            else{
                $("#Vimage").attr('src', " {{ \Illuminate\Support\Facades\URL::asset('assets/images/items//default.jpg')}}");
            }
            $("#vItemCode").val(data.items.itemcode);
            $("#vDescription").val(data.items.description);
            $("#vPPrice").val(data.items.purchasePrice);
            $("#vUnitPrice").val(data.items.unitPrice);

            $("input:radio[name='viewColor']").prop('disabled',true);
            $("input:radio[name='viewColor'][value='" +data.items.color+"']").prop('checked', true).prop('disabled',false);

            $("#vItemImage").val(data.items.image);
            $("#vVat").val(data.items.vat);
            $("#vVatType").val(data.items.vatType);
            $("#vTaxRate").val(data.items.taxRate);
            $("#vItemBin").val(data.items.binLocation);
            $("#VisScale").prop("checked",data.items.isScaleItem);
        });
    });




    $(document).on('click', '#itemUpdate', function () {

        var itemId = $(this).data("id");

        $.post('getItemByID', {itemId: itemId}, function (data) {
            $("#hiddenUID").val(itemId);
            $("#uIType").val(data.items.Item_Type);
            $("#uMainCat").val(data.items.mainCategory).trigger('change');
            $("#uItemName").val(data.items.itemName);
            $("#Umeasurement").val(data.items.measurement_idMeasurement);
            $("#uItemCode").val(data.items.itemcode);
            $("#uDescription").val(data.items.description);
            $("#uPPrice").val(data.items.purchasePrice);
            $("#uUnitPrice").val(data.items.unitPrice);
            $("#vIImage").val(data.items.image);
            $("#uVat").val(data.items.vat);
            $("#uminQty").val(data.items.low_qty);
            $("#umaxQty").val(data.items.max_qty);
            $("#uVatType").val(data.items.vatType);
            $("#uTaxRate").val(data.items.taxRate);
            $("#uItemBin").val(data.items.binLocation);
            $("#UisScale").prop("checked",data.items.isScaleItem);

            $("input:radio[name='updateColor'][value='" +data.items.color+"']").prop('checked', true);
            if(data.items.image !== '') {
                $("#updateImage").attr('src', "{{ URL::asset('assets/images/items/')}}/"+ data.items.image+"");
            }
            else{
                $("#updateImage").attr('src',  "{{ URL::asset('assets/images/items/default.jpg')}}");
            }
        });
    });


    function updateItem() {
        $('.notify').empty();
        $('.alert').hide();
        $('.alert').html("");

        var hiddenUID = $("#hiddenUID").val();
        var uIType = $("#uIType").val();
        var uMainCat = $("#uMainCat").val();
        var uSubCat = $("#uSubCat").val();
        var uItemName = $("#uItemName").val();
        var uItemCode = $("#uItemCode").val();
        var uDescription = $("#uDescription").val();
        var Umeasurement = $("#Umeasurement").val();
        var uPPrice = $("#uPPrice").val();
        var uUnitPrice = $("#uUnitPrice").val();
        var uVat = $("#uVat").val();
        var uVatType = $("#uVatType").val();
        var uTaxRate = $("#uTaxRate").val();
        var uItemBin = $("#uItemBin").val();
        var umaxQty = $("#umaxQty").val();
        var uminQty = $("#uminQty").val();
        var isScale = $("#UisScale").prop('checked');

        $.post('updateItem', {
            hiddenUID: hiddenUID,
            uIType: uIType,
            uminQty:uminQty,
            umaxQty:umaxQty,
            uMainCat: uMainCat,
            uSubCat: uSubCat,
            uItemName: uItemName,
            uItemCode: uItemCode,
            uDescription: uDescription,
            uPPrice: uPPrice,
            uUnitPrice: uUnitPrice,
            uVat: uVat,
            isScale: isScale,
            uVatType: uVatType,
            uTaxRate: uTaxRate,
            uItemBin: uItemBin,
            Umeasurement: Umeasurement,

        }, function (data) {
            if (data.errors != null) {
                $('#errorAlertUpdate').show();
                $.each(data.errors, function (key, value) {
                    $('#errorAlertUpdate').append('<p>' + value + '</p>');
                });
                $('html, body').animate({
                    scrollTop: $("#errorAlertUpdate").offset().top
                }, 1000);
            }
            if (data.success != null) {

                    $('#updateItemImage').submit();

            }
        });
    }

    function itemImageUploader() {
        $("#selected").click();
    }
    function updateImageUploader() {
        $("#updatedImage").click();
    }

    function setProImage(input) {

        if (input.files[0] !== null) {
            var reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById("MyImage").setAttribute("src", e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    function setUpdateImage(input) {

        if (input.files[0] !== null) {
            var reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById("updateImage").setAttribute("src", e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $('#uploadItemImage').on('submit',function (event) {
        event.preventDefault();
        $.ajax({
            type:'POST',

            url:"{{route('saveItemImage') }}",

            data:new FormData(this),
            dataType:'JSON',
            contentType:false,
            cache:false,
            processData:false,
            success:function(data){
                if (data.errors != null) {
                    $.each(data.errors, function (key, value) {
                        $('#errorAlertUpdate').append('<p>' + value + '</p>');
                    });
                    $('html, body').animate({
                        scrollTop: $("#errorAlertUpdate").offset().top
                    }, 1000);
                }
                if (data.success != null) {

                    notify({
                        type: "success", //alert | success | error | warning | info
                        title: 'PRODUCT UPDATED',
                        autoHide: true, //true | false
                        delay: 2500, //number ms
                        position: {
                            x: "right",
                            y: "top"
                        },
                        icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                        message:'Product updated successfully.'
                    });

                    $('#addModal').modal('hide');
                }
            }
        });
    })

    $('#updateItemImage').on('submit',function (event) {
        event.preventDefault();
        $.ajax({
            type:'POST',

            url:"{{route('updateItemImage') }}",

            data:new FormData(this),
            dataType:'JSON',
            contentType:false,
            cache:false,
            processData:false,
            success:function(data){
                if (data.errors != null) {

                    $('#errorAlert1').show();
                    $.each(data.errors, function (key, value) {
                        $('#errorAlert1').append('<p>' + value + '</p>');
                    });
                }
                if (data.success != null) {


                    notify({
                        type: "success", //alert | success | error | warning | info
                        title: 'PRODUCT UPDATED',
                        autoHide: true, //true | false
                        delay: 2500, //number ms
                        position: {
                            x: "right",
                            y: "top"
                        },
                        icon: '<img src="{{ URL::asset('assets/images/correct.png')}}" />',

                        message:'Product updated successfully.'
                    });
                    $('#updateItem').modal('hide');

                }
            }
        });
    });


    $( document ).on( 'focus', ':input', function(){
        $( this ).attr( 'autocomplete', 'off' );
    });


    $(document).on("wheel", "input[type=number]", function (e) {
        $(this).blur();
    });

    $('.modal').on('hidden.bs.modal', function () {

        $(".select2").val('').trigger('change');
        $('textarea').val('');
        $('input').not(':radio').val('');
        $('input').not('.status').prop('checked', false);
        $("#MyImage").attr("src","{{ URL::asset('assets/images/items/default.jpg')}}");
        $("#updateImage").attr('src',  "{{ URL::asset('assets/images/items//default.jpg')}}");

        $('.alert').html('');
        $('.alert').hide();
    });



</script>



@include('includes.footer_end')