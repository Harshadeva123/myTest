<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();

Route::get('/signin', function () {
    return view('signin');
})->middleware('guest');

Route::post('/loginMy', 'SecurityController@signIn')->name('loginMy');

Route::group(['middleware' => 'auth', 'prefix' => ''], function () {

    //common
    Route::get('/', function () {
        return view('index', ['title' => 'Home']);
    });
    Route::get('/logout', 'SecurityController@logoutNow')->name('logout');
    Route::post('/activateDeactivate', 'CommonController@activateDeactivate')->name('activateDeactivate');


    //User Management
    Route::get('/add_user', 'UserController@createView')->name('add_user');
    Route::get('/view_users', 'UserController@view')->name('view_users');
    Route::post('/create_user', 'UserController@createUser')->name('createUser');
    Route::post('/getViewUserById', 'UserController@getById')->name('getViewUserById');
    Route::post('/updateUser', 'UserController@update')->name('updateUser');
    Route::post('/updatePassword', 'UserController@updatePassword')->name('updatePassword');
    Route::post('/getViewUserPassById', 'UserController@getPasswordById')->name('getViewUserPassById');
    Route::post('/checkUsername', 'UserController@checkUsername')->name('checkUsername');
    Route::post('/changeUserStatus', 'UserController@changeStatus')->name('changeUserStatus');

    //Product Management
    Route::get('/products', 'ItemController@search')->name('product');
    Route::post('/changeItemStatus', 'ItemController@changeStatus')->name('changeItemStatus');
    Route::post('/getItemByID', 'ItemController@getByID')->name('getItemByID');
    Route::post('/saveMainItem', 'ItemController@save')->name('saveMainItem');
    Route::post('/saveItemImage', 'ItemController@saveImage')->name('saveItemImage');
    Route::post('/updateItemImage', 'ItemController@updateImage')->name('updateItemImage');
    Route::post('/updateItem', 'ItemController@update')->name('updateItem');
    Route::get('/add-product', 'ItemController@index')->name('addProduct');

    //Category management
    Route::get('categories', 'CategoryController@index')->name('category');
    Route::post('changeCategoryStatus', 'CategoryController@changeStatus')->name('changeCategoryStatus');
    Route::post('mainCatUpdate', 'CategoryController@update')->name('mainCatUpdate');
    Route::post('saveMainCategory', 'CategoryController@store')->name('saveMainCategory');

    //Brand management
    Route::get('brands', 'BrandController@index')->name('brands');
    Route::post('saveBrand', 'BrandController@store')->name('saveBrand');
    Route::post('getBrandTableData', 'BrandController@getTableData')->name('getBrandTableData');
    Route::post('changeBrandStatus', 'BrandController@changeStatus')->name('changeBrandStatus');
    Route::post('updateBrand', 'BrandController@update')->name('updateBrand');

    //Measurement management
    Route::get('/measurements', 'MeasurementControllers@index')->name('measurements');
    Route::post('/measurementById', 'MeasurementControllers@getById')->name('measurementById');
    Route::post('/addMeasurement', 'MeasurementControllers@save')->name('addMeasurement');
    Route::post('/changeMeasurementStatus', 'MeasurementControllers@changeStatus')->name('changeMeasurementStatus');
    Route::post('/updateMeasurement', 'MeasurementControllers@update')->name('updateMeasurement');

    //Store management
    Route::get('/stores', 'StoreController@index')->name('stores');
    Route::post('/getStoreByID', 'StoreController@getByID')->name('getStoreByID');
    Route::post('/saveStockType', 'StoreController@store')->name('saveStockType');
    Route::post('/updateStockType', 'StoreController@update')->name('updateStockType');
    Route::post('/changeStoreStatus', 'StoreController@changeStatus')->name('changeStoreStatus');

    //Supplier Management
    Route::get('/add-suppliers', 'SupplierControllers@index')->name('add_suppliers');
    Route::get('/view-suppliers', 'SupplierControllers@search')->name('view_suppliers');
    Route::post('/saveUpdatedSupplier', 'SupplierControllers@saveUpdatedSupplier')->name('saveUpdatedSupplier');
    Route::post('/updateSupplier', 'SupplierControllers@update')->name('updateSupplier');
    Route::post('/saveSupplier', 'SupplierControllers@store')->name('saveSupplier');
    Route::post('/getSupplierByID', 'SupplierControllers@getByID')->name('getSupplierByID');
    Route::post('supplierTableData', 'SupplierControllers@viewTableData')->name('supplierTableData');
    Route::post('/changeSupplierStatus', 'SupplierControllers@changeStatus')->name('changeSupplierStatus');

    //Grn Management
    Route::get('issue_list_search_grn', 'GrnControllers@issueListSearchGrn')->name('issueListSearchGrn');
    Route::get('/add-grn', 'GrnControllers@index')->name('grn_management');
    Route::get('issue_materials_history', 'GrnControllers@issueMaterialsHistory')->name('issueMaterialsHistory');
    Route::get('issue_materials', 'GrnControllers@issueMaterials')->name('issueMaterials');
    Route::get('/grn-history', 'GrnControllers@view')->name('grnSearch');
    Route::get('/searchGrn', 'GrnControllers@search')->name('searchGrn');
    Route::post('/saveUpdateGrn', 'GrnControllers@save')->name('saveUpdateGrn');
    Route::post('/deleteTempGrn', 'GrnControllers@deleteTemp')->name('deleteTempGrn');
    Route::post('/getGrnDataById', 'GrnControllers@getGrnDataById')->name('getGrnDataById');
    Route::post('viewMoreGrn', 'GrnControllers@viewMore')->name('viewMoreGrn');
    Route::post('addItemIssueTempGrn', 'GrnControllers@addItemIssueTempGrn')->name('addItemIssueTempGrn');
    Route::post('getItemIssueTempGrn', 'GrnControllers@getItemIssueTempGrn')->name('getItemIssueTempGrn');
    Route::post('saveItemIssuedGrn', 'GrnControllers@saveItemIssuedGrn')->name('saveItemIssuedGrn');
    Route::post('getGrnTempDataById', 'GrnControllers@getTempById')->name('getGrnTempDataById');
    Route::post('clearGrnTempTable', 'GrnControllers@clearTempTable')->name('clearGrnTempTable');
    Route::post('/addItemToGRN', 'GrnControllers@addItem')->name('addItemToGRN');
    Route::post('/updateTempGrn', 'GrnControllers@updateTempTable')->name('updateTempGrn');
    Route::post('getTempTableDataGrn', 'GrnControllers@getTempTableData')->name('getTempTableDataGrn');
    Route::post('getTempTableTotal', 'GrnControllers@getTempTableTotal')->name('getTempTableTotal');
    Route::post('getBuyingPrice', 'GrnControllers@getBuyingPrice')->name('getBuyingPrice');
    Route::post('viewStockGrn', 'GrnControllers@viewStock')->name('viewStockGrn');


    //opening stock
    Route::get('opening-stock', 'OpeningStockController@index')->name('openingStock');
    Route::post('saveOpeningStock', 'OpeningStockController@save')->name('saveOpeningStock');

    //active stock
    Route::get('active-stock', 'ActiveStockController@index')->name('activeStock');
    Route::post('viewActiveStockMore', 'ActiveStockController@viewMore')->name('viewActiveStockMore');

    //deactivated stock
    Route::get('deactivated-stock', 'DeactivatedStockController@index')->name('deactivateStock');
    Route::post('viewDeactivatedStockMore', 'DeactivatedStockController@viewMore')->name('viewDeactivatedStockMore');

    //low stock
    Route::get('low-stock', 'LowStockController@index')->name('lowStock');

    //Max stock
    Route::get('max-stock', 'MaxStockController@index')->name('maxStock');

    //store change
    Route::get('store-change', 'StockController@storeChange')->name('storeChange');
    Route::post('getItemByStore', 'StockController@getItemByStore')->name('getItemByStore');
    Route::post('getAvailableICountByStore', 'StockController@getAvailableICountByStore')->name('getAvailableICountByStore');
    Route::post('addItemStoreChange', 'StockController@addItemStoreChange')->name('addItemStoreChange');
    Route::post('getStoreChangeData', 'StockController@getStoreChangeData')->name('getStoreChangeData');
    Route::post('deleteStoreChange', 'StockController@deleteStoreChange')->name('deleteStoreChange');
    Route::post('saveStoreChange', 'StockController@saveStoreChange')->name('saveStoreChange');

    Route::get('stock-overview', 'StockController@overView')->name('stockOverview');

    //Bin card
    Route::get('bin-card', 'BinCardController@index')->name('binCard');

    //Purchase order management
    Route::get('create-po', 'POController@index')->name('createPO');
    Route::get('cancelled-po', 'POController@viewCancelled')->name('cancelledPo');
    Route::post('addItemPO', 'POController@add')->name('addItemPO');
    Route::post('getTempPurchaseData', 'POController@getTempData')->name('getTempPurchaseData');
    Route::post('deleteTempPurchase', 'POController@delete')->name('deleteTempPurchase');
    Route::post('savePurchaseOrder', 'POController@save')->name('savePurchaseOrder');
    Route::get('po-history', 'POController@view')->name('POHistory');
    Route::post('viewPurchaseReg', 'POController@viewRegistry')->name('viewPurchaseReg');
    Route::post('purchaseItemChange', 'POController@itemChange')->name('purchaseItemChange');
    Route::post('deletePO', 'POController@deletePO')->name('deletePO');
    Route::post('poTransferToGrn', 'POController@transferToGrn')->name('poTransferToGrn');


    //payment management
    Route::post('getBankDetails', 'PaymentController@getBankDetails')->name('getBankDetails');
    Route::post('addBankDetailsTemp', 'PaymentController@addBankDetailsTemp')->name('addBankDetailsTemp');
    Route::post('getBankAccounts', 'PaymentController@getBankAccounts')->name('getBankAccounts');
    Route::post('loadBankDetailsTemp', 'PaymentController@loadBankDetailsTemp')->name('loadBankDetailsTemp');
    Route::post('loadChequeDetailsTemp', 'PaymentController@loadChequeDetailsTemp')->name('loadChequeDetailsTemp');
    Route::post('addChequeDetailsTemp', 'PaymentController@addChequeDetailsTemp')->name('addChequeDetailsTemp');
    Route::post('paymentTypeChangedDelete', 'PaymentController@paymentTypeChangedDelete')->name('paymentTypeChangedDelete');
    Route::post('BankPaymentsTempDelete', 'PaymentController@BankPaymentsTempDelete')->name('BankPaymentsTempDelete');
    Route::post('ChequePaymentTempDelete', 'PaymentController@ChequePaymentTempDelete')->name('ChequePaymentTempDelete');


    //Bank Accounts
    Route::get('bank_accounts', 'BankAccountController@index')->name('bankAccounts');
    Route::post('getBankAccountData', 'BankAccountController@getBankAccountData')->name('getBankAccountData');
    Route::post('saveBankAccount', 'BankAccountController@save')->name('saveBankAccount');
    Route::post('getBankAccountById', 'BankAccountController@getById')->name('getBankAccountById');
    Route::post('updateBankAccount', 'BankAccountController@update')->name('updateBankAccount');
    Route::post('bankAccountStatus', 'BankAccountController@changeStatus')->name('bankAccountStatus');


//    //Customer Management
    Route::get('add-customer', 'CustomerControllers@index')->name('addCustomer');
    Route::post('saveCustomer', 'CustomerControllers@save')->name('saveCustomer');
    Route::post('changeCustomerStatus', 'CustomerControllers@changeStatus')->name('changeCustomerStatus');
    Route::get('view-customer', 'CustomerControllers@view')->name('viewCustomer');
    Route::post('customerTableData', 'CustomerControllers@viewTableData')->name('customerTableData');
    Route::post('/updateCustomer', 'CustomerControllers@update')->name('updateCustomer');
    Route::post('/viewCustomerByID', 'CustomerControllers@getByID')->name('viewCustomerByID');
    Route::post('/getCustomerByID', 'CustomerControllers@getByID')->name('getCustomerByID');
    Route::get('/searchCustomer', 'CustomerControllers@searchCustomer')->name('searchCustomer');


    //    Route::get('searchMainCat', 'MainCategoryController@searchMainCat')->name('searchMainCat');
//    Route::post('loadMainCategory', 'MainCategoryController@loadMainCategory')->name('loadMainCategory');
//    Route::get('/getCatByID', 'MainCategoryController@getCatByID')->name('getCatByID');
//    Route::post('/getMainCategory', 'MainCategoryController@getMainCategory')->name('getMainCategory');
//    Route::get('/main_category/search', 'MainCategoryController@search')->name('main_category.search');


    //    Route::post('availableItemCount', 'PaymentController@availableItemCount')->name('availableItemCount');
//
//    //common for GRN and opening stock
//    Route::post('/addItemToGRN', 'GrnControllers@addItemToGRN')->name('addItemToGRN');
//    Route::post('getTempTableData', 'GrnControllers@getTempTableData')->name('getTempTableData');
//    Route::post('/updateTempGrn', 'GrnControllers@updateTempGrn')->name('updateTempGrn');
//    Route::post('clearGrnTempTable', 'GrnControllers@clearGrnTempTable')->name('clearGrnTempTable');
//
//    /// common for GRN + Productio + Transfer
//    Route::post('feedStores', 'TransferController@feedStores')->name('feedStores');
//
//    //common for GRN + Production
//    Route::post('availableStoreSelect', 'ProductionController@availableStoreSelect')->name('availableStoreSelect');
//    Route::post('availibleItemsByStore', 'ProductionController@availibleItemsByStore')->name('availibleItemsByStore');
//    Route::get('issueListSearch', 'ProductionController@issueListSearch')->name('issueListSearch');
//    Route::post('deleteTempIssue', 'ProductionController@deleteTempIssue')->name('deleteTempIssue');
//
//
//    //voucher
//    Route::get('/create_voucher', 'VoucherController@createVoucherView')->name('create_voucher');
//    Route::get('/voucher_history', 'VoucherController@voucherHistoryView')->name('voucher_history');
//
//    //receipt
//    Route::get('/receipt_history', 'ReceiptController@receiptHistoryView')->name('receipt_history');
//
//    //Petty Cash
//    Route::get('/petty_cash', 'PettyCashController@petty_cash')->name('petty_cash');
//    Route::get('/pettyCashSearch', 'PettyCashController@pettyCashSearch')->name('petty_cash');
//



//    //Agency Management
//    Route::get('/agency_management', 'AgencyController@searchAgency')->name('agency_management');
//    Route::get('/searchAgency', 'AgencyController@searchAgency')->name('searchAgency');
//    Route::post('/saveCompany', 'AgencyController@saveCompany')->name('saveCompany');
//    Route::get('/getAgencyByID', 'AgencyController@getAgencyByID')->name('getAgencyByID');
//    Route::post('/updateAgency', 'AgencyController@updateAgency')->name('updateAgency');
//
//

//
//    //section management
//    Route::get('section_management', 'SectionController@section')->name('section');
//    Route::post('sectionStatusChange', 'SectionController@sectionStatusChange')->name('sectionStatusChange');
//    Route::post('addSection', 'SectionController@addSection')->name('addSection');
//    Route::post('updateSection', 'SectionController@updateSection')->name('updateSection');
//    Route::get('searchSectionName', 'SectionController@searchSectionName')->name('searchSectionName');
//    Route::post('viewSectionTable', 'SectionController@viewSectionTable')->name('viewSectionTable');
//





//
//    Route::get('/add_lead', 'CustomerControllers@addLeadView')->name('add_lead');
//
//    //purchase order
//    Route::get('create_po', 'PurchaseController@createPO')->name('createPO');
//    Route::get('view_po', 'PurchaseController@viewPo')->name('viewPo');
//    Route::post('addItemPO', 'PurchaseController@addItemPO')->name('addItemPO');
//    Route::get('PoSearch', 'PurchaseController@PoSearch')->name('PoSearch');
//
//    //reports
//    Route::get('product_issue_report', 'ReportController@productIssueReport')->name('productIssueReport');
//    Route::get('daily_production_report', 'ReportController@dailyProductionReport')->name('dailyProductionReport');
//    Route::post('daily_production_report', 'ReportController@dailyProductionReport')->name('dailyProductionReport');
//    Route::post('viewDailyProductionMore', 'ReportController@viewDailyProductionMore')->name('viewDailyProductionMore');
//    Route::get('item_material_issue_report', 'ReportController@itemMaterialIssueReport')->name('itemMaterialIssueReport');
//    Route::post('item_material_issue_report', 'ReportController@itemMaterialIssueReport')->name('itemMaterialIssueReport');
//    Route::post('product_issue_report', 'ReportController@productIssueReport')->name('productIssueReport');
//    Route::get('invoice_sales_reports', 'ReportController@invoiceSalesReports')->name('invoiceSalesReports');
//    Route::get('product_selling_report', 'ReportController@productSellingReport')->name('productSellingReport');
//    Route::post('product_selling_report', 'ReportController@productSellingReport')->name('productSellingReport');
//    Route::get('special_order_report', 'ReportController@specialOrderPayment')->name('specialOrderPayment');
//    Route::post('special_order_report', 'ReportController@specialOrderPayment')->name('specialOrderPayment');
//    Route::get('free_issue_reports', 'ReportController@freeIssueReports')->name('freeIssueReports');
//    Route::post('invoice_sales_reports', 'ReportController@invoiceSalesReports')->name('invoiceSalesReports');
//    Route::get('stock_reports', 'ReportController@stockReports')->name('stockReports');
//    Route::get('product_reports', 'ReportController@productReports')->name('productReports');
//    Route::post('product_reports', 'ReportController@productReports')->name('productReports');
//    Route::get('searchReportStock', 'ReportController@searchReportStock')->name('searchReportStock');
//    Route::get('expired_items_report', 'ReportController@expiredItemsReport')->name('expiredItemsReport');
//    Route::post('viewExpireStockMore', 'ReportController@viewExpireStockMore')->name('viewExpireStockMore');
//    Route::get('searchExpireReportStock', 'ReportController@searchExpireReportStock')->name('searchExpireReportStock');
//    Route::post('stock_over_view', 'ReportController@stockOverView')->name('stockOverView');
//    Route::post('getInvoiceItemsForReport', 'ReportController@getInvoiceItemsForReport')->name('getInvoiceItemsForReport');
//
//    //Stock only for main branch
//    Route::get('low_stock', 'StockController@lowStock')->name('lowStock');
//    Route::post('viewMaxStockMore', 'StockController@viewMaxStockMore')->name('viewMaxStockMore');
//    Route::post('viewLowStockMore', 'StockController@viewLowStockMore')->name('viewLowStockMore');
//    Route::get('max_stock', 'StockController@maxStock')->name('maxStock');
//    Route::get('search_max_stock', 'StockController@searchMaxStock')->name('searchMaxStock');
//    Route::get('search_low_stock', 'StockController@searchLowStock')->name('searchLowStock');
//
//
//    //transfer
//    Route::get('new_transfer', 'TransferController@newTransfer')->name('newTransfer');
//    Route::get('pending_transfer', 'TransferController@transferPending')->name('transferPending');
//    Route::get('returns_history', 'TransferController@returnsHistory')->name('returnsHistory');
//    Route::post('getTransferTempTable', 'TransferController@getTransferTempTable')->name('getTransferTempTable');
//    Route::post('viewPendingReturns', 'TransferController@viewPendingReturns')->name('viewPendingReturns');
//    Route::post('cancelTransfer', 'TransferController@cancelTransfer')->name('cancelTransfer');
//    Route::post('deleteTempTransfer', 'TransferController@deleteTempTransfer')->name('deleteTempTransfer');
//    Route::post('addItemTransferTemp', 'TransferController@addItemTransferTemp')->name('addItemTransferTemp');
//    Route::post('feedItem', 'TransferController@feedItem')->name('feedItem');
//    Route::post('clearTransferTempTable', 'TransferController@clearTransferTempTable')->name('clearTransferTempTable');
//    Route::post('saveTransfer', 'TransferController@saveTransfer')->name('saveTransfer');
//    Route::get('view_transfer', 'TransferController@viewTransfer')->name('viewTransfer');
//    Route::post('viewTrasferedItems', 'TransferController@viewTrasferedItems')->name('viewTrasferedItems');
//    Route::get('transferSearch', 'TransferController@transferSearch')->name('transferSearch');
//    Route::post('transferItemChanged', 'TransferController@transferItemChanged')->name('transferItemChanged');
//    Route::get('printTransferStock/{id}/{create}', 'TransferController@printTransferStock')->name('printTransferStock');
//    Route::get('printTransferStockFromView/{id}', 'TransferController@printTransferStockFromView')->name('printTransferStockFromView');
//    Route::get('editTransfer', 'TransferController@editTransfer')->name('editTransfer');
//    Route::post('saveAndEditTransfer', 'TransferController@saveAndEditTransfer')->name('saveAndEditTransfer');
//    Route::post('loadFromOrder', 'TransferController@loadFromOrder')->name('loadFromOrder');
//    Route::post('getSelectedOrderData', 'TransferController@getSelectedOrderData')->name('getSelectedOrderData');
//    Route::post('selectOrderForTransfer', 'TransferController@selectOrderForTransfer')->name('selectOrderForTransfer');
//    Route::get('transfer_returns', 'TransferController@transferReturns')->name('transferReturns');
//    Route::get('transfer_return_search', 'TransferController@transferReturnSearch')->name('transferReturnSearch');
//    Route::post('returnTransfer', 'TransferController@returnTransfer')->name('returnTransfer');
//    Route::post('getTransferByCompany', 'TransferController@getTransferByCompany')->name('getTransferByCompany');
//    Route::get('editPendingTransfer', 'TransferController@editPendingTransfer')->name('editPendingTransfer');
//    Route::post('getTransferItemTable', 'TransferController@getTransferItemTable')->name('getTransferItemTable');
//    Route::post('deleteTransferItems', 'TransferController@deleteTransferItems')->name('deleteTransferItems');
//    Route::post('addItemTransferItem', 'TransferController@addItemTransferItem')->name('addItemTransferItem');
//    Route::post('markTransferDelivery', 'TransferController@markTransferDelivery')->name('markTransferDelivery');
//
//
//    //production
//    Route::get('issue_production', 'ProductionController@issueMeterials')->name('issueMeterials');
//    Route::get('Output_history', 'ProductionController@OutputHistory')->name('OutputHistory');
//    Route::get('OngoingIssueListSearch', 'ProductionController@OngoingIssueListSearch')->name('OngoingIssueListSearch');
//    Route::get('production_input', 'ProductionController@productionOutput')->name('productionOutput');
//    Route::get('issued_history', 'ProductionController@issueHistory')->name('issueHistory');
//    Route::post('addItemProductionOutputTemp', 'ProductionController@addItemProductionOutputTemp')->name('addItemProductionOutputTemp');
//    Route::post('deleteProductionOutAll', 'ProductionController@deleteProductionOutAll')->name('deleteProductionOutAll');
//    Route::post('saveProductionOutput', 'ProductionController@saveProductionOutput')->name('saveProductionOutput');
//    Route::post('getProductionOutTemp', 'ProductionController@getProductionOutTemp')->name('getProductionOutTemp');
//    Route::post('deleteTempProductionOut', 'ProductionController@deleteTempProductionOut')->name('deleteTempProductionOut');
//    Route::post('viewIssueItemList', 'ProductionController@viewIssueItemList')->name('viewIssueItemList');
//    Route::post('viewProductOutputItemList', 'ProductionController@viewProductOutputItemList')->name('viewProductOutputItemList');
//    Route::post('viewExpected', 'ProductionController@viewExpected')->name('viewExpected');
//    Route::post('markAsConpleted', 'ProductionController@markAsConpleted')->name('markAsConpleted');
//    Route::post('addExpectedItem', 'ProductionController@addExpectedItem')->name('addExpectedItem');
//    Route::post('showExpectedTableData', 'ProductionController@showExpectedTableData')->name('showExpectedTableData');
//    Route::post('deleteExpectedTempIssue', 'ProductionController@deleteExpectedTempIssue')->name('deleteExpectedTempIssue');
//    Route::post('viewExpectedCompleteModal', 'ProductionController@viewExpectedCompleteModal')->name('viewExpectedCompleteModal');
//    Route::post('getItemMeasurement', 'ProductionController@getItemMeasurement')->name('getItemMeasurement');
//    Route::post('addItemIssueTemp', 'ProductionController@addItemIssueTemp')->name('addItemIssueTemp');
//    Route::post('getItemIssueTemp', 'ProductionController@getItemIssueTemp')->name('getItemIssueTemp');
//    Route::post('saveItemIssued', 'ProductionController@saveItemIssued')->name('saveItemIssued');
//

//
//    //payments receive
//    Route::get('receive_payment', 'PaymentController@receivePayment')->name('receivePayment');
//    Route::get('payment_history', 'PaymentController@paymentHistory')->name('paymentHistory');
//    Route::get('printTransferStockBulk/{id}', 'PaymentController@printTransferStockBulk')->name('printTransferStockBulk');
//    Route::post('viewPaymentsTransfer', 'PaymentController@viewPaymentsTransfer')->name('viewPaymentsTransfer');
//    Route::post('viewPaymentModalTransfer', 'PaymentController@viewPaymentModalTransfer')->name('viewPaymentModalTransfer');
//    Route::post('showTableDataTransfer', 'PaymentController@showTableDataTransfer')->name('showTableDataTransfer');
//    Route::post('addPaymentTransfer', 'PaymentController@addPaymentTransfer')->name('addPaymentTransfer');
//    Route::post('viewBulkPaymentModalTransfer', 'PaymentController@viewBulkPaymentModalTransfer')->name('viewBulkPaymentModalTransfer');
//    Route::post('bulk_addPaymentTransfer', 'PaymentController@bulk_addPaymentTransfer')->name('bulk_addPaymentTransfer');
//    Route::post('totalChequeAmountTemp', 'PaymentController@totalChequeAmountTemp')->name('totalChequeAmountTemp');
//    Route::post('totalBankAmountTemp', 'PaymentController@totalBankAmountTemp')->name('totalBankAmountTemp');
//
//
//
//    //special order
//    Route::get('create_so', 'SpecialOrderController@createSo')->name('createSo');
//    Route::get('approved_so', 'SpecialOrderController@approvedSo')->name('approvedSo');
//    Route::post('saveSalesOrder', 'SpecialOrderController@saveSalesOrder')->name('saveSalesOrder');
//    Route::get('view_so', 'SpecialOrderController@viewSo')->name('viewSo');
//    Route::post('viewSalesOrder', 'SpecialOrderController@viewSalesOrder')->name('viewSalesOrder');
//    Route::get('soSearch', 'SpecialOrderController@soSearch')->name('soSearch');
//    Route::get('SO_Pending_Search', 'SpecialOrderController@SoPendingSearch')->name('SoPendingSearch');
//    Route::get('pending_so', 'SpecialOrderController@pendingSo')->name('pendingSo');
//    Route::post('approveSOrder', 'SpecialOrderController@approveSOrder')->name('approveSOrder');
//    Route::post('checkSODue', 'SpecialOrderController@checkSODue')->name('checkSODue');
//    Route::post('markAsDeliveredSO', 'SpecialOrderController@markAsDeliveredSO')->name('markAsDeliveredSO');
//    Route::post('DeliveredWithPaymentSO', 'SpecialOrderController@DeliveredWithPaymentSO')->name('DeliveredWithPaymentSO');
//    Route::get('PrintSO/{id}', 'SpecialOrderController@PrintSO')->name('PrintSO');
//
//    //Daily orders
//    Route::get('create_do', 'DailyOrderController@createDo')->name('createDo');
//    Route::post('placeDailyOrder', 'DailyOrderController@placeDailyOrder')->name('placeDailyOrder');
//    Route::get('pending_do', 'DailyOrderController@pendingDo')->name('pendingDo');
//    Route::post('viewOrderItems', 'DailyOrderController@viewOrderItems')->name('viewOrderItems');
//    Route::post('approveOrder', 'DailyOrderController@approveOrder')->name('approveOrder');
//    Route::get('approved_do', 'DailyOrderController@approvedDo')->name('approvedDo');
//    Route::post('getOrderItems', 'DailyOrderController@getOrderItems')->name('getOrderItems');
//
//    //Customer Management
//    Route::get('/customer_management', 'CustomerControllers@getView')->name('customer_management');
//    Route::get('/add_customer', 'CustomerControllers@getView')->name('add_customer');
//    Route::post('/saveCustomer', 'CustomerControllers@saveCustomer')->name('saveCustomer');
//    Route::get('/view_customer', 'CustomerControllers@searchCustomer')->name('view_customer');
//    Route::post('/updateCustomer', 'CustomerControllers@updateCustomer')->name('updateCustomer');
//    Route::post('/viewCustomerByID', 'CustomerControllers@viewCustomerByID')->name('viewCustomerByID');
//    Route::post('/getCustomerByID', 'CustomerControllers@getCustomerByID')->name('getCustomerByID');
//    Route::get('/searchCustomer', 'CustomerControllers@searchCustomer')->name('searchCustomer');
//
//
//    //invoice
//    Route::get('create_invoice', 'InvoiceController@createInvoice')->name('createInvoice');
//    Route::post('getInvoiceTemp', 'InvoiceController@getInvoiceTemp')->name('getInvoiceTemp');
//    Route::post('addBarcodeItemToInvoiceTemp', 'InvoiceController@addBarcodeItemToInvoiceTemp')->name('addBarcodeItemToInvoiceTemp');
//    Route::post('addItemToInvoice', 'InvoiceController@addItemToInvoice')->name('addItemToInvoice');
//    Route::post('saveInvoice', 'InvoiceController@saveInvoice')->name('saveInvoice');
//    Route::post('deleteTempInvoice', 'InvoiceController@deleteTempInvoice')->name('deleteTempInvoice');
//    Route::get('invoice_history', 'InvoiceController@invoiceHistory')->name('invoiceHistory');
//    Route::post('viewInvoiceReg', 'InvoiceController@viewInvoiceReg')->name('viewInvoiceReg');
//    Route::get('invoiceSearch', 'InvoiceController@invoiceSearch')->name('invoiceSearch');
//    Route::get('invoice_return', 'InvoiceController@invoiceReturn')->name('invoiceReturn');
//    Route::get('invoice_return_search', 'InvoiceController@invoiceReturnSearch')->name('invoice_return_search');
//    Route::post('returnInvoice', 'InvoiceController@returnInvoice')->name('returnInvoice');
//    Route::get('invoice_return_history', 'InvoiceController@invoiceReturnHistory')->name('invoiceReturnHistory');
//    Route::get('return_inv_hist_search', 'InvoiceController@returnInvHistSearch')->name('returnInvHistSearch');
//    Route::post('showInvoiceForReturn', 'InvoiceController@showInvoiceForReturn')->name('showInvoiceForReturn');
//    Route::get('PrintInvoice/{id}', 'InvoiceController@PrintInvoice')->name('PrintInvoice');
//    Route::post('getInvoiceItems', 'InvoiceController@getInvoiceItems')->name('getInvoiceItems');


});

