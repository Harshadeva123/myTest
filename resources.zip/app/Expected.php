<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-002
// * Date: 8/2/2019
// * Time: 11:02 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class Expected extends Model
//{
//    protected $table = 'expected_output';
//    protected $primaryKey = 'idExpected_Product';
//
//    public function item()
//    {
//        return $this->belongsTo(Item::class,'Items_idItems');
//    }
//    public function production()
//    {
//        return $this->belongsTo(ProductionIssue::class,'idProduction_Issue');
//    }
//}