<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 11:02 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class GrnItemsTemp extends Model
{
    protected $table = 'grn_items_temp';
    protected $primaryKey = 'idGRn_Temp';

    public function Store()
    {
        return $this->belongsTo(Store::class,'store');
    }
    public function item()
    {
        return $this->belongsTo(Item::class,'Items_idItems');
    }

}