<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class PurchaseOrderReg extends Model
{
    protected $table = 'po_reg';
    protected $primaryKey = 'idPO_Reg';


    public function Purchase()
    {
        return $this->belongsTo(Purchase::class, 'Purchase_Order_idPO');
    }
    public function item()
    {
        return $this->belongsTo(Item::class, 'items_idItems');
    }


}
