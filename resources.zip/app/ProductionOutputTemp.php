<?php
//
//namespace App;
//
//use Illuminate\Database\Eloquent\Model;
//
//class ProductionOutputTemp extends Model
//{
//    protected $table = 'production_output_temp';
//    protected $primaryKey = 'idproduction_output_temp';
//
//    public function company()
//    {
//        return $this->belongsTo(CompanyInfo::class,'companyinfomaster_idCompanyInfo');
//    }
//    public function store()
//    {
//        return $this->belongsTo(StockType::class,'stock_type_idStock_Type');
//    }
//    public function user()
//    {
//        return $this->belongsTo(User::class,'usermaster_idUser');
//    }
//    public function item()
//    {
//        return $this->belongsTo(Item::class,'items_idItems');
//    }
//    public function section()
//    {
//        return $this->belongsTo(Section::class,'section_idSection');
//    }
//}
