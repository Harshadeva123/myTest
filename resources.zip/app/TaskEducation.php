<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaskEducation extends Model
{
    protected $table = 'task_education';
    protected $primaryKey = 'idtask_education';
}
