<?php
///**
// * Created by PhpStorm.
// * User: Nimesh VGS
// * Date: 2/10/2020
// * Time: 10:15 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class Receipt extends Model
//{
//    protected $table='receipt';
//    protected $primaryKey='idReceipt';
//
//    public function Customer(){
//        return $this->belongsTo(Customer::class,'Customer_idCustomer');
//    }
//    public function User(){
//        return $this->belongsTo(User::class,'Master_User');
//    }
//}