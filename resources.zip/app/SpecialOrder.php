<?php
///**
// * Created by PhpStorm.
// * User: ishar
// * Date: 3/10/2019
// * Time: 11:30 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class SpecialOrder extends Model
//{
//    protected $table = 'special_order';
//    protected $primaryKey = 'idOrder';
//
//
//    public function companyInfo()
//    {
//        return $this->belongsTo(CompanyInfo::class, 'Company');
//    }
//    public function user()
//    {
//        return $this->belongsTo(User::class, 'UserMaster_idUser');
//    }
//    public function paymentType()
//    {
//        return $this->belongsTo(PaymentType::class, 'payment_type');
//    }
//
//}