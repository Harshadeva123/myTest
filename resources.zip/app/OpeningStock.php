<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class OpeningStock extends Model
{
    protected $table = 'opening_stock';
    protected $primaryKey = 'idopening_stock';


    public function user()
    {
        return $this->belongsTo(User::class, 'usermaster_idUser');
    }



}
