<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentRefference extends Model
{
    protected $table = 'payment_referances';
    protected $primaryKey = 'idpayment_referance';


    public function payment()
    {
        return $this->belongsTo(Payment::class,'payment_idpayment');
    }

}
