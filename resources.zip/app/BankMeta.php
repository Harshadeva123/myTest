<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class BankMeta extends Model
{
    protected $table = 'bank';
    protected $primaryKey = 'idbank';

    public function cheque()
    {
        return $this->hasMany(ChequePayments::class);
    }
    public function accounts()
    {
        return $this->hasMany(BankAccount::class);
    }
    public function bankPayments()
    {
        return $this->hasMany(BankPayments::class);
    }
    public function bankPaymentsTemos()
    {
        return $this->hasMany(BankPaymentsTemp::class);
    }
    public function chequeTemps()
    {
        return $this->hasMany(ChequePaymentTemp::class);
    }

}
