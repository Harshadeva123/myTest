<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 4/7/2019
// * Time: 3:01 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class InvoiceTemp extends Model
//{
//    protected $table = 'invoice_reg_temp';
//    protected $primaryKey = 'idinvoice_reg_temp';
//
//    public function item()
//    {
//        return $this->belongsTo(Item::class, 'items_idItems');
//    }
//
//}