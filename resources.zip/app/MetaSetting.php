<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MetaSetting extends Model
{
    protected $table = 'meta_settings';
    protected $primaryKey = 'idSettings';

    public function company()
    {
        return $this->hasOne(CompanyInfo::class,'Company');
    }
}
