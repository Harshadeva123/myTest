<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/8/2019
// * Time: 11:02 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class ReturnItemTransferAdded extends Model
//{
//    protected $table = 'return_items_tranfer_added';
//    protected $primaryKey = 'idreturn_items_tranfer_added';
//
//    public function transfer()
//    {
//        return $this->belongsTo(StockTransfer::class,'stock_transfer_idStock_Transfer');
//    }
//    public function returns()
//    {
//        return $this->belongsTo(TransferReturns::class,'transfer_returns_idtransfer_returns');
//    }
//
//    public function returnItem()
//    {
//        return $this->belongsTo(TransferItem::class,'transfer_item_idTransfer_Item');
//    }
//
//}