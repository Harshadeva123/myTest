<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    protected $table = 'purchase_order';
    protected $primaryKey = 'idPO';


    public function registry()
    {
        return $this->hasMany(PurchaseOrderReg::class);
    }
    public function supplier()
    {
        return $this->belongsTo(Supplier::class, 'Supplier_idSupplier');
    }
    public function companyInfo()
    {
        return $this->belongsTo(CompanyInfo::class, 'Company');
    }
    public function payment()
    {
        return $this->belongsTo(PaymentType::class, 'meta_payment_type');
    }


}
