<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $table = 'payment';
    protected $primaryKey = 'idpayment';


    public function user()
    {
        return $this->belongsTo(User::class, 'usermaster_idUser');
    }
    public function company()
    {
        return $this->belongsTo(CompanyInfo::class, 'Company');
    }
    public function payment()
    {
        return $this->belongsTo(PaymentType::class, 'payment_type_idpayment_type');
    }
    public function cheque()
    {
        return $this->hasMany(ChequePayments::class);
    }
    public function bankPayments()
    {
        return $this->hasMany(BankPayments::class);
    }
    public function PaymentRefference()
    {
        return $this->hasMany(PaymentRefference::class);
    }

}
