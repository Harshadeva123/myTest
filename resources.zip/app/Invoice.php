<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 4/7/2019
// * Time: 3:01 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//use phpDocumentor\Reflection\DocBlock\Tags\Return_;
//
//class Invoice extends Model
//{
//    protected $table = 'invoice';
//    protected $primaryKey = 'idInvoice';
//
//    public function invoiceRegs()
//    {
//        return $this->hasMany(InvoiceReg::class);
//    }
//    public function invoiceItem(){
//        return $this->hasMany(InvoiceRegItems::class);
//    }
//    public function returned(){
//        return $this->hasMany(InvoiceReturn::class);
//    }
//    public function user(){
//        return $this->belongsTo(User::class,'UserMaster_idUser');
//    }
//    public function paymentT(){
//        return $this->belongsTo(PaymentType::class,'paymentType');
//    }
//    public function compnayInfo(){
//        return $this->belongsTo(CompanyInfo::class,'Company');
//    }
//
//}