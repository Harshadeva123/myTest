<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 5/5/2019
// * Time: 6:03 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class TransferItem extends Model
//{
//    protected $table = 'transfer_item';
//    protected $primaryKey = 'idTransfer_Item';
//
//    public function transferStock(){
//        return $this->belongsTo(StockTransfer::class,'idStock_Transfer');
//    }
//    public function stock(){
//        return $this->belongsTo(Stock::class,'Stock_idStock');
//    }
//    public function ToStore(){
//        return $this->belongsTo(StockType::class,'From_Stock');
//    }
//
//    public function FromStore(){
//        return $this->belongsTo(StockType::class,'To_Stock');
//    }
//
//}