<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 4/7/2019
// * Time: 3:01 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class InvoiceRegItems extends Model
//{
//    protected $table = 'invoice_reg_items';
//    protected $primaryKey = 'idinvoice_reg_items';
//
//    public function item()
//    {
//        return $this->belongsTo(Item::class, 'items_idItems');
//    }
//    public function invoice()
//    {
//        return $this->belongsTo(Invoice::class, 'invoice_idInvoice');
//    }
//    public function returned(){
//        return $this->hasMany(InvoiceReturn::class);
//    }
//
//}