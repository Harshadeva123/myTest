<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-002
 * Date: 7/23/2019
 * Time: 2:45 PM
 */

namespace App;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    protected $table = 'items';
    protected $primaryKey = 'idItems';


    public function Brand(){
        return $this->belongsTo(Brand::class,'Item_Type');
    }
    public function transferReturns(){
        return $this->hasMany(TransferReturns::class);
    }
    public function SubCategory(){
        return $this->belongsTo(SubCategory::class,'Sub_Category');
    }
    public function MainCategory(){
        return $this->belongsTo(MainCategory::class,'mainCategory');
    }
    public function measurement(){
        return $this->belongsTo(Measurement::class,'measurement_idMeasurement');
    }
    public function GrnItemsTemp(){
        return $this->hasMany(GrnItemsTemp::class);
    }
    public function storeChange(){
        return $this->hasMany(StoreChange::class);
    }
    public function purchaseTemp(){
        return $this->hasMany(PurchaseTempary::class);
    }
    public function TransferTemp(){
        return $this->hasMany(TransferItemTemp::class);
    }
    public function stock(){
        return $this->hasMany(Stock::class);
    }
    public function invoiceTemps(){
        return $this->hasMany(InvoiceTemp::class);
    }
    public function invoiceItem(){
        return $this->hasMany(InvoiceRegItems::class);
    }
    public function itemIssuedTemps(){
        return $this->hasMany(ItemIssueTemp::class);
    }
    public function productionOutTemp()
    {
        return $this->hasMany(ProductionOutputTemp::class);
    }
    public function itemIssuedlists(){
        return $this->hasMany(ItemIssueList::class);
    }
    public function expects(){
        return $this->hasMany(Expected::class);
    }
    public function invoiceRegs()
    {
        return $this->hasMany(InvoiceReg::class);
    }
    public function expectedTemps()
    {
        return $this->hasMany(ExpectedTemp::class);
    }
    public function User()
    {
        return $this->belongsTo(User::class, 'UserMaster_idUser');
    }
}
