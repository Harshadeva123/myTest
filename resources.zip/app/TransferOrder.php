<?php
//
//namespace App;
//
//use Illuminate\Database\Eloquent\Model;
//
//class TransferOrder extends Model
//{
//    protected $table = 'transfer_order';
//    protected $primaryKey = 'idtransfer_order';
//
//}
