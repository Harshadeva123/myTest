<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/8/2019
// * Time: 8:32 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class ItemIssueTemp extends Model
//{
//    protected $table = 'item_issue_temp';
//    protected $primaryKey = 'item_issue_temp_id';
//
//    public function item()
//    {
//        return $this->belongsTo(Item::class,'items_idItems');
//    }
//    public function store()
//    {
//        return $this->belongsTo(StockType::class,'stock_type_idStock_Type');
//    }
//}