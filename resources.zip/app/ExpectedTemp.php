<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-002
// * Date: 8/2/2019
// * Time: 11:02 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class ExpectedTemp extends Model
//{
//    protected $table = 'expected_temp';
//    protected $primaryKey = 'idexpectedTemp';
//
//    public function item()
//    {
//        return $this->belongsTo(Item::class,'items_idItems');
//    }
//    public function user()
//    {
//        return $this->belongsTo(User::class,'usermaster_idUser');
//    }
//}