<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class ChequePayments extends Model
{
    protected $table = 'cheque_payment';
    protected $primaryKey = 'idcheque_payment';


    public function payment()
    {
        return $this->belongsTo(Payment::class, 'payment_idpayment');
    }
    public function company()
    {
        return $this->belongsTo(CompanyInfo::class, 'Company');
    }
    public function bank()
    {
        return $this->belongsTo(BankMeta::class, 'bank_meta_idbank_meta');
    }


}
