<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-002
// * Date: 8/2/2019
// * Time: 11:02 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class Product extends Model
//{
//    public $fillable = ['name', 'details'];
//}