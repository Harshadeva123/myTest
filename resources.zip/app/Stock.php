<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{
    protected $table = 'stock';
    protected $primaryKey = 'idStock';

//    public function availbaleSum(){
//        $id = $this->Items_idItems;
//        $stocks = Stock::wher('Items_idItems',$id)->get();
//        $total = 0;
//        foreach ($stocks as $stock){
//            $total += $stock->qty_available;
//        }
//        return $total;
//    }
//    public function transferReturns(){
//        return $this->hasMany(TransferReturns::class);
//    }
    public function item()
    {
        return $this->belongsTo(Item::class,'Items_idItems');
    }
//    public function transfers()
//    {
//        return $this->hasMany(TransferItem::class);
//    }
//    public function invoiceRegs()
//    {
//        return $this->hasMany(InvoiceReg::class);
//    }
    public function storeDetails()
    {
        return $this->belongsTo(Store::class,'store');
    }
    public function company()
    {
        return $this->belongsTo(CompanyInfo::class,'Company');
    }

//    public function returned(){
//        return $this->hasMany(InvoiceReturn::class);
//    }


}

