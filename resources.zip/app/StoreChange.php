<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StoreChange extends Model
{
    protected $table = 'store_change';
    protected $primaryKey = 'idStore_Change';

    public function item(){
        return $this->belongsTo(Item::class,'items_idItems');
    }

    public function fromStoreDetails(){
        return $this->belongsTo(Store::class,'fromStore');
    }

    public function toStoreDetails(){
        return $this->belongsTo(Store::class,'toStore');
    }
}

