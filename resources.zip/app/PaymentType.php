<?php
/**
 * Created by PhpStorm.
 * User: ishar
 * Date: 3/10/2019
 * Time: 11:30 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class PaymentType extends Model
{
    protected $table = 'meta_payment';
    protected $primaryKey = 'idmeta_payment';


    public function companyPaymentType()
    {
        return $this->hasMany(CompanyPaymentType::class);
    }
    public function po()
    {
        return $this->hasMany(Purchase::class);
    }
//    public function invoice()
//    {
//        return $this->hasMany(Invoice::class);
//    }
//    public function grn()
//    {
//        return $this->hasMany(GRN::class);
//    }
//    public function specials()
//    {
//        return $this->hasMany(SpecialOrder::class);
//    }
//    public function payment()
//    {
//        return $this->hasMany(Payment::class);
//    }

}