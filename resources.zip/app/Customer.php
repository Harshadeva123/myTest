<?php
/**
 * Created by PhpStorm.
 * User: Thilina
 * Date: 5/5/2019
 * Time: 12:07 PM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $table = 'customer';
    protected $primaryKey = 'idCustomer';

    public function User()
    {
        return $this->belongsTo(User::class,'UserMaster_idUser');
    }
}