<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-002
 * Date: 9/12/2019
 * Time: 9:13 AM
 */

namespace App\Http;


class ItemCategory
{

}