<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class AgencyCashier
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(Auth::user()->UserRole == 1 || Auth::user()->UserRole == 2  || Auth::user()->UserRole == 3  || Auth::user()->UserRole == 4  || Auth::user()->UserRole == 6 ){
            return $next($request);
        }
        else{
            return redirect('/');
        }
    }
}
