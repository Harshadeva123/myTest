<?php
///**
// * Created by PhpStorm.
// * User: Nimesh VGS
// * Date: 2/18/2020
// * Time: 9:48 AM
// */
//
//namespace App\Http\Controllers;
//
//
//use App\Customer;
//use App\Http\Controllers\Controller;
//use App\Receipt;
//use Illuminate\Support\Facades\Auth;
//use Illuminate\Http\Request;
//
//class ReceiptController extends Controller
//{
//    public function receiptHistoryView(){
//
//        $customers=Customer::where('status',1)->where('Company',Auth::user()->Company)->get();
//        $receipts=Receipt::where('status',1)->where('company',Auth::user()->Company)->orderBy('created_at', 'desc')->paginate(10);
//        return view('receipthistory.receipt_history',['title'=>'Receipts History','receipts'=>$receipts,'customers'=>$customers]);
//    }
//
//
//    public function searchReceipt(Request $request){
//
//
//        $baseId = $request['baseId'];
//        $customer = $request['customer'];
//        $customers=Customer::where('status',1)->where('Company',Auth::user()->Company)->get();
//
//        if (!empty($baseId)) {
//            $receipts = Receipt::where('id',$baseId)->where('Company',Auth::user()->Company)->where('status', 1)->paginate(10);
//            if ($receipts != null) {
//                return view('receipthistory.receipt_history')->with(['title'=>'Receipts History','receipts'=>$receipts,'customers'=>$customers]);
//
//            } else {
//
//                $customers=Customer::where('status',1)->where('Company',Auth::user()->Company)->get();
//                $receipts=Receipt::where('status',1)->where('company',Auth::user()->Company)->orderBy('created_at', 'desc')->paginate(10);
//                return view('receipthistory.receipt_history')->with(['title'=>'Receipts History','receipts'=>$receipts,'customers'=>$customers]);
//            }
//
//        }
//
//
//        if (!empty($customer)) {
//            $receipts = Receipt::where('Customer_idCustomer',$customer)
//                ->where('Company',Auth::user()->Company)->where('status',1)->paginate(10);
//            if($receipts !=  null) {
//                $customers=Customer::where('status',1)->where('Company',Auth::user()->Company)->get();
//                return view('receipthistory.receipt_history')->with(['title'=>'Receipts History','receipts'=>$receipts,'customers'=>$customers]);
//            }
//            else{
//                $customers=Customer::where('status',1)->where('Company',Auth::user()->Company)->get();
//                $receipts=Receipt::where('status',1)->where('company',Auth::user()->Company)->orderBy('created_at', 'desc')->paginate(10);
//                return view('receipthistory.receipt_history')->with(['title'=>'Receipts History','receipts'=>$receipts,'customers'=>$customers]);
//            }
//
//        }
//        $customers=Customer::where('status',1)->where('Company',Auth::user()->Company)->get();
//        $receipts=Receipt::where('status',1)->where('company',Auth::user()->Company)->orderBy('created_at', 'desc')->paginate(10);
//        return view('receipthistory.receipt_history')->with(['title'=>'Receipts History','receipts'=>$receipts,'customers'=>$customers]);
//
//    }
//
//    public function PrintReceipt($id = null)
//    {
//        $receipt= Receipt::find(intval($id));
//        return view('print.PrintReceipt')->with("receipt", $receipt);
//    }
//
//
//
//}