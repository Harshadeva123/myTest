<?php

namespace App\Http\Controllers;

use App\GrnItemsTemp;
use App\Item;
use App\OpeningStock;
use App\Stock;
use App\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OpeningStockController extends Controller
{
    public function index(){
        $stockTypes = Store::where('status',1)->where('Company',Auth::user()->Company)->get();
        $items = Item::where('status',1)->where('Company',Auth::user()->Company)->get();
        return view('stock.opening_stock')->with(['stockTypes' => $stockTypes,'title'=>'Opening Stock','items'=>$items]);
    }

    public function save(){
        $GrnItemsTemps = GrnItemsTemp::where('status',1)->where('UserMaster_idUser',Auth::user()->idUser)->get();
        if($GrnItemsTemps != null) {



            if (count($GrnItemsTemps) > 0) {

                $opening = new OpeningStock();
                $opening->usermaster_idUser = Auth::user()->idUser;
                $opening->Company = Auth::user()->Company;
                $opening->status = 1;
                $opening->save();


                foreach ($GrnItemsTemps as $GrnItemsTemp) {
                    $stock = new Stock();
                    if (Store::find($GrnItemsTemp->store)->Company == Auth::user()->Company) {
                        $stock->store = $GrnItemsTemp->store;
                    } else {
                        return response()->json(['errors' => ['error' => 'Store name not found.']]);
                    }

                    $stock->base = 4;
                    $stock->GRN_id_or_Production_id = $opening->idopening_stock;
                    $stock->Company = Auth::user()->Company;
                    $stock->Items_idItems = $GrnItemsTemp->Items_idItems;
                    $stock->qty_grn = $GrnItemsTemp->qty_grn;
                    $stock->qty_available = $GrnItemsTemp->qty_grn;
                    $stock->qty_inv_return = 0;
                    $stock->qty_grn_return = 0;
                    $stock->binNo = $GrnItemsTemp->binNo;
                    $stock->expDate = $GrnItemsTemp->expDate;
                    $stock->expHave = $GrnItemsTemp->expHave;
                    $stock->mnfDate = $GrnItemsTemp->mnfDate;
                    $stock->bp = $GrnItemsTemp->bp;
                    $stock->wp = $GrnItemsTemp->wp;
                    $stock->sp = $GrnItemsTemp->sp;
                    $stock->status = 1;
                    $stock->save();
                    $GrnItemsTemp->delete();
                }
            } else {
                return response()->json(['errors' => ['error' => 'No items to save!']]);
            }
        }
        else {
            return response()->json(['errors' => ['error' => 'No items to save!']]);
        }
        return response()->json(['success' => 'Saved Successfully.']);
    }

}
