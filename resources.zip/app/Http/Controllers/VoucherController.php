<?php
///**
// * Created by PhpStorm.
// * User: Nimesh VGS
// * Date: 3/10/2020
// * Time: 3:42 PM
// */
//
//namespace App\Http\Controllers;
//
//
//use App\PaymentType;
//use App\Voucher;
//use App\VoucherTypeMeta;
//
//class VoucherController extends Controller
//{
//    public function createVoucherView()
//    {
//        $voucherTypes=VoucherTypeMeta::where('status',1)->get();
//        $paymentTypes = PaymentType::where('status', 1)->get();
//        return view('voucher.create_voucher', ['title' => 'Create Voucher', 'paymentTypes' => $paymentTypes,'voucherTypes'=>$voucherTypes]);
//    }
//
//    public function voucherHistoryView(){
//
//        $getVoucherDetails = Voucher::latest()->paginate(10);
//        return view('voucher.voucher_history',['getVoucherDetails'=>$getVoucherDetails,'title'=>'voucher History']);
//    }
//
//}