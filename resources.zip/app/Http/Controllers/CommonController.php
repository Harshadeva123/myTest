<?php
//
//namespace App\Http\Controllers;
//
//use App\CompanyInfo;
//use App\Complement;
//use App\Customer;
//use App\GRN;
//use App\Guarantor;
//use App\Item;
//use App\ItemCategory;
//use App\Loan;
//use App\MainCategory;
//use App\Measurement;
//use App\Package;
//use App\StockType;
//use App\Store;
//use App\SubCategory;
//use App\Supplier;
//use App\Table;
//use App\User;
//use App\UserRole;
//use App\Waiter;
//use Illuminate\Http\Request;
//
//class CommonController extends Controller
//{
//
//    public function __construct()
//    {
//        $this->middleware('auth');
//    }
//
//
//    public function activateDeactivate(Request $request)
//    {
//
//        $id = $request['id'];
//        $table = $request['table'];
//
//        if ($table == "package") {
//
//            $package = Package::find($id);
//            if ($package->status == 1) {
//                $package->status = 0;
//            } else {
//                $package->status = 1;
//            }
//            $package->update();
//
//        } else if ($table == "table_restaurant") {
//
//            $table = Table::find($id);
//            if ($table->status == 1) {
//                $table->status = 0;
//            } else {
//                $table->status = 1;
//            }
//            $table->update();
//
//        }else if ($table == "item_category") {
//
//            $mCategory = MainCategory::find($id);
//            if ($mCategory->status == 1) {
//                $mCategory->status = 0;
//            } else {
//                $mCategory->status = 1;
//            }
//            $mCategory->update();
//
//        }else if ($table == "item_sub_category") {
//
//            $suCategory = SubCategory::find($id);
//            if ($suCategory->status == 1) {
//                $suCategory->status = 0;
//            } else {
//                $suCategory->status = 1;
//            }
//            $suCategory->update();
//
//        }else if ($table == "waiter") {
//
//            $witer = Waiter::find($id);
//            if ($witer->status == 1) {
//                $witer->status = 0;
//            } else {
//                $witer->status = 1;
//            }
//            $witer->update();
//
//        }else if ($table == "customer") {
//
//            $customer = Customer::find($id);
//            if ($customer->status == 1) {
//                $customer->status = 0;
//            } else {
//                $customer->status = 1;
//            }
//            $customer->update();
//
//        }
//        else if ($table == "supplier") {
//
//            $supplier = Supplier::find($id);
//            if ($supplier->status == 1) {
//                $supplier->status = 0;
//            } else {
//                $supplier->status = 1;
//            }
//            $supplier->update();
//        }
//
//       else if ($table == "items") {
//
//            $Item = Item::find($id);
//            if ($Item->status == 1) {
//                $Item->status = 0;
//            } else {
//                $Item->status = 1;
//            }
//            $Item->update();
//
//        }else if ($table=="measurement") {
//
//            $measurement = Measurement::find($id);
//            if ($measurement->status == 1) {
//                $measurement->status = 0;
//            } else {
//                $measurement->status = 1;
//            }
//            $measurement->update();
//
//        }else if ($table == "stock") {
//
//            $stock = Stock::find($id);
//            if ($stock->status == 1) {
//                $stock->status = 0;
//            } else {
//                $stock->status = 1;
//            }
//            $stock->update();
//        }
//        else if ($table == "usermaster") {
//
//            $user = User::find($id);
//            if ($user->status == 1) {
//                $user->status = 0;
//            } else {
//                $user->status = 1;
//            }
//            $user->update();
//        }else if ($table == "Item_Category") {
//
//            $user = MainCategory::find($id);
//            if ($user->status == 1) {
//                $user->status = 0;
//            } else {
//                $user->status = 1;
//            }
//            $user->update();
//        }
//        else if ($table == "Item_Sub_Category") {
//
//            $user = SubCategory::find($id);
//            if ($user->status == 1) {
//                $user->status = 0;
//            } else {
//                $user->status = 1;
//            }
//            $user->update();
//        }
//        else if ($table == "Items") {
//
//            $user = Item::find($id);
//            if ($user->status == 1) {
//                $user->status = 0;
//            } else {
//                $user->status = 1;
//            }
//            $user->update();
//        }else if ($table == "companyinfomaster") {
//
//            $user = CompanyInfo::find($id);
//            if ($user->status == 1) {
//                $user->status = 0;
//            } else {
//                $user->status = 1;
//            }
//            $user->update();
//        }
//        else if ($table == "grn") {
//
//            $user = GRN::find($id);
//            if ($user->status == 1) {
//                $user->status = 0;
//            } else {
//                $user->status = 1;
//            }
//            $user->update();
//        }else if ($table == "store") {
//
//            $user = Store::find($id);
//            if ($user->status == 1) {
//                $user->status = 0;
//            } else {
//                $user->status = 1;
//            }
//            $user->update();
//        }
//
//    }
//
//}
