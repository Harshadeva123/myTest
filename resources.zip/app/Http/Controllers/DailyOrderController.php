<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/15/2019
// * Time: 8:04 AM
// */
//
//namespace App\Http\Controllers;
//
//
//use App\CompanyInfo;
//use App\DailyOrder;
//use App\DailyOrderItems;
//use App\Item;
//use App\SpecialOrder;
//use App\StockTransfer;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Auth;
//
//class DailyOrderController extends Controller
//{
// public function createDo()
//    {
//        $items = Item::where('Item_Type','!=',2)->get();
//        return view('order.createDo')->with(['title'=>'Daily Order','items'=>$items]);
//    }
//
// public function placeDailyOrder(Request $request){
//        $validator = \Validator::make($request->all(), [
//            'orders' => 'required',
//
//        ], [
//            'orders.required' => "At least one 'Qty' field should be filled.",
//
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $orders = $request['orders'];
//        $daily = new DailyOrder();
//        $daily->companyinfomaster_id = Auth::user()->Company;
//        $daily->usermaster_idUser = Auth::user()->idUser;
//        $daily->status = 2;
//        $daily->save();
//      foreach ($orders as $order){
//
//          $items = new DailyOrderItems();
//          $items->orders_idsales_order = $daily->idsales_order;
//          $items->items_idItems = $order['rowId'];
//          $items->requestedQty = $order['qty'];
//          $items->approvedQty = 0;
//          $items->remark = $order['remark'];
//          $items->status = 1;
//          $items->save();
//      }
//        return response()->json([ 'success' => 'Successfully saved']);
//
//    }
//
// public function pendingDo(){
//     $companies = CompanyInfo::where('status',1)->get();
//     $items = Item::all();
//     if(Auth::user()->companyInfo->isBranch == 0){
//         $orders = DailyOrder::where('status',2)->paginate(10);
//     }else{
//         $orders = DailyOrder::where('status',2)->where('companyinfomaster_id',Auth::user()->Company)->paginate(10);
//     }
//     return view('order.pending_do')->with(['title'=>'Pending Orders','orders'=>$orders,'items'=>$items,'companies'=>$companies]);
// }
//
// public function viewOrderItems(Request $request){
//     $id = $request['rowId'];
//     $items = DailyOrderItems::where('orders_idsales_order',$id)->get();
//     $tableData = "";
//     foreach ($items as $item){
//         if(\Illuminate\Support\Facades\Auth::user()->companyInfo->isBranch == 0) {
//
//             $tableData .= "<tr>
//                            <td>" . $item->item->itemName . "
//                            <br/>Qty : " . $item->requestedQty . ' ' . $item->item->measurement->mian . "";
//             if ($item->remark != null) {
//                 $tableData .= "<br/>Remarks : " . $item->remark . "";
//             }
//
//             $tableData .= "      </td>";
//
//             $tableData .= "                 <td width='30%'>
//                                <div class='input-group mb-2'>
//                                    <input type='number' class='form-control qty' data-id=" . $item->idorder_items . " oninput='qtyInput(this)' data-measure=" . $item->item->measurement->mian . " placeholder='0.00' value='" . $item->requestedQty . "'  id='qty-" . $item->idorder_items . "' placeholder='0.00'>
//                                    <div class='input-group-prepend'>
//                                        <div class='input-group-text'>" . $item->item->measurement->mian . "</div>
//                                    </div>
//                                </div>
//                                </td>";
//
//             $tableData .= "             </tr>";
//         }else{
//             $tableData .= "<tr>
//                            <td>" . $item->item->itemName . "";
//             if ($item->remark != null) {
//                 $tableData .= "<br/>Remarks : " . $item->remark . "";
//             }
//
//             $tableData .= "      </td>";
//
//             $tableData .= "<td width='30%'>".$item->requestedQty."
//                            </td>";
//
//             $tableData .= "             </tr>";
//         }
//     }
//     return response()->json([ 'success' => $tableData]);
// }
//
// public function approveOrder(Request $request){
//     $validator = \Validator::make($request->all(), [
//         'approved' => 'required',
//     ], [
//         'approved.required' => "Request invalid.Please try again later.",
//     ]);
//
//     if ($validator->fails()) {
//         return response()->json(['errors' => $validator->errors()->all()]);
//     }
//        $approveds =  $request['approved'];
//        foreach ($approveds as $approved){
//            $order = DailyOrderItems::find($approved['item']);
//            $order->approvedQty = $approved['qty'];
//            $order->save();
//            $stockOrdet = DailyOrder::find(intval($order->orders_idsales_order));
//            $stockOrdet->status = 1;
//            $stockOrdet->save();
//        }
//     return response()->json([ 'success' => 'success']);
// }
//
// public function approvedDo(){
//     if(Auth::user()->companyInfo->isBranch == 0) {
//         $orders = DailyOrder::where('status', 1)->latest()->get();
//     }
//     else{
//         $orders = DailyOrder::where('status', 1)->where('companyinfomaster_id',Auth::user()->Company)->latest()->get();
//     }
//        return view('order.approved_orders')->with(['title'=>'Approved Order','orders'=>$orders]);
// }
//
// public function getOrderItems(Request $request){
//        $id = $request['id'];
//        $items = DailyOrderItems::where('orders_idsales_order',$id)->get();
//        $tableData  = "";
//        foreach ($items as $item){
//            $tableData .= "<tr>";
//            $tableData .= "<td>".$item->item->itemName."</td>";
//            $tableData .= "<td style='text-align: center;'>".$item->requestedQty."</td>";
//            $tableData .= "<td style='text-align: center;'>".$item->approvedQty."</td>";
//            $tableData .= "</tr>";
//        }
//        return $tableData;
// }
//}