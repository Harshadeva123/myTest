<?php

namespace App\Http\Controllers;

use App\CompanyInfo;
use App\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StoreController extends Controller
{
    public function index(Request $request)
    {
        $keyword = $request['search'];
        $viewAllStockTypes = Store::
        where(function ($query) use ($keyword){
                $query->where('type', 'LIKE',"%$keyword%");
            })
            ->where('Company',Auth::user()->Company)->latest()->paginate(10);

        $viewAllStockTypes->appends(array(
                'search' => $request['search'],
                'type' => $request['type']
            ));

        return view('store.stock_type', [ 'title' => 'Stores', 'viewAllStockTypes' => $viewAllStockTypes]);
    }

    public function store(Request $request)
    {
        $company = Auth::user()->Company;
        $type = $request['type'];

        $validator = \Validator::make($request->all(), [
            'type' => 'required',

        ], [
            'type.required' => 'Store Name should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $typeExists = Store::where('type', strtoupper($type))->where('Company', $company)->where('status',1)
            ->first();
        if ($typeExists == null) {
            $subCat = new Store();
            $subCat->Company = $company;
            $subCat->type = strtoupper($type);
            $subCat->status = '1';
            $subCat->save();

            $stockTypes = Store::orderBy('created_at', 'desc')->where('Company',Auth::user()->Company)->paginate(10);
            $tableData = '';
            foreach ($stockTypes as $stockType) {
                $tableData .= "<tr>";
                $tableData .= "<td>" . $stockType->type . "</td>";
                $tableData .= "<td>" . $stockType->created_at . "</td>";
                $tableData .= "<td>" . $stockType->updated_at . "</td>";
                if ($stockType->status == 1) {

                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$stockType->idStore','stock_type') id='c" . $stockType->idStore . "' checked switch='none'/>";
                    $tableData .= "<label for='c" . $stockType->idStore . "' data-on-label='On' data-off-label='Off'></label>";
                    $tableData .= "</td>";
                } else {
                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$stockType->idStore','stock_type') id='c" . $stockType->idStore . "'  switch='none'/>";
                    $tableData .= "<label for='c" . $stockType->idStore . "' data-on-label='On' data-off-label='Off'></label>";
                    $tableData .= "</td>";
                }
                $tableData .= "<td style='text-align: center;'>";
                $tableData .= " <p>";
                $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light'
              data-toggle='modal' data-id='$stockType->idStore' id='stockTypeId' data-target='#updateStockType'>";
                $tableData .= "<i class='fa fa-edit'></i>";
                $tableData .= "</button>";
                $tableData .= " </p>";
                $tableData .= " </td>";
                $tableData .= "</tr>";
            }
            return response()->json(['tableData' => $tableData, 'success' => 'Store successfully saved']);

        } else {
            return response()->json(['errors' => ['error' => 'Store name already exist!']]);
        }

    }

    public function getByID(Request $request){
        $typeId=$request['typeId'];
        $stockType=Store::where('idStore',intval($typeId))->where('Company',Auth::user()->Company)->first();
        return response()->json($stockType);
    }

    public function update(Request $request){
        $hiddenTID = $request['hiddenTID'];
        $uCompany =  Auth::user()->Company;
        $uType = $request['uType'];

        $validator = \Validator::make($request->all(), [
            'uType' => 'required',
        ], [
            'uType.required' => 'Store Name should be provided!',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $isExist = Store::where('Company',Auth::user()->Company)->where('idStore','!=',$hiddenTID)->where('type',$uType)->first();

        if($isExist == null) {

            $uSType = Store::find(intval($hiddenTID));
            $uSType->Company = $uCompany;
            $uSType->type = $uType;
            $uSType->save();

            $stockTypes = Store::orderBy('created_at', 'desc')->where('Company', Auth::user()->Company)->paginate(10);
            $tableData = '';

            foreach ($stockTypes as $stockType) {
                $tableData .= "<tr>";
                $tableData .= "<td>" . $stockType->type . "</td>";
                $tableData .= "<td>" . $stockType->created_at . "</td>";
                $tableData .= "<td>" . $stockType->updated_at . "</td>";
                if ($stockType->status == 1) {

                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$stockType->idStore','stock_type') id='c" . $stockType->idStore . "' checked switch='none'/>";
                    $tableData .= "<label for='c" . $stockType->idStore . "' data-on-label='On' data-off-label='Off'></label>";
                    $tableData .= "</td>";
                } else {
                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$stockType->idStore','stock_type') id='c" . $stockType->idStore . "'  switch='none'/>";
                    $tableData .= "<label for='c" . $stockType->idStore . "' data-on-label='On' data-off-label='Off'></label>";
                    $tableData .= "</td>";
                }
                $tableData .= "<td style='text-align: center;'>";
                $tableData .= " <p>";
                $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light'
              data-toggle='modal' data-id='$stockType->idStore' id='stockTypeId' data-target='#updateStockType'>";
                $tableData .= "<i class='fa fa-edit'></i>";
                $tableData .= "</button>";
                $tableData .= " </p>";
                $tableData .= " </td>";
                $tableData .= "</tr>";
            }
            return response()->json(['tableData' => $tableData, 'success' => 'Store successfully saved']);
        }else{
            return response()->json(['errors' => ['error'=>'Store name already exist!']]);
        }


    }

    public function changeStatus(Request $request){
        $id = $request['id'];
        $user = Store::find($id);
        if ($user->status == 1) {
            $user->status = 0;
        } else {
            $user->status = 1;
        }
        $user->save();
    }
}
