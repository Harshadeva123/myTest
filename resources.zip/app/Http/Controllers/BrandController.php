<?php

namespace App\Http\Controllers;

use App\Brand;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BrandController extends Controller
{
    public function index(Request $request){
        $search = $request['search'];
        $query = Brand::query();

        if (!empty($search)) {
            $query = $query->where('type', 'LIKE', '%' . $search . '%');
        }

        $brands = $query->where('Company',Auth::user()->Company)->latest()->paginate(10);

        $brands->appends(array(
            'search' => $request['search']
        ));
        return view('brands.brands', ['title' => 'Brands', 'brands' => $brands]);
    }

    public function store(Request $request)
    {
        $brandName = $request['addBrand'];
        $validator = \Validator::make($request->all(), [

            'addBrand' => 'required',
        ], [
            'addBrand.required' => 'Brand Name should be provided!',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        $exist = Brand::where('type', strtoupper($brandName))->where('Company',Auth::user()->Company)->first();
        if ($exist == null) {
            $brand = new Brand();
            $brand->type = strtoupper($brandName);
            $brand->Company = Auth::user()->Company;
            $brand->status = '1';
            $brand->UserMaster_idUser = Auth::user()->idUser;
            $brand->save();
        }
        else{
            return response()->json(['errors' => ['error' => 'Brand name already exist!']]);

        }

        return response()->json(['success' => 'Brand Successfully Added!']);

    }

    public function getTableData(){
            $mainCats = Brand::orderBy('created_at', 'desc')->where('Company',Auth::user()->Company)->paginate(10);
            $tableData = '';
            foreach ($mainCats as $mainCat) {
                $tableData .= "<tr>";
                $tableData .= "<td>" . $mainCat->type . "</td>";
                $tableData .= "<td>" . $mainCat->User->fName . "</td>";
                $tableData .= "<td>" . $mainCat->created_at . "</td>";
                if ($mainCat->status == 1) {

                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$mainCat->idItem_Type') id='c" . $mainCat->idItem_Type . "' checked switch='none'/>";
                    $tableData .= "<label for='c" . $mainCat->idItem_Type . "' data-on-label='On' data-off-label='Off'></label>";

                    $tableData .= "</td>";
                } else {
                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$mainCat->idItem_Type') id='c" . $mainCat->idItem_Type . "'  switch='none'/>";
                    $tableData .= "<label for='c" . $mainCat->idItem_Type . "' data-on-label='On' data-off-label='Off'></label>";
                    $tableData .= "</td>";
                }
                $tableData .= "<td>";
                $tableData .= " <p>";
                $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light'
                   data-name='$mainCat->type' data-toggle='modal' data-id='$mainCat->idItem_Type' id='mainCategoryId' data-target='#mainCatUpdate'>";
                $tableData .= "<i class='fa fa-edit'></i>";
                $tableData .= "</button>";
                $tableData .= " </p>";
                $tableData .= " </td>";
                $tableData .= "</tr>";
            }
            return response()->json(['tableData' => $tableData]);

    }

    public function changeStatus(Request $request){
        $id  = $request['id'];
        $cat = Brand::find($id);
        if ($cat->status == 1) {
            $cat->status = 0;
        } else {
            $cat->status = 1;
        }
        $cat->save();

    }

    public function update(Request $request)
    {
        $id = $request['id'];
        $uBrand = $request['uBrand'];

        $validator = \Validator::make($request->all(), [

            'uBrand' => 'required',
        ], [
            'uBrand.required' => 'Brand Name should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        $exist = Brand::where('type', strtoupper($uBrand))->where('Company',Auth::user()->Company)->where('idItem_Type','!=',$id)->first();

        if($exist != null){
            return response()->json(['errors' => ['error' => 'Brand name already exist!']]);
        }

        $mainCat = Brand::find(intval($id));
        $mainCat->type = strtoupper($uBrand);
        $mainCat->save();

        return response()->json([ 'success' => 'Brand successfully updated']);

    }

}
