<?php
///**
// * Created by PhpStorm.
// * User: ishar
// * Date: 3/10/2019
// * Time: 11:14 AM
// */
//
//namespace App\Http\Controllers;
//
//
//
//use App\BankPayments;
//use App\BankPaymentsTemp;
//use App\ChequePaymentTemp;
//use App\CompanyInfo;
//use App\DailyOrder;
//use App\DailyOrderItems;
//use App\Item;
//use App\Payment;
//use App\PaymentType;
//use App\PendingTransferItem;
//use App\ReturnItemTransferAdded;
//use App\Stock;
//use App\StockTransfer;
//use App\StockType;
//use App\TransferItem;
//use App\TransferItemTemp;
//use App\TransferOrder;
//use App\TransferReturns;
//use Illuminate\Support\Facades\Auth;
//use Symfony\Component\HttpFoundation\Request;
//
//class TransferController extends Controller
//{
//    public function newTransfer(){
//        $companies = CompanyInfo::where('status',1)->get();
//        $company = CompanyInfo::where('status',1)->where('isBranch',0)->first();
//        $store = StockType::where('type','DELIVERY SECTION STORE')->where('Company',$company->idCompanyInfo)->first();
//        $items = Stock::where('Stock_Type',$store->idStock_Type)->where('Company',$company->idCompanyInfo)->where('qty_available','>',0)->where('status',1)->select('Items_idItems')->distinct()->get();
//        $payments = PaymentType::where('status',1)->get();
//        return view("transfer.transferItems")->with(['companies'=>$companies,'items'=>$items,'store'=>$store,'payments'=>$payments,'company'=>$company,'title'=>'Transfer']);
//    }
//
//    public function getTransferTempTable(){
//
//        $temps = TransferItemTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        $tableData = "";
//        if(count($temps)) {
//            foreach ($temps as $temp) {
//                $tableData .= "<tr  id=" . $temp->idtransfer_item_temp . ">";
//                $tableData .= "<td>" . $temp->item->itemName . "</td>";
//                $tableData .= "<td>" . $temp->qty . "</td>";
//                if($temp->fromOrder != 0){
//                    $tableData .= " <td style='text-align:center;'>
//                                <div class='button-items'>
//                                    <button type='button'  title='This will delete all item belongs to selected order'
//                                            class='btn btn-sm btn-danger  waves-effect waves-light'
//                                             onclick='deleteTempTransfer(this)'
//                                            data-id=" . $temp->idtransfer_item_temp . "
//                                            >
//                                            <i class='ti-trash'></i>
//                                     </button>
//
//                                </div>
//                            </td>";
//                }
//                else {
//                    $tableData .= " <td style='text-align:center;'>
//                                <div class='button-items'>
//                                    <button type='button'
//                                            class='btn btn-sm btn-danger  waves-effect waves-light'
//                                            data-id=" . $temp->idtransfer_item_temp . "
//                                            onclick='deleteTempTransfer(this)'>
//                                            <i class='fa fa-trash'></i>
//                                     </button>
//
//                                </div>
//                            </td>";
//                }
//                $tableData .= "</tr>";
//            }
//        }else{
//            $tableData .="<tr><td style='text-align: center' colspan='5'>No available data. </td> </tr>";
//        }
//        return $tableData;
//    }
//
//    public function deleteTempTransfer(Request $request){
//
//        $temp = TransferItemTemp::find($request['id']);
//        if($temp->fromOrder !=0 ){
//            $orderItems = TransferItemTemp::where('fromOrder',$temp->fromOrder)->get();
//            foreach ($orderItems as $orderItem){
//                $orderItem->delete();
//            }
//        }
//        else {
//            $temp->delete();
//        }
//    }
//
//    public function clearTransferTempTable(){
//
//        TransferItemTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->delete();
//    }
//
//    public function feedStores(Request $request){
//        $company = $request['company'];
//        $isBranch  = CompanyInfo::find($company)->isBranch;
//        $stores = StockType::where('Company',$company)->where('status',1)->get();
//        $optionData = "<option disabled selected>
//                              Select store name
//                         </option>";
//        foreach ($stores as $store){
//            $optionData .= "<option value=".$store->idStock_Type.">
//                              ".$store->type."
//                         </option>";
//        }
//        return response()->json([ 'options' => $optionData,'isBranch'=>$isBranch]);
//    }
//
//    public function transferItemChanged(Request $request){
//        $store = $request['store'];
//        $company = $request['Company'];
//        $item = $request['item'];
//        return Stock::where(function ($query) use ($company,$item,$store){
//            $query->where('expDate','>=',date('Y-m-d'))->where('Stock_Type',$store)->where('Company',$company)->where('Items_idItems',$item)->where('status',1);
//        })
//            ->orWhere(function ($query) use ($company,$item,$store){
//                $query->where('expHave',0)->where('Company',$company)->where('Stock_Type',$store)->where('Items_idItems',$item)->where('status',1);
//            })->sum('qty_available');
//    }
//
//    public function loadFromOrder(Request $request){
//        $company = $request['company'];
//
//        $query = DailyOrder::query();
//        if($company != null) {
//            $query = $query->where('companyinfomaster_id', $company);
//        }
//        $orders = $query->where('status',1)->limit(10)->get();
//        $tableData = "";
//        foreach ($orders as $order){
//            $tableData .= "<tr id='order-".$order->idsales_order."' onclick='getSelectedOrderData(this)' data-id='$order->idsales_order'>";
//            $tableData .= "<td><em class='ti-plus orderDetailsIcon' id='orderDetailsIcon-".$order->idsales_order."'></em> ".$order->CompanyInfo->companyName."</td>";
//            $tableData .= "<td>".$order->created_at->format('Y-m-d H:i')."</td>";
//            $tableData .= "<td>  <button class='btn btn-sm btn-success' data-id='".$order->idsales_order."' onclick='selectOrderForTransfer(this)'>Select </button></td>";
//            $tableData .= "</tr>";
//            $tableData .= "<tr >";
//            $tableData .= "<td colspan='3' style='display:none;' class='orderDetails' id='orderDetails-".$order->idsales_order."'  ></td>";
//            $tableData .= "</tr>";
//        }
//        return response()->json(['orders' => $tableData]);
//    }
//
//    public function getSelectedOrderData(Request $request){
//        $id = $request['id'];
//        $items = DailyOrderItems::where('orders_idsales_order',$id)->where('status',1)->get();
//        $tableData = "";
//        foreach ($items as $item){
//
//            $tableData .= "<div  class='row'>";
//            $tableData .= "<p class='text-secondary ml-3 col-md-5'>".$item->item->itemName."</p>";
//            $tableData .= "<p class='text-secondary ml-3 col-md-2'>".$item->approvedQty."</p>";
//            $tableData .= "<p class='text-secondary ml-3 col-md-4'>" . $item->remark . "</p>";
//            $tableData .= "</div>";
//
//        }
//
//        return response()->json(['items' => $tableData]);
//
//    }
//
//    public function selectOrderForTransfer(Request $request){
//        $validator = \Validator::make($request->all(), [
//            'id' => 'required',
//            'company' => 'required',
//            'store' => 'required',
//            'ToCompany' => 'required',
//        ], [
//            'id.required' => 'Process invalid.',
//            'company.required' => 'From Company should be provided.',
//            'store.required' => 'From Store should be provided.',
//            'ToCompany.required' => 'To company should be provided.',
//        ]);
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $id  = $request['id'];
//        $company  = $request['company'];
//        $store  = $request['store'];
//        $ToCompany  = $request['ToCompany'];
//        if(CompanyInfo::find(intval($ToCompany))->isBranch) {
//            $toStock = StockType::where('Company', $ToCompany)->where('status', 1)->first()->idStock_Type;
//        }
//        else{
//            if($request['ToStore'] == null){
//                return response()->json(['errors' => ['error' => 'To Store should be provided!']]);
//            }
//            $toStock = $request['ToStore'];
//        }
//        $items = DailyOrderItems::where('orders_idsales_order',$id)->where('status',1)->get();
//        $orderCompany = DailyOrder::find($id)->companyinfomaster_id;
//        $exist = TransferItemTemp::where('fromOrder',$id)->where('status',1)->first();
//        if($exist != null){
//            return response()->json(['errors' => ['error' =>  'Order already selected.']]);
//        }
//
//        $available = true;
//        foreach ($items as $item){
//            if($item->requestedQty > Stock::where('Company',$company)->where('Stock_Type',$store)->where('Items_idItems',$item->items_idItems)->sum('qty_available')){
//                $available = false;
//            }
//            if(!$available){
//                TransferItemTemp::where('usermaster_idUser',Auth::user()->idUser)->where('status',1)->delete();
//                return response()->json(['errors' => ['error' =>  ''.$item->item->itemName.' available qty is less than order qty.']]);
//
//            }
//
//            $po = new TransferItemTemp();
//            $po->items_idItems = $item->items_idItems;
//            $po->fromStore = $store;
//            $po->toStore = $toStock;
//            $po->toCompany = $ToCompany;
//            $po->idStock_Transfer = 0;
//            $po->qty = $item->approvedQty;
//            $po->status = 1;
//            $po->fromOrder = $id;
//            $po->usermaster_idUser = Auth::user()->idUser;
//            $po->save();
//
//        }
//        return response()->json(['success' => 'success','company'=>$orderCompany,'orderNo'=>$id]);
//
//    }
//
//    public function addItemTransferTemp(Request $request){
//
//        $item = $request['item'];
//        $qtyGrn = $request['qty'];
//        $ToCompany = $request['ToCompany'];
//        $fromCompany = CompanyInfo::where('status',1)->where('isBranch',0)->first();
//        $FromStore = StockType::where('type','DELIVERY SECTION STORE')->where('Company',$fromCompany->idCompanyInfo)->first();
//
//        if($FromStore == null){
//            return response()->json(['errors' => ['error' => 'Delivery section store not found.']]);
//        }
//        $validator = \Validator::make($request->all(), [
//            'item' => 'required',
//            'qty' => 'required',
//            'ToCompany' => 'required'
//        ], [
//            'item.required' => 'Item should be provided!',
//            'qty.required' => 'Qty should be provided!',
//            'ToCompany.required' => 'To Company should be provided!',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        if(CompanyInfo::find(intval($ToCompany))->isBranch) {
//            $toStock = StockType::where('Company', intval($ToCompany))->where('status',1)->first()->idStock_Type;
//
//        }
//        else{
//            if($request['ToStore'] == null){
//                return response()->json(['errors' => ['error' => 'To Store should be provided!']]);
//            }
//            $toStock = $request['ToStore'];
//        }
//
//        $isExist = TransferItemTemp::where('items_idItems',$item)->where('fromOrder',0)->where('usermaster_idUser',Auth::user()->idUser)->where('status',1)->first();
//        if($isExist != null){
//            $isExist->qty += $qtyGrn;
//            $isExist->save();
//        }
//        else{
//
//            $po = new TransferItemTemp();
//            $po->items_idItems = $item;
//            $po->fromStore = $FromStore->idStock_Type;
//            $po->toStore = $toStock;
//            $po->toCompany = $ToCompany;
//            $po->idStock_Transfer = 0;
//            $po->qty = $qtyGrn;
//            $po->status = 1;
//            $po->fromOrder = 0;
//            $po->usermaster_idUser = Auth::user()->idUser;
//            $po->save();
//
//        }
//        return response()->json([ 'success' => 'Successfully saved']);
//    }
//
//    public function viewPendingReturns(Request $request){
//
//        $returns = TransferReturns::whereHas("stockTransfer", function ($q) use ($request) {
//            $q->where("Company_To", $request->company);
//        }, true)->where('status',1)->get();
//
//        $tableData = "";
//        foreach ($returns as $return){
//            $tableData .= "<tr>";
//            $tableData .= "<td>".sprintf('%06d', $return->stock_transfer_idStock_Transfer)."</td>";
//            $tableData .= "<td>".$return->item->itemName."</td>";
//            $tableData .= "<td>".$return->qty."</td>";
//            $tableData .= " <td><div class=\"checkbox\">
//                                     <label><input class='returns' type=\"checkbox\" value=".$return->idtransfer_returns."></label>
//                                  </div>
//                               </td>";
//            $tableData .= "</tr>";
//        }
//        return response()->json(['returns' => $tableData]);
//
//    }
//
//    public function saveTransfer(Request $request)
//    {
//
//        $validator = \Validator::make($request->all(), [
//            'ToCompany' => 'required',
//            'FromCompany' => 'required',
//            'payment' => 'required',
//            'cType' => 'required',
//        ], [
//            'ToCompany.required' => 'To Company should be provided!',
//            'FromCompany.required' => 'From Company should be provided!',
//            'cType.required' => 'Company Type should be provided!',
//            'payment.required' => 'Payment type should be provided!',
//        ]);
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//        if(CompanyInfo::find(intval($request['ToCompany']))->isBranch) {
//            $toStock = StockType::where('Company', $request['ToCompany'])->where('status', 1)->first()->idStock_Type;
//        }
//        else{
//            if($request['ToStore'] == null){
//                return response()->json(['errors' => ['error' => 'To Store should be provided!']]);
//            }
//            $toStock = $request['ToStore'];
//        }
//
//        $temps = TransferItemTemp::where('status',1)->where('UserMaster_idUser',Auth::user()->idUser)->get();
//        if(count($temps)>0) {
//            $available = true;
//            $totalAmount = 0;
//
//            foreach ($temps as $temp){
//                $totalAmount += floatval($temp->qty)*floatval($temp->item->unitPrice);
//                if($temp->qty > Stock::where('Stock_Type',$request['FromStore'])->where('Company',$request['FromCompany'])->where('Items_idItems',$temp->items_idItems)->where('status',1)->sum('qty_available')){
//                    $available = false;
//                }
//            }
//
//            if($available) {
//                $transfer = new StockTransfer();
//                $transfer->transferNo = 1;
//                $transfer->Company_From = $request['FromCompany'];
//                $transfer->Company_To = $request['ToCompany'];
//                $transfer->payment_type = $request['payment'];
//                $transfer->UserMaster_idUser = Auth::user()->idUser;
////                $transfer->totalAmount = $totalAmount;
//                $transfer->totalAmount = 0;
//                $transfer->returns = 0;
//                $transfer->companyType = $request['cType'];
//                $transfer->paidTotal = 0;
////                $transfer->commissionRate = $commission =  CompanyInfo::find(floatval($request['ToCompany']))->commission;
//                $transfer->commissionRate = 0;
////                $transfer->commission = $commissionAmount = floatval($totalAmount)*(floatval($commission)/100);
//                $transfer->commission = 0;
////                $transfer->netTotal = $netTotal =  floatval($totalAmount - $commissionAmount);
//                $transfer->netTotal = 0;
//                $transfer->status = 2;
//                $transfer->save();
//
//                foreach ($temps as $temp) {
//
//                    $temp->idStock_Transfer = $transfer->idStock_Transfer;
//                    $temp->status = 2;
//                    $temp->save();
//
//                    if($temp->fromOrder != 0){
//
//                        $order = DailyOrder::find(intval($temp->fromOrder));
//                        $order->status = 4;
//                        $order->save();
//
//                        $orderItems = DailyOrderItems::where('items_idItems',$temp->items_idItems)->where('orders_idsales_order', intval($temp->fromOrder))->get();
//                        foreach ($orderItems as $orderItem) {
//                            $orderItem->status = 2;
//                            $orderItem->save();
//                        }
//
//                        $transOrder = new TransferOrder();
//                        $transOrder->stock_transfer_idStock_Transfer = $transfer->idStock_Transfer;
//                        $transOrder->daily_orders_idsales_order = $temp->fromOrder;
//                        $transOrder->status = 2;
//                        $transOrder->save();
//
//                    }
//
////                    $stocks = Stock::where('Stock_Type', $request['FromStore'])->where('Company', $request['FromCompany'])->where('Items_idItems', $temp->items_idItems)->where('status', 1)->orderBy('idStock','DESC')->get();
////                    $qty = $temp->qty;
////                    foreach ($stocks as $stock) {
////                        $stockQty = $stock->qty_available;
//
////                        if ($qty <= $stockQty) {
////                            $stock->qty_available -= $qty;
////                            if($qty == $stockQty){
////                                $stock->status = 0;
////                            }
////                            $stock->save();
//
////                            $item = new TransferItem();
////                            $item->idStock_Transfer = $transfer->idStock_Transfer;
////                            $item->Stock_idStock = $stock->idStock;
////                            $item->From_Stock = $request['FromStore'];
////                            $item->To_Stock = $toStock;
////                            $item->fromOrder = $temp->fromOrder;
////                            $item->qty = $qty;
////                            $item->unitPrice = $stock->item->unitPrice;
////                            $item->returnQty = 0;
////                            $item->status = 2;
////                            $item->save();
//
////                            $qty = 0;
//
////                            $stock2 = new Stock();
////                            $stock2->Stock_Type = $toStock;
////                            $stock2->base = 3;
////                            $stock2->GRN_id_or_Production_id = $transfer->idStock_Transfer;
////                            $stock2->Company =  $request['ToCompany'];
////                            $stock2->Items_idItems = $stock->Items_idItems;
////                            $stock2->qty_grn = $temp->qty;
////                            $stock2->qty_available = $temp->qty;
////                            $stock2->qty_inv_return = $stock->qty_inv_return;
////                            $stock2->qty_grn_return = 0;
////                            $stock2->binNo = $stock->binNo;
////                            $stock2->expDate = $stock->expDate;
////                            $stock2->expHave = $stock->expHave;
////                            $stock2->mnfDate = $stock->mnfDate;
////                            $stock2->bp = $stock->bp;
////                            $stock2->wp = $stock->wp;
////                            $stock2->sp = $stock->sp;
////                            $stock2->status = 1;
////                            $stock2->save();
////                            $temp->delete();
////                            break;
////                        } else {
//
////                            if($stock->qty_available > 0) {
////                                $item = new TransferItem();
////                                $item->idStock_Transfer = $transfer->idStock_Transfer;
////                                $item->Stock_idStock = $stock->idStock;
////                                $item->From_Stock = $request['FromStore'];
////                                $item->To_Stock = $toStock;
////                                $item->fromOrder = $temp->fromOrder;
////                                $item->qty = $stock->qty_available;
////                                $item->unitPrice = $stock->item->unitPrice;
////                                $item->returnQty = 0;
////                                $item->status = 2;
////                                $item->save();
////                            }
////
////                            $qty = floatval($qty)-floatval($stock->qty_available);
////                            $stock->qty_available = 0;
////                            $stock->status = 0;
////                            $stock->save();
////                        }
////                    }
////                    $temp->delete();
////                    if ($qty > 0) {
////                        return response()->json(['errors' => ['error' => 'Process invalid']]);
////
////                    }
//
////                    if($temp->fromOrder != 0){
////                            $order = DailyOrder::find(intval($temp->fromOrder));
////                            $order->status = 0;
////                            $order->save();
////
////                            $orderItems = DailyOrderItems::where('items_idItems',$temp->items_idItems)->where('orders_idsales_order', intval($temp->fromOrder))->get();
////                            foreach ($orderItems as $orderItem) {
////                                $orderItem->status = 0;
////                                $orderItem->save();
////                            }
////
////                            $transOrder = new TransferOrder();
////                            $transOrder->stock_transfer_idStock_Transfer = $transfer->idStock_Transfer;
////                            $transOrder->daily_orders_idsales_order = $temp->fromOrder;
////                            $transOrder->status = 1;
////                            $transOrder->save();
//
////                    }
//
//                }
//            }
//            else{
//                return response()->json(['errors' => ['error' => 'Available quantity is less than your request.']]);
//            }
//        }
//        else{
//            return response()->json(['errors' => ['error' => 'No item to save.']]);
//        }
//
//        $remainReturns = $request['returns'];
//
//        if($remainReturns != null) {
//            $totalReturnsAmount  = 0;
//            foreach ($remainReturns as $remainReturn) {
//                $return = TransferReturns::find($remainReturn);
//
//                $returnsAdded = new ReturnItemTransferAdded();
//                $returnsAdded->stock_transfer_idStock_Transfer = $transfer->idStock_Transfer;
//                $returnsAdded->transfer_returns_idtransfer_returns = $remainReturn;
//                $returnsAdded->qty = $return->qty;
//                $returnsAdded->status = 1;
//                $returnsAdded->save();
//
//                $totalReturnsAmount += floatval($return->qty)*floatval($return->item->unitPrice);
//
//                $return->status = 0;
//                $return->save();
//            }
////            $transfer->returns += $totalReturnsAmount;
////            $transfer->commission =  $newCommission =  floatval($totalAmount - floatval($totalReturnsAmount))*(floatval($commission)/100);
////            $transfer->netTotal = $netTotal =  floatval($totalAmount - $newCommission - $totalReturnsAmount);
////            $transfer->save();
//        }
//
//        return response()->json(['success' => 'successfully Saved','id'=>$transfer->idStock_Transfer]);
//    }
//
//    public function markTransferDelivery(Request $request){
//        $id = $request['id'];
//        $transfer = StockTransfer::find($id);
//        $items = TransferItemTemp::where('idStock_Transfer',$id)->where('status',2)->get();
//        $available = true;
//        $totalAmount = 0;
//        foreach ($items as $item) {
//            $itemDetails = Item::find(intval($item->items_idItems));
//            $totalAmount += floatval($item->qty)*floatval($itemDetails->unitPrice);
//        }
//
//        foreach ($items as $item) {
//            $company = CompanyInfo::where('status', 1)->where('isBranch', 0)->first();
//            $store = StockType::where('type', 'DELIVERY SECTION STORE')->where('Company', $company->idCompanyInfo)->first()->idStock_Type;
//            $totalQty = TransferItemTemp::where('items_idItems', $item->items_idItems)->where('idStock_Transfer',$id)->sum('qty');
//            $availableInStock = Stock::where(function ($query) use ($company,$item,$store){
//                $query->where('expDate','>=',date('Y-m-d'))->where('Stock_Type',$store)->where('Company',$company->idCompanyInfo)->where('Items_idItems',$item->items_idItems)->where('status',1);
//            })
//                ->orWhere(function ($query) use ($company,$item,$store){
//                    $query->where('expHave',0)->where('Company',$company->idCompanyInfo)->where('Stock_Type',$store)->where('Items_idItems',$item->items_idItems)->where('status',1);
//                })->sum('qty_available');
//            if (floatval($totalQty) > floatval($availableInStock)) {
//                $available = false;
//            }
//            $itemQty = $item->qty;
//            if ($available) {
//                $stocks = Stock::where(function ($query) use ($company,$item,$store){
//                    $query->where('expDate','>=',date('Y-m-d'))->where('Stock_Type',$store)->where('Company',$company->idCompanyInfo)->where('Items_idItems',$item->items_idItems)->where('status',1);
//                })
//                    ->orWhere(function ($query) use ($company,$item,$store){
//                        $query->where('expHave',0)->where('Company',$company->idCompanyInfo)->where('Stock_Type',$store)->where('Items_idItems',$item->items_idItems)->where('status',1);
//                    })->orderBy('idStock', 'DESC')->get();
//
//                $returns = TransferReturns::where('stock_transfer_idStock_Transfer',$id)->where('status',0)->get();
//                $totalReturnsAmount = 0;
//
//                if($returns != null) {
//                    foreach ($returns as $return) {
//                        $totalReturnsAmount += floatval($return->qty) * floatval($return->item->unitPrice);
//                    }
//                }
//
//            $transfer->totalAmount = $totalAmount;
//            $transfer->returns = $totalReturnsAmount;
//            $transfer->commissionRate =  $commission =  CompanyInfo::find(floatval($item->toCompany))->commission;
//            $transfer->commission =  $newCommission =  floatval($totalAmount - floatval($totalReturnsAmount))*(floatval($commission)/100);
//            $transfer->status =  1;
//            $transfer->netTotal = $netTotal =  floatval($totalAmount - $newCommission - $totalReturnsAmount);
//            $transfer->save();
//
//                foreach ($stocks as $stock) {
//                    $stockQty = $stock->qty_available;
//
//                    if ($itemQty <= $stockQty) {
//                        $stock->qty_available -= $itemQty;
//                        if ($itemQty == $stockQty) {
//                            $stock->status = 0;
//                        }
//                        $stock->save();
//
//
//                        $transferItem = new TransferItem();
//                        $transferItem->idStock_Transfer = $transfer->idStock_Transfer;
//                        $transferItem->Stock_idStock = $stock->idStock;
//                        $transferItem->From_Stock = $store;
//                        $transferItem->To_Stock = $item->toStore;
//                        $transferItem->fromOrder = $item->fromOrder;
//                        $transferItem->qty = $itemQty;
//                        $transferItem->unitPrice = $stock->item->unitPrice;
//                        $transferItem->returnQty = 0;
//                        $transferItem->status = 1;
//                        $transferItem->save();
//
//                        $stock2 = new Stock();
//                        $stock2->Stock_Type = $item->toStore;
//                        $stock2->base = 3;
//                        $stock2->GRN_id_or_Production_id = $transfer->idStock_Transfer;
//                        $stock2->Company = $item->toCompany;
//                        $stock2->Items_idItems = $stock->Items_idItems;
//                        $stock2->qty_grn = $item->qty;
//                        $stock2->qty_available = $item->qty;
//                        $stock2->qty_inv_return = $stock->qty_inv_return;
//                        $stock2->qty_grn_return = 0;
//                        $stock2->binNo = $stock->binNo;
//                        $stock2->expDate = $stock->expDate;
//                        $stock2->expHave = $stock->expHave;
//                        $stock2->mnfDate = $stock->mnfDate;
//                        $stock2->bp = $stock->bp;
//                        $stock2->wp = $stock->wp;
//                        $stock2->sp = $stock->sp;
//                        $stock2->status = 1;
//                        $stock2->save();
//
//                        $item->delete();
//                        $itemQty = 0;
//                        break;
//                    } else {
//
//                        if ($stock->qty_available > 0) {
//
//
//                            $transferItem = new TransferItem();
//                            $transferItem->idStock_Transfer = $transfer->idStock_Transfer;
//                            $transferItem->Stock_idStock = $stock->idStock;
//                            $transferItem->From_Stock = $store;
//                            $transferItem->To_Stock = $item->toStore;
//                            $transferItem->fromOrder = $item->fromOrder;
//                            $transferItem->qty = $stock->qty_available;
//                            $transferItem->unitPrice = $stock->item->unitPrice;
//                            $transferItem->returnQty = 0;
//                            $transferItem->status = 1;
//                            $transferItem->save();
//
//                        }
//
//                        $itemQty = floatval($itemQty) - floatval($stock->qty_available);
//                        $stock->qty_available = 0;
//                        $stock->status = 0;
//                        $stock->save();
//
//                    }
//                }
//                if ($itemQty > 0) {
//                    return response()->json(['errors' => ['error' => 'Process invalid']]);
//
//                }
//            } else {
//                return response()->json(['errors' => ['error' => 'Available qty is less than requested qty.']]);
//            }
//
//            if ($available) {
//                if ($item->fromOrder != 0) {
//                    $order = DailyOrder::find(intval($item->fromOrder));
//                    $order->status = 0;
//                    $order->save();
//
//                    $orderItems = DailyOrderItems::where('items_idItems', $item->items_idItems)->where('orders_idsales_order', intval($item->fromOrder))->get();
//                    foreach ($orderItems as $orderItem) {
//                        $orderItem->status = 0;
//                        $orderItem->save();
//                    }
//
//                    if (TransferOrder::where('stock_transfer_idStock_Transfer', $transfer->idStock_Transfer)->where('daily_orders_idsales_order', $item->fromOrder)->where('status', 1)->first() == null) {
//                        $transOrder = new TransferOrder();
//                        $transOrder->stock_transfer_idStock_Transfer = $transfer->idStock_Transfer;
//                        $transOrder->daily_orders_idsales_order = $item->fromOrder;
//                        $transOrder->status = 1;
//                        $transOrder->save();
//                    }
//
//                }
//            }
//        }
//
//
//
////        $returns = TransferReturns::where('stock_transfer_idStock_Transfer',$id)->where('status',0)->get();
////        $totalReturnsAmount = 0;
//
////        foreach ($returns as $return){
////            $totalReturnsAmount += floatval($return->qty) * floatval(Item::find($return->items_idItems)->unitPrice);
////        }
////
//////        $transfer->commission =  $newCommission =  floatval($totalAmount - floatval($totalReturnsAmount))*(floatval($commission)/100);
//////        $transfer->netTotal = $netTotal =  floatval($totalAmount - $newCommission - $totalReturnsAmount);
////          $netTotal =  floatval($totalAmount -  $totalReturnsAmount);
//////        $transfer->save();
//
//
//        $payment = new Payment();
//        $payment->Company = Auth::user()->Company;
//        $payment->payment_type_idpayment_type = 2;
//        $payment->base = 3;
//        $payment->id =$transfer->idStock_Transfer;
//        $payment->totalAmount = floatval($transfer->netTotal);
//        $payment->cash = 0;
//        $payment->credit = floatval($transfer->netTotal);
//        $payment->cheque = 0;
//        $payment->bank = 0;
//        $payment->visa = 0;
//        $payment->visaBillNo = null;
//        $payment->free = 0;
//        $payment->status = 1;
//        $payment->usermaster_idUser = Auth::user()->idUser;
//        $payment->save();
//
//        return response()->json(['success' =>'Successfully transferee.']);
//
//    }
//
//    public function saveAndEditTransfer(Request $request){
//
////        $id = $request['id'];
//        $items = $request['orders'];
//        $cType = $request['cType'];
//        $transferId = intval(TransferItemTemp::find(intval($items[0]['rowId']))->idStock_Transfer);
//        $transfer = StockTransfer::find($transferId);
//        $transfer->companyType = intval($cType);
//        $transfer->save();
////        $totalAmount = 0;
//
//        foreach ($items as $item) {
//            $transferItem = TransferItemTemp::find(intval($item['rowId']));
//            $transferItem->qty = floatval($item['qty']);
//            $transferItem->save();
////            $previousQty = $transferItem->qty;
////            if($previousQty>$item->qty){
////
////                $transferItem->qty = $item->qty;
////                $transferItem->save();
////
////                $balance = floatval($previousQty - $item->qty);
////                $stock = Stock::find($item->Stock_idStock);
////                $stock->qty_available += $balance;
////                $stock->status = 1;
////                $stock->save();
////
////                $totalAmount -= floatval($stock->item->unitPrice*$balance);
////            }
////            if($previousQty<$item->qty){
////
////                $transferItem->qty = $item->qty;
////                $transferItem->save();
////
////                $qty = floatval($item->qty - $previousQty);
////                $company = CompanyInfo::where('status',1)->where('isBranch',0)->first();
////                $store = StockType::where('type','DELIVERY SECTION STORE')->where('Company',$company->idCompanyInfo)->first();
////
////                $stocks = Stock::where('Stock_Type', $store->idStock_Type)->where('Company', $company->idCompanyInfo)->where('Items_idItems', $transferItem->stock->item->idItems)->where('status', 1)->orderBy('idStock','DESC')->get();
////
////                foreach ($stocks as $stock) {
////                    $stockQty = $stock->qty_available;
////
////                    if ($qty <= $stockQty) {
////                        $stock->qty_available -= $qty;
////                        if($qty == $stockQty){
////                            $stock->status = 0;
////                        }
////                        $stock->save();
////
////                        $item = new TransferItem();
////                        $item->idStock_Transfer = $transferItem->idStock_Transfer;
////                        $item->Stock_idStock = $stock->idStock;
////                        $item->From_Stock = $store->idStock_Type;
////                        $item->To_Stock = $transferItem->To_Stock;
////                        $item->fromOrder = 0;
////                        $item->qty = $qty;
////                        $item->unitPrice = $stock->item->unitPrice;
////                        $item->returnQty = 0;
////                        $item->status = 2;
////                        $item->save();
////
////                        $qty = 0;
////
////                        $stock2 = new Stock();
////                        $stock2->Stock_Type = $transferItem->To_Stock;
////                        $stock2->base = 3;
////                        $stock2->GRN_id_or_Production_id = $transferItem->idStock_Transfer;
////                        $stock2->Company =   $transferItem->transferStock->idStock_Transfer;
////                        $stock2->Items_idItems = $stock->Items_idItems;
////                        $stock2->qty_grn = floatval($item->qty - $previousQty);
////                        $stock2->qty_available = floatval($item->qty - $previousQty);
////                        $stock2->qty_inv_return = $stock->qty_inv_return;
////                        $stock2->qty_grn_return = 0;
////                        $stock2->binNo = $stock->binNo;
////                        $stock2->expDate = $stock->expDate;
////                        $stock2->expHave = $stock->expHave;
////                        $stock2->mnfDate = $stock->mnfDate;
////                        $stock2->bp = $stock->bp;
////                        $stock2->wp = $stock->wp;
////                        $stock2->sp = $stock->sp;
////                        $stock2->status = 1;
////                        $stock2->save();
////                        break;
////                    } else {
////
////                        if($stock->qty_available > 0) {
////                            $item = new TransferItem();
////                            $item->idStock_Transfer = $transferItem->idStock_Transfer;
////                            $item->Stock_idStock = $stock->idStock;
////                            $item->From_Stock = $store->idStock_Type;
////                            $item->To_Stock = $transferItem->To_Stock;
////                            $item->fromOrder = 0;
////                            $item->qty = $stock->qty_available;
////                            $item->unitPrice = $stock->item->unitPrice;
////                            $item->returnQty = 0;
////                            $item->status = 2;
////                            $item->save();
////                        }
////
////                        $qty = floatval($qty)-floatval($stock->qty_available);
////                        $stock->qty_available = 0;
////                        $stock->status = 0;
////                        $stock->save();
////                    }
////                }
////                if ($qty > 0) {
////                    return response()->json(['errors' => ['error' => 'Process invalid']]);
////
////                }
//
//        }
//
////        $transfer = StockTransfer::find($id);
////        $transfer->totalAmount;
//
//
//    }
//
////    public function feedItem(Request $request){
////        $store = $request['store'];
////        $company = $request['Company'];
////        $items = Stock::where('Stock_Type',$store)->where('Company',$company)->where('qty_available','>',0)->where('status',1)->select('Items_idItems')->distinct()->get();
////        if(count($items)>0) {
////            $optionData = "<option value='' disabled selected>Select Item</option>";
////            foreach ($items as $item) {
////                    $optionData .= "<option value=" . $item->Items_idItems . ">
////                              " . $item->item->itemcode . ' - ' . $item->item->itemName . "
////                         </option>";
////
////            }
////        }else{
////            $optionData = "<option value='' disabled selected>No available items in this store</option>";
////        }
////
////        return $optionData;
////    }
//
//    public function viewTransfer(){
//        if(Auth::user()->companyInfo->isBranch == 0 ){
//            $transfers = StockTransfer::where('status',1)->latest()->paginate(10);
//        }
//        else{
//            $transfers = StockTransfer::where('Company_To',Auth::user()->Company)->where('status',1)->latest()->paginate(10);
//        }
//        return view("transfer.viewTransfer")->with(['title'=>'Transfer History','transfers'=>$transfers]);
//    }
//
//    public function viewTrasferedItems(Request $request){
//        $id = $request['id'];
//        $regs = TransferItem::where('idStock_Transfer',$id)->where('status',1)->get();
//        $tableData = "";
//        foreach ($regs as $reg){
//            $tableData .= "<tr>
//                              <td>".$reg->idTransfer_Item."</td>
//                              <td>".$reg->stock->item->itemName."</td>
//                              <td>".$reg->ToStore->type."</td>
//                              <td>".$reg->FromStore->type."</td>
//                              <td>".$reg->qty."</td>
//                         </tr>";
//        }
//        return $tableData;
//    }
//
//    public function transferSearch(Request $request){
//        $transferId = $request['transferId'];
//        $endDate = $request['end'];
//        $startDate = $request['start'];
//
//        if (!empty($transferId)) {
//            $transfers = StockTransfer::where('idStock_Transfer',$transferId)->where('status',1)->paginate(10);
//
//            return view("transfer.viewTransfer")->with(['title'=>'Transfer','transfers'=>$transfers]);
//
//        } else if (!empty($startDate) && !empty($endDate)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            $transfers = StockTransfer::whereBetween('created_at', [$startDate, $endDate])->where('status',1)->latest()->paginate(10);
//            $transfers->appends(array(
//                'start' => $request['start'],
//                'end' => $request['end']
//            ));
//
//            return view("transfer.viewTransfer")->with(['title'=>'Transfer','transfers'=>$transfers]);
//        } else {
//            $transfers = StockTransfer::where('status',1)->latest()->paginate(10);
//            return view("transfer.viewTransfer")->with(['title'=>'Transfer','transfers'=>$transfers]);
//        }
//    }
//
//    public function printTransferStock($id=null,$create=true)
//    {
//        $transfer = StockTransfer::find(intval($id));
//        $returns = ReturnItemTransferAdded::where('stock_transfer_idStock_Transfer',$id)->where('status',1)->get();
//
//        return view('print.printTransfer')->with(['transfer' => $transfer,'returns'=>$returns]);
//    }
//
//    public function printTransferStockFromView($id=null)
//    {
//
//        $transfer = StockTransfer::find(intval($id));
//        $returns = ReturnItemTransferAdded::where('stock_transfer_idStock_Transfer',$id)->where('status',1)->get();
//
//        return view('print.printTransfer')->with(['transfer' => $transfer,'returns'=>$returns]);
//    }
//
//    public function transferReturns(){
//        $companies = CompanyInfo::where('status',1)->get();
//        return view("transfer.transferReturn")->with(['title'=>'Transfer Returns','companies'=>$companies]);
//    }
//
//    public function transferReturnSearch(Request $request){
//        $id = $request['transferId'];
//        if(Auth::user()->companyInfo->isBranch == 0 ){
//            $transfer = StockTransfer::find($id);
//            $items = TransferItem::where('idStock_Transfer',intval($id))->where('status',1)->get();
//
//
//        }
//        else{
//            $transfer = StockTransfer::find($id);
//            $items = TransferItem::where('idStock_Transfer',intval($id))->where('status',1)->get();
//            if($transfer->Company_To != Auth::user()->Company){
//                $transfer = null;
//                $items = null;
//            }
//
//        }
//        $companies = CompanyInfo::where('status',1)->get();
////        $items = TransferItem::with('stock')->where('idStock_Transfer',$transfer->idStock_Transfer)->where('status',1)->orderBy('Stock_idStock')->get()->groupBy('stock.Items_idItems');
//        return view("transfer.transferReturn")->with(['title'=>'Transfer Returns','items'=>$items,'transfer'=>$transfer,'companies'=>$companies]);
//    }
//
//    public function returnTransfer(Request $request){
//        $trnsId = $request['id'];
////        $Tdate = $request['Tdate'];
//        $returnQty = $request['returnQty'];
//        $reason = $request['reason'];
//
//        $transferItem = TransferItem::find( $trnsId);
//        $transferItem->returnQty += $returnQty;
//        $transferItem->save();
////        $totalReturnAmount = floatval($transferItem->unitPrice * $returnQty);
//
//
////        $transfer = StockTransfer::find( $transferItem->idStock_Transfer);
////        $transfer->returns += $transferItem->stock->item->unitPrice * $returnQty;
////        $transfer->save();
//
//        $return = new TransferReturns();
//        $return->stock_transfer_idStock_Transfer = $transferItem->idStock_Transfer;
//        $return->items_idItems = $transferItem->stock->item->idItems;
//        $return->qty =$returnQty;
//        $return->reason =$reason;
//        $return->usermaster_idUser =Auth::user()->idUser;
//        $return->status =1;
//        $return->save();
//
//
//        return response()->json([ 'success' => 'Item successfully returned','returned'=>$transferItem->returnQty]);
//    }
//
//    public function getTransferByCompany(Request $request){
//        $id = $request['company'];
//        $transfers = StockTransfer::where('Company_To',$id)->where('status',1)->orderBy('idStock_Transfer','DESC')->limit(5)->get();
//        $tableData = "";
//        foreach ($transfers as $transfer){
//            $tableData .= "<tr>";
//            $tableData .= "<td>";
//            $tableData .= "".sprintf('%06d', $transfer->idStock_Transfer)."";
//            $tableData .= "</td>";
//            $tableData .= "<td>";
//            $tableData .= "".$transfer->created_at->format('Y-m-d   H:i')."";
//            $tableData .= "</td>";
//            $tableData .= "<td style='text-align: right;'>";
//            $tableData .= "".number_format($transfer->totalAmount,2)."";
//            $tableData .= "</td>";
//            $tableData .= "<td style='text-align: center;'>";
//            $tableData .= "<div class='button-items'>
//                                    <button type='button'
//                                            class='btn btn-md btn-success  waves-effect waves-light'
//                                            onclick='orderSelected($transfer->idStock_Transfer)'>
//                                            select
//                                     </button>
//
//                                </div>";
//            $tableData .= "</td>";
//            $tableData .= "</tr>";
//        }
//        return $tableData;
//
//    }
//
//    public function editTransfer(Request $request){
//
//        $id = $request['id'];
//
//        $items = TransferItem::where('idStock_Transfer',$id)->where('status',1)->get();
//        if($items != null) {
//            TransferItemTemp::where('usermaster_idUser',Auth::user()->idUser)->delete();
//            foreach ($items as $item) {
//                $temp = new TransferItemTemp();
//                $temp->items_idItems = $item->stock->Items_idItems;
//                $temp->qty = $item->qty;
//                $temp->fromOrder = 0;
//                $temp->usermaster_idUser = Auth::user()->idUser;
//                $temp->status = 1;
//                $temp->save();
//
//            }
//        }
//    }
//
//    public function cancelTransfer(Request $request){
//
//        $id = $request['id'];
//        $transfer = StockTransfer::find($id);
//        $transfer->status = 0;
//        $transfer->save();
//
//        $items = TransferItem::where('idStock_Transfer',$id)->get();
//        if($items != null) {
//            foreach ($items as $item) {
//                $item->status = 0;
//                $item->save();
//
//                $stock = Stock::find($item->Stock_idStock);
//                $stock->qty_available += $item->qty;
//                $stock->status = 1;
//                $stock->save();
//            }
//        }
//
//        $orders = TransferOrder::where('stock_transfer_idStock_Transfer',$id)->get();
//        if($orders != null){
//            foreach ($orders as $order){
//                $order->satatus = 0;
//                $order->save();
//
//                $orderId = $order->daily_orders_idsales_order;
//
//                $dailyOrder = DailyOrder::find($orderId);
//                if($dailyOrder != null) {
//                    $dailyOrder->status = 1;
//                    $dailyOrder->save();
//                }
//
//                $orderItems = DailyOrderItems::where('orders_idsales_order',$orderId)->get();
//                if($orderItems != null){
//                    foreach ($orderItems as $orderItem){
//                        $orderItem->status = 1;
//                        $orderItem->save();
//                    }
//                }
//            }
//        }
//
//        Stock::where('base',3)->where('GRN_id_or_Production_id',$id)->delete();
//
//       $payments =  Payment::where('base',3)->where('id',$id)->get();
//       foreach ($payments as $payment){
//           $payment->status = 0;
//           $payment->save();
//       }
//
//    }
//
//    public function returnsHistory(Request $request){
//        $query = TransferReturns::query();
//        if (!empty($request->transferId)) {
//            $query = $query->where('stock_transfer_idStock_Transfer', $request->transferId);
//        }
//        if (!empty($request->end) && !empty($request->str)) {
//            $startDate = date('Y-m-d', strtotime($request['str']));
//            $endDate = date('Y-m-d', strtotime($request['end'].' +1 day'));
//            $query = $query->whereBetween('created_at', [$startDate, $endDate]);
//        }
//        $transfers = $query->latest()->paginate(10);
//        return view("transfer.returnsHistory")->with(['title'=>'Return History','transfers'=>$transfers]);
//    }
//
//    public function transferPending(){
//        $transfers = StockTransfer::where('status',2)->latest()->paginate(10);
//        return view("transfer.transferPending")->with(['transfers'=>$transfers,'title'=>'Pending Transfer']);
//
//    }
//
//    public function editPendingTransfer(Request $request){
//        $transfer = StockTransfer::find(intval($request['transferId']));
//        $company = CompanyInfo::where('status',1)->where('isBranch',0)->first();
//        $companies = CompanyInfo::where('status',1)->get();
//        $store = StockType::where('type','DELIVERY SECTION STORE')->where('Company',$company->idCompanyInfo)->first();
//        $items = Stock::where('Stock_Type',$store->idStock_Type)->where('Company',$company->idCompanyInfo)->where('qty_available','>',0)->where('status',1)->select('Items_idItems')->distinct()->get();
//        $payments = PaymentType::where('status',1)->get();
//        return view("transfer.editPendingTransfer")->with(['transfer'=>$transfer,'companies'=>$companies,'items'=>$items,'store'=>$store,'payments'=>$payments,'company'=>$company,'title'=>'Edit Transfer']);
//
//    }
//
//    public function getTransferItemTable(Request $request){
//
//        $id = $request['id'];
//        $items = TransferItemTemp::where('status',2)->where('idStock_Transfer',$id)->get();
//        $tableData = "";
//        if(count($items) > 0) {
//            foreach ($items as $temp) {
//                $company = CompanyInfo::where('status',1)->where('isBranch',0)->first();
//                $store = StockType::where('type','DELIVERY SECTION STORE')->where('Company',$company->idCompanyInfo)->first()->idStock_Type;
//                $itemId = $temp->item->idItems;
//                $available = Stock::where(function ($query) use ($company,$itemId,$store){
//                    $query->where('expDate','>=',date('Y-m-d'))->where('Stock_Type',$store)->where('Company',$company->idCompanyInfo)->where('Items_idItems',$itemId)->where('status',1);
//                })
//                    ->orWhere(function ($query) use ($company,$itemId,$store){
//                        $query->where('expHave',0)->where('Company',$company->idCompanyInfo)->where('Stock_Type',$store)->where('Items_idItems',$itemId)->where('status',1);
//                    })->sum('qty_available');
//
//                $tableData .= "<tr  id=" . $temp->idtransfer_item_temp . ">";
//                $tableData .= "<td>" . $temp->item->itemName . "</td>";
//                if(strtolower($temp->item->measurement->mian) == 'nos'){
//                    $tableData .= "<td  width='30%'>
//                                   <div class='input-group mb-2'>
//                                            <input type='number' class='form-control newQty' value=".$temp->qty."  data-id='". $temp->idtransfer_item_temp."'   name='qty-". $temp->idtransfer_item_temp."' id='qty-". $temp->idtransfer_item_temp."' min='0'
//                                               onkeypress='return event.charCode >= 48 && event.charCode <= 57'
//                  title='Numbers only'    placeholder='0.00'/>
//                                            <div class='input-group-prepend'>
//                                                <div id='qty_mes' class='input-group-text'>".$temp->item->measurement->mian."</div>
//                                            </div>
//                                        </div>
//                               </td>";
//                }
//                else{
//                    $tableData .= "<td  width='30%'>
//                                    <div class='input-group mb-2'>
//                                            <input type='number' class='form-control newQty'  value=".$temp->qty."   name='qty-". $temp->idtransfer_item_temp."' data-id='". $temp->idtransfer_item_temp."' id='qty-". $temp->idtransfer_item_temp."' min='0'
//                                                   placeholder='0.00'/>
//                                            <div class='input-group-prepend'>
//                                                <div id='qty_mes' class='input-group-text'>".$temp->item->measurement->mian."</div>
//                                            </div>
//                                        </div>
//                               </td>";
//                }
//
//                $tableData .= "<td>" . $available .' '.$temp->item->measurement->mian. "</td>";
//                if($temp->fromOrder != 0){
//                    $tableData .= " <td style='text-align:center;'>
//                                <div class='button-items'>
//                                    <button type='button'  title='This will delete all item belongs to selected order'
//                                            class='btn btn-sm btn-danger  waves-effect waves-light'
//                                             onclick='deleteTransferItems(this)'
//                                            data-id=" . $temp->idtransfer_item_temp . "
//                                            >
//                                            <i class='ti-trash'></i>
//                                     </button>
//
//                                </div>
//                            </td>";
//                }
//                else {
//                    $tableData .= " <td style='text-align:center;'>
//                                <div class='button-items'>
//                                    <button type='button'
//                                            class='btn btn-sm btn-danger  waves-effect waves-light'
//                                            data-id=" . $temp->idtransfer_item_temp . "
//                                            onclick='deleteTransferItems(this)'>
//                                            <i class='fa fa-trash'></i>
//                                     </button>
//
//                                </div>
//                            </td>";
//                }
//                $tableData .= "</tr>";
//            }
//        }
//
//
////        $temps = TransferItemTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
////        if(count($temps)) {
////            foreach ($temps as $temp) {
////                $company = Auth::user()->Company;
////                $available = Stock::where(function ($query) use ($company){
////                    $query->where('expDate','>=',date('Y-m-d'))->where('Company',$company)->where('Items_idItems',$itemId)->where('status',1);
////                })
////                    ->orWhere(function ($query) use ($company,$itemId){
////                        $query->where('expHave',0)->where('Company',$company)->where('Items_idItems',$itemId)->where('status',1);
////                    })->sum('qty_available');
////
////
////                $tableData .= "<tr class='text-primary'  id=" . $temp->idtransfer_item_temp . ">";
////                $tableData .= "<td>" . $temp->item->itemName . "</td>";
////                $tableData .= "<td>" . $temp->qty . "</td>";
////                $tableData .= "<td>" . $temp->qty . "</td>";
////                if($temp->fromOrder != 0){
////                    $tableData .= " <td style='text-align:center;'>
////                                <div class='button-items'>
////                                    <button type='button'  title='This will delete all item belongs to selected order'
////                                            class='btn btn-sm btn-primary  waves-effect waves-light'
////                                             onclick='deleteTempTransfer(this)'
////                                            data-id=" . $temp->idtransfer_item_temp . "
////                                            >
////                                            <i class='ti-trash'></i>
////                                     </button>
////
////                                </div>
////                            </td>";
////                }
////                else {
////                    $tableData .= " <td style='text-align:center;'>
////                                <div class='button-items'>
////                                    <button type='button'
////                                            class='btn btn-sm btn-primary  waves-effect waves-light'
////                                            data-id=" . $temp->idtransfer_item_temp . "
////                                            onclick='deleteTempTransfer(this)'>
////                                            <i class='fa fa-trash'></i>
////                                     </button>
////
////                                </div>
////                            </td>";
////                }
////                $tableData .= "</tr>";
////            }
////        }
//        if( count($items) == 0){
//
//            $tableData .="<tr><td style='text-align: center' colspan='5'>No available data. </td> </tr>";
//
//        }
//        return $tableData;
//
//
//
//    }
//
//    public function deleteTransferItems(Request $request){
//        $temp = TransferItem::find($request['id']);
//        if($temp->fromOrder !=0 ){
//            $orderItems = TransferItem::where('fromOrder',$temp->fromOrder)->get();
//            foreach ($orderItems as $orderItem){
//
//                $orderItem->delete();
//            }
//        }
//        else {
////            $stock = Stock::find($temp->Stock_idStock);
////            $stock->qty_available += $temp->qty;
////            $stock->save();
//            $temp->delete();
//        }
//    }
//
////    public function addItemTransferItem(Request $request){
////        $item = $request['item'];
////        $qty = $request['qty'];
////        $id = $request['id'];
////        $itemDetails = Item::find($item);
////        $transfer = StockTransfer::find($id);
////
////
////        $validator = \Validator::make($request->all(), [
////            'item' => 'required',
////            'qty' => 'required',
////            'id' => 'required'
////        ], [
////            'item.required' => 'Item should be provided!',
////            'qty.required' => 'Qty should be provided!',
////            'id.required' => 'ID should be provided!',
////        ]);
////
////        if ($validator->fails()) {
////            return response()->json(['errors' => $validator->errors()->all()]);
////        }
////
////            $available = true;
////                $totalAmount = floatval($qty)*floatval($itemDetails->unitPrice);
////                if($qty >Stock::where('Stock_Type',$request['FromStore'])->where('Company',$request['FromCompany'])->where('Items_idItems',$item)->where('status',1)->sum('qty_available')){
////                    $available = false;
////                }
////            if($available) {
////
////                    $stocks = Stock::where('Stock_Type', $request['FromStore'])->where('Company', $request['FromCompany'])->where('Items_idItems', $item)->where('status', 1)->orderBy('idStock','DESC')->get();
////
////                    foreach ($stocks as $stock) {
////                        $stockQty = $stock->qty_available;
////
////                        if ($qty <= $stockQty) {
////                            $stock->qty_available -= $qty;
////                            if($qty == $stockQty){
////                                $stock->status = 0;
////                            }
////                            $stock->save();
////
////                            $item = new TransferItem();
////                            $item->idStock_Transfer = $id;
////                            $item->Stock_idStock = $stock->idStock;
////                            $item->From_Stock = $request['FromStore'];
////                            $item->To_Stock = $transfer->;
////                            $item->fromOrder = 0;
////                            $item->qty = $qty;
////                            $item->unitPrice = $stock->item->unitPrice;
////                            $item->returnQty = 0;
////                            $item->status = 2;
////                            $item->save();
////
////                            $qty = 0;
////
////                            $stock2 = new Stock();
////                            $stock2->Stock_Type = $toStock;
////                            $stock2->base = 3;
////                            $stock2->GRN_id_or_Production_id = $transfer->idStock_Transfer;
////                            $stock2->Company =  $request['ToCompany'];
////                            $stock2->Items_idItems = $stock->Items_idItems;
////                            $stock2->qty_grn = $temp->qty;
////                            $stock2->qty_available = $temp->qty;
////                            $stock2->qty_inv_return = $stock->qty_inv_return;
////                            $stock2->qty_grn_return = 0;
////                            $stock2->binNo = $stock->binNo;
////                            $stock2->expDate = $stock->expDate;
////                            $stock2->expHave = $stock->expHave;
////                            $stock2->mnfDate = $stock->mnfDate;
////                            $stock2->bp = $stock->bp;
////                            $stock2->wp = $stock->wp;
////                            $stock2->sp = $stock->sp;
////                            $stock2->status = 1;
////                            $stock2->save();
////                            $temp->delete();
////                            break;
////                        } else {
////
////                            if($stock->qty_available > 0) {
////                                $item = new TransferItem();
////                                $item->idStock_Transfer = $transfer->idStock_Transfer;
////                                $item->Stock_idStock = $stock->idStock;
////                                $item->From_Stock = $request['FromStore'];
////                                $item->To_Stock = $toStock;
////                                $item->fromOrder = $temp->fromOrder;
////                                $item->qty = $stock->qty_available;
////                                $item->unitPrice = $stock->item->unitPrice;
////                                $item->returnQty = 0;
////                                $item->status = 2;
////                                $item->save();
////                            }
////
////                            $qty = floatval($qty)-floatval($stock->qty_available);
////                            $stock->qty_available = 0;
////                            $stock->status = 0;
////                            $stock->save();
////                        }
////
////                    $temp->delete();
////                    if ($qty > 0) {
////                        return response()->json(['errors' => ['error' => 'Process invalid']]);
////
////                    }
////
////
////        $po = new TransferItem();
////        $po->idStock_Transfer = $item;
////        $po->qty= $qtyGrn;
////        $po->status = 1;
////        $po->fromOrder = 0;
////        $po->usermaster_idUser = Auth::user()->idUser;
////        $po->save();
////
////        return response()->json([ 'success' => 'Successfully saved']);
////    }
//
//}