<?php
/**
 * Created by PhpStorm.
 * User: Thilina
 * Date: 3/15/2019
 * Time: 6:02 PM
 */

namespace App\Http\Controllers;


use App\Item;
use App\ItemCategory;
use App\Brand;
use App\MainCategory;
use App\Measurement;
use App\SubCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use PhpOffice\PhpSpreadsheet\Calculation\Category;

class ItemController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $categories = MainCategory::where('status',1)->where('Company',Auth::user()->Company)->get();
        $types = Brand::where('status',1)->where('Company',Auth::user()->Company)->get();
        $measurements = Measurement::where('status',1)->where('Company',Auth::user()->Company)->get();

        return view('product.add_products', ['types'=>$types,'categories'=>$categories,'title' => 'Add Product','measurements'=>$measurements]);
    }

    public function save(Request $request)
    {
        $iType = $request['iType'];
        $MainCat = $request['MainCat'];
        $itemName = $request['itemName'];
        $itemCode = $request['itemCode'];
        $description = $request['description'];
        $pPrice = round($request['pPrice'],2);
        $unitPrice = round($request['unitPrice'],2);
        $itemColor = $request['itemColor'];
        $minQty = $request['minQty'];
        $maxQty = $request['maxQty'];
        $vat = $request['vat'];
        $vatType = $request['vatType'];
        $taxRate = $request['taxRate'];
        $itemBin = $request['itemBin'];
        $measurement = $request['measurement'];

        $validator = \Validator::make($request->all(), [

            'itemName' => 'required',
            'itemCode' => 'required',
            'iType' => 'required',
            'MainCat' => 'required',
            'measurement' => 'required',
            'pPrice' => 'required',
            'unitPrice' => 'required',
            'minQty' => 'required',
            'maxQty' => 'required',
            'itemColor' => 'required',

        ], [
            'itemName.required' => 'Product Name should be provided!',
            'itemCode.required' => 'Product Code should be provided!',
            'iType.required' => 'Product type should be provided!',
            'MainCat.required' => 'Main category should be provided!',
            'measurement.required' => 'Measurement should be provided!',
            'pPrice.required' => 'Purchase Price should be provided!',
            'unitPrice.required' => 'Unit Price should be provided!',
            'minQty.required' => 'Min Qty should be provided!',
            'maxQty.required' => 'Max Qty should be provided!',
            'itemColor.required' => 'Product color should be provided!',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        if(Item::where('itemcode',$itemCode)->where('Company',Auth::user()->Company)->first()){
            return response()->json(['errors' => ['error' => 'Item code already exist.']]);
        }

        if($minQty >= $maxQty){
            return response()->json(['errors' => ['error' => 'Min Qty must be less than Max Qty.']]);
        }

        $mainItem = new Item();
        $mainItem->Item_Type = $iType;
        $mainItem->mainCategory = $MainCat;
        $mainItem->itemName = strtoupper($itemName);
        $mainItem->itemcode = $itemCode;
        $mainItem->description = $description;
        $mainItem->purchasePrice = $pPrice;
        $mainItem->unitPrice = $unitPrice;
        $mainItem->low_qty = $minQty;
        $mainItem->max_qty = $maxQty;
        $mainItem->measurement_idMeasurement = $measurement;
        $mainItem->color = $itemColor;
        $mainItem->vat = $vat;
        $mainItem->vatType = $vatType;
        $mainItem->taxRate = $taxRate;
        $mainItem->binLocation = $itemBin;
        $mainItem->UserMaster_idUser = Auth::user()->idUser;
        $mainItem->Company = Auth::user()->Company;
        $mainItem->status = '1';
        $mainItem->save();


        return response()->json([ 'success' => 'Product info is successfully updated','itemId'=>$mainItem->idItems]);

    }

    public function update(Request $request)
    {
        $hiddenUID = $request['hiddenUID'];
        $uIType = $request['uIType'];
        $uMainCat = $request['uMainCat'];
        $uItemName = $request['uItemName'];
        $uItemCode = $request['uItemCode'];
        $uDescription = $request['uDescription'];
        $uPPrice = round($request['uPPrice'],2);
        $uUnitPrice = round($request['uUnitPrice'],2);
        $uVat = $request['uVat'];
        $uVatType = $request['uVatType'];
        $uTaxRate = $request['uTaxRate'];
        $uItemBin = $request['uItemBin'];
        $Umeasurement = $request['Umeasurement'];
        $umaxQty = $request['umaxQty'];
        $uminQty = $request['uminQty'];



        $validator = \Validator::make($request->all(), [

            'uItemName' => 'required',
            'uItemCode' => 'required',
            'uIType' => 'required',
            'uMainCat' => 'required',
            'Umeasurement' => 'required',
            'uUnitPrice' => 'required',
            'uPPrice' => 'required',
            'uminQty' => 'required',
            'umaxQty' => 'required',


        ], [
            'uItemName.required' => 'Product name should be provided!',
            'uItemCode.required' => 'Product code should be provided!',
            'uIType.required' => 'Product type should be provided!',
            'uMainCat.required' => 'Category should be provided!',
            'Umeasurement.required' => 'Measurement should be provided!',
            'uUnitPrice.required' => 'Unit price should be provided!',
            'uPPrice.required' => 'Purchase price should be provided!',
            'uminQty.required' => 'Min qty should be provided!',
            'umaxQty.required' => 'Max qty should be provided!',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        if(Item::where('itemcode',$uItemCode)->where('idItems','!=',$hiddenUID)->where('Company',Auth::user()->Company)->first()){
            return response()->json(['errors' => ['error' => 'Item code already exist.']]);
        }

        if($uminQty >= $umaxQty){
            return response()->json(['errors' => ['error' => 'Min Qty must be less than Max Qty.']]);
        }

        $item = Item::find(intval($hiddenUID));
        $item->Item_Type = $uIType;
        $item->mainCategory = $uMainCat;
        $item->itemName = strtoupper($uItemName);
        $item->itemcode = $uItemCode;
        $item->description = $uDescription;
        $item->purchasePrice = $uPPrice;
        $item->unitPrice = $uUnitPrice;
        $item->vat = $uVat;
        $item->low_qty = $uminQty;
        $item->max_qty = $umaxQty;
        $item->vatType = $uVatType;
        $item->taxRate = $uTaxRate;
        $item->measurement_idMeasurement = $Umeasurement;
        $item->binLocation = $uItemBin;
        $item->UserMaster_idUser = Auth::user()->idUser;
        $item->save();


        return response()->json([ 'success' => 'Product successfully updated']);

    }

    public function search(Request $request)
    {
        $keyword = $request['search'];
        $type = $request['type'];
        $main = $request['main'];

        $query = Item::query();
        $query = $query->where(function ($query) use($keyword,$main,$type){
            $query->where('itemName', 'LIKE',"%$keyword%")->where('Company',Auth::user()->Company);
            if(!empty($main)){
                $query->where('mainCategory',$main);
            }
            if(!empty($type)){
                $query->where('Item_Type',$type);
            }
        })->orWhere(function ($query)  use($keyword,$main,$type){
            $query->where('itemCode', 'LIKE',"%$keyword%")->where('Company',Auth::user()->Company);
            if(!empty($main)){
                $query->where('mainCategory',$main);
            }
            if(!empty($type)){
              $query->where('Item_Type',$type);
            }
        });

        $getItemViews = $query->orderBy('itemCode','ASC')->paginate(10);

        $types = Brand::where('Company',Auth::user()->Company)->where('status',1)->get();
        $measurements = Measurement::where('status',1)->where('Company',Auth::user()->Company)->get();
        $cats = MainCategory::where('status', '1')->where('Company',Auth::user()->Company)->get();

        $getItemViews->appends(array(
            'search' => $request['search'],
            'type'   => $request['type'],
            'main'   => $request['main']
        ));

        return view('product.item_managment', ['title' => 'View Products','measurements'=>$measurements, 'types' => $types, 'cats' => $cats,  'getItemViews' => $getItemViews]);

    }

    
    public function changeStatus(Request $request){
        $id = $request['id'];
        $user = Item::find(intval($id));
        if ($user->status == 1) {
            $user->status = 0;
        } else {
            $user->status = 1;
        }
        $user->save();
    }

    public function getByID(Request $request)
    {
        $itemId = $request['itemId'];
        $item = Item::find(intval($itemId));
        return response()->json(['items'=>$item]);
    }

    public function saveImage(Request $request){

        $file= $request->file('selected');
        $id = $request['hiddenItemId'];

        if($file != null) {
            $name = time() . $file->getClientOriginalName();
            $file->move(public_path('assets/images/items/'), $name);

            $item = Item::find($id);
            $item->image = $name;
            $item->save();

        }
        return response()->json([ 'success' => 'success']);
//        return response()->json(['errors' => ['error' => 'Image not found']]);



    }

    public function updateImage(Request $request){

        $file = $request->file('updatedImage');
        $id = $request['hiddenUID'];

        if($file != null) {
            $name = Auth::user()->idUser.time() . $file->getClientOriginalName();
            $file->move(public_path('assets/images/items/'), $name);

            $item = Item::find($id);
            $item->image = $name;
            $item->save();
        }
        return response()->json([ 'success' => 'success']);

//        return response()->json(['errors' => ['error' => 'Image not found']]);


    }


}