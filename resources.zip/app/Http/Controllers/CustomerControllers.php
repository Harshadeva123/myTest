<?php
/**
 * Created by PhpStorm.
 * User: Thilina
 * Date: 5/4/2019
 * Time: 8:51 PM
 */

namespace App\Http\Controllers;

use App\Customer;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class CustomerControllers extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('customer.add_customer', ['title' => 'Add Customer']);
    }

    public function view(Request $request)
    {

        $paginate = 10;
        $keyword = $request['search'];
        $column = '';
        $viewAllCustomers = Customer::orderBy('created_at', 'desc')
            ->Where(function ($query) use ($column, $keyword) {
                $query->where('fName' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('lName' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('contactNo1' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('contactNo2' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('email' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('address_line_1' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('address_line_2' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('city' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('texCode' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('creditLimit' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orWhere(function ($query) use ($column, $keyword) {
                $query->where('email' . $column . '', 'LIKE', "%$keyword%")->where('Company', Auth::user()->Company);
            })
            ->orderBy('idCustomer', 'DESC')->paginate($paginate);
        $viewAllCustomers->appends(array('search' => $request['search'],));


        return view('customer.view_customer', ['viewAllCustomers' => $viewAllCustomers,'title'=>'Customers']);
    }

    public function save(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'cfName' => 'required||regex:/^[a-zA-Z ]+$/u|max:255',
            'clName' => 'required||regex:/^[a-zA-Z ]+$/u|max:255',
            'cTitle' => 'required|in:Mr.,Mrs.,Miss.',
        ], [
            'cfName.required' => 'Customer First Name should be provided!',
            'cTitle.required' => 'Title should be provided!',
            'cTitle.in' => 'Title should be provided!',
            'cfName.regex' => 'Customer First Name Format Is Invalid!',
            'cfName.max' => 'Customer First Name May Not Be Greater Than 255!',
            'clName.required' => 'Customer Last Name Format Is Invalid!',
            'clName.max' => 'Customer Last Name May Not Be Greater Than 255!',
            'clName.regex' => 'Customer Last Name should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        } else {
            $cTitle = $request['cTitle'];
            $cfName = $request['cfName'];
            $clName = $request['clName'];
            $cNumber = $request['cNumber'];
            $cNumber2 = $request['cNumber2'];
            $cFax = $request['cFax'];
            $creditLimit=$request['creditLimit'];
            $balance=$request['balance'];
            $cEmail = $request['cEmail'];
            $cWebsite = $request['cWebsite'];
            $cAddress1 = $request['cAddress1'];
            $cAddress2 = $request['cAddress2'];
            $cCity = $request['cCity'];
            $cState = $request['cState'];
            $cZipCode = $request['cZipCode'];
            $cGender = $request['cGender'];
            $cBirthDay = $request['cBirthDay'];
            $cVAtId = $request['cVAtId'];
            $cTaxesCode = $request['cTaxesCode'];

            $cust = new Customer();
            $cust->title = $cTitle;
            $cust->fname = strtoupper($cfName);
            $cust->lname = strtoupper($clName);
            $cust->contactNo1 = $cNumber;
            $cust->contactNo2 = $cNumber2;
            $cust->fax = $cFax;
            $cust->email = $cEmail;
            $cust->website = $cWebsite;
            $cust->address_line_1 = $cAddress1;
            $cust->address_line_2 = $cAddress2;
            $cust->City = $cCity;
            $cust->creditLimit=$creditLimit;
            $cust->balance=$balance;
            $cust->State = $cState;
            $cust->zipCode = $cZipCode;
            $cust->gender = $cGender;
            $cust->birthday = $cBirthDay;
            $cust->vatId = $cVAtId;
            $cust->texCode = $cTaxesCode;
            $cust->Company = Auth::user()->Company;
            $cust->UserMaster_idUser = Auth::user()->idUser;
            $cust->isPublic = '1';
            $cust->status = '1';
            $cust->save();
            return response()->json(['success' => 'Customer info is successfully updated']);
        }

    }

    public function changeStatus(Request $request)
    {
        $customerId = $request['id'];
        if($customerId != 1) {
            $customer = Customer::find(intval($customerId));
            if ($customer->status == 1) {
                $customer->status = 0;
            } else {
                $customer->status = 1;
            }
            $customer->save();
        }
    }

    public function getByID(Request $request)
    {
        $customerId = $request['customerId'];
        $customer = Customer::find(intval($customerId));
        return response()->json($customer);
    }

    public function update(Request $request)
    {
        $hiddenCID = $request['hiddenCID'];
        $cuUTitle = $request['cuUTitle'];
        $cuUfName = $request['cuUfName'];
        $cuUlName = $request['cuUlName'];
        $cuUNumber1 = $request['cuUNumber1'];
        $cuUNumber2 = $request['cuUNumber2'];
        $cuUFax = $request['cuUFax'];
        $cuUEmail = $request['cuUEmail'];
        $cuUWebSite = $request['cuUWebSite'];
        $cuUAddress = $request['cuUAddress'];
        $cuUAddress2 = $request['cuUAddress2'];
        $cuUCity = $request['cuUCity'];
        $cuUState = $request['cuUState'];
        $cuUZipCode = $request['cuUZipCode'];
        $ucGender = $request['ucGender'];
        $cuUBDay = $request['cuBirthDay'];
        $cuUVatId = $request['cuVAtId'];
        $cuUTexCode = $request['cuTaxesCode'];
        $cuCreditLimit=$request['cuCreditLimit'];
        $cuBalance=$request['cuBalance'];

        $validator = \Validator::make($request->all(), [
            'cuUfName' => 'required||regex:/^[a-zA-Z ]+$/u|max:255',
            'cuUlName' => 'required||regex:/^[a-zA-Z ]+$/u|max:255',

        ], [
            'cuUfName.required' => 'Customer First Name should be provided!',
            'cuUfName.max' => 'Customer First Name May Not Be Greater Than 255!',
            'cuUlName.required' => 'Customer Last Name should be provided!',
            'cUfName.regex' => 'Customer First Name Format Is Invalid!',
            'cuUlName.regex' => 'Customer Last Name Format Is Invalid!',
            'cuUlName.max' => 'Customer First Name May Not Be Greater Than 255!',


        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        if($hiddenCID == 1){
            return response()->json(['errors' =>['error'=>'Default customer can not be edited.']]);
        }

        $editCust = Customer::find(intval($hiddenCID));
        $editCust->title = $cuUTitle;
        $editCust->fname = strtoupper($cuUfName);
        $editCust->lname = strtoupper($cuUlName);
        $editCust->contactNo1 = $cuUNumber1;
        $editCust->contactNo2 = $cuUNumber2;
        $editCust->fax = $cuUFax;
        $editCust->email = $cuUEmail;
        $editCust->website = $cuUWebSite;
        $editCust->address_line_1 = $cuUAddress;
        $editCust->address_line_2 = $cuUAddress2;
        $editCust->city = $cuUCity;
        $editCust->creditLimit=$cuCreditLimit;
        $editCust->balance=$cuBalance;
        $editCust->state = $cuUState;
        $editCust->zipCode = $cuUZipCode;
        $editCust->gender = $ucGender;
        $editCust->birthday = $cuUBDay;
        $editCust->vatId = $cuUVatId;
        $editCust->texCode = $cuUTexCode;
        $editCust->update();

        $customers = Customer::orderBy('created_at', 'desc')->paginate(10);
        $tableData = '';
        foreach ($customers as $customer) {
            $tableData .= "<tr>";
            $tableData .= "<td>" .strtoupper(($customer->idCustomer != 1? $customer->title : '').' '. $customer->fname ." ". $customer->lname) . "</td>";
            $tableData .= "<td>" . $customer->address_line_1 . '' . $customer->address_line_2 . ' ' . $customer->City . "</td>";
            $tableData .= "<td>" . $customer->contactNo1 . "</td>";
            $tableData .= "<td>" . $customer->User->fName. "</td>";
            $tableData .= "<td>" . $customer->created_at . "</td>";
            $tableData .= "<td>" . $customer->updated_at . "</td>";
            if ($customer->status == 1) {

                $tableData .= "<td>";
                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$customer->idCustomer','customer') id='c" . $customer->idCustomer . "' checked switch='none'/>";
                $tableData .= "<label for='c" . $customer->idCustomer . "' data-on-label='On' data-off-label='Off'></label>";
                $tableData .= "</td>";
            } else {
                $tableData .= "<td>";
                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$customer->idCustomer','customer') id='c" . $customer->idCustomer . "'  switch='none'/>";
                $tableData .= "<label for='c" . $customer->idCustomer . "' data-on-label='On' data-off-label='Off'></label>";
                $tableData .= "</td>";
            }

            $tableData .= "<td>";
            $tableData .= "<div class='dropdown'>";
            $tableData .= "<button class='btn btn-secondary btn-md dropdown-toggle'  type='button' id='dropdownMenuButton'  data-toggle='dropdown' aria-haspopup='true'  aria-expanded='false'>Option  </button>";
            $tableData .= " <div class='dropdown-menu'   aria-labelledby='dropdownMenuButton'>";
            if($customer->idCustomer != 1) {
                $tableData .= " <a class='dropdown-item' href = '#'  data-toggle= 'modal' data-id ='$customer->idCustomer'  id = 'customerUpdate'   data-target = '#myModal' >Edit</a >";
            }
            $tableData .= "<a class='dropdown-item' href = '#' data-toggle = 'modal' data-id = '$customer->idCustomer'  id = 'customerView' data-target = '#myModal1' >View</a >";
            $tableData .= "  </div >";
            $tableData .= "</td >";

        }

        return response()->json(['tableData' => $tableData, 'success' => 'Customer info is successfully updated']);
    }

    public function viewTableData(Request $request){

        $customerId = $request['customerId'];
        $getCustomer = Customer::find(intval($customerId));
        $tableData = "";
        $tableData .= "<tr><td colspan='2' width='100%'><h6>Personal Details</h6></td></tr>";
        $tableData .= "<tr><td width='40%'>Customer Name</td><td width='60%'> : ".$getCustomer->title.$getCustomer->fname." ".$getCustomer->lname ."</td></tr>";
        $tableData .= "<tr><td width='40%'>Gender</td><td width='60%'> : ".$getCustomer->gender."</td></tr>";
        $tableData .= "<tr><td width='40%'>Date of Birth</td><td width='60%'> : ".$getCustomer->birthday."</td></tr>";
        $tableData .= "<tr><td colspan='2' width='100%'><h6>Contact Information</h6></td></tr>";
        $tableData .= "<tr><td width='40%'>Contact No 1</td><td width='60%'> : <a href='tel:$getCustomer->contactNo1'>".$getCustomer->contactNo1."</a></td></tr>";
        $tableData .= "<tr><td width='40%'>Contact No 2</td><td width='60%'> : <a href='tel:$getCustomer->contactNo2'>".$getCustomer->contactNo2."</a></td></tr>";
        $tableData .= "<tr><td width='40%'>Email</td><td width='60%'> : <a href='mailto:$getCustomer->email'>".$getCustomer->email."</a></td></tr>";
        $tableData .= "<tr><td width='40%'>Fax</td><td width='60%'> : ".$getCustomer->fax."</td></tr>";
        $tableData .= "<tr><td width='40%'>Website</td><td width='60%'> : <a target='_blank' href='$getCustomer->website'>".$getCustomer->website."</a></td></tr>";
        $tableData .= "<tr><td width='40%'>Address</td><td width='60%'> : ".$getCustomer->address_line_1.",".$getCustomer->address_line_2 ."</td></tr>";
        $tableData .= "<tr><td width='40%'>City</td><td width='60%'> : ".$getCustomer->City."</td></tr>";
        $tableData .= "<tr><td width='40%'>State</td><td width='60%'> : ".$getCustomer->State."</td></tr>";
        $tableData .= "<tr><td width='40%'>Zip Code/Postal Code</td><td width='60%'> : ".$getCustomer->zipCode."</td></tr>";
        $tableData .= "<tr><td colspan='2' width='100%'><h6>Tax Information</h6></td></tr>";
        $tableData .= "<tr><td width='40%'>VAT ID</td><td width='60%'> :".$getCustomer->vatId."</td></tr>";
        $tableData .= "<tr><td width='40%'>TAX Code</td><td width='60%'> :".$getCustomer->texCode."</td></tr>";
        $tableData .= "<tr><td width='40%'>Credit Limit</td><td width='60%'> :".$getCustomer->creditLimit."</td></tr>";
        $tableData .= "<tr><td width='40%'>Balance</td><td width='60%'> :".$getCustomer->balance."</td></tr>";
        $tableData .= "<tr><td colspan='2' width='100%'><h6>System Generated Data</h6></td></tr>";
        $tableData .= "<tr><td width='40%'>Created/Updated By</td><td width='60%'>: ".$getCustomer->User->fName."</td></tr>";
        $tableData .= "<tr><td width='40%'>Created At</td><td width='60%'> : ".$getCustomer->created_at."</td></tr>";
        $tableData .= "<tr><td width='40%'>Last Updated</td><td width='60%'> : ".$getCustomer->updated_at."</td></tr>";

        return response()->json(['tableData'=>$tableData]);
    }




}