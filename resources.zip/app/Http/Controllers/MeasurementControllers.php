<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/7/2019
 * Time: 8:11 AM
 */

namespace App\Http\Controllers;


use App\Measurement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MeasurementControllers extends Controller
{

    public function index(Request $request)
    {
        $search = $request['search'];
        $query = Measurement::query();
        if (!empty($search)) {
            $query = $query->where('measurement', 'LIKE', '%' . $search . '%');
        }
        $measurementViews = $query->where('Company',Auth::user()->Company)->latest()->paginate(10);

        return view('measurement.measurement', ['title' => 'Measurements', 'measurementViews' => $measurementViews]);
    }

    public function getById(Request $request)
    {
        $measurementId = $request['measurementId'];
        $measurement = Measurement::find(intval($measurementId));
        return response()->json($measurement);
    }

    public function save(Request $request)
    {
        $measurement = $request['measurement'];
        $mMeasurement = $request['mMeasurement'];
        $subMeasurement = $request['subMeasurement'];
        $mainValue = $request['mainValue'];
        $subVal = $request['subVal'];

        $validator = \Validator::make($request->all(), [
            'measurement' => 'required',
            'mMeasurement' => 'required',
            'subMeasurement' => 'required',
        ], [
            'measurement.required' => 'Measurement Name should be provided!',
            'mMeasurement.required' => 'Main Measurement should be provided!',
            'subMeasurement.required' => 'Sub Measurement should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $measurementExist = Measurement::where('measurement', strtoupper($measurement))->where('Company',Auth::user()->Company)->first();

        if ($measurementExist == null) {
            $measure = New Measurement();
            $measure->measurement = strtoupper($measurement);
            $measure->mian = $mMeasurement;
            $measure->Company = Auth::user()->Company;
            $measure->usermaster_idUser = Auth::user()->idUser;
            $measure->sub = $subMeasurement;
            $measure->mainValue = doubleval($mainValue);
            $measure->subValue = doubleval($subVal);
            $measure->status = '1';
            $measure->save();

            $measureViews = Measurement::latest()->where('Company',Auth::user()->Company)->paginate(10);
            $tableData = '';
            foreach ($measureViews as $measureView) {
                $tableData .= "<tr>";
                $tableData .= "<td>" . $measureView->measurement . "</td>";
                $tableData .= "<td>" . $measureView->mian . "</td>";
                $tableData .= "<td>" . $measureView->sub . "</td>";
                $tableData .= "<td>" . $measureView->mainValue . "</td>";
                $tableData .= "<td>" . $measureView->subValue . "</td>";
                $tableData .= "<td>" . $measureView->created_at . "</td>";
                if ($measureView->status == 1) {

                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$measureView->idMeasurement','measurement') id='c" . $measureView->idMeasurement . "' checked switch='none'/>";
                    $tableData .= "<label for='c" . $measureView->idMeasurement . "' data-on-label='On' data-off-label='Off'></label>";
                    $tableData .= "</td>";
                } else {
                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$measureView->idMeasurement','measurement') id='c" . $measureView->idMeasurement . "'  switch='none'/>";
                    $tableData .= "<label for='c" . $measureView->idMeasurement . "' data-on-label='On' data-off-label='Off'></label>";
                    $tableData .= "</td>";
                }
                $tableData .= "<td>";
                $tableData .= " <p>";
                $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light'
              data-toggle='modal' data-id='$measureView->idMeasurement' id='uMeasurementId' data-target='#updateMeasurement'>";
                $tableData .= "<i class='fa fa-edit'></i>";
                $tableData .= "</button>";
                $tableData .= " </p>";
                $tableData .= " </td>";
                $tableData .= "</tr>";
            }

            return response()->json(['success' => 'Measurement info is successfully Save', 'tableData' => $tableData]);
        } else {
            return response()->json(['errors' => ['a' => 'Measurement Name already exist!']]);
        }
    }

    public function changeStatus(Request $request){

        $id = $request['id'];
        $measurement = Measurement::find($id);
        if ($measurement->status == 1) {
            $measurement->status = 0;
        } else {
            $measurement->status = 1;
        }
        $measurement->save();
    }

    public function update(Request $request)
    {
        $measurementId = $request['measurementId'];
        $uMeasurement = $request['uMeasurement'];
        $uMMeasurement = $request['uMMeasurement'];
        $uSubMeasurement = $request['uSubMeasurement'];
        $uMainValue = $request['uMainValue'];
        $uSubVal = $request['uSubVal'];

        $validator = \Validator::make($request->all(), [
            'uMeasurement' => 'required',
            'uMMeasurement' => 'required',
            'uSubMeasurement' => 'required',
        ], [
            'uMeasurement.required' => 'Measurement Name should be provided!',
            'uMMeasurement.required' => 'Main Measurement  should be provided!',
            'uSubMeasurement.required' => 'Sub Measurement should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        $measurementExist = Measurement::where('measurement', strtoupper($uMeasurement))->where('Company',Auth::user()->Company)->first();
        if ($measurementExist != null) {
            return response()->json(['errors' => ['error'=>'Measurement name already exist!']]);
        }

        $umeasurement = Measurement::find(intval($measurementId));
        $umeasurement->measurement = strtoupper($uMeasurement);
        $umeasurement->mian = $uMMeasurement;
        $umeasurement->sub = $uSubMeasurement;
        $umeasurement->mainValue = doubleval($uMainValue);
        $umeasurement->subValue = doubleval($uSubVal);
        $umeasurement->update();


        $measureViews = Measurement::latest()->where('Company',Auth::user()->Company)->paginate(10);
        $tableData = '';
        foreach ($measureViews as $measureView) {
            $tableData .= "<tr>";
            $tableData .= "<td>" . $measureView->measurement . "</td>";
            $tableData .= "<td>" . $measureView->mian . "</td>";
            $tableData .= "<td>" . $measureView->sub . "</td>";
            $tableData .= "<td>" . $measureView->mainValue . "</td>";
            $tableData .= "<td>" . $measureView->subValue . "</td>";
            $tableData .= "<td>" . $measureView->created_at . "</td>";
            if ($measureView->status == 1) {

                $tableData .= "<td>";
                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$measureView->idMeasurement','measurement') id='c" . $measureView->idMeasurement . "' checked switch='none'/>";
                $tableData .= "<label for='c" . $measureView->idMeasurement . "' data-on-label='On' data-off-label='Off'></label>";
                $tableData .= "</td>";
            } else {
                $tableData .= "<td>";
                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$measureView->idMeasurement','measurement') id='c" . $measureView->idMeasurement . "'  switch='none'/>";
                $tableData .= "<label for='c" . $measureView->idMeasurement . "' data-on-label='On' data-off-label='Off'></label>";
                $tableData .= "</td>";
            }
            $tableData .= "<td>";
            $tableData .= " <p>";
            $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light'
              data-toggle='modal' data-id='$measureView->idMeasurement' id='uMeasurementId' data-target='#updateMeasurement'>";
            $tableData .= "<i class='fa fa-edit'></i>";
            $tableData .= "</button>";
            $tableData .= " </p>";
            $tableData .= " </td>";
            $tableData .= "</tr>";
        }

        return response()->json(['success' => 'Measurement info is successfully updated', 'tableData' => $tableData]);

    }
}