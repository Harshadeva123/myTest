<?php
/**
 * Created by PhpStorm.
 * User: Thilina
 * Date: 5/4/2019
 * Time: 10:57 PM
 */

namespace App\Http\Controllers;

use App\CompanyInfo;
use Illuminate\Support\Facades\Auth;
use App\Supplier;
use Illuminate\Http\Request;
use DB;
class SupplierControllers extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('supplier.add_suppliers', ['title' => 'Add Supplier']);
    }

    public function store(Request $request)
    {

        $supComName = $request['supComName'];
        $supfName = $request['supfName'];
        $suplName = $request['suplName'];
        $supNumber1 = $request['supNumber1'];
        $supNumber2 = $request['supNumber2'];
        $supEmail = $request['supEmail'];
        $supWebsite = $request['supWebsite'];
        $supAddress1 = $request['supAddress1'];
        $supAddress2 = $request['supAddress2'];
        $supFax = $request['supFax'];
        $supCity = $request['supCity'];
        $supState = $request['supState'];
        $supZipCode = $request['supZipCode'];
        $supVAtId = $request['supVAtId'];
        $supTaxesCode = $request['supTaxesCode'];
        $supCrdtLmt =  round(floatval($request['supCrdtLmt']),2);
        $supBalance= round(floatval($request['supBalance']),2);

        $validator = \Validator::make($request->all(), [
            'supComName' => 'required',
            'supfName' => 'required||regex:/^[a-zA-Z ]+$/u|max:255',
            'suplName' => 'required||regex:/^[a-zA-Z ]+$/u|max:255'
        ], [
            'supComName.required' => 'Company name should be provided!',
            'supfName.required' => 'Supplier First Name should be provided!',
            'supfName.regex' => 'Supplier First Name Format Is Invalid!',
            'supfName.max' => 'Supplier First Name May Not Be Greater Than 255!',

            'suplName.required' => 'Supplier Last Name should be provided!',
            'suplName.max' => 'Supplier Last Name May Not Be Greater Than 255!',
            'suplName.regex' => 'Supplier Last Name should be provided!'

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        $isExist =  Supplier::where('Company',Auth::user()->Company)->where('companyName',$supComName)->first();

        if ($isExist != null) {
            return response()->json(['errors' => ['error'=>'Supplier already exists!']]);
        }
        else {
            $Sup = new Supplier();
            $Sup->companyName = strtoupper($supComName);
            $Sup->fname = strtoupper($supfName);
            $Sup->lname = strtoupper($suplName);
            $Sup->contactNo1 = $supNumber1;
            $Sup->contactNo2 = $supNumber2;
            $Sup->email = $supEmail;
            $Sup->website = $supWebsite;
            $Sup->fax = $supFax;
            $Sup->address_line_1 = $supAddress1;
            $Sup->address_line_2 = $supAddress2;
            $Sup->city = $supCity;
            $Sup->State = $supState;
            $Sup->zipCode = $supZipCode;
            $Sup->vatId = $supVAtId;
            $Sup->taxCode = $supTaxesCode;
            $Sup->creditLimit = $supCrdtLmt;
            $Sup->UserMaster_idUser = Auth::user()->idUser;
            $Sup->status = '1';
            $Sup->isPublic = '1';
            $Sup->Company = Auth::user()->Company;
            $Sup->balance=$supBalance;
            $Sup->save();
            return response()->json(['success' => 'Supplier details successfully updated']);
        }
    }

    public function search(Request $request)
    {
        $keyword = $request['search'];
        $query = Supplier::query();
        if($keyword != null){
            $query = $query->where(function ($query) use($keyword){
                $query->where('companyName','LIKE',"%$keyword%")->where('Company',Auth::user()->Company);
            })->orWhere(function ($query)  use($keyword){
                $query->where('fname','LIKE',"%$keyword%")->where('Company',Auth::user()->Company);
            })->orWhere(function ($query)  use($keyword){
                $query->where('lname','LIKE',"%$keyword%")->where('Company',Auth::user()->Company);
            });
        }
        $viewAllSuppliers =  $query->paginate(10);
        $viewAllSuppliers->appends(array('search' => $request['search'],));

        return view('supplier.view_suppliers', ['title' => 'View Suppliers', 'viewAllSuppliers' => $viewAllSuppliers]);
    }

    public function getByID(Request $request)
    {
        $supplierId = $request['supplierId'];
        $supplier = Supplier::find(intval($supplierId));
        return response()->json($supplier);
    }

    public function update(Request $request)
    {
        $hiddenSID = $request['hiddenSID'];
        $usCompany = $request['usCompany'];
        $usfName = $request['usfName'];
        $uslName = $request['uslName'];
        $usNumber1 = $request['usNumber1'];
        $usNumber2 = $request['usNumber2'];
        $usEmail = $request['usEmail'];
        $usWeb = $request['usWeb'];
        $usFax = $request['usFax'];
        $usAddress = $request['usAddress'];
        $usAddress2 = $request['usAddress2'];
        $usCity = $request['usCity'];
        $usState = $request['usState'];
        $usZipCode = $request['usZipCode'];
        $usVatId = $request['usVatId'];
        $usTaxCode = $request['usTaxCode'];
        $usCredit = round(floatval($request['usCredit']),2);
        $usBalance=round(floatval($request['usBalance']),2);

        $validator = \Validator::make($request->all(), [
            'usCompany' => 'required',
            'usfName' => 'required|max:255',
            'uslName' => 'required|max:255',

        ], [
            'usCompany.required' => 'Company should be provided!',
            'usfName.required' => 'Supplier First Name should be provided!',
            'usfName.max' => 'Supplier First Name May Not Be Greater Than 255!',

            'uslName.required' => 'Supplier Last Name should be provided!',
            'uslName.max' => 'Supplier Last Name May Not Be Greater Than 255!',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        $isExist =  Supplier::where('idSupplier','!=',$hiddenSID)->where('Company',Auth::user()->Company)->where('companyName',$usCompany)->first();

        if ($isExist != null) {
            return response()->json(['errors' => ['error'=>'Supplier already exists!']]);
        }
        else {

            $usupplier = Supplier::find(intval($hiddenSID));
            $usupplier->companyName = strtoupper($usCompany);
            $usupplier->fname = strtoupper($usfName);
            $usupplier->lname = strtoupper($uslName);
            $usupplier->contactNo1 = $usNumber1;
            $usupplier->contactNo2 = $usNumber2;
            $usupplier->email = $usEmail;
            $usupplier->website = $usWeb;
            $usupplier->fax = $usFax;
            $usupplier->address_line_1 = $usAddress;
            $usupplier->address_line_2 = $usAddress2;
            $usupplier->city = $usCity;
            $usupplier->state = $usState;
            $usupplier->zipCode = $usZipCode;
            $usupplier->vatId = $usVatId;
            $usupplier->taxCode = $usTaxCode;
            $usupplier->creditLimit = doubleval($usCredit);
            $usupplier->balance=$usBalance;
            $usupplier->update();


            $suppliers = Supplier::where('Company',Auth::user()->Company)->orderBy('created_at', 'desc')->paginate(10);
            $tableData = '';
            if($suppliers != null) {
                foreach ($suppliers as $supplier) {
                    $tableData .= "<tr>";
                    $tableData .= "<td>" . $supplier->companyName . "</td>";
                    $tableData .= "<td>" . $supplier->title . ' ' . $supplier->fname . " " . $supplier->lname . "</td>";
                    $tableData .= "<td>" . $supplier->contactNo1 . "</td>";
                    $tableData .= "<td>" . $supplier->address_line_1 . '' . $supplier->address_line_2 . ',' . $supplier->city . "</td>";
                    $tableData .= "<td>" . $supplier->User->fName. "</td>";
                    $tableData .= "<td>" . $supplier->created_at . "</td>";
                    $tableData .= "<td>" . $supplier->updated_at . "</td>";
                    if ($supplier->status == 1) {

                        $tableData .= "<td>";
                        $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$supplier->idSupplier','supplier') id='c" . $supplier->idSupplier . "' checked switch='none'/>";
                        $tableData .= "<label for='c" . $supplier->idSupplier . "' data-on-label='On' data-off-label='Off'></label>";
                        $tableData .= "</td>";
                    } else {
                        $tableData .= "<td>";
                        $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$supplier->idSupplier','supplier') id='c" . $supplier->idSupplier . "'  switch='none'/>";
                        $tableData .= "<label for='c" . $supplier->idSupplier . "' data-on-label='On' data-off-label='Off'></label>";
                        $tableData .= "</td>";
                    }

                    $tableData .= "<td>";
                    $tableData .= "<div class='dropdown'>";
                    $tableData .= "<button class='btn btn-secondary btn-md dropdown-toggle'  type='button' id='dropdownMenuButton'  data-toggle='dropdown' aria-haspopup='true'  aria-expanded='false'>Option  </button>";
                    $tableData .= " <div class='dropdown-menu'   aria-labelledby='dropdownMenuButton'>";
                    $tableData .= " <a class='dropdown-item' href = '#'  data-toggle= 'modal' data-id ='$supplier->idSupplier'  id = 'updateSupplier'   data-target = '#supplierUpdate' >Update</a >";

                    $tableData .= "<a class='dropdown-item' href = '#' data-toggle = 'modal' data-id = '$supplier->idSupplier'  id = 'supplierView' data-target = '#viewSupplier' >View</a >";
                    $tableData .= "  </div >";
                    $tableData .= "</td >";
                }
            }
            else{
                $tableData = "<tr><td>No orders yet.</td></tr>";
            }
            return response()->json(['tableData' => $tableData, 'success' => 'Supplier info is successfully updated']);

        }
    }

    public function changeStatus(Request $request){
        $id = $request['id'];
        $supplier = Supplier::find($id);
        if ($supplier->status == 1) {
            $supplier->status = 0;
        } else {
            $supplier->status = 1;
        }
        $supplier->save();
    }


    public function viewTableData(Request $request){

        $supplierId = $request['supplierId'];
        $getSupplier = Supplier::find(intval($supplierId));
        $tableData = "";
        $tableData .= "<tr><td colspan='2' width='100%'><h6>Company Information</h6></td></tr>";
        $tableData .= "<tr><td width='40%'>Company Name</td><td width='60%'> : ".$getSupplier->companyName ."</td></tr>";
        $tableData .= "<tr><td width='40%'>Contact Person Name</td><td width='60%'> : ".$getSupplier->fname." ".$getSupplier->lname ."</td></tr>";
        $tableData .= "<tr><td colspan='2' width='100%'><h6>Contact Information</h6></td></tr>";
        $tableData .= "<tr><td width='40%'>Contact No 1</td><td width='60%'> : <a href='tel:$getSupplier->contactNo1'>".$getSupplier->contactNo1."</a></td></tr>";
        $tableData .= "<tr><td width='40%'>Contact No 2</td><td width='60%'> : <a href='tel:$getSupplier->contactNo2'>".$getSupplier->contactNo2."</a></td></tr>";
        $tableData .= "<tr><td width='40%'>Email</td><td width='60%'> : <a href='mailto:$getSupplier->email'>".$getSupplier->email."</a></td></tr>";
        $tableData .= "<tr><td width='40%'>Fax</td><td width='60%'> : ".$getSupplier->fax."</td></tr>";
        $tableData .= "<tr><td width='40%'>Website</td><td width='60%'> : <a target='_blank' href='$getSupplier->website'>".$getSupplier->website."</a></td></tr>";
        $tableData .= "<tr><td width='40%'>Address</td><td width='60%'> : ".$getSupplier->address_line_1.",".$getSupplier->address_line_2 ."</td></tr>";
        $tableData .= "<tr><td width='40%'>City</td><td width='60%'> : ".$getSupplier->city."</td></tr>";
        $tableData .= "<tr><td width='40%'>State</td><td width='60%'> : ".$getSupplier->state."</td></tr>";
        $tableData .= "<tr><td width='40%'>Zip Code/Postal Code</td><td width='60%'> : ".$getSupplier->zipCode."</td></tr>";
        $tableData .= "<tr><td colspan='2' width='100%'><h6>Tax Information</h6></td></tr>";
        $tableData .= "<tr><td width='40%'>VAT ID</td><td width='60%'> :".$getSupplier->vatId."</td></tr>";
        $tableData .= "<tr><td width='40%'>TAX Code</td><td width='60%'> :".$getSupplier->taxCode."</td></tr>";
        $tableData .= "<tr><td width='40%'>Credit Limit</td><td width='60%'> :".$getSupplier->creditLimit."</td></tr>";
        $tableData .= "<tr><td width='40%'>Balance</td><td width='60%'> :".$getSupplier->balance."</td></tr>";
        $tableData .= "<tr><td colspan='2' width='100%'><h6>System Generated Data</h6></td></tr>";
        $tableData .= "<tr><td width='40%'>Created/Updated By</td><td width='60%'>: ".$getSupplier->User->fName."</td></tr>";
        $tableData .= "<tr><td width='40%'>Created At</td><td width='60%'> : ".$getSupplier->created_at."</td></tr>";
        $tableData .= "<tr><td width='40%'>Last Updated</td><td width='60%'> : ".$getSupplier->updated_at."</td></tr>";




        return response()->json(['tableData'=>$tableData]);
    }
}