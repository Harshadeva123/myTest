<?php
///**
// * Created by PhpStorm.
// * User: ishar
// * Date: 3/10/2019
// * Time: 11:14 AM
// */
//
//namespace App\Http\Controllers;
//
//use App\Package;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\DB;
//
//
//class PackageController extends Controller
//{
//
//    public function __construct()
//    {
//        $this->middleware('auth');
//    }
//
//
//
//    public function searchPackage(Request $request)
//    {
//        $paginate = 10;
//        $keyword = $request['search'];
//        $column = '';
//
//        $package = Package::Where('status', 1)->orderBy('created_at', 'desc')->where('packageName' . $column . '', 'LIKE',
//            "%$keyword%")
//            ->orwhere('rate' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orderBy('idPackage', 'DESC')->paginate($paginate);
//        $package->appends(array('search' => $request['search'],
//        ));
//        return
//            view('add_package', ['title' => 'Packages Management', 'packages' => $package]);
//    }
//
//
//    public
//    function savePackage(Request $request)
//    {
//        $pName = $request['pName'];
//        $rate = $request['rate'];
//
//        $validator = \Validator::make($request->all(), [
//            'pName' => 'required',
//            'rate' => 'required',
//        ], [
//            'pName.required' => 'Package Name should be provided!',
//            'rate.required' => 'Rate should be provided!',
//
//        ]);
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $pNameExist = Package::where('packageName', strtoupper($pName))->first();
//        if ($pNameExist == null) {
//            $package = new Package();
//            $package->packageName = strtoupper($pName);
//            $package->rate = $rate;
//            $package->status = '1';
//            $package->save();
//
//            $packages = Package::orderBy('created_at', 'desc')->paginate(10);
//            $tableData = '';
//
//            foreach ($packages as $package) {
//                $tableData .= "<tr>";
//                $tableData .= "<td>" . $package->packageName . "</td>";
//                $tableData .= "<td>" . $package->rate . "</td>";
//                if ($package->status == 1) {
//
//                    $tableData .= "<td>";
//                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$$package->idPackage','package') id='c" . $package->idPackage . "' checked switch='none'/>";
//                    $tableData .= "<label for='c" . $package->idPackage . "' data-on-label='On' data-off-label='Off'></label>";
//                    $tableData .= "</td>";
//                } else {
//                    $tableData .= "<td>";
//                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$package->idPackage','package') id='c" . $package->idPackage . "'  switch='none'/>";
//                    $tableData .= "<label for='c" . $package->idPackage . "' data-on-label='On' data-off-label='Off'></label>";
//                    $tableData .= "</td>";
//                    $tableData .= "</tr>";
//                }
//                $tableData .= "<td>";
//                $tableData .= " <p>";
//                $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light' data-type='$package->rate'
//               data-name='$package->packageName' data-toggle='modal' data-id='$package->idPackage' id='packageUpdate' data-target='#updateModalPackage'>";
//                $tableData .= "<i class='fa fa-edit'></i>";
//                $tableData .= "</button>";
//                $tableData .= "</p>";
//                $tableData .= "</td>";
//                $tableData .= "</tr>";
//            }
//            return response()->json(['tableData' => $tableData, 'success' => 'Package Added successfully Save']);
//        } else {
//            return response()->json(['errors' => ['error' => 'Package Name Already In Database']]);
//        }
//    }
//
//    public
//    function getPackageId(Request $request)
//    {
//        $packageId = $request['packageId'];
//        $package = Package::find(intval($packageId));
//
//        return response()->json($package);
//    }
//
//    public
//    function updatePackage(Request $request)
//    {
//        $hiddenUPID = $request['hiddenUPID'];
//        $uPName = $request['uPName'];
//        $uRate = $request['uRate'];
//
//        $validator = \Validator::make($request->all(), [
//
//            'uPName' => 'required',
//            'uRate' => 'required',
//
//        ], [
//            'uPName.required' => 'Package Name should be provided!',
//            'uRate.required' => 'Package Rate should be provided!',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//
//        $uPackage = Package::find(intval($hiddenUPID));
//        $uPackage->packageName = strtoupper($uPName);
//        $uPackage->rate = $uRate;
//        $uPackage->status = '1';
//        $uPackage->update();
//        $uPackages = Package::orderBy('created_at', 'desc')->paginate(10);
//        $tableData = '';
//
//        foreach ($uPackages as $uPackage) {
//            $tableData .= "<tr>";
//            $tableData .= "<td>" . $uPackage->packageName . "</td>";
//            $tableData .= "<td>" . $uPackage->rate . "</td>";
//            if ($uPackage->status == 1) {
//
//                $tableData .= "<td>";
//                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$uPackage->idPackage','package') id='c" . $uPackage->idPackage . "' checked switch='none'/>";
//                $tableData .= "<label for='c" . $uPackage->idPackage . "' data-on-label='On' data-off-label='Off'></label>";
//                $tableData .= "</td>";
//            } else {
//                $tableData .= "<td>";
//                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$uPackage->idPackage','package') id='c" . $uPackage->idPackage . "'  switch='none'/>";
//                $tableData .= "<label for='c" . $uPackage->idPackage . "' data-on-label='On' data-off-label='Off'></label>";
//                $tableData .= "</td>";
//                $tableData .= "</tr>";
//            }
//            $tableData .= "<td>";
//            $tableData .= " <p>";
//            $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light' data-type='$uPackage->rate'
//               data-name='$uPackage->packageName' data-toggle='modal' data-id='$uPackage->idPackage' id='packageUpdate' data-target='#updateModalPackage'>";
//            $tableData .= "<i class='fa fa-edit'></i>";
//            $tableData .= "</button>";
//            $tableData .= "</p>";
//            $tableData .= "</td>";
//        }
//        return response()->json(['tableData' => $tableData, 'success' => 'Package Added Successfully!']);
//    }
//
//}
