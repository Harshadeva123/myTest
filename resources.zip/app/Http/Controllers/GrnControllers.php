<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/6/2019
 * Time: 4:03 PM
 */

namespace App\Http\Controllers;


use App\BankMeta;
use App\BankPayments;
use App\BankPaymentsTemp;
use App\ChequePayments;
use App\ChequePaymentTemp;
use App\CompanyInfo;
use App\CompanyPaymentType;
use App\GRN;
use App\GrnItemsTemp;
use App\Item;
use App\ItemIssueList;
use App\ItemIssueTemp;
use App\Measurement;
use App\Payment;
use App\PaymentRefference;
use App\PaymentType;
use App\ProductionIssue;
use App\Section;
use App\Stock;
use App\Store;
use App\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class GrnControllers extends Controller
{
    //add GRN functions
    public function index(Request $request)
    {
        $suppliers = Supplier::where('status', '1')->where('Company', intval(Auth::user()->Company))->get();
        $stockTypes = Store::where('status',1)->where('Company',Auth::user()->Company)->get();
        $items = Item::where('status', 1)->where('Company', intval(Auth::user()->Company))->get();
        $measurements = Measurement::where('status', 1)->where('Company', intval(Auth::user()->Company))->get();
        $payments = CompanyPaymentType::where('status',1)->where('Company', intval(Auth::user()->Company))->where('grn',1)->get();
        return view('grn.add_grn', ['payments'=>$payments,'measurements' => $measurements, 'items' => $items, 'stockTypes' => $stockTypes,'allSuppliers'=>$suppliers, 'title' => 'Add GRN']);
    }

    public function getTempTableData(){
        $grnValues = GrnItemsTemp::where('UserMaster_idUser',Auth::user()->idUser)->where('status',1)->orderBy('created_at', 'desc')->get();
        $tableData = '';
        $po = null;
        if(count($grnValues)>0) {
            foreach ($grnValues as $grnValue) {
                if($grnValue->po_no != null){
                    $po = $grnValue->po_no;
                }
                $tableData .= "<tr>";
                $tableData .= "<td>" . $grnValue->Item->itemName . "</td>";
                $tableData .= "<td>" . $grnValue->qty_grn .' ' . $grnValue->item->measurement->mian . "</td>";
                $tableData .= "<td>" . str_pad($grnValue->po_no,5,'0',STR_PAD_LEFT) . "</td>";
                $tableData .= "<td>" . $grnValue->Store->type . "</td>";
                $tableData .= "<td style='text-align: right' class='bp'>
                                    <input type='hidden' class='doNotClear hidBprice' value=" . $grnValue->bp*$grnValue->qty_grn . ">
                                    " . number_format($grnValue->bp, 2) . "</td>";
                $tableData .= "<td style='text-align: right;'>" .  number_format($grnValue->bp*$grnValue->qty_grn, 2) . "</td>";
                $tableData .= "<td>";
                $tableData .= " <div class='button-items'>
                                    <button type='button'
                                            class='btn btn-sm btn-warning  waves-effect waves-light'
                                            data-id=" . $grnValue->idGRn_Temp . "
                                          onclick='showUpdateModal(this)'><i
                                                class='fa fa-edit'></i></button>";
                $tableData .= "<button type='button' 
                            class='btn btn-sm btn-danger  waves-effect waves-light'
                                            data-id=" . $grnValue->idGRn_Temp . "
                                          onclick='deleteRecord($grnValue->idGRn_Temp)'><i
                                                class='fa fa-trash'></i></button>";

                $tableData .= "  </div>";
            }
        }
        else{
            $tableData .= " <tr>
                                <td colspan='8' style='text-align: center;font-weight: 500'>Sorry No Results Found.
                                </td>
                            </tr>";
        }
        return response()->json(['tableData' => $tableData,'po'=>$po]);
    }

    public function addItem(Request $request)
    {
        $item = $request['item'];
        $binNo = $request['binNo'];
        $mFDate = $request['mFDate'];
        $bPrice = $request['bPrice'];
        $eDate = $request['eDate'];
        $qtyGrn = $request['qtyGrn'];
        $stock = $request['sType'];

        $validator = \Validator::make($request->all(), [
            'item' => 'required',
            'qtyGrn' => 'required|not_in:0',
            'bPrice' => 'required|not_in:0',
            'sType' => 'required'
        ], [
            'item.required' => 'Item should be provided!',
            'qtyGrn.required' => 'Qty should be provided!',
            'qtyGrn.not_in' => 'Qty should be grater than zero (0)',
            'bPrice.required' => 'Buying Price should be provided!',
            'bPrice.not_in' => 'Buying Price should be grater than zero (0)',
            'sType.required' => 'Store should be provided!',
        ]);


        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        if(date('Y', strtotime($mFDate))<2000){
            $mnfDate = null;
            return response()->json(['errors' =>['error'=>'Manufacture Date should be provided!']]);
        }
        else{
            $mnfDate = date('Y-m-d', strtotime($mFDate));
        };
        if(date('Y', strtotime($eDate))<2000){
            $expDate = null;
        }
        else{
            $expDate = date('Y-m-d', strtotime($eDate));
        };
        $exist = GrnItemsTemp::where('UserMaster_idUser',Auth::user()->idUser)->where('status',1)->where('mnfDate',$mnfDate)->where('expDate',$expDate)

            ->where('bp',$bPrice)->where('Items_idItems',$item)->where('store',$stock)->first();
        if($exist != null){
            $exist->qty_grn += $qtyGrn;
            $exist->save();
        }
        else {
            $grn = new GrnItemsTemp();
            $grn->store = $stock;
            $grn->po_no = null;
            $grn->Items_idItems = $item;
            $grn->qty_grn = $qtyGrn;
            $grn->binNo = $binNo;
            $grn->bp = $bPrice;

            $grn->expDate = $expDate;
            if ($eDate == null) {
                $grn->expHave = '0';
            } else {
                $grn->expHave = '1';
            }
            $grn->mnfDate = $mnfDate;

            $grn->status = 1;
            $grn->UserMaster_idUser = Auth::user()->idUser;
            $grn->save();
        }

        return response()->json([ 'success' => 'Item has been added']);

    }

    public function updateTempTable(Request $request){

        $validator = \Validator::make($request->all(), [
            'Uitem' => 'required',
            'UsType' => 'required',
            'UqtyGrn' => 'required|not_in:0',
            'UmFDate' => 'required',
            'UbPrice' => 'required|not_in:0',

        ], [
            'UsType.required' => 'Stock Type should be provided!',
            'UqtyGrn.required' => 'Qty should be provided!',
            'UqtyGrn.not_in' => 'Qty should be grater than zero (0)',
            'Uitem.purchaseOrderNo.required' => 'Item should be provided!',
            'UmFDate.required' => 'Manufacture Date should be provided!',
            'UbPrice.required' => 'Buying Price should be provided!',
            'UbPrice.not_in' => 'Buying Price should be grater than zero (0)',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $id = $request['id'];
        $temp = GrnItemsTemp::find($id);
        $temp->store = $request['UsType'];
        $temp->Items_idItems = $request['Uitem'];
        $temp->qty_grn = $request['UqtyGrn'];
        $temp->binNo = $request['UbinNo'];
        $temp->expDate = date('Y-m-d', strtotime($request['expDate']));
        if($request['expDate'] != null){
            $temp->expHave = $request['expHave'];

        }else{
            $temp->expHave = 0;
        }
        $temp->mnfDate = date('Y-m-d', strtotime($request['UmFDate']));
        $temp->bp = $request['UbPrice'];
        $temp->UserMaster_idUser = Auth::user()->idUser;
        $temp->save();
        return response()->json(['success' => "Item updated successfully."]);
    }

    public function getTempTableTotal(){
        $temps =  GrnItemsTemp::where('UserMaster_idUser',Auth::user()->idUser)->where('status',1)->get();
        $total = 0;
        foreach ($temps as $temp){
            $total += round($temp->bp * $temp->qty_grn,2);
        }
        return $total;
    }

    public function getTempById(Request $request){
        $id = $request['id'];
        $grn = GrnItemsTemp::find(intval($id));
        return $grn;
    }

    public function clearTempTable(){
        GrnItemsTemp::where('UserMaster_idUser',Auth::user()->idUser)->where('status',1)->delete();
    }

    public function save(Request $request)
    {
        $uPurchaseOrderNo = $request['uPurchaseOrderNo'];
        $uInvoiceNo = $request['uInvoiceNo'];
        $uDiscount = round($request['uDiscount'],2);
        $uSupplier = $request['uSupplier'];
        $paymentType = $request['uPaymentType'];
        $uDate = date('Y-m-d', strtotime($request['uDate']));
        $hiddenGrnID = $request['hiddenGrnID'];
        $company = Auth::user()->Company;
        $paid = round($request['paid'],2);
        $visaBill = $request['visaBill'];
        $cardAmount = round($request['cardAmount'],2);
        $bankId = $request['bankId'];
        $chequeBankName = $request['chequeBankName'];
        $chequeDate = $request['chequeDate'];
        $chequeNo = $request['chequeNo'];

        //Start Validations
        $validator = \Validator::make($request->all(), [
            'uTotal' => 'required',
            'uNetTotal' => 'required',
            'uPaymentType' => 'required',
            'uDate' => 'required',
            'uSupplier' => 'required'
        ], [
            'uTotal.required' => 'Total Price should be provided!',
            'uNetTotal.required' => 'Net Total Price should be provided!',
            'uPaymentType.required' => 'Payment Type should be provided!',
            'uDate.required' => 'Date should be provided!',
            'uSupplier.required' => 'Supplier should be provided!'
        ]);
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $uTotal = 0;
        $paidTotal = 0;
        $GrnItemsTemps = GrnItemsTemp::where('status',1)->where('UserMaster_idUser',Auth::user()->idUser)->get();
        if($GrnItemsTemps == null || count($GrnItemsTemps) <= 0) {
            return response()->json(['errors' => ['error' => 'No item to save!']]);
        }
        else {

            foreach ($GrnItemsTemps as $grnItemsTemp) {
                $uTotal += round($grnItemsTemp->bp *( $grnItemsTemp->qty_grn - $grnItemsTemp->qty_free ), 2);
            }
            $netTotal = round(floatval($uTotal) - floatval($uDiscount), 2);

            if ($paymentType == 1 || $paymentType == 2) {

                if ($paymentType == 1) {
                    if ($paid == null) {
                        return response()->json(['errors' => ['error' => 'Paid amount should be provided.']]);
                    }
                    if ($paid < $netTotal) {
                        return response()->json(['errors' => ['error' => 'Paid amount is lower than net total.Please change payment type to add half payment.']]);
                    }

                    $paidTotal = $netTotal;
                }
                else{
                    if ($paid == null) {
                        $paidTotal = 0;

                    }
                    else{
                        $paidTotal = $paid;

                    }
                }

            } else if ($paymentType == 3) {
                if ($visaBill == null) {
                    return response()->json(['errors' => ['error' => 'Card no should be provided.']]);
                }
                $paidTotal = $netTotal;
            } else if ($paymentType == 4) {
                if ($bankId == null) {
                    return response()->json(['errors' => ['error' => 'Bank name should be provided.']]);
                }
                $bankAmount = round(BankPaymentsTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->sum('amount'), 2);
                if ($netTotal > $bankAmount) {
                    return response()->json(['errors' => ['error' => 'Total bank amount is lower than net total.Please change payment type to add credits.']]);
                }
                $paidTotal = $bankAmount;
            } else if ($paymentType == 5) {
                if ($chequeBankName == null) {
                    return response()->json(['errors' => ['error' => 'Bank name should be provided.']]);
                }
                if ($chequeDate == null) {
                    return response()->json(['errors' => ['error' => 'Cheque date should be provided.']]);
                }
                if ($chequeNo == null) {
                    return response()->json(['errors' => ['error' => 'Cheque no should be provided.']]);
                }
                $chequeAmount = round(ChequePaymentTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->sum('amount'), 2);
                if ($netTotal > $chequeAmount) {
                    return response()->json(['errors' => ['error' => 'Total cheque amount is lower than net total.Please change payment type to add credits.']]);
                }
                $paidTotal = $chequeAmount;
            }else if ($paymentType == 11) {
                if ($paid != null) {
                    $paidTotal += $paid;
                }
                if ($cardAmount != null) {
                    $paidTotal += $cardAmount;
                }
                $banks = BankPaymentsTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->get();
                if ($banks != null) {
                    $paidTotal += round($banks->sum('amount'),2);
                }
                $cheque = ChequePaymentTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->get();
                if ($cheque != null) {
                    $paidTotal += round($cheque->sum('amount'),2);
                }
            }
            else{
                return response()->json(['errors' => ['error' => 'Payment type unknown!']]);
            }
        }

        if ($paidTotal > $netTotal) {
            return response()->json(['errors' => ['error' => 'Paid total is grater than net amount.']]);
        }

        //End Validations

        if($hiddenGrnID != null){
            $grn = GRN::find(intval($hiddenGrnID));
        }
        else{
            $grn = new GRN();
        }

        $grnNos = GRN::select('grnNo')->where('Company',$company)->get();
        if($grnNos != null){
            $maxNo = intval($grnNos->max('grnNo'))+1;
        }
        else{
            $maxNo = 1;
        }
        $grn->grnNo = $maxNo;
        $grn->Company = $company;
        $grn->Supplier_idSupplier = $uSupplier;
        $grn->poNo = $uPurchaseOrderNo;
        $grn->invNo = $uInvoiceNo;
        $grn->total = $uTotal;
        $grn->discount = $uDiscount;
        $grn->net_total = $netTotal;
        $grn->paymentType = $paymentType;
        if ($paymentType == 2) {
            $grn->paidDue = $paid;
            $grn->due = round($netTotal - $paid,2);
        }
        else{
            $grn->paidDue = $netTotal;
            $grn->due = 0;
        }
        $grn->date = $uDate;
        $grn->status = '1';
        $grn->UserMaster_idUser = Auth::user()->idUser;
        $grn->save();

        foreach ($GrnItemsTemps as $GrnItemsTemp) {
            $stock = new Stock();
            $stock->store = $GrnItemsTemp->store;
            $stock->base = 1;
            $stock->GRN_id_or_Production_id = $grn->idGRN;
            $stock->Company = $company;
            $stock->Items_idItems = $GrnItemsTemp->Items_idItems;
            $stock->qty_grn = $GrnItemsTemp->qty_grn;
            $stock->qty_available = $GrnItemsTemp->qty_grn;
            $stock->qty_inv_return = 0;
            $stock->qty_grn_return = 0;
            $stock->binNo = $GrnItemsTemp->binNo;
            $stock->expDate = $GrnItemsTemp->expDate;
            $stock->expHave = $GrnItemsTemp->expHave;
            $stock->mnfDate = $GrnItemsTemp->mnfDate;
            $stock->bp = $GrnItemsTemp->bp;
            $stock->wp = $GrnItemsTemp->wp;
            $stock->sp = $GrnItemsTemp->sp;
            $stock->status = 1;
            $stock->save();
            $GrnItemsTemp->delete();
        }

        $payment = new Payment();
        $payment->System_Company = $company;
        $payment->PaymentToType = 2;
        $payment->paymentToRefNo = 0;
        $payment->base = 2;
        $payment->id = $grn->idGRN;
        $payment->totalAmount = $netTotal;
        $payment->payment_type_idpayment_type = $paymentType;

        if ($paymentType == 1) {
            $payment->cash = $netTotal;
        }
        else if ($paymentType == 2) {
            $payment->cash = $paid;
            $payment->credit = round(floatval($netTotal) - floatval($paid),2);
        }
        else if ($paymentType == 4) {
            $payment->bank = $netTotal;
        }
        else if ($paymentType == 3) {
            $payment->visa = $netTotal;
            $payment->visaBillNo = $visaBill;
        }
        else if ($paymentType == 5) {
            $payment->cheque = $netTotal;
        }
        else if ($paymentType == 11) {
            if ($paid != null) {
                $payment->cash = $paid;
            }
            if ($cardAmount != null) {
                $payment->visa = $cardAmount;
                $payment->visaBillNo = $visaBill;
            }
            $banks = BankPaymentsTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->get();
            if ($banks != null) {
                $payment->bank = round($banks->sum('amount'),2);
            }
            $cheque = ChequePaymentTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->get();
            if ($cheque != null) {
                $payment->cheque = round($cheque->sum('amount'),2);
            }
            if($netTotal - $paidTotal > 0){
                $payment->credit = round($netTotal - $paidTotal,2);
            }
        }

        $payment->free = null;
        $payment->voucher = null;
        $payment->voucher_no = null;
        $payment->loyalty_point = null;
        $payment->online_pay = null;
        $payment->isBulk = 0;
        $payment->status = 1;
        $payment->usermaster_idUser = Auth::user()->idUser;
        $payment->save();

        $reference = new PaymentRefference();
        $reference->payment_idpayment = $payment->idpayment;
        $reference->base = 2;
        $reference->Company = $company;
        $reference->ref_no = $grn->idGRN;
        $reference->amount = $paidTotal;
        $reference->status = 1;
        $reference->save();



        if ($paymentType == 4) {
            $records = BankPaymentsTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->get();
            foreach ($records as $record) {
                $bank = new BankPayments();
                $bank->Company = $company;
                $bank->payment_idpayment = $payment->idpayment;
                $bank->bank_idbank = $record->bank_idbank;
                $bank->bank_account = $record->bank_account;
                $bank->amount = $record->amount;
                $bank->status = 1;
                $bank->save();
                $record->delete();
            }

        }
        if ($paymentType == 5) {
            $records = ChequePaymentTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->get();
            foreach ($records as $record) {
                $bank = new ChequePayments();
                $bank->Company = $company;
                $bank->payment_idpayment = $payment->idpayment;
                $bank->bank_idbank = $record->bank_idbank;
                $bank->chequeNo = $record->chequeNo;
                $bank->chequeDate = $record->chequeDate;
                $bank->amount = $record->amount;
                $bank->bank_account = $record->bank_account;
                $bank->status = 1;
                $bank->save();
                $record->delete();
            }

        }
        if ($paymentType == 11) {
            $records = BankPaymentsTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->get();
            if ($records != null) {
                foreach ($records as $record) {
                    $bank = new BankPayments();
                    $bank->Company = $company;
                    $bank->payment_idpayment = $payment->idpayment;
                    $bank->bank_idbank = $record->bank_idbank;
                    $bank->bank_account = $record->bank_account;
                    $bank->amount = $record->amount;
                    $bank->status = 1;
                    $bank->save();
                    $record->delete();
                }
            }
            $recordsCheques = ChequePaymentTemp::where('status', 1)->where('usermaster_idUser', Auth::user()->idUser)->get();
            if ($recordsCheques != null) {

                foreach ($recordsCheques as $recordsCheque) {
                    $bank = new ChequePayments();
                    $bank->Company = $company;
                    $bank->payment_idpayment = $payment->idpayment;
                    $bank->bank_idbank = $recordsCheque->bank_idbank;
                    $bank->chequeNo = $recordsCheque->chequeNo;
                    $bank->chequeDate = $recordsCheque->chequeDate;
                    $bank->amount = $recordsCheque->amount;
                    $bank->bank_account = $recordsCheque->bank_account;
                    $bank->status = 1;
                    $bank->save();
                    $recordsCheque->delete();
                }
            }
            if ($paidTotal < $netTotal) {

                $grn->paidDue = $paidTotal;
                $grn->due = round(floatval($netTotal) - floatval($paidTotal),2);
                $grn->save();
            }
        }


        return response()->json(['success' => 'GRN successfully Saved','id'=>$grn->idGRN]);


    }

    public function getBuyingPrice(Request $request){
        $item = $request['item'];

        $item=Item::find(intval($item));
        if($item!=null){
            return $item->purchasePrice;
        }else{
            return "0";
        }


    }

    public function deleteTemp(Request $request){
        $id = $request['id'];
        GrnItemsTemp::find($id)->delete();
    }

    //View GRN functions
    public function view(Request $request)
    {

        $grnId = $request['id'];
        $idType = $request['idType'];
        $supplier = $request['supplier'];
        $endDate = $request['end'];
        $startDate = $request['start'];
        $query = GRN::query();
        if (!empty($grnId)) {
            $query = $query->where($idType,$grnId);

        }
        if (!empty($supplier)) {
            $query = $query->where('Supplier_idSupplier',$supplier);

        }
        if (!empty($startDate) && !empty($endDate)) {
            $startDate = date('Y-m-d', strtotime($request['start']));
            $endDate = date('Y-m-d', strtotime($request['end']));

            $query = $query->whereBetween('date', [$startDate, $endDate]);
        }

        $grns = $query->where('status',1)->where('Company', intval(Auth::user()->Company))->latest()->paginate(10);

        $grns->appends(array(
            'start' => $request['start'],
            'end' => $request['end'],
            'id' => $request['id'],
            'supplier' => $request['supplier'],
            'idType' => $request['idType']
        ));

        $suppliers = Supplier::where('status',1)->where('Company',Auth::user()->Company)->get();
        return view('grn.view_grn')->with(['grns'=> $grns,'title' => 'GRN History','suppliers'=>$suppliers]);

    }

    public function viewByID(Request $request)
    {
        $grnId = $request['grnId'];
        $grn = GRN::find(intval($grnId));
        return response()->json($grn);
    }

    public function viewMore(Request $request){
        $id = $request['id'];
        $grns = GRN::where('idGRN',$id)->where('status',1)->get();
        $tableData = "";
        foreach ($grns as $grn){
            $tableData .= " <tr>
                                <td width='50%'>PO No</td>
                                <td width='50%'>".$grn->poNo."</td>
                             </tr>
                             <tr>
                                <td width='50%'>Invoice No </td>
                                <td width='50%'>".$grn->invNo."</td>
                             </tr>
                             <tr>
                                <td width='50%'>Payment Type </td>
                                <td width='50%'>".$grn->payment->type."</td>
                             </tr>  
                             <tr>
                                <td width='50%'>Paid Total </td>
                                <td width='50%'>".number_format($grn->paidDue,2)."</td>
                             </tr>";
        }
        return $tableData;
    }

    public function viewStock(Request $request){
        $id = $request['id'];
        $stocks = Stock::where('GRN_id_or_Production_id',$id)->where('base',1)->get();
        $tableData = "";
        foreach ($stocks as $stock){
            if ($stock->base == 1) {
                $base  = "GRN";
            } elseif ($stock->base == 2) {
                $base  = "PRODUCTION";
            } elseif ($stock->base == 3) {
                $base  = "TRANSFER";
            } elseif ($stock->base == 4) {
                $base  = "OPENING";
            }elseif($stock->base == 5){
                $base  = "STORE CHANGE";
            }elseif($stock->base == 6){
                $base  = "ITEM ISSUE";
            }
            else {
                $base  = "UNKNOWN";
            };
            $tableData .= "<tr>
                                <td>".$stock->item->itemName."</td>
                                <td>".$stock->GRN_id_or_Production_id."</td>
                                <td>".$base."</td>
                                <td style='text-align:right;'>".$stock->qty_grn."</td>
                                <td style='text-align:right;'>".$stock->mnfDate."</td>
                                <td style='text-align:right;'>".$stock->expDate."</td>
                                <td style='text-align: right;'>".number_format($stock->bp,2)."</td>

                            </tr> ";

        }

        return $tableData;
    }




//    public function availableItemCountGRN(Request $request){
//        $item = $request['item'];
//        $company = Auth::user()->Company;
//        $count = Stock::where(function ($query) use ($company,$item){
//            $query->where('expDate','>=',date('Y-m-d'))->where('Company',$company)->where('Items_idItems',$item)->where('status',1);
//        })
//            ->orWhere(function ($query) use ($company,$item){
//                $query->where('expHave',0)->where('Company',$company)->where('Items_idItems',$item)->where('status',1);
//            })->sum('qty_available');
//
//        $rate = 0;
//        if(Item::find(intval($item)) != null) {
//            $rate = Item::find(intval($item))->unitPrice;
//        }
//        $measurement = '';
//        if(Item::find(intval($item)) != null) {
//            $measurement = Item::find($item)->measurement->mian;
//
//        }
//        return response()->json(['count' => $count,'measurement'=>$measurement,'rate'=>$rate]);
//    }





























































//    public function issueMaterials(){
//        $matirials = Item::where('status',1)->where('Item_Type',2)->get();
//        $sections = Section::where('status',1)->where('sectionName','!=','DELIVERY SECTION')->get();
//        $stores = StockType::where('status',1)->where('type','!=','DELIVERY SECTION STORE')->where('Company',Auth::user()->Company)->get();
//        return view('grn.issue_material_grn')->with(['sections'=>$sections,'stores'=>$stores,'items'=>$matirials,'title'=>'Issue Materials']);
//
//    }
//
//    public function issueMaterialsHistory(){
//        $company = Auth::user()->Company;
//        $sections = Section::where('status',1)->get();
//        $productions = ProductionIssue::where('base',1)->where('Company',$company)->where('status',1)->latest()->paginate(10);
//        return view('grn.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//    }
//
//    public function addItemIssueTempGrn(Request $request){
//        $validator = \Validator::make($request->all(), [
//            'item' => 'required',
//            'qty' => 'required|min:0|not_in:0',
//            'store' => 'required',
//        ], [
//            'item.required' => 'Item should be provided.',
//            'qty.required' => 'Qty should be provided',
//            'store.required' => 'Store should be provided',
//            'qty.min' => 'Qty must be grater than 0',
//            'qty.not_in' => 'Qty must be grater than 0',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $item  = $request['item'];
//        $qty  = $request['qty'];
//        $store  = $request['store'];
//
//        $isExist = ItemIssueTemp::where('base',1)->where('items_idItems',$item)->where('stock_type_idStock_Type',$store)->where('usermaster_idUser',Auth::user()->idUser)->where('status',1)->first();
//        if($isExist != null){
//            $isExist->qty += $qty;
//            $isExist->save();
//            return response()->json(['success' => 'Material qty updated.']);
//        }
//        else {
//            $temp = new ItemIssueTemp();
//            $temp->qty = $qty;
//            $temp->base = 1;
//            $temp->items_idItems = $item;
//            $temp->stock_type_idStock_Type = $store;
//            $temp->status = 1;
//            $temp->usermaster_idUser = Auth::user()->idUser;
//            $temp->save();
//            return response()->json(['success' => 'Material added to list.']);
//        }
//    }
//
//    public function getItemIssueTempGrn(){
//        $temps = ItemIssueTemp::where('base',1)->where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        $tableData = "";
//        if(!empty($temps)) {
//            foreach ($temps as $temp) {
//                $tableData .= "<tr id=" . $temp->item_issue_temp_id . ">
//                                <td>
//                                " . $temp->item->itemName . "
//                                </td>
//                                <td>
//                                " . $temp->store->type . "
//                                </td>
//                                 <td>
//                                " . $temp->qty . "
//                                </td>
//                                <td style='text-align: center'>
//                                <div class='button-items'>
//                                    <button type='button'
//                                            class='btn btn-sm btn-danger  waves-effect waves-light'
//                                            data-id='" . $temp->item_issue_temp_id . "'
//                                            onclick='deleteTempIssue(this)'>
//                                            <i class='fa fa-trash'></i>
//                                     </button>
//
//                                </div>
//                                </td>
//                            </tr>";
//            }
//        }
//        return $tableData;
//    }
//
//    public function saveItemIssuedGrn(Request $request){
//        $section = $request['section'];
//        $validator = \Validator::make($request->all(), [
//            'section' => 'required',
//        ], [
//            'section.required' => 'Section should be provided',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//        $deliveryId = StockType::where('type','DELIVERY SECTION STORE')->first()->idStock_Type;
//
//        $company = Auth::user()->Company;
//        $user = Auth::user()->idUser;
//        $pass = true;
//        $temps = ItemIssueTemp::where('base',1)->where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        if($temps == null || empty($temps) || count($temps)==0){
//            $pass = false;
//            return response()->json(['errors' => ['error' => 'No items available.']]);
//        }
//        else{
//            foreach ($temps as $temp) {
//                $available = Stock::where('Company', $company)->where('status', 1)->where('Stock_Type',$temp->stock_type_idStock_Type)->where('Items_idItems', $temp->items_idItems)->sum('qty_available');
//
//                if (floatval($temp->qty) > floatval($available)) {
//                    $pass = false;
//                    return response()->json(['errors' => ['error' => 'Available \''.$temp->item->itemName.'\' quantity in  \''.$temp->store->type.'\' is lower than requested quantity.']]);
//                }
//            }
//        }
//
//
//        if($pass) {
//            $issue = new ProductionIssue();
//            $issue->Company = $company;
//            $issue->base = 1;
//            $issue->date = date('Y-m-d');
//            $issue->Section_idSection = $section;
//            $issue->UserMaster_idUser = Auth::user()->idUser;
//            $issue->status = 1;
//            $issue->save();
//
//
//
//            foreach ($temps as $temp) {
//                $qty = $temp->qty;
//                $stocks = Stock::where('Company', $company)->where('status', 1)->where('Stock_Type',$temp->stock_type_idStock_Type)->where('Items_idItems', $temp->items_idItems)->get();
//                foreach ($stocks as $stock) {
//
//                    $stockQty = $stock->qty_available;
//
//                    if ($qty <= $stockQty) {
//                        $stock->qty_available -= $qty;
//                        $stock->save();
//
//                        $list = new ItemIssueList();
//                        $list->idProduction_Issue = $issue->idProduction_Issue;
//                        $list->items_idItems = $temp->items_idItems;
//                        $list->qty = $qty;
//                        $list->Stock_idStock = $stock->idStock;
//                        $list->status = 1;
//                        $temp->delete();
//                        $list->save();
//
//                        if(Section::find($section)->sectionName == 'DELIVERY SECTION') {
//
//                            $stock2 = new Stock();
//                            $stock2->Stock_Type = $deliveryId;
//                            $stock2->base = 6;
//                            $stock2->GRN_id_or_Production_id = $issue->idProduction_Issue;
//                            $stock2->Company = Auth::user()->Company;
//                            $stock2->Items_idItems = $stock->Items_idItems;
//                            $stock2->qty_grn = $temp->qty;
//                            $stock2->qty_available = $temp->qty;
//                            $stock2->qty_inv_return = $stock->qty_inv_return;
//                            $stock2->qty_grn_return = 0;
//                            $stock2->binNo = $stock->binNo;
//                            $stock2->expDate = $stock->expDate;
//                            $stock2->expHave = $stock->expHave;
//                            $stock2->mnfDate = $stock->mnfDate;
//                            $stock2->bp = $stock->bp;
//                            $stock2->wp = $stock->wp;
//                            $stock2->sp = $stock->sp;
//                            $stock2->status = 1;
//                            $stock2->save();
//                        }
//                        $qty = 0;
//                        break;
//                    } else {
//                        $availableQty = $stock->qty_available;
//                        $qty -= $availableQty;
//                        $stock->qty_available = 0;
//                        $stock->save();
//
//                        if($availableQty>0) {
//                            $list = new ItemIssueList();
//                            $list->idProduction_Issue = $issue->idProduction_Issue;
//                            $list->Items_idItems = $temp->items_idItems;
//                            $list->qty = $availableQty;
//                            $list->Stock_idStock = $stock->idStock;
//                            $list->status = 1;
//                            $list->save();
//                        }
//                    }
//                }
//                if ($qty > 0) {
//                    return response()->json(['errors' => ['error' => 'Process invalid.Contact system administrator.']]);
//
//                }
//            }
//        }
//        else{
//            return response()->json(['errors' => ['error' => 'Requested quantity is grater than available quantity.']]);
//        }
//
//        return response()->json(['success' =>'Material issued successfully.']);
//
//    }
//
//    public function issueListSearchGrn(Request $request){
//        $id = $request['id'];
//        $endDate = $request['end'];
//        $startDate = $request['start'];
//        $list = $request['list'];
//        $company = Auth::user()->Company;
//        $sections = Section::where('status',1)->get();
//
//        if (!empty($id)) {
//            $productions = ProductionIssue::where('base',1)->where('idProduction_Issue',intval($id))->paginate(10);
//
//            return view('grn.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//
//        } else if (!empty($startDate) && !empty($endDate)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            if(empty($list)){
//                $productions = ProductionIssue::where('base',1)->whereBetween('date', [$startDate, $endDate])->latest()->latest()->paginate(10);
//            }
//            else{
//                $productions = ProductionIssue::where('base',1)->whereBetween('date', [$startDate, $endDate])->where('Section_idSection',$list)->latest()->latest()->paginate(10);
//            }
//
//            $productions->appends(array(
//                'start' => $request['start'],
//                'list' => $request['list'],
//                'end' => $request['end']
//            ));
//
//            return view('grn.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//        }
//        else if (empty($startDate) && empty($endDate) && !empty($list)) {
//            $productions = ProductionIssue::where('base',1)->where('Section_idSection',intval($list))->latest()->paginate(10);
//            $productions->appends(array(
//                'start' => $request['start'],
//                'list' => $request['list'],
//                'end' => $request['end']
//            ));
//            return view('grn.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//        }
//        else {
//            $productions = ProductionIssue::where('base',1)->where('Company',$company)->latest()->paginate(10);
//            return view('grn.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//        }
//    }


}