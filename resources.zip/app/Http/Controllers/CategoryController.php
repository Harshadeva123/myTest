<?php
/**
 * Created by PhpStorm.
 * User: Thilina
 * Date: 3/14/2019
 * Time: 1:36 PM
 */

namespace App\Http\Controllers;

use App\Brand;
use App\Http\ItemCategory;
use App\MainCategory;
use DemeterChain\Main;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Services\DataTable;


class CategoryController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $search = $request['search'];
        $query = MainCategory::query();

        if (!empty($search)) {
            $query = $query->where('catName', 'LIKE', '%' . $search . '%');
        }

        $categories = $query->where('Company',Auth::user()->Company)->latest()->paginate(10);

        $categories->appends(array(
            'search' => $request['search']
        ));
        return view('category.category', ['title' => 'Categories', 'categories' => $categories]);
    }

    public function store(Request $request)
    {

        $categoryName = $request['categoryName'];
        $validator = \Validator::make($request->all(), [

            'categoryName' => 'required',
        ], [
            'categoryName.required' => 'Category Name should be provided!',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        $mainCatExist = MainCategory::where('catName', strtoupper($categoryName))->where('Company',Auth::user()->Company)->first();
        if ($mainCatExist == null) {
            $mainCat = new MainCategory();
            $mainCat->catName = strtoupper($categoryName);
            $mainCat->Company = Auth::user()->Company;
            $mainCat->status = '1';
            $mainCat->UserMaster_idUser = Auth::user()->idUser;
            $mainCat->save();

            $mainCats = MainCategory::where('Company',Auth::user()->Company)->latest()->paginate(10);
            $tableData = '';
            foreach ($mainCats as $mainCat) {
                $tableData .= "<tr>";
                $tableData .= "<td>" . $mainCat->catName . "</td>";
                $tableData .= "<td>" . $mainCat->User->fName . "</td>";
                $tableData .= "<td>" . $mainCat->created_at . "</td>";
                if ($mainCat->status == 1) {

                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$mainCat->idItem_Category') id='c" . $mainCat->idItem_Category . "' checked switch='none'/>";
                    $tableData .= "<label for='c" . $mainCat->idItem_Category . "' data-on-label='On' data-off-label='Off'></label>";

                    $tableData .= "</td>";
                } else {
                    $tableData .= "<td>";
                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$mainCat->idItem_Category') id='c" . $mainCat->idItem_Category . "'  switch='none'/>";
                    $tableData .= "<label for='c" . $mainCat->idItem_Category . "' data-on-label='On' data-off-label='Off'></label>";
                    $tableData .= "</td>";
                }
                $tableData .= "<td>";
                $tableData .= " <p>";
                $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light'
               data-name='$mainCat->catName' data-toggle='modal' data-id='$mainCat->idItem_Category' id='mainCategoryId' data-target='#mainCatUpdate'>";
                $tableData .= "<i class='fa fa-edit'></i>";
                $tableData .= "</button>";
                $tableData .= " </p>";
                $tableData .= " </td>";
                $tableData .= "</tr>";
            }
            return response()->json(['tableData' => $tableData, 'success' => 'Category Successfully Added!']);
        } else {
            return response()->json(['errors' => ['error' => 'Category name already exist!']]);
        }
    }

    public function update(Request $request)
    {
        $mainCatID = $request['mainCatID'];
        $uCategoryName = $request['uCategoryName'];
        $validator = \Validator::make($request->all(), [

            'uCategoryName' => 'required',
        ], [
            'uCategoryName.required' => 'Category Name should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $mainCatExist = MainCategory::where('idItem_Category','!=',$mainCatID)->where('catName', strtoupper($uCategoryName))->where('Company',Auth::user()->Company)->first();

        if ($mainCatExist != null) {
            return response()->json(['errors' => ['error' => 'Category name already exist!']]);
        }

        $mainCat = MainCategory::find(intval($mainCatID));
        $mainCat->catName = strtoupper($uCategoryName);
        $mainCat->save();

        $mainCats = MainCategory::orderBy('created_at', 'desc')->where('Company',Auth::user()->Company)->paginate(10);
        $tableData = '';
        foreach ($mainCats as $mainCat) {
            $tableData .= "<tr>";
            $tableData .= "<td>" . $mainCat->catName . "</td>";
            $tableData .= "<td>" . $mainCat->User->fName . "</td>";
            $tableData .= "<td>" . $mainCat->created_at . "</td>";
            if ($mainCat->status == 1) {

                $tableData .= "<td>";
                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$mainCat->idItem_Category') id='c" . $mainCat->idItem_Category . "' checked switch='none'/>";
                $tableData .= "<label for='c" . $mainCat->idItem_Category . "' data-on-label='On' data-off-label='Off'></label>";
                $tableData .= "</td>";
            } else {
                $tableData .= "<td>";
                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$mainCat->idItem_Category') id='c" . $mainCat->idItem_Category . "'  switch='none'/>";
                $tableData .= "<label for='c" . $mainCat->idItem_Category . "' data-on-label='On' data-off-label='Off'></label>";
                $tableData .= "</td>";
            }
            $tableData .= "<td>";
            $tableData .= " <p>";
            $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light'
               data-name='$mainCat->catName' data-toggle='modal' data-id='$mainCat->idItem_Category' id='mainCategoryId' data-target='#mainCatUpdate'>";
            $tableData .= "<i class='fa fa-edit'></i>";
            $tableData .= "</button>";
            $tableData .= " </p>";
            $tableData .= " </td>";
            $tableData .= "</tr>";
        }
        return response()->json(['tableData' => $tableData, 'success' => 'Category successfully updated']);
    }

    public function changeStatus(Request $request){
        $id  = $request['id'];
        $cat = MainCategory::find($id);
        if ($cat->status == 1) {
            $cat->status = 0;
        } else {
            $cat->status = 1;
        }
        $cat->save();

    }

}