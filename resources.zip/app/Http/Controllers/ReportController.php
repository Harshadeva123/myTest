<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/15/2019
// * Time: 8:04 AM
// */
//
//namespace App\Http\Controllers;
//
//use App\CompanyInfo;
//use App\Http\ItemCategory;
//use App\Invoice;
//use App\InvoiceRegItems;
//use App\Item;
//use App\ItemIssueList;
//use App\ItemType;
//use App\MainCategory;
//use App\Payment;
//use App\PaymentType;
//use App\ProductionIssue;
//use App\Section;
//use App\SpecialOrder;
//use App\Stock;
//use App\StockType;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Auth;
//
//class ReportController extends Controller
//{
//    private $take = 10;
//
//    public function stockReports(Request $request)
//    {
//
//        $Authcompany = Auth::user()->Company;
//        $skip = isset($request['skip']) ? $request['skip'] : 0;
//        $companies = CompanyInfo::where('status', 1)->get();
//        $categories = MainCategory::where('status', 1)->get();
//        $stockTypes = StockType::where('status', 1)->where('Company', $Authcompany)->get();
//        if (Auth::user()->companyInfo->isBranch == 0) {
//            $types = ItemType::where('status', 1)->get();
//        } else {
//            $types = ItemType::where('status', 1)->where('idItem_Type', '!=', '2')->get();
//        }
//        $items = Item::where('status', 1)->get();
//        $stocks = collect();
//        $end = false;
//        $start = false;
//        $stockGroups = Stock::where('Company', $Authcompany)->select('Items_idItems')->distinct()->get();
//        $last = count($stockGroups);
//        if ($skip + $this->take >= $last) {
//            $end = true;
//        }
//        if ($skip - $this->take < 0) {
//            $start = true;
//        }
//        if ($last % $this->take == 0) {
//            $lastPage = (floor($last / $this->take) * $this->take) - $this->take;
//        } else {
//            $lastPage = floor($last / $this->take) * $this->take;
//        }
//        foreach ($stockGroups as $stockGroup) {
//            $object = new \stdClass();
//            $object->item = $stockGroup->item->itemName;
//            $object->itemId = $stockGroup->Items_idItems;
//            $object->type = $stockGroup->item->ItemType->type;
//            $object->rate = $stockGroup->item->rate;
//            $object->itemCode = $stockGroup->item->itemcode;
//            $object->category = $stockGroup->item->MainCategory->catName;
//            $available = Stock::where('Company', $Authcompany)->where('Items_idItems', $stockGroup->Items_idItems)->sum('qty_available');
//            $object->available = $available;
//            $object->measurement = $stockGroup->item->measurement->mian;
//            $stocks[] = $object;
//        }
//
//        $startLink = route('stockReports', ['skip' => 0]);
//        $prevLink = route('stockReports', ['skip' => $skip - $this->take]);
//        $nextLink = route('stockReports', ['skip' => $skip + $this->take]);
//        $lastLink = route('stockReports', ['skip' => $lastPage]);
//        $stocks = $stocks->slice($skip, $this->take);
//        return view('reports.stockReport', ['categories' => $categories, 'paginator' => $stocks, 'types' => $types, 'title' => 'Stock Report', 'companies' => $companies, 'stockTypes' => $stockTypes, 'items' => $items, 'prevLink' => $prevLink, 'nextLink' => $nextLink, 'lastLink' => $lastLink, 'startLink' => $startLink, 'last' => $last, 'nextLink' => $nextLink, 'end' => $end, 'start' => $start,]);
//    }
//
//    public function searchReportStock(Request $request)
//    {
//
//        $item = $request['item'];
//        $type = $request['type'];
//        $category = $request['category'];
//        $status = $request['status'];
//        $rows = $request['rows'] != null? $request['rows'] : 10;
//
//
//        $Authcompany = Auth::user()->Company;
//        $skip = isset($request['skip']) ? $request['skip'] : 0;
//        $companies = CompanyInfo::where('status', 1)->get();
//        $categories = MainCategory::where('status', 1)->get();
//        $stockTypes = StockType::where('status', 1)->where('Company', $Authcompany)->get();
//        if (Auth::user()->companyInfo->isBranch == 0) {
//            $types = ItemType::where('status', 1)->get();
//        } else {
//            $types = ItemType::where('status', 1)->where('idItem_Type', '!=', '2')->get();
//        }
//        $items = Item::where('status', 1)->get();
//        $stocks = collect();
//        $end = false;
//        $start = false;
//        $query = Stock::query();
//
//        if (!empty($item)) {
//            $query = $query->whereHas("item", function ($q) use ($item) {
//                $q->Where('itemName', 'like', '%' . $item . '%')->orWhere('itemcode', $item);
//            }, true);
//        }
//        if (!empty($type)) {
//            $query = $query->whereHas("item", function ($q) use ($type) {
//                $q->where("Item_Type", $type);
//            }, true);
//        }
//        if (!empty($category)) {
//            $query = $query->whereHas("item", function ($q) use ($category) {
//                $q->where("mainCategory", $category);
//            }, true);
//        }
//        if ($status != null) {
//            $query = $query->where('status', $status);
//        }
//
//
//        $stockGroups = $query->where('Company', $Authcompany)->select('Items_idItems')->distinct()->get();
//
//        $last = count($stockGroups);
//        if ($rows != 'all') {
//            if ($skip + $rows >= $last) {
//                $end = true;
//            }
//            if ($skip - $rows < 0) {
//                $start = true;
//            }
//            if ($last % $rows == 0) {
//                $lastPage = (floor($last / $rows) * $rows) - $rows;
//            } else {
//                $lastPage = floor($last / $rows) * $rows;
//            }
//        } else {
//            $end = true;
//            $start = true;
//            $lastPage = floor($last / 1) * 1;
//        }
//        foreach ($stockGroups as $stockGroup) {
//            $object = new \stdClass();
//            $object->item = $stockGroup->item->itemName;
//            $object->itemId = $stockGroup->Items_idItems;
//            $object->rate = $stockGroup->item->rate;
//            $object->itemCode = $stockGroup->item->itemcode;
//            $object->type = $stockGroup->item->ItemType->type;
//            $object->category = $stockGroup->item->MainCategory->catName;
//
//            if ($status != null) {
//                $available = Stock::where('Company', $Authcompany)->where('status', $status)->where('Items_idItems', $stockGroup->Items_idItems)->sum('qty_available');
//            } else {
//                $available = Stock::where('Company', $Authcompany)->where('Items_idItems', $stockGroup->Items_idItems)->sum('qty_available');
//            }
//
//            $object->available = $available;
//            $object->measurement = $stockGroup->item->measurement->mian;
//            $stocks[] = $object;
//        }
//
//        if ($rows != 'all') {
//            $startLink = route('searchReportStock', ['skip' => 0, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => $rows]);
//            $prevLink = route('searchReportStock', ['skip' => $skip - $rows, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => $rows]);
//            $nextLink = route('searchReportStock', ['skip' => $skip + $rows, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => $rows]);
//            $lastLink = route('searchReportStock', ['skip' => $lastPage, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => $rows]);
//            $stocks = $stocks->slice($skip, $rows);
//        } else {
//            $startLink = route('searchReportStock', ['skip' => 0, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => 'all']);
//            $prevLink = route('searchReportStock', ['skip' => $skip - null, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => 'all']);
//            $nextLink = route('searchReportStock', ['skip' => $skip + null, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => 'all']);
//            $lastLink = route('searchReportStock', ['skip' => $lastPage, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => 'all']);
//            $stocks = $stocks->slice($skip, null);
//        }
//        return view('reports.stockReport', ['rows' => $rows, 'categories' => $categories, 'paginator' => $stocks, 'types' => $types, 'title' => 'Stock Report', 'companies' => $companies, 'stockTypes' => $stockTypes, 'items' => $items, 'prevLink' => $prevLink, 'nextLink' => $nextLink, 'lastLink' => $lastLink, 'startLink' => $startLink, 'last' => $last, 'nextLink' => $nextLink, 'end' => $end, 'start' => $start,]);
//    }
//
//    public function productReports(Request $request)
//    {
//        $query = Item::query();
//
//        if (request()->ajax()) {
//            $query = Item::query();
//            if (!empty($request->search)) {
//                $query = $query->Where('itemName','like', '%' .  $request['search'] .'%');
//            }
//            if (!empty($request['main'])) {
//                $query = $query->Where('mainCategory',$request['main']);
//            }
//            if ($request['status'] != null) {
//                $query = $query->Where('status',$request['status']);
//            }
//            if ($request['type'] != null) {
//                $query = $query->Where('Item_Type',$request['type']);
//            }
//            return datatables()->of($query->get())->addColumn('category', function (Item $item) {
//                return $item->MainCategory->catName;
//            })->addColumn('ItemType', function (Item $item) {
//                return $item->ItemType->type;
//            })->addColumn('IdName', function (Item $item) {
//                return $item->itemcode.' - '.$item->itemName;
//            })->make(true);
//        }
//        if (!empty($request['search'])) {
//            $query = $query->Where('itemName', 'like', '%' . $request['search'] . '%');
//        }
//        if (!empty($request['type'])) {
//            $query = $query->Where('Item_Type', $request['type']);
//        }
//        if (!empty($request['main'])) {
//            $query = $query->Where('mainCategory', $request['main']);
//        }
//        if ($request['status'] != null) {
//            $query = $query->Where('status', $request['status']);
//        }
//        $items = $query->get();
//        $categories = MainCategory::where('status', 1)->get();
//        $types = ItemType::where('status', 1)->get();
//        return view('reports.productReport')->with(['types'=>$types,'title' => 'Product Report', 'items' => $items, 'categories' => $categories]);
//    }
//
//    public function invoiceSalesReports(Request $request){
//        $companies  = CompanyInfo::where('status',1)->get();
//        if (request()->ajax()) {
//            $query = Invoice::query();
//            if(Auth::user()->companyInfo->isBranch == 0){
//                if (!empty($request->company)) {
//                    $query = $query->Where('Company',$request->company);
//                }
//            }
//            else{
//                $query = $query->Where('Company',Auth::user()->Company);
//            }
//
//
//            if (!empty($request->end) && !empty($request->str)) {
//                $startDate = date('Y-m-d', strtotime($request['str']));
//                $endDate = date('Y-m-d', strtotime($request['end']));
//
//                $query = $query->whereBetween('date', [$startDate, $endDate]);
//            }
//            return datatables()->of($query->get())->addColumn('PaymentNa', function (Invoice $invoice) {
//                return $invoice->paymentT->type;
//            })->addColumn('companyNa', function (Invoice $invoice) {
//                return $invoice->compnayInfo->companyName;
//            })->addColumn('userNa', function (Invoice $invoice) {
//                return $invoice->user->fName;
//            })->addColumn('action', function (Invoice $invoice) {
//                $action = "<div class='button-items'>
//                                <button type='button'
//                                    class='btn btn-sm btn-info  waves-effect waves-light'
//                                    onclick='showInvoice($invoice->idInvoice)'>
//                                    <em class='fa fa-eye'></em>
//                                </button>
//                            </div>";
//                return $action;
//            })->make(true);
//        }
//
//        $query = Invoice::query();
//        if(Auth::user()->companyInfo->isBranch == 0){
//            if (!empty($request->company)) {
//                $query = $query->Where('Company',$request->company);
//            }
//        }
//        else{
//            $query = $query->Where('Company',Auth::user()->Company);
//        }
//
//
//        if (!empty($request->end) && !empty($request->start)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            $query = $query->whereBetween('date', [$startDate, $endDate]);
//        }
//        $invoices = $query->get();
//        $bankTotal = 0;
//        $creditTotal = 0;
//        $cashTotal = 0;
//        $chequeTotal = 0;
//        $visaTotal = 0;
//        $discountTotal = 0;
//        $totalSale = 0;
//        $netTotal = 0;
//        $totalFree = 0;
//
//        foreach ($invoices as $invoice){
//            $cash = floatval(Payment::where('base',1)->where('id',$invoice->idInvoice)->sum('cash'));
//            $bank = floatval(Payment::where('base',1)->where('id',$invoice->idInvoice)->sum('bank'));
//            $credit = floatval(Payment::where('base',1)->where('id',$invoice->idInvoice)->sum('credit'));
//            $cheque = floatval(Payment::where('base',1)->where('id',$invoice->idInvoice)->sum('cheque'));
//            $visa = floatval(Payment::where('base',1)->where('id',$invoice->idInvoice)->sum('visa'));
//            $free = floatval(Payment::where('base',1)->where('id',$invoice->idInvoice)->sum('free'));
//
//            $cashTotal += $cash;
//            $bankTotal += $bank;
//            $creditTotal += $credit;
//            $chequeTotal += $cheque;
//            $visaTotal += $visa;
//            $totalFree += $free;
//            $discountTotal += floatval($invoice->discount);
//            $totalSale += floatval($invoice->total);
//            $netTotal += floatval($invoice->net_total);
//        }
//        return view('reports.invoiceSales')->with(['totalFree'=>$totalFree,'netTotal'=>number_format((float)$netTotal,2),'totalSale'=>number_format((float)$totalSale,2),'discountTotal'=>number_format((float)$discountTotal,2),'chequeTotal'=>number_format((float)$chequeTotal,2),'visaTotal'=>number_format((float)$visaTotal,2),'bankTotal'=>number_format((float)$bankTotal,2),'creditTotal'=>number_format((float)$creditTotal,2),'cashTotal'=>number_format((float)$cashTotal,2),'companies'=>$companies,'title'=>'Invoice Sales Report']);
//    }
//
//    public function stockOverView(Request $request){
//        if (request()->ajax()) {
//            $query = Stock::query();
//            if (!empty($request->company)) {
//                $query = $query->Where('Company',$request->company);
//            }
//            else{
//                $query = $query->Where('Company', Auth::user()->Company);
//            }
//            if (!empty($request->end) && !empty($request->str)) {
//                $startDate = date('Y-m-d', strtotime($request['str']));
//                $endDate = date('Y-m-d', strtotime($request['end']));
//
//                $query = $query->whereBetween('created_at', [$startDate, $endDate]);
//            }
//
//            return datatables()->of($query->get())->addColumn('companyNa', function (Stock $stock) {
//                return $stock->company->companyName;
//            })->addColumn('item', function (Stock $stock) {
//                return $stock->item->itemName;
//            })->addColumn('baseNa', function (Stock $stock) {
//               if( $stock->base == 1){ return 'GRN';};
//               if( $stock->base == 2){ return 'PRODUCTION';};
//               if( $stock->base == 3){ return 'TRANSFER';};
//               if( $stock->base == 4){ return 'OPENING';};
//            })->make(true);
//        }
//        $stocks = Stock::where('status',1)->get();
//        $companies  = CompanyInfo::where('status',1)->get();
//        return view('reports.stockOverView')->with(['companies'=>$companies,'stocks'=>$stocks,'title'=>'Stock Overview Report']);
//    }
//
//    public function getInvoiceItemsForReport(Request $request){
//        $id = $request['id'];
//        $regs = InvoiceRegItems::where('invoice_idInvoice',intval($id))->get();
//        $tableData = "";
//        foreach($regs as $reg){
//            $tableData .= "<tr>";
//            $tableData .= "<td>".$reg->item->itemName."</td>";
//            $tableData .= "<td>".$reg->qty."</td>";
//            $tableData .= "<td style='text-align: right;'>".number_format($reg->rate,2)."</td>";
//            $tableData .= "<td style='text-align: right;'>".number_format($reg->discount,2)."</td>";
//            $tableData .= "</tr>";
//        }
//        return response()->json([ 'tableData' => $tableData]);
//    }
//
//    public function expiredItemsReport(Request $request){
//
//        $Authcompany = Auth::user()->Company;
//        $skip = isset($request['skip']) ? $request['skip'] : 0;
//        $companies = CompanyInfo::where('status', 1)->get();
//        $categories = MainCategory::where('status', 1)->get();
//        $stockTypes = StockType::where('status', 1)->where('Company', $Authcompany)->get();
//        if (Auth::user()->companyInfo->isBranch == 0) {
//            $types = ItemType::where('status', 1)->get();
//        } else {
//            $types = ItemType::where('status', 1)->where('idItem_Type', '!=', '2')->get();
//        }
//        $items = Item::where('status', 1)->get();
//        $stocks = collect();
//        $end = false;
//        $start = false;
//        $stockGroups = Stock::where('Company', $Authcompany)->select('Items_idItems')->distinct()->get();
//
//        foreach ($stockGroups as $stockGroup) {
//            $object = new \stdClass();
//            $object->item = $stockGroup->item->itemName;
//            $object->itemId = $stockGroup->Items_idItems;
//            $object->type = $stockGroup->item->ItemType->type;
//            $object->rate = $stockGroup->item->rate;
//            $object->itemCode = $stockGroup->item->itemcode;
//            $object->category = $stockGroup->item->MainCategory->catName;
//            $available = Stock::where('Company', $Authcompany)->where('expHave',1)->Where('qty_available','>',0)->where('expDate','<=',date('Y-m-d'))->where('Items_idItems', $stockGroup->Items_idItems)->sum('qty_available');
//            $object->available = $available;
//            $object->measurement = $stockGroup->item->measurement->mian;
//            if($available > 0) {
//                $stocks[] = $object;
//            }
//        }
//
//        $last = count($stocks);
//        if ($skip + $this->take >= $last) {
//            $end = true;
//        }
//        if ($skip - $this->take < 0) {
//            $start = true;
//        }
//        if ($last % $this->take == 0) {
//            $lastPage = (floor($last / $this->take) * $this->take) - $this->take;
//        } else {
//            $lastPage = floor($last / $this->take) * $this->take;
//        }
//        $startLink = route('expiredItemsReport', ['skip' => 0]);
//        $prevLink = route('expiredItemsReport', ['skip' => $skip - $this->take]);
//        $nextLink = route('expiredItemsReport', ['skip' => $skip + $this->take]);
//        $lastLink = route('expiredItemsReport', ['skip' => $lastPage]);
//        $stocks = $stocks->slice($skip, $this->take);
//        return view('reports.expiredItems', ['categories' => $categories, 'paginator' => $stocks, 'types' => $types, 'title' => 'Expired Stock Report', 'companies' => $companies, 'stockTypes' => $stockTypes, 'items' => $items, 'prevLink' => $prevLink, 'nextLink' => $nextLink, 'lastLink' => $lastLink, 'startLink' => $startLink, 'last' => $last, 'nextLink' => $nextLink, 'end' => $end, 'start' => $start,]);
//    }
//
//    public function viewExpireStockMore(Request $request){
//
//        $id = $request['id'];
////        $company = $request['company'];
////        $store = $request['store'];
//
//        $Authcompany = Auth::user()->Company;
//        $stocks = Stock::where('Company', $Authcompany)->where('expHave',1)->Where('qty_available','>',0)->where('expDate','<=',date('Y-m-d'))->where('Items_idItems', $id)->get();
//
//
//        $tableData = "";
//        foreach ($stocks as $stock){
//            if($stock->qty_available > 0) {
//
//                $tableData .= "<tr class='text-danger'>";
//                $tableData .= "              <td>" . $stock->stockTypes->type . "</td>";
//                if ($stock->base == 1) {
//                    $tableData .= "<td>GRN</td>";
//                } elseif ($stock->base == 2) {
//                    $tableData .= "<td>PRODUCTION</td>";
//                } elseif ($stock->base == 3) {
//                    $tableData .= "<td>TRANSFER</td>";
//                }
//                elseif($stock->base == 4){
//                    $tableData .= "<td>OPENING</td>";
//                }
//                else{
//                    $tableData .= "<td>UNKNOWN</td>";
//                }
//
//                $tableData .= "     <td>" . $stock->GRN_id_or_Production_id . "</td>";
//                $tableData .= "     <td>" . $stock->qty_available . "</td>";
//                $tableData .= "     <td style=\"text-align: right;\">" . $stock->mnfDate. "</td>";
//                $tableData .= "     <td style=\"text-align: right;\">" . $stock->expDate. "</td>";
//                $tableData .= "     <td style=\"text-align: right;\">" . number_format($stock->sp,2) . "</td>";
//                $tableData .= "     <td style=\"text-align: right;display: none;\">" . number_format($stock->bp,2) . "</td>";
//                $tableData .= "      </tr>";
//            }
//        }
//
//        return $tableData;
//
//    }
//
//    public function searchExpireReportStock(Request $request)
//    {
//
//        $item = $request['item'];
//        $type = $request['type'];
//        $category = $request['category'];
//        $status = $request['status'];
//        $rows = $request['rows'] != null? $request['rows'] : 10;
//
//
//        $Authcompany = Auth::user()->Company;
//        $skip = isset($request['skip']) ? $request['skip'] : 0;
//        $companies = CompanyInfo::where('status', 1)->get();
//        $categories = MainCategory::where('status', 1)->get();
//        $stockTypes = StockType::where('status', 1)->where('Company', $Authcompany)->get();
//        if (Auth::user()->companyInfo->isBranch == 0) {
//            $types = ItemType::where('status', 1)->get();
//        } else {
//            $types = ItemType::where('status', 1)->where('idItem_Type', '!=', '2')->get();
//        }
//        $items = Item::where('status', 1)->get();
//        $stocks = collect();
//        $end = false;
//        $start = false;
//        $query = Stock::query();
//
//        if (!empty($item)) {
//            $query = $query->whereHas("item", function ($q) use ($item) {
//                $q->Where('itemName', 'like', '%' . $item . '%')->orWhere('itemcode', $item);
//            }, true);
//        }
//        if (!empty($type)) {
//            $query = $query->whereHas("item", function ($q) use ($type) {
//                $q->where("Item_Type", $type);
//            }, true);
//        }
//        if (!empty($category)) {
//            $query = $query->whereHas("item", function ($q) use ($category) {
//                $q->where("mainCategory", $category);
//            }, true);
//        }
//        if ($status != null) {
//            $query = $query->where('status', $status);
//        }
//
//
//        $stockGroups = $query->where('Company', $Authcompany)->select('Items_idItems')->distinct()->get();
//
//
//        foreach ($stockGroups as $stockGroup) {
//            $object = new \stdClass();
//            $object->item = $stockGroup->item->itemName;
//            $object->itemId = $stockGroup->Items_idItems;
//            $object->type = $stockGroup->item->ItemType->type;
//            $object->rate = $stockGroup->item->rate;
//            $object->itemCode = $stockGroup->item->itemcode;
//            $object->category = $stockGroup->item->MainCategory->catName;
//            $available = Stock::where('Company', $Authcompany)->where('expHave',1)->Where('qty_available','>',0)->where('expDate','<=',date('Y-m-d'))->where('Items_idItems', $stockGroup->Items_idItems)->sum('qty_available');
//            $object->available = $available;
//            $object->measurement = $stockGroup->item->measurement->mian;
//            if($available > 0) {
//                $stocks[] = $object;
//            }
//        }
//
//        $last = count($stocks);
//        if ($rows != 'all') {
//            if ($skip + $rows >= $last) {
//                $end = true;
//            }
//            if ($skip - $rows < 0) {
//                $start = true;
//            }
//            if ($last % $rows == 0) {
//                $lastPage = (floor($last / $rows) * $rows) - $rows;
//            } else {
//                $lastPage = floor($last / $rows) * $rows;
//            }
//        } else {
//            $end = true;
//            $start = true;
//            $lastPage = floor($last / 1) * 1;
//        }
//
//        if ($rows != 'all') {
//            $startLink = route('expiredItemsReport', ['skip' => 0, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => $rows]);
//            $prevLink = route('expiredItemsReport', ['skip' => $skip - $rows, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => $rows]);
//            $nextLink = route('expiredItemsReport', ['skip' => $skip + $rows, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => $rows]);
//            $lastLink = route('expiredItemsReport', ['skip' => $lastPage, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => $rows]);
//            $stocks = $stocks->slice($skip, $rows);
//        } else {
//            $startLink = route('expiredItemsReport', ['skip' => 0, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => 'all']);
//            $prevLink = route('expiredItemsReport', ['skip' => $skip - null, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => 'all']);
//            $nextLink = route('expiredItemsReport', ['skip' => $skip + null, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => 'all']);
//            $lastLink = route('expiredItemsReport', ['skip' => $lastPage, 'item' => $item, 'type' => $type, 'category' => $category, 'status' => $status, 'rows' => 'all']);
//            $stocks = $stocks->slice($skip, null);
//        }
//        return view('reports.expiredItems', ['rows' => $rows, 'categories' => $categories, 'paginator' => $stocks, 'types' => $types, 'title' => 'Expire Stock Report', 'companies' => $companies, 'stockTypes' => $stockTypes, 'items' => $items, 'prevLink' => $prevLink, 'nextLink' => $nextLink, 'lastLink' => $lastLink, 'startLink' => $startLink, 'last' => $last, 'nextLink' => $nextLink, 'end' => $end, 'start' => $start,]);
//    }
//
//    public function freeIssueReports(Request $request){;
//        $query = Payment::query();
//        $query1 = Payment::query();
//        $issues = collect();
//        $TotalInvoice = 0;
//        $TotalSpecials = 0;
//        $companies = CompanyInfo::where('status',1)->get();
//
//        if (!empty($request->start) && !empty($request->end)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            $query = $query->whereBetween('created_at', [$startDate." 00:00:00", $endDate." 23:59:59"]);
//            $query1 = $query1->whereBetween('created_at', [$startDate." 00:00:00", $endDate." 23:59:59"]);
//        }
//        if (!empty($request->company)) {
//            $query = $query->where('Company',$request->company);
//            $query1 = $query1->where('Company',$request->company);
//        }
//        if (!empty($request->base)) {
//            if($request->base == 1){
//                $invoices = $query1->where('base', 1)->where('payment_type_idpayment_type', 7)->get();
//                if($invoices != null){
//                    foreach ($invoices as $inv) {
//                        $invoice = Invoice::find($inv->id);
//                        $object = new \stdClass();
//                        $object->id = $invoice->idInvoice;
//                        $object->Company = $invoice->Company;
//                        $object->createdAt = $invoice->created_at->format('Y-m-d');
//                        $object->CompanyName = $invoice->compnayInfo->companyName;
//                        $object->userName = $invoice->user->fName;
//                        $object->base = 'INVOICE';
//                        $object->total = number_format($invoice->net_total, 2);
//                        $issues[] = $object;
//                        $TotalInvoice += $invoice->net_total;
//                    }
//                }
//
//            }
//            if($request->base == 3){
//                $specials = $query->where('base', 3)->where('payment_type_idpayment_type', 7)->get();
//                if($specials != null) {
//                    foreach ($specials as $special) {
//
//                        $order = SpecialOrder::find($special->id);
//                        $object1 = new \stdClass();
//                        $object1->id = $order->idOrder;
//                        $object1->Company = $order->Company;
//                        $object1->createdAt = $order->created_at->format('Y-m-d');
//                        $object1->CompanyName = $order->companyInfo->companyName;
//                        $object1->userName = $order->user->fName;
//                        $object1->base = 'SPECIAL ORDER';
//                        $object1->total = number_format($order->amount, 2);
//                        $issues[] = $object1;
//                        $TotalSpecials += $order->amount;
//                    }
//                }
//            }
//        }
//        else {
//            $specials = $query->where('base', 3)->where('payment_type_idpayment_type', 7)->get();
//            $invoices = $query1->where('base', 1)->where('payment_type_idpayment_type', 7)->get();
//
//            if($invoices != null){
//                foreach ($invoices as $inv) {
//                    $invoice = Invoice::find($inv->id);
//                    $object = new \stdClass();
//                    $object->id = $invoice->idInvoice;
//                    $object->Company = $invoice->Company;
//                    $object->createdAt = $invoice->created_at->format('Y-m-d');
//                    $object->CompanyName = $invoice->compnayInfo->companyName;
//                    $object->userName = $invoice->user->fName;
//                    $object->base = 'INVOICE';
//                    $object->total = number_format($invoice->net_total, 2);
//                    $issues[] = $object;
//                    $TotalInvoice += $invoice->net_total;
//                }
//            }
//
//            if($specials != null) {
//                foreach ($specials as $special) {
//
//                    $order = SpecialOrder::find($special->id);
//                    $object1 = new \stdClass();
//                    $object1->id = $order->idOrder;
//                    $object1->Company = $order->Company;
//                    $object1->createdAt = $order->created_at->format('Y-m-d');
//                    $object1->CompanyName = $order->companyInfo->companyName;
//                    $object1->userName = $order->user->fName;
//                    $object1->base = 'SPECIAL ORDER';
//                    $object1->total = number_format($order->amount, 2);
//                    $issues[] = $object1;
//                    $TotalSpecials += $order->amount;
//                }
//            }
//        }
//        return view('reports.freeIssue')->with(['companies'=>$companies,'totalInvoice'=>number_format($TotalInvoice,2),'totalSpecials'=>number_format($TotalSpecials,2),'issues'=>$issues,'title'=>'Free Issue Report']);
//    }
//
//    public function specialOrderPayment(Request $request){
//        $query1 = SpecialOrder::query();
//        $companies = CompanyInfo::where('status',1)->get();
//        $paymentTypes = PaymentType::where('status',1)->get();
//        if (request()->ajax()) {
//            $query = SpecialOrder::query();
//            if (!empty($request->company)) {
//                $query = $query->Where('Company',$request->company);
//            }
//            else{
//                if(Auth::user()->companyInfo->isBranch == 1) {
//                    $query = $query->Where('Company', Auth::user()->Company);
//                }
//            }
//            if (!empty($request->type)) {
//                $query = $query->Where('payment_type',$request->type);
//            }
//            if (!empty($request->end) && !empty($request->str)) {
//                $startDate = date('Y-m-d', strtotime($request['str']));
//                $endDate = date('Y-m-d', strtotime($request['end']));
//
//                $query = $query->whereBetween('orderDate', [$startDate, $endDate]);
//            }
//
//            return datatables()->of($query->get())->addColumn('paymentType', function (SpecialOrder $order) {
//                return $order->paymentType->type;
//            })->make(true);
//        }
//        if (!empty($request->company)) {
//            $query1 = $query1->Where('Company',$request->company);
//        }
//        else{
//            if(Auth::user()->companyInfo->isBranch == 1) {
//                $query1 = $query1->Where('Company', Auth::user()->Company);
//            }
//        }
//        if (!empty($request->type)) {
//            $query1 = $query1->Where('payment_type',$request->type);
//        }
//        else{
//            $query1 = $query1->Where('Company', Auth::user()->Company);
//        }
//        if (!empty($request->end) && !empty($request->str)) {
//            $startDate = date('Y-m-d', strtotime($request['str']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            $query1 = $query1->whereBetween('created_at', [$startDate, $endDate]);
//        }
//        $specialOrders = $query1->get();
//        $advanced = number_format($specialOrders->sum('advanced'),2);
//        $due = number_format($specialOrders->sum('due'),2);
//        $amount = number_format($specialOrders->sum('amount'),2);
//        $paidDue = number_format($specialOrders->sum('paidDue'),2);
//        return view('reports.specialOrderPayment')->with(['paymentTypes'=>$paymentTypes,'paidDue'=>$paidDue,'amount'=>$amount,'due'=>$due,'advanced'=>$advanced,'companies'=>$companies,'specialOrders'=>$specialOrders,'title'=>'Special Order Report']);
//    }
//
//    public function productSellingReport(Request $request){
//
//        $types = ItemType::where('status',1)->get();
//        $companies = CompanyInfo::where('status',1)->get();
//
//        if (request()->ajax()) {
//            $stocks =  collect();
//
//            $query1 = Item::query();
//            if (!empty($request->type)) {
//                $query1 = $query1->Where('Item_Type',$request->type);
//            }
//            $items = $query1->where('status',1)->get();
//            if (!empty($request->month) ) {
//                $month = date('Y-m', strtotime($request['month'])) ;
//            }
//            else{
//                $month = date('Y-m') ;
//            }
//
//
//            foreach ($items as $item) {
//                $object = new \stdClass();
//
//                $query = InvoiceRegItems::query();
//
//                if(Auth::user()->companyInfo->isBranch == 0) {
//                    if (!empty($request->company)) {
//                        $query = $query->whereHas("invoice", function ($q) use ($request) {
//                            $q->where("Company", $request->company);
//                        }, true);
//                    }
//                }
//                else {
//                    $query = $query->whereHas("invoice", function ($q) use ($request) {
//                        $q->where("Company", Auth::user()->Company);
//                    }, true);
//                }
//                $c = $query->whereBetween('date',[$month.'-1',$month.'-31'])->where('items_idItems',$item->idItems)->sum('qty');
//                if($c == null || empty($c)){
//                    $count = 0;
//                }
//                else{
//                    $count = $c;
//                }
//
//                $object->count =$count;
//                $object->itemId = $item->idItems;
//                $object->itemName = $item->itemName;
//                $object->amount = number_format(floatval($count * $item->unitPrice),2);
//                $stocks[] = $object;
//            }
//
//            $dataTable =  datatables()->of($stocks);
//            if(Auth::user()->companyInfo->isBranch == 0) {
//                if (!empty($request->company)) {
//                    for ($i=1;$i<32;$i++){
//                        $dataTable = $dataTable
//                            ->addColumn( $i.'+col', function ($stocks) use ($i,$month,$request) {
//                                $s =  InvoiceRegItems::whereHas("invoice", function ($q) use($request){
//                                    $q->where("Company", $request->company);
//                                }, true)->where('items_idItems',$stocks->itemId)->where('date',$month.'-'.$i)->get();
//                                if($s != null && !empty($s)){
//                                    return $s->sum('qty');
//                                }
//                                else{
//                                    return 0;
//                                }
//                            });
//                    }
//                }
//                else{
//                    for ($i=1;$i<32;$i++){
//                        $dataTable = $dataTable
//                            ->addColumn( $i.'+col', function ($stocks) use ($i,$month) {
//                                $s =  InvoiceRegItems::where('items_idItems',$stocks->itemId)->where('date',$month.'-'.$i)->get();
//                                if($s != null && !empty($s)){
//                                    return $s->sum('qty');
//                                }
//                                else{
//                                    return 0;
//                                }
//                            });
//                    }
//                }
//            }
//            else {
//                for ($i=1;$i<32;$i++){
//                    $dataTable = $dataTable
//                        ->addColumn( $i.'+col', function ($stocks) use ($i,$month) {
//                            $s =  InvoiceRegItems::whereHas("invoice", function ($q) {
//                                $q->where("Company", Auth::user()->Company);
//                            }, true)->where('items_idItems',$stocks->itemId)->where('date',$month.'-'.$i)->get();
//                            if($s != null && !empty($s)){
//                                return $s->sum('qty');
//                            }
//                            else{
//                                return 0;
//                            }
//                        });
//                }
//            }
//
//            $dataTable = $dataTable->make(true);
//
//            return $dataTable;
//        }
//
//        return view('reports.productSellingReport')->with(['companies'=>$companies,'types'=>$types,'title'=>'Product Selling Report']);
//    }
//
//    public function productIssueReport(Request $request){
//        $types = ItemType::where('status',1)->get();
//        $companies = CompanyInfo::where('status',1)->get();
//
//        if (request()->ajax()) {
//            $query = ItemIssueList::query();
//
//            if(Auth::user()->companyInfo->isBranch == 1) {
//                $query = $query->whereHas("issue", function ($q) {
//                    $q->where("Company", Auth::user()->Company);
//                }, true);
//            }
//            else{
//                if (!empty($request->company)) {
//                    $query = $query->whereHas("issue", function ($q) use ($request) {
//                        $q->where("Company", $request->company);
//                    }, true);
//                }
//            }
//
//            if (!empty($request->end) && !empty($request->str)) {
//                $startDate = date('Y-m-d', strtotime($request['str']));
//                $endDate = date('Y-m-d', strtotime($request['end']));
//
//                $query = $query->whereHas("issue", function ($q) use ($startDate,$endDate) {
//                    $q->whereBetween('date', [$startDate, $endDate]);
//                }, true);
//            }
//
//            return datatables()->of($query->get())
//                ->addColumn('itemName', function (ItemIssueList $item) {
//                return $item->item->itemName;
//            })->addColumn('section', function (ItemIssueList $item) {
//                return $item->issue->section->sectionName;
//            })->addColumn('date', function (ItemIssueList $item) {
//                return $item->issue->date;
//            })->addColumn('issuedBy', function (ItemIssueList $item) {
//                return $item->issue->user->fName;
//            })->make(true);
//        }
//        return view('reports.productIssueReport')->with(['companies'=>$companies,'types'=>$types,'title'=>'Product Issue Report']);
//
//    }
//
//    public function itemMaterialIssueReport(Request $request){
//        $sections  = Section::where('Company',Auth::user()->Company)->where('status',1)->get();
//        if (request()->ajax()) {
//            $query = ItemIssueList::query();
//            if (!empty($request->end) && !empty($request->str)) {
//                $startDate = date('Y-m-d', strtotime($request['str']));
//                $endDate = date('Y-m-d', strtotime($request['end']));
//
//                $query = $query->whereHas("issue", function ($q) use($startDate,$endDate) {
//                    $q->whereBetween('date', [$startDate, $endDate]);
//                }, true);
//            }
//
//            if (!empty($request->sec)) {
//                $sec  = $request->sec;
//                $query = $query->whereHas("issue", function ($q) use($sec) {
//                    $q->where('Section_idSection',$sec)->where('status',1);
//                }, true);
//            }
//
//            $production = $query->get();
//
//            return datatables()->of($production)->addColumn('id', function (ItemIssueList $production) {
//                return $production->issue->idProduction_Issue;
//            })->addColumn('item', function (ItemIssueList $production) {
//                return $production->item->itemName;
//            })->addColumn('section', function (ItemIssueList $production) {
//                return $production->issue->section->sectionName;
//            })->addColumn('user', function (ItemIssueList $production) {
//                return $production->issue->user->fName;
//            })->addColumn('date', function (ItemIssueList $production) {
//                return $production->issue->date;
//            })->make(true);
//        }
//
//        return view('reports.itemMaterialIssueReport')->with(['sections'=>$sections,'title'=>'Item/Material Issue Report']);
//    }
//
//    public function dailyProductionReport(Request $request){
//
//        $AuthCompany = Auth::user()->Company;
//        $skip = isset($request['skip']) ? $request['skip'] : 0;
//        $end = false;
//        $start = false;
//
//        $query = Stock::query();
//        if (!empty($request->end) && !empty($request->str)) {
//            $startDate = date('Y-m-d', strtotime($request['str']));
//            $endDate = date('Y-m-d', strtotime($request['end'].' +1 day'));
//            $query = $query->whereBetween('created_at', [$startDate, $endDate]);
//        }
//        else{
//            $query = $query->whereBetween('created_at', [date('Y-m-d'), date('Y-m-d', strtotime(' +1 day'))]);
//        }
//
//        $distItems = $query->where('Company', $AuthCompany)->where('status', 1)->select('Items_idItems','created_at')->groupBy('Items_idItems')->get();
//
//        $last = count($distItems);
//        if ($skip + $this->take >= $last) {
//            $end = true;
//        }
//        if ($skip - $this->take < 0) {
//            $start = true;
//        }
//        if ($last % $this->take == 0) {
//            $lastPage = (floor($last / $this->take) * $this->take) - $this->take;
//        } else {
//            $lastPage = floor($last / $this->take) * $this->take;
//        }
//
//        $stocks =  collect();
//
//
//        foreach ($distItems as $distItem) {
//            $object = new \stdClass();
//            $object->item = $distItem->item->itemName;
//            $object->itemId = $distItem->Items_idItems;
//            $object->date = $distItem->created_at->format('Y-m-d');
//            $object->rate = $distItem->item->rate;
//            $object->itemCode = $distItem->item->itemcode;
//            $object->category = $distItem->item->MainCategory->catName;
//            $query1 = Stock::query();
//            if (!empty($request->end) && !empty($request->str)) {
//                $startDate = date('Y-m-d', strtotime($request['str']));
//                $endDate = date('Y-m-d', strtotime($request['end'].' +1 day'));
//
//                $query1 = $query1->whereBetween('created_at', [$startDate, $endDate]);
//            }
//            else{
//                $query1 = $query1->whereBetween('created_at', [date('Y-m-d'), date('Y-m-d', strtotime(' +1 day'))]);
//            }
//
////            $produce =  $query2->where('Company', $AuthCompany)->where('Items_idItems', $distItem->Items_idItems)->where('status',1)->sum('qty_available');
//            $produce =  $query1->where('Company', $AuthCompany)->where('Items_idItems', $distItem->Items_idItems)->where('status',1)->sum('qty_grn');
//            $object->produce = $produce;
//            $object->measurement = $distItem->item->measurement->mian;
//            $stocks[] = $object;
//        }
//
//
//        $startLink = route('dailyProductionReport', ['skip' => 0]);
//        $prevLink = route('dailyProductionReport', ['skip' => $skip - $this->take]);
//        $nextLink = route('dailyProductionReport', ['skip' => $skip + $this->take]);
//        $lastLink = route('dailyProductionReport', ['skip' => $lastPage]);
//        $stocks = $stocks->slice($skip, $this->take);
//
//        return view('reports.dailyProductionReport')->with(['title'=>'Daily Production Report', 'paginator' => $stocks, 'prevLink' => $prevLink, 'nextLink' => $nextLink, 'lastLink' => $lastLink, 'startLink' => $startLink, 'last' => $last, 'end' => $end, 'start' => $start]);
//    }
//
//    public function viewDailyProductionMore(Request $request){
//        $id = $request['id'];
//        $AuthCompany = Auth::user()->Company;
//        $startDate = date('Y-m-d', strtotime($request['str']));
//        $endDate = date('Y-m-d', strtotime($request['end'].' +1 day'));
//
//        $stocks = Stock::where('Items_idItems',$id)->where('Company',$AuthCompany)->whereBetween('created_at', [$startDate, $endDate])->where('status',1)->orderBy('idStock','DESC')->get();
//
//        $tableData = "";
//        foreach ($stocks as $stock){
//            if($stock->qty_available > 0) {
//                if($stock->expDate >= date('Y-m-d') || $stock->expHave == 0){
//                    $tableData .= "<tr>";
//                }
//                else{
//                    $tableData .= "<tr class='text-danger'>";
//                }
//                $tableData .= "<td>" . $stock->stockTypes->type . "</td>";
//                if ($stock->base == 1) {
//                    $tableData .= "<td>GRN</td>";
//                } elseif ($stock->base == 2) {
//                    $tableData .= "<td>PRODUCTION</td>";
//                } elseif ($stock->base == 3) {
//                    $tableData .= "<td>TRANSFER</td>";
//                }
//                elseif($stock->base == 4){
//                    $tableData .= "<td>OPENING</td>";
//                }
//                elseif($stock->base == 5){
//                    $tableData .= "<td>STORE CHANGE</td>";
//                }
//                else{
//                    $tableData .= "<td>UNKNOWN</td>";
//                }
//
//                $tableData .= "     <td>" . $stock->GRN_id_or_Production_id . "</td>";
//                $tableData .= "     <td>" . $stock->qty_available . "</td>";
//                $tableData .= "     <td style=\"text-align: right;\">" . $stock->mnfDate. "</td>";
//                $tableData .= "     <td style=\"text-align: right;\">" . $stock->expDate. "</td>";
//                $tableData .= "     <td style=\"text-align: right;\">" . $stock->created_at->format('Y-m-d'). "</td>";
////                $tableData .= "     <td style=\"text-align: right;\">" . number_format($stock->sp,2) . "</td>";
////                $tableData .= "     <td style=\"text-align: right;display: none;\">" . number_format($stock->bp,2) . "</td>";
//                $tableData .= "      </tr>";
//            }
//        }
//
//        return $tableData;
//    }
//}