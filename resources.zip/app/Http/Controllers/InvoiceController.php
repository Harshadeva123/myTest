<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/15/2019
// * Time: 2:08 PM
// */
//
//namespace App\Http\Controllers;
//
//use App\BankMeta;
//use App\BankPayments;
//use App\BankPaymentsTemp;
//use App\ChequePayments;
//use App\ChequePaymentTemp;
//use App\CompanyInfo;
//use App\Customer;
//use App\InvoiceReg;
//use App\InvoiceRegItems;
//use App\InvoiceReturn;
//use App\InvoiceTemp;
//use App\Payment;
//use App\PaymentType;
//use App\Stock;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Auth;
//use App\Invoice;
//use App\Item;
//use App\StockType;
//
//class InvoiceController extends Controller
//{
//
//    public function createInvoice()
//    {
//        $paymentTypes = PaymentType::where('status',1)->get();
//        $stockTypes = StockType::all();
//        $items = Item::where('status', 1)->where('Item_Type','!=',2)->get();
//        $companies = CompanyInfo::where('status',1)->get();
//        $customers = Customer::where('status',1)->get();
//        return view('invoice.createInvoice')->with(['paymentTypes'=>$paymentTypes,'title'=>'Create Invoice','stockTypes'=>$stockTypes,'items'=>$items,'companies'=>$companies,'customers'=>$customers]);
//    }
//
//    public function addItemToInvoice(Request $request)
//    {
//        $validator = \Validator::make($request->all(), [
//            'item' => 'required',
//            'qty' => 'required|not_in:0',
//        ], [
//            'item.required' => 'Item should be provided!',
//            'qty.required' => 'Qty should be provided!',
//            'qty.not_in' => 'Qty must be grater than 0.',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//        $isExist = InvoiceTemp::where('items_idItems',$request['item'])->where('usermaster_idUser',Auth::user()->idUser)->where('rate',$request['rate'])->where('discount',$request['discount'])->where('status',1)->first();
//        if($isExist != null){
//            $isExist->qty += $request['qty'];
//            $isExist->save();
//        }
//        else {
//            $inv = new InvoiceTemp();
//            $inv->usermaster_idUser = Auth::user()->idUser;
//            $inv->items_idItems = $request['item'];
//            $inv->discount = $request['discount'];
//            $inv->rate = Item::find($request['item'])->unitPrice;
//            $inv->qty = $request['qty'];
//            $inv->status = 1;
//            $inv->save();
//        }
//
//        return response()->json([ 'success' => 'Successfully saved']);
//    }
//
//    public function getInvoiceTemp(){
//        $tableData = "";
//        $total = 0;
//        $items = InvoiceTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        if(count($items)!=0){
//            foreach ($items as $item){
//                $rowTotal = (floatval($item->qty)*floatval($item->rate))-floatval($item->discount);
//                $total += $rowTotal;
//                $tableData .= "<tr id=".$item->idinvoice_reg_temp.">
//                                    <td>".$item->item->itemName."</td>
//                                    <td>".$item->qty.' '.$item->item->measurement->mian."</td>
//                                    <td style='text-align: right '>".number_format($item->rate,2)."</td>
//
//                                    <td style='text-align: right '>".number_format($rowTotal,2)."</td>
//                                    <td>
//                                            <div class='button-items'>
//                                                <button type='button'
//                                                        class='btn btn-sm btn-danger  waves-effect waves-light'
//                                                        data-id=".$item->idinvoice_reg_temp."
//                                                        onclick='deleteTempInvoice(this)'>
//                                                        <i class='fa fa-trash'></i>
//                                                 </button>
//
//                                            </div>
//                                    </td>
//                                </tr>";
//            }
//
//        }
//        else{
//            $tableData= "<tr><td colspan='6' style='text-align: center;font-weight: 500'>Sorry No Results Found..</td></tr>";
//        }
//        return response()->json([ 'tableData' => $tableData,'total'=>$total]);
//    }
//
//    public function deleteTempInvoice(Request $request){
//        $id = $request['id'];
//        $inv = InvoiceTemp::find($id);
//        $inv->status = 0;
//        $inv->save();
//    }
//
//    public function saveInvoice(Request $request){
//        $validator = \Validator::make($request->all(), [
//            'date' => 'required',
//            'payment' => 'required'
//        ], [
//            'date.required' => 'Date should be provided!',
//            'payment.required' => 'Payment type should be provided!',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $company = Auth::user()->Company;
//        $orderNo = $request['orderNo'];
//        $paid = $request['paid'];
//        $disType = $request['disType'];
//        $disInput = $request['disInput'];
//        $visaBill = $request['visaBill'];
//        $cardAmount = $request['cardAmount'];
//        $bankId = $request['bankId'];
//        $chequeBankName = $request['chequeBankName'];
//        $chequeDate = $request['chequeDate'];
//        $chequeNo = $request['chequeNo'];
//        $paymentType = intval($request['payment']);
//        $date = date('Y-m-d', strtotime($request['date']));
//        $name = isset($request['name'])?$request['name']:1;
//        $total = 0;
//        $pass = true;
//        $totalPaid = 0;
//        $temps = InvoiceTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        if($temps != null){
////            $discount = $temps->sum('discount');
//            foreach ($temps as $temp){
//                $rowTotal = (floatval($temp->qty)*floatval($temp->rate))-floatval($temp->discount);
//                $total += $rowTotal;
//                $stocks =  Stock::where('Company',$company)->where('status',1)->where('Items_idItems',$temp->items_idItems)->sum('qty_available');
//                if($stocks<$temp->qty){
//                    $pass = false;
//                }
//
//            }
//        }
//        else{
//            return response()->json(['errors' => ['error' => 'No items available.']]);
//        }
//
//        if($disType == 1){
//            if($disInput/100 > 1){
//                return response()->json(['errors' => ['error' => 'Invalid Discount.']]);
//            }
//            $discount = $total *  ($disInput/100);
//
//        }
//        elseif( $disType == 2){
//            if($disInput > $total){
//                return response()->json(['errors' => ['error' => 'Invalid Discount.']]);
//            }
//            $discount = $disInput;
//        }
//        else{
//            $discount = 0;
//        }
//        $netTotal  = $total - $discount;
//        if($paymentType == 1 || $paymentType == 2){
//            if($paid == null){
//                return response()->json(['errors' => ['error' => 'Paid amount should be provided.']]);
//            }
//            if($paymentType == 2){
//                if($paid >= $netTotal){
//                    return response()->json(['errors' => ['error' => 'Zero (0) amount goes to credit.please select "CASH" payment type.']]);
//                }
//                if($name == 1){
//                    return response()->json(['errors' => ['error' => 'Please select registered customer for add credit.']]);
//                }
//            }
//            if($paymentType == 1){
//                if($paid<$netTotal){
//                    return response()->json(['errors' => ['error' => 'Paid amount is lower than net total.Please change payment type to add credits.']]);
//                }
//            }
//            $totalPaid = $paid;
//        }
//        if($paymentType == 4){
//            if($visaBill == null){
//                return response()->json(['errors' => ['error' => 'Card no should be provided.']]);
//            }
//            $totalPaid = $netTotal;
//        }
//        if($paymentType == 3){
//            if($bankId == null){
//                return response()->json(['errors' => ['error' => 'Bank name should be provided.']]);
//            }
//            $bankAmount = floatval(BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->sum('amount'));
//            if(floatval($netTotal) > $bankAmount){
//                return response()->json(['errors' => ['error' => 'Total bank amount is lower than net total.Please change payment type to add credits.']]);
//            }
//            $totalPaid = $bankAmount;
//        }
//        if($paymentType == 5){
//            if($chequeBankName == null){
//                return response()->json(['errors' => ['error' => 'Bank name should be provided.']]);
//            }
//            if($chequeDate == null){
//                return response()->json(['errors' => ['error' => 'Cheque date should be provided.']]);
//            }
//            if($chequeNo == null){
//                return response()->json(['errors' => ['error' => 'Cheque no should be provided.']]);
//            }
//            $chequePayments = floatval(ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->sum('amount'));
//            if(floatval($netTotal) > $chequePayments){
//                return response()->json(['errors' => ['error' => 'Total cheque amount is lower than net total.Please change payment type to add credits.']]);
//            }
//            $totalPaid = $chequePayments;
//        }
//        if($paymentType == 6){
//            if($paid != null){
//                $totalPaid += $paid;
//            }
//            if($cardAmount != null){
//                $totalPaid += $cardAmount;
//            }
//            $banks = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//            if($banks != null){
//                $totalPaid += $banks->sum('amount');
//            }
//            $cheque  = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//            if($cheque != null){
//                $totalPaid += $cheque->sum('amount');
//            }
//
//            if($netTotal > $totalPaid && $name == 1 ){
//                return response()->json(['errors' => ['error' => 'Total cheque amount is lower than net total.Please select a registered customer to add credits.']]);
//            }
//        }
//        if($paymentType == 7){
//            if($name == 1){
//                return response()->json(['errors' => ['error' => 'Please select registered customer for free issue.']]);
//            }
//            $totalPaid = 0;
//        }
//        if($pass) {
//            $invoice = new Invoice();
//            $invoNos = Invoice::select('invoiceNo')->where('Company',$company)->get();
//            if($invoNos != null){
//                $maxNo = intval($invoNos->max('invoiceNo'))+1;
//            }
//            else{
//                $maxNo = 1;
//            }
//            $invoice->invoiceNo = $maxNo;
//            $invoice->Company = $company;
//            $invoice->Customer = $name;
//            $invoice->orderNo = $orderNo;
//            $invoice->total = $total;
//            $invoice->discount = $discount;
//            $invoice->net_total = $netTotal;
//            $invoice->date = $date;
//            $invoice->paymentType = $paymentType;
//            if($paymentType == 2 ){
//                $invoice->paidDue = 0;
//                $invoice->due = $netTotal - $paid;
//            }
//            $invoice->paid = $totalPaid;
//            $invoice->status = 1;
//            $invoice->UserMaster_idUser = Auth::user()->idUser;
//            $invoice->save();
//
//            $payment = new Payment();
//            $payment->System_Company = $company;
//            $payment->payment_type_idpayment_type = $paymentType;
//            $payment->base = 1;
//            $payment->id = $invoice->idInvoice;
//            $payment->totalAmount = $netTotal;
//            if($paymentType == 1){
//                $payment->cash = $netTotal;
//            }
//            if($paymentType == 2){
//                $payment->cash = $paid;
//                $payment->credit = floatval($netTotal)-floatval($paid);
//            }
//            if($paymentType == 4){
//                $payment->visa = $netTotal;
//                $payment->visaBillNo = $visaBill;
//            }
//            if($paymentType == 3){
//                $payment->bank = $netTotal;
//            }
//            if($paymentType == 5){
//                $payment->cheque = $netTotal;
//            }
//            if($paymentType == 6){
//                if($paid != null){
//                    $payment->cash = $paid;
//                }
//                if($cardAmount != null){
//                    $payment->visa = $cardAmount;
//                    $payment->visaBillNo = $visaBill;
//                }
//                $banks = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//                if($banks != null){
//                    $payment->bank = $banks->sum('amount');
//                }
//                $cheque  = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//                if($cheque != null){
//                    $payment->cheque = $cheque->sum('amount');
//                }
//            }
//            if($paymentType == 7){
//                $payment->free = $netTotal;
//            }
//            $payment->status = 1;
//            $payment->usermaster_idUser = Auth::user()->idUser;
//            $payment->save();
//
//            if($paymentType == 3){
//                $records = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//                foreach ($records as $record) {
//                    $bank = new BankPayments();
//                    $bank->Company = $company;
//                    $bank->payment_idpayment = $payment->idpayment;
//                    $bank->bank_meta_idbank_meta = $record->bank_meta_idbank_meta;
//                    $bank->amount = $record->amount;
//                    $bank->status = 1;
//                    $bank->save();
//                    $record->delete();
//                }
//
//            }
//            if($paymentType == 5){
//                $records = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//                foreach ($records as $record) {
//                    $bank = new ChequePayments();
//                    $bank->Company = $company;
//                    $bank->payment_idpayment = $payment->idpayment;
//                    $bank->bank_meta_idbank_meta = $record->bank_meta_idbank_meta;
//                    $bank->chequeNo = $record->chequeNo;
//                    $bank->chequeDate = date('Y-m-d', strtotime($record->chequeDate));
//                    $bank->amount = $record->amount;
//                    $bank->status = 1;
//                    $bank->save();
//                    $record->delete();
//                }
//
//            }
//            if($paymentType == 6){
//                $records = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//                if($records != null){
//                    $bankTotal = $records->sum('amount');
//                    foreach ($records as $record) {
//                        $bank = new BankPayments();
//                        $bank->Company = $company;
//                        $bank->payment_idpayment = $payment->idpayment;
//                        $bank->bank_meta_idbank_meta = $record->bank_meta_idbank_meta;
//                        $bank->amount = $record->amount;
//                        $bank->status = 1;
//                        $bank->save();
//                        $record->delete();
//                    }
//                }
//                $cheques = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//                if($cheques != null) {
//                    $chequeTotal = $cheques->sum('amount');
//                    foreach ($cheques as $cheque) {
//                        $bank = new ChequePayments();
//                        $bank->Company = $company;
//                        $bank->payment_idpayment = $payment->idpayment;
//                        $bank->bank_meta_idbank_meta = $cheque->bank_meta_idbank_meta;
//                        $bank->chequeNo = $cheque->chequeNo;
//                        $bank->chequeDate = date('Y-m-d', strtotime($cheque->chequeDate));
//                        $bank->amount = $cheque->amount;
//                        $bank->status = 1;
//                        $bank->save();
//                        $cheque->delete();
//                    }
//                }
//                if($chequeTotal+$bankTotal+$paid+$cardAmount < $netTotal){
//                    $invoice->paidDue = 0;
//                    $invoice->due = floatval($netTotal - ($chequeTotal+$bankTotal+$paid+$cardAmount));
//                    $invoice->save();
//
//                    $payment->credit = floatval($netTotal)-floatval($chequeTotal+$bankTotal+$paid+$cardAmount);
//                    $payment->save();
//                }
//            }
//
//            foreach ($temps as $temp){
//                $qty = $temp->qty;
//                $stocks =  Stock::where('Company',$company)->where('status',1)->where('qty_available','>',0)->where('Items_idItems',$temp->items_idItems)->get();
//                foreach ($stocks as $stock) {
//                    $stockQty = $stock->qty_available;
//
//
//
//                    if ($qty < $stockQty) {
//                        $stock->qty_available -= $qty;
//                        $stock->save();
//
//                        $reg  = new InvoiceReg();
//                        $reg->Stock_idStock = $stock->idStock ;
//                        $reg->qty = $qty ;
//                        $reg->rate = $temp->rate ;
//                        $reg->discount = $temp->discount ;
//                        $reg->date = $date;
//                        $reg->status = 1 ;
//                        $reg->returnQty = 0 ;
//                        $reg->invoice_idInvoice = $invoice->idInvoice ;
//                        $reg->save();
//
//                        $qty = 0;
//                        break;
//                    }
//                    elseif ($qty == $stockQty) {
//                        $stock->qty_available -= $qty;
//                        $stock->status = 0;
//                        $stock->save();
//
//                        $reg = new InvoiceReg();
//                        $reg->Stock_idStock = $stock->idStock;
//                        $reg->qty = $qty;
//                        $reg->rate = $temp->rate;
//                        $reg->discount = $temp->discount;
//                        $reg->date = $date;
//                        $reg->status = 1;
//                        $reg->returnQty = 0;
//                        $reg->invoice_idInvoice = $invoice->idInvoice;
//                        $reg->save();
//
//                        $qty = 0;
//                        break;
//                    }
//                        else {
//                        $availableQty = $stock->qty_available;
//                        $qty -= $availableQty;
//                        $stock->status = 0;
//                        $stock->qty_available = 0;
//                        $stock->save();
//
//                        $reg  = new InvoiceReg();
//                        $reg->Stock_idStock = $stock->idStock ;
//                        $reg->qty = $availableQty;
//                        $reg->rate = $temp->rate ;
//                        $reg->discount = $temp->discount ;
//                        $reg->date = $date;
//                        $reg->status = 1 ;
//                        $reg->returnQty = 0 ;
//                        $reg->invoice_idInvoice = $invoice->idInvoice ;
//                        $reg->save();
//
//                    }
//                }
//                if ($qty > 0) {
//                    return response()->json(['errors' => ['error' => 'Process invalid']]);
//
//                }
//
//                $reg  = new InvoiceRegItems();
//                $reg->items_idItems = $temp->items_idItems ;
//                $reg->qty = $temp->qty ;
//                $reg->rate = $temp->rate ;
//                $reg->discount = $temp->discount ;
//                $reg->date = $date;
//                $reg->status = 1 ;
//                $reg->returnQty = 0 ;
//                $reg->invoice_idInvoice = $invoice->idInvoice ;
//                $reg->save();
//                $temp->delete();
//            }
//
//        }
//        else{
//            return response()->json(['errors' => ['error' => 'Available qty is less than requested qty.']]);
//        }
//        return response()->json(['success' => 'Invoice saved successfully.','id'=>$invoice->idInvoice]);
//    }
//
//    public function availableItemCount(Request $request){
//        $item = $request['item'];
//        $company = Auth::user()->Company;
//        $count = Stock::where(function ($query) use ($company,$item){
//                            $query->where('expDate','>=',date('Y-m-d'))->where('Company',$company)->where('Items_idItems',$item)->where('status',1);
//                        })
//                        ->orWhere(function ($query) use ($company,$item){
//                            $query->where('expHave',0)->where('Company',$company)->where('Items_idItems',$item)->where('status',1);
//                        })->sum('qty_available');
//
//        $rate = Item::find($item)->unitPrice;
//        $isScale = Item::find($item)->isScaleItem;
//        $measurement = Item::find($item)->measurement->mian;
//        return response()->json(['isScale'=>$isScale,'count' => $count,'measurement'=>$measurement,'rate'=>$rate]);
//    }
//
//    public function invoiceHistory(){
//
//        $invoices = Invoice::where('status',1)->where('Company',Auth::user()->Company)->latest()->paginate(10);
//        return view('invoice.viewInvoice')->with(['title'=>'Invoice History','invoices'=>$invoices]);
//
//    }
//
//    public  function viewInvoiceReg(Request $request){
//        $id = $request['id'];
//        $regs = InvoiceRegItems::where('invoice_idInvoice',$id)->where('status',1)->get();
//        $tableData = "";
//        foreach ($regs as $reg){
//            $tableData .= "<tr>
//                              <td>".$reg->idinvoice_reg_items."</td>
//                              <td>".$reg->item->itemName."</td>
//                              <td>".$reg->qty."</td>
//                              <td style='text-align: right'>".number_format($reg->rate,2)."</td>
//                              <td style='text-align: right'>".number_format($reg->discount,2)."</td>
//                         </tr>";
//        }
//        return $tableData;
//    }
//
//    public function invoiceSearch(Request $request){
//        $orderId = $request['invoiceId'];
//        $endDate = $request['end'];
//        $startDate = $request['start'];
//        $company = Auth::user()->Company;
//
//
//        if (!empty($orderId)) {
//            $invoices = Invoice::where('idInvoice',$orderId)->where('Company',$company)->where('status',1)->paginate(10);
//            if($invoices !=  null) {
//                return view('invoice.viewInvoice')->with(['title'=>'Invoice History','invoices'=>$invoices]);
//            }
//            else{
//                return view('invoice.viewInvoice')->with(['title'=>'Invoice History','invoices'=>$invoices]);
//            }
//
//        } else if (!empty($startDate) && !empty($endDate)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            $invoices = Invoice::whereBetween('date', [$startDate, $endDate])->where('status',1)->where('Company',$company)->latest()->paginate(10);
//            $invoices->appends(array(
//                'start' => $request['start'],
//                'end' => $request['end']
//            ));
//
//            return view('invoice.viewInvoice')->with(['title'=>'Invoice History','invoices'=>$invoices]);
//        } else {
//            $invoices = Invoice::where('status',1)->where('Company',$company)->latest()->paginate(10);
//            return view('invoice.viewInvoice')->with(['title'=>'Invoice History','invoices'=>$invoices]);
//        }
//    }
//
//    public function invoiceReturn(Request $request){
//        return view('invoice.return_invoice')->with(['title'=>'Return Invoice']);
//    }
//
//    public function invoiceReturnSearch(Request $request){
//        $company = Auth::user()->Company;
//        $invoiceNo = $request['invoiceNo'];
//        $items = InvoiceReg::whereHas("invoice", function($q) use($invoiceNo,$company){
//                $q->where("invoiceNo",$invoiceNo)->where('Company',$company);
//            },true)->where('status',1)->get();
//        return view('invoice.return_invoice')->with(['title'=>'Return Invoice','items'=>$items]);
//    }
//
//    public function returnInvoice(Request $request){
//        $regid = $request['id'];
//        $Tdate = $request['Tdate'];
//        $returnQty = $request['returnQty'];
//        $reason = $request['reason'];
//        $company = Auth::user()->Company;
//
//        $reg = InvoiceReg::find($regid);
//        $reg->returnQty += $returnQty;
//        $reg->save();
//
////        $itemReg =  InvoiceRegItems::where('invoice_idInvoice',$reg->Invoice_idInvoice)->where('items_idItems',$reg->stock->item->idItems)->first();
////        $invoiceRegId = $itemReg->idinvoice_reg_items;
//
//        $regExist = InvoiceReturn::where('Company',$company)->latest()->first();
//
//        if($regExist != null){
//            $refference = $regExist->returnReferances;
//            $reff = intval($refference)+1;
//        }
//        else{
//            $reff  = 1;
//        }
//
//        $return = new InvoiceReturn();
//        $return->Company = $company;
//        $return->returnReferances = $reff;
//        $return->Invoice_id = $reg->Invoice_idInvoice;
//        $return->Invoice_Reg_id = $regid;
//        $return->Stock_idStock = $reg->stock->idStock;
//        $return->returnType = $reason;
//        $return->qty = $returnQty;
//        $return->refundAmount = floatval($reg->rate)*floatval($returnQty);
//        $return->date =  date('Y-m-d', strtotime($Tdate));
//        $return->status = 1;
//        $return->UserMaster_idUser = Auth::user()->idUser;
//        $return->save();
//
//        return response()->json([ 'success' => 'Item successfully returned','returned'=>$reg->returnQty]);
//    }
//    public function invoiceReturnHistory(){
//        $company = Auth::user()->Company;
//        $items = Item::where('status',1)->get();
//        $returns = InvoiceReturn::where('Company',$company)->where('status',1)->latest()->paginate(10);
//        return view('invoice.invoice_return_history')->with(['title'=>'Return Invoice History','returns'=>$returns,'items'=>$items]);
//    }
//
//    public function returnInvHistSearch(Request $request){
//        $stock = $request['stock'];
//        $invoiceNo = $request['invoiceNo'];
//        $returnType = $request['returnType'];
//        $company = Auth::user()->Company;
//
//        $query = InvoiceReturn::query();
//
//        if (!empty($stock)) {
//            $query = $query->where('Stock_idStock', $stock);
//        }
//        if (!empty($invoiceNo)) {
//            $query = $query->whereHas("invoice", function($q) use($invoiceNo,$company){
//                    $q->where("invoiceNo",$invoiceNo)->where('Company',$company);
//                },true);
//        }
//        if (!empty($returnType)) {
//            $query = $query->where('returnType', $returnType);
//        }
////        if (!empty($item)) {
////            $query = $query->with('stock')->whereHas('stock', function($q) use($item){
////                    $q->where('Items_idItems', $item);
////                },null);
////        }
//
//        $query = $query->where('Company',$company)->where('status',1)->latest();
//
//        $returns = $query->paginate(10);
//
//
//        $returns->appends(array(
//                'stock' => $request['stock'],
//                'invoice' => $request['invoice'],
//                'returnType' => $request['returnType'],
////                'item' => $request['item']
//            ));
//
//        $items = Item::where('status',1)->get();
//        return view('invoice.invoice_return_history')->with(['title'=>'Return Invoice History','returns'=>$returns,'items'=>$items]);
//
//    }
//
//    public function PrintInvoice($id = null){
//        $invoice = Invoice::find(intval($id));
//        return view('print.printInvoice')->with("invoice",$invoice);
//    }
//
//
//
//    public function getInvoiceItems(Request $request){
//        $id = $request['id'];
//        $regs = InvoiceRegItems::where('invoice_idInvoice',intval($id))->get();
//        $tableData = "";
//        foreach($regs as $reg){
//            $tableData .= "<tr>";
//            $tableData .= "<td>".$reg->item->itemName."</td>";
//            $tableData .= "<td>".$reg->qty."</td>";
//            $tableData .= "<td style='text-align: right;'>".number_format($reg->rate,2)."</td>";
//            $tableData .= "<td style='text-align: right;'>".number_format($reg->discount,2)."</td>";
//            $tableData .= "</tr>";
//        }
//        return response()->json([ 'tableData' => $tableData]);
//    }
//
//    public function addBarcodeItemToInvoiceTemp(Request $request){
//        $itemCode = sprintf('%05d', ltrim($request['item'], '0'));
//        $qty = floatval($request['qty'])/1000;
//        $item = Item::where('itemcode',$itemCode)->where('status',1)->first();
//        if($item == null){
//            return response()->json(['errors' => ['error' => 'Invalid item code provided.']]);
//        }
//        $available = $this->checkAvailableQty($item->idItems,$qty,Auth::user()->Company);
//        if($available->getData()->availability){
//
//            $isExist = InvoiceTemp::where('items_idItems',$item->idItems)->where('usermaster_idUser',Auth::user()->idUser)->where('rate',$item->unitPrice)->where('status',1)->first();
//            if($isExist != null){
//                $isExist->qty += $qty;
//                $isExist->save();
//            }
//            else {
//                $inv = new InvoiceTemp();
//                $inv->usermaster_idUser = Auth::user()->idUser;
//                $inv->items_idItems = $item->idItems;
//                $inv->discount = 0;
//                $inv->rate = $item->unitPrice;
//                $inv->qty = $qty;
//                $inv->status = 1;
//                $inv->save();
//            }
//            return response()->json([ 'success' => 'Successfully saved']);
//        }
//        else{
//            return response()->json(['errors' => ['error' => 'Qty can not be grater than available qty.']]);
//        }
//    }
//
//    public function checkAvailableQty($itemId, $qty, $company){
//
//        $available = Stock::where(function ($query) use ($company,$itemId){
//            $query->where('expDate','>=',date('Y-m-d'))->where('Company',$company)->where('Items_idItems',$itemId)->where('status',1);
//        })
//            ->orWhere(function ($query) use ($company,$itemId){
//                $query->where('expHave',0)->where('Company',$company)->where('Items_idItems',$itemId)->where('status',1);
//            })->sum('qty_available');
//
//        if($qty<$available){
//            return response()->json(['availability' => true]);
//
//        }
//        else{
//            return response()->json(['availability' => false]);
//
//        }
//
//    }
//}