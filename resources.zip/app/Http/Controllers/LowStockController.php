<?php

namespace App\Http\Controllers;

use App\Brand;
use App\MainCategory;
use App\Stock;
use App\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LowStockController extends Controller
{
    private $take = 10;
    public function index(Request $request){

        $item  = $request['item'];
        $type  = $request['type'];
        $category  = $request['category'];

        $AuthCompany = Auth::user()->Company;
        $skip = isset($request['skip'])?$request['skip']:0;
        $categories = MainCategory::where('status',1)->get();
        $stockTypes = Store::where('status',1)->where('Company',$AuthCompany)->get();
        $types = Brand::where('status', 1)->where('Company',$AuthCompany)->get();

        $stocks =  collect();
        $end = false;
        $start = false;
        $query = Stock::query();

        if (!empty($item)) {
            $query = $query->whereHas("item", function($q) use($item){
                $q->Where('itemName','like', '%' .  $item .'%')->orWhere('itemCode','like', '%' .  $item .'%');
            },true);
        }
        if (!empty($type)) {
            $query = $query->whereHas("item", function($q) use($type){
                $q->where("Item_Type",$type);
            },true);
        }
        if (!empty($category)) {
            $query = $query->whereHas("item", function($q) use($category){
                $q->where("mainCategory",$category);
            },true);
        }

        $stockGroups =  $query->where('Company', $AuthCompany)->where('status', 1)->select('Items_idItems')->distinct()->get();

        foreach ($stockGroups as $stockGroup) {
            $available = Stock::where('Company', $AuthCompany)->where('status',1)->where('Items_idItems',$stockGroup->Items_idItems)->sum('qty_available');
            if($stockGroup->item->low_qty >= $available) {
                $object = new \stdClass();
                $object->item = $stockGroup->item->itemName;
                $object->itemId = $stockGroup->Items_idItems;
                $object->itemCode = $stockGroup->item->itemcode;
                $object->rate = $stockGroup->item->unitPrice;
                $object->low = $stockGroup->item->low_qty;
                $object->type = $stockGroup->item->Brand->type;
                $object->category = $stockGroup->item->MainCategory->catName;

                $object->available = $available;
                $object->measurement = $stockGroup->item->measurement->mian;
                $stocks[] = $object;
            }
        }

        $last = count($stocks);
        if($skip+$this->take >= $last){
            $end = true;
        }
        if($skip-$this->take < 0){
            $start = true;
        }
        if($last%$this->take == 0) {
            $lastPage = (floor($last / $this->take) * $this->take)-$this->take;
        }
        else{
            $lastPage = floor($last / $this->take) * $this->take;
        }

        $stocks = $stocks->slice($skip, $this->take);
        $startLink = route('lowStock',['skip'=>0,'item'=>$item,'type'=>$type,'category'=>$category]);
        $prevLink = route('lowStock',['skip'=>$skip-$this->take,'item'=>$item,'type'=>$type,'category'=>$category]);
        $nextLink = route('lowStock',['skip'=>$skip+$this->take,'item'=>$item,'type'=>$type,'category'=>$category]);
        $lastLink = route('lowStock',['skip'=>$lastPage,'item'=>$item,'type'=>$type,'category'=>$category]);
        return view('stock.low_stock', ['categories'=>$categories,'paginator'=>$stocks,'types'=>$types,'title' => 'Low Stock','stockTypes'=>$stockTypes,'prevLink'=>$prevLink,'nextLink'=>$nextLink,'lastLink'=>$lastLink,'startLink'=>$startLink,'last'=>$last,'end'=>$end,'start'=>$start,]);

    }
}
