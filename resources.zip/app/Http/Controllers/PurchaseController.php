<?php
///**
// * Created by PhpStorm.
// * User: ishar
// * Date: 3/10/2019
// * Time: 11:14 AM
// */
//
//namespace App\Http\Controllers;
//
//
//
//
//use App\CompanyInfo;
//use App\Item;
//use App\Measurement;
//use App\Purchase;
//use App\PurchaseOrderReg;
//use App\PurchaseTempary;
//use App\Supplier;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Auth;
//
//class PurchaseController extends Controller
//{
//    public  function createPO(){
//        $suppliers = Supplier::where('status', '1')->get();
//        $items = Item::where('status', 1)->get();
//        $measurements = Measurement::where('status', 1)->get();
//        $companies = CompanyInfo::where('status',1)->get();
//        return view('purchase.addPO')->with(['title'=>'Purchase orders','suppliers'=>$suppliers,'items'=>$items,'measurements'=>$measurements,'companies'=>$companies]);
//    }
//
//    public function addItemPO(Request $request){
//        $item = $request['item'];
////        $measurement = $request['measurement'];
//        $bPrice = $request['bPrice'];
//        $qtyGrn = $request['qty'];
//
//        $validator = \Validator::make($request->all(), [
//            'item' => 'required',
////            'measurement' => 'required',
//            'bPrice' => 'required',
//            'qty' => 'required'
//        ], [
//            'item.required' => 'Item should be provided!',
////            'measurement.required' => 'Measurement should be provided!',
//            'bPrice.required' => 'Buying price should be provided!',
//            'qty.required' => 'Qty should be provided!',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//
//        $po = new PurchaseTempary();
//        $po->items_idItems= $item;
////        $po->measurement_idMeasurement= $measurement;
//        $po->bp= $bPrice;
//        $po->qty= $qtyGrn;
//        $po->status = 1;
//        $po->usermaster_idUser = Auth::user()->idUser;
//        $po->save();
//
//        return response()->json([ 'success' => 'Successfully saved']);
//
//    }
//
//    public function getTempPurchaseData(){
//
//        $tableData = "";
//        $total = 0;
//        $items = PurchaseTempary::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        if($items != null){
//            foreach ($items as $item){
//                $total += $item->bp*$item->qty;
//                $tableData .= "<tr id=".$item->idpo_temp.">
//                                    <td>".$item->item->itemName."</td>
//                                    <td>".$item->qty."</td>
//                                    <td style='text-align: right '>".number_format($item->bp,2)."</td>
//                                    <td style='text-align: right '>".number_format($item->bp*$item->qty,2)."</td>
//                                    <td>
//                                            <div class='button-items'>
//                                                <button type='button'
//                                                        class='btn btn-sm btn-danger  waves-effect waves-light'
//                                                        data-id=".$item->idpo_temp."
//                                                        onclick='deleteTempPurchase(this)'>
//                                                        <i class='fa fa-trash'></i>
//                                                 </button>
//
//                                            </div>
//                                    </td>
//                                </tr>";
//            }
//
//        }
//        else{
//            $tableData= "<tr>
//                        <td colspan='5'>No available items.</td>
//                     </tr>";
//        }
//        return response()->json([ 'tableData' => $tableData,'total'=>number_format($total,2)]);
//
//    }
//
//    public function deleteTempPurchase(Request $request){
//        $id = $request['id'];
//        $tempItemp = PurchaseTempary::find($id);
//        $tempItemp->delete();
//
//    }
//
//    public function savePurchaseOrder(Request $request){
//        $validator = \Validator::make($request->all(), [
//            'supplier' => 'required',
//            'company' => 'required',
//            'date' => 'required',
//            'payment' => 'required',
//            'total'=>'required'
//        ], [
//            'supplier.required' => 'Supplier should be provided!',
//            'company.required' => 'Company should be provided!',
//            'date.required' => 'Date should be provided!',
//            'payment.required' => 'Payment tyoe should be provided!',
//            'total.required' => 'Total should be provided!',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $items = PurchaseTempary::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        if($items != null){
//
//            $orderNumber = Purchase::where('Company',$request['company'])->latest()->first();
//            if($orderNumber == null){
//                $orderNumber = 1;
//            }
//            else{
//                $orderNumber = $orderNumber->poNo;
//            }
//            $purchase = new Purchase();
//            $purchase->poNo = 1+intval($orderNumber);
//            $purchase->Company = $request['company'];
//            $purchase->Supplier_idSupplier = $request['supplier'];
//            $purchase->total = floatval($request['total']);
//            $purchase->paymentType = $request['payment'];
//            $purchase->date	 = date('Y-m-d', strtotime($request['date']));
//            $purchase->UserMaster_idUser = Auth::user()->idUser;
//            $purchase->status = 1;
//            $purchase->save();
//
//            foreach ($items as $item){
//                $reg = new PurchaseOrderReg();
//                $reg->items_idItems = $item->items_idItems ;
////                $reg->idMeasurement = $item-> measurement_idMeasurement
//                $reg->qty = $item->qty;
//                $reg-> bp= $item->bp ;
//                $reg-> status= 1 ;
//                $reg->Purchase_Order_idPO = $purchase->idPO;
//                $reg->save();
//                $item->delete();
//            }
//            return response()->json(['success' => 'Success']);
//        }
//        else{
//            return response()->json(['errors' => ['error' => 'No items available.']]);
//        }
//
//    }
//
//    public function viewPo(){
//        $orders = Purchase::where('status',1)->orderBy('idPO','DESC')->paginate(10);
//        return view('purchase.viewPo')->with(['title'=>'Purchase History','orders'=>$orders]);
//    }
//
//    //search GRN
//    public function PoSearch(Request $request)
//    {
//
//        $orderId = $request['orderId'];
//        $endDate = $request['end'];
//        $startDate = $request['start'];
//
//        if (!empty($orderId)) {
//            $orders = Purchase::where('idPO',$orderId)->where('status',1)->paginate(10);
//            if($orders !=  null) {
//                return view('purchase.viewPo')->with(['from'=>'exits','orders' => $orders, 'searchID' => $orderId,'title' => 'View Purchase SpecialOrder']);
//            }
//            else{
//                return view('purchase.viewPo')->with(['from'=>'none','title' => 'View Purchase SpecialOrder']);
//            }
//
//        } else if (!empty($startDate) && !empty($endDate)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            $orders = Purchase::whereBetween('date', [$startDate, $endDate])->where('status',1)->latest()->paginate(10);
//            $orders->appends(array(
//                'start' => $request['start'],
//                'end' => $request['end']
//            ));
//
//            return view('purchase.viewPo')->with(['orders' => $orders, 'from' => $startDate, 'to' => $endDate,'title' => 'View Purchase SpecialOrder']);
//        } else {
//            $orders = Purchase::where('status',1)->latest()->paginate(10);
//            return view('purchase.viewPo')->with(['orders'=> $orders,'title' => 'View Purchase SpecialOrder']);
//        }
//
//    }
//
//    public function viewPurchaseReg(Request $request){
//        $id = $request['id'];
//        $regs = PurchaseOrderReg::where('Purchase_Order_idPO',$id)->where('status',1)->get();
//        $tableData = "";
//       foreach ($regs as $reg){
//           $tableData .= "<tr>
//                              <td>".$reg->idPO_Reg."</td>
//                              <td>".$reg->item->itemName."</td>
//                              <td>".$reg->qty."</td>
//                              <td style='text-align: right'>".number_format($reg->bp,2)."</td>
//                         </tr>";
//       }
//        return $tableData;
//    }
//
//
//}