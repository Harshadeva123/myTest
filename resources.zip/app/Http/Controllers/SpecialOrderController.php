<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/15/2019
// * Time: 8:04 AM
// */
//
//namespace App\Http\Controllers;
//
//
//use App\BankPaymentsTemp;
//use App\ChequePaymentTemp;
//use App\CompanyInfo;
//use App\Payment;
//use App\PaymentType;
//use App\SpecialOrder;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Auth;
//
//class SpecialOrderController extends Controller
//{
//    public function createSo()
//    {
//        $companies = CompanyInfo::where('status',1)->get();
//        $paymentTypes = PaymentType::where('status',1)->get();
//        return view('special.createSo')->with(['paymentTypes'=>$paymentTypes,'title'=>'Special Order','companies'=>$companies]);
//    }
//
//    public function pendingSo()
//    {
//        $specials = SpecialOrder::where('status',2)->orderBy('idOrder','DESC')->paginate(10);
//        return view('special.pendingSo')->with(['title'=>'Pending Special Orders','specials'=>$specials]);
//    }
//
//    public function approvedSo()
//    {
//        $paymentTypes = PaymentType::where('status',1)->get();
//        $specials = SpecialOrder::where('status',1)->orderBy('idOrder','DESC')->paginate(10);
//        return view('special.approvedOrder')->with(['paymentTypes'=>$paymentTypes,'title'=>'Approved Special Orders','specials'=>$specials]);
//    }
//
//    public function saveSalesOrder(Request $request)
//    {
//       $validator = \Validator::make($request->all(), [
////           'company' => 'required',
//           'Cname' => 'required',
//           'qty' => 'required',
//           'amount' => 'required',
//           'payment' => 'required',
//        ], [
////            'company.required' => 'Company should be provided!',
//           'Cname.required' => 'Customer name price should be provided!',
//           'qty.required' => 'Qty should be provided!',
//           'amount.required' => 'Amount should be provided!',
//           'payment.required' => 'Payment Type should be provided!',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        if(Auth::user()->companyInfo->isBranch == 0){
//            $validator = \Validator::make($request->all(), [
//                'company' => 'required',
//            ], [
//                'company.required' => 'Company should be provided!',
//            ]);
//
//            if ($validator->fails()) {
//                return response()->json(['errors' => $validator->errors()->all()]);
//            }
//            $company = $request['company'];
//        }
//        else{
//            $company = Auth::user()->Company;
//        }
//
//
//        $totalAmount = $request['amount'];
//        $paid = $request['paid'];
//        $visaBill = $request['visaBill'];
//        $cardAmount = $request['cardAmount'];
//        $paymentType = intval($request['payment']);
//
//
//        $orderDate = date('Y-m-d', strtotime($request['orderDate']));
//        $deliveryDate = date('Y-m-d', strtotime($request['deliveryDate']));
//
//        $advance = 0;
//        if($paymentType == 1){
//            if($paid == null){
//                return response()->json(['errors' => ['error' => 'Paid amount should be provided.']]);
//            }
//            $advance = $paid;
//        }
//        if($paymentType == 3){
//           $bankAmount =  floatval(BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->sum('amount'));
//            if($bankAmount == null || $bankAmount == 0){
//                return response()->json(['errors' => ['error' => 'At leaset one bank should be added.']]);
//            }
//           $advance = $bankAmount;
//        }
//        if($paymentType == 4){
//            if($cardAmount == null){
//                return response()->json(['errors' => ['error' => 'Card Amount should be provided.']]);
//            }
//            if($visaBill == null){
//                return response()->json(['errors' => ['error' => 'Card No should be provided.']]);
//            }
//            $advance = $cardAmount;
//        }
//        if($paymentType == 5){
//            $chequepayment = floatval(ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->sum('amount'));
//            if($chequepayment == null || $chequepayment == 0){
//                return response()->json(['errors' => ['error' => 'At leaset one cheque payment should be added.']]);
//            }
//            $advance = $chequepayment;
//        }
//        if($paymentType == 6){
//            if($paid != null){
//                $advance += $paid;
//            }
//            if($cardAmount != null){
//                $advance += $cardAmount;
//            }
//            $banks = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//            if($banks != null){
//                $advance += $banks->sum('amount');
//            }
//            $cheque  = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//            if($cheque != null){
//                $advance += $cheque->sum('amount');
//            }
//        }
//
//        $order = new SpecialOrder();
//        $order->Company= $company;
//        $order->CustomerName = $request['Cname'];
//        $order->contactNo = $request['contact'];
//        $order->orderDate = $orderDate;
//        $order->deliveryDate = $deliveryDate;
//        $order->specialNote = $request['note'];
//        $order->remarks = $request['remark'];
//        $order->amount= $totalAmount ;
//        $order->payment_type= $paymentType;
//        $order->advanced = $advance;
//        $order->due = floatval($totalAmount) - floatval($advance);
//        $order->paidDue = 0;
//        $order->status = 2;
//        $order->UserMaster_idUser = Auth::user()->idUser;
//        $order->save();
//
//        $payment = new Payment();
//        $payment->Company = Auth::user()->Company;
//        $payment->payment_type_idpayment_type = $paymentType;
//        $payment->base = 3;
//        $payment->id = $order->idOrder;
//        $payment->totalAmount = $totalAmount ;
//        $payment->cash	= $paid;
//        $payment->credit = 0;
//        $payment->cheque = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->sum('amount');
//        $payment->bank = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->sum('amount');
//        $payment->visa = $cardAmount;
//        $payment->visaBillNo = $visaBill;
//        $payment->status = 1;
//        $payment->usermaster_idUser = Auth::user()->idUser;
//        $payment->save();
//
//        ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->delete();
//        BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->delete();
//
//
//        return response()->json([ 'success' => 'Successfully saved','id'=>$order->idOrder]);
//
//    }
//
//    public function viewSo()
//    {
//        if(Auth::user()->companyInfo->isBranch == 0) {
//            $orders = SpecialOrder::where('status',0)->latest()->paginate(10);
//        }
//        else{
//            $orders = SpecialOrder::where('status',0)->where('Company',Auth::user()->Company)->latest()->paginate(10);
//        }
//        return view('special.viewSo')->with(['orders'=>$orders,'title'=>'Special Orders History']);
//    }
//
//    public function viewSalesOrder(Request $request)
//    {
//        $id = $request['id'];
//        $order = SpecialOrder::find(intval($id));
//        $tableData = "";
//            $tableData .= " <tr>
//                                            <td width='50%'>DailyOrder No </td>
//                                            <td width='50%'>SP/".$order->idOrder."</td>
//                             </tr>
//                             <tr>
//                                            <td width='50%'>Company name </td>
//                                            <td width='50%'>".$order->companyInfo->companyName."</td>
//                             </tr>
//                             <tr>
//                                            <td width='50%'>Customer name </td>
//                                            <td width='50%'>".$order->CustomerName."</td>
//                             </tr>
//                              <tr>
//                                            <td width='50%'>Contact No </td>
//                                            <td width='50%'>".$order->contactNo."</td>
//
//                             </tr>
//                              <tr>
//                                            <td width='50%'>SpecialOrder Date </td>
//                                            <td width='50%'>".$order->orderDate."</td>
//
//                             </tr>
//                              <tr>
//                                            <td width='50%'>Delivery Date </td>
//                                            <td width='50%'>".$order->deliveryDate."</td>
//
//                             </tr>
//                              <tr>
//                                            <td width='50%'>Total Amount </td>
//                                            <td width='50%'>".number_format($order->amount,2)."</td>
//
//                             </tr>
//                              <tr>
//                                            <td width='50%'>Advanced Payment </td>
//                                            <td width='50%'>".number_format($order->advanced,2)."</td>
//
//                             </tr>
//                              <tr>
//                                            <td title='Paid Total = Advanced payment + Due payments' width='50%'>Paid Total </td>
//                                            <td title='Paid Total = Advanced payment + Due payments' width='50%'>".number_format($order->paidDue + $order->advanced,2)."</td>
//
//                              </tr>
//                              <tr>
//                                            <td title='Payment Due = Total Amount - Paid Total' width='50%'>Payment Due</td>
//                                            <td title='Payment Due = Total Amount - Paid Total' width='50%'>".number_format($order->amount - ($order->paidDue + $order->advanced),2)."</td>
//
//                             </tr>
//                              <tr>
//                                            <td width='50%'>Special Notes </td>
//                                            <td width='50%'>".$order->specialNote."</td>
//
//                             </tr>
//                              <tr>
//                                            <td width='50%'>Remarks </td>
//                                            <td width='50%'>".$order->remarks."</td>
//
//                             </tr>";
//        return $tableData;
//    }
//
//    public function soSearch(Request $request)
//    {
//        $orderId = $request['orderId'];
//        $endDate = $request['end'];
//        $startDate = $request['start'];
//
//        if (!empty($orderId)) {
//            $orders = SpecialOrder::where('status',0)->where('idOrder',$orderId)->paginate(10);
//            if($orders !=  null) {
//                return view('special.viewSo')->with(['orders'=>$orders,'title'=>'Special Orders History']);
//            }
//            else{
//                return view('special.viewSo')->with(['orders'=>$orders,'title'=>'Special Orders History']);
//            }
//
//        } else if (!empty($startDate) && !empty($endDate)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            $orders = SpecialOrder::where('status',0)->whereBetween('orderDate', [$startDate, $endDate])->latest()->paginate(10);
//            $orders->appends(array(
//                'start' => $request['start'],
//                'end' => $request['end']
//            ));
//
//            return view('special.viewSo')->with(['orders'=>$orders,'title'=>'Special Orders History']);
//        } else {
//            $orders = SpecialOrder::where('status',0)->latest()->paginate(10);
//            return view('special.viewSo')->with(['orders'=>$orders,'title'=>'Special Orders History']);
//        }
//
//    }
//
//    public function SoPendingSearch(Request $request)
//    {
//        $orderId = $request['orderId'];
//        $endDate = $request['end'];
//        $startDate = $request['start'];
//
//        if (!empty($orderId)) {
//            $orders = SpecialOrder::where('idOrder',$orderId)->paginate(10);
//            if($orders !=  null) {
//                return view('special.pendingSo')->with(['specials'=>$orders,'title'=>'Pending Special Orders']);
//            }
//            else{
//                return view('special.pendingSo')->with(['specials'=>$orders,'title'=>'Pending Special Orders']);
//            }
//
//        } else if (!empty($startDate) && !empty($endDate)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            $orders = SpecialOrder::whereBetween('orderDate', [$startDate, $endDate])->latest()->paginate(10);
//            $orders->appends(array(
//                'start' => $request['start'],
//                'end' => $request['end']
//            ));
//
//            return view('special.pendingSo')->with(['specials'=>$orders,'title'=>'Pending Special Orders']);
//        } else {
//            $orders = SpecialOrder::latest()->paginate(10);
//            return view('special.pendingSo')->with(['specials'=>$orders,'title'=>'Pending Special Orders']);
//        }
//
//    }
//
//    public function approveSOrder(Request $request)
//    {
//       $id = $request['id'];
//       $special = SpecialOrder::find($id);
//       if($special != null) {
//           $special->status = 1;
//           $special->save();
//           return response()->json([ 'success' => 'success']);
//       }
//    else{
//        return response()->json([ 'error' => 'Order not found']);
//       }
//
//    }
//
//    public function checkSODue(Request $request)
//    {
//        $id = $request['id'];
//        $order = SpecialOrder::find($id);
//        $due = $order->amount - ($order->advanced + $order->paidDue);
//        return response()->json([ 'due' => $due]);
//    }
//
//    public function markAsDeliveredSO(Request $request)
//    {
//        $id = $request['id'];
//        $special = SpecialOrder::find($id);
//        $special->status = 0;
//        $special->save();
//    }
//
//    public function DeliveredWithPaymentSO(Request $request)
//    {
//        $validator = \Validator::make($request->all(), [
//            'id' => 'required',
//            'payment' => 'required',
//        ], [
//            'id.required' => 'Invalid id has been provided for special order.',
//            'payment.required' => 'Payment Type should be provided.',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $id = $request['id'];
//        $paid = $request['paid'];
//        $visaBill = $request['visaBill'];
//        $paymentType = intval($request['payment']);
//        $order = SpecialOrder::find($id);
//        $due = floatval($order->amount - ($order->advanced + $order->paidDue));
//        $cardAmount = $request['cardAmount'];
//        $bankAmount = 0 ;
//        $chequepayment = 0 ;
//        $totalPaid = 0;
//        $totalCredit = 0;
//        $free = 0;
//
//        if($paymentType == 1){
//            if($paid == null){
//                return response()->json(['errors' => ['error' => 'Paid amount should be provided.']]);
//            }
//            if($due > $paid){
//                return response()->json(['errors' => ['error' => "Payment amount is lower than due amount.please change 'PAYMENT TYPE' for add credit payments."]]);
//            }
//            $totalPaid = $paid;
//        }
//        if($paymentType == 2){
//            if($paid == null){
//                return response()->json(['errors' => ['error' => 'Paid amount should be provided.']]);
//            }
//            if($due <= $paid){
//                return response()->json(['errors' => ['error' => "Zero (0) amount goes to credit.Please change 'PAYMENT TYPE' into 'CASH'."]]);
//            }
//            $totalPaid = $paid;
//            $totalCredit = $due-$paid;
//        }
//
//        if($paymentType == 3){
//            $bankAmount =  floatval(BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->sum('amount'));
//            if($bankAmount == null || $bankAmount == 0){
//                return response()->json(['errors' => ['error' => 'At leaset one bank should be added.']]);
//            }
//            if($bankAmount < $due){
//                return response()->json(['errors' => ['error' => "Payment amount is lower than due amount.please change 'PAYMENT TYPE' for add credit payments."]]);
//            }
//            if($bankAmount > $due){
//                return response()->json(['errors' => ['error' => "Bank amount is grater than due amount."]]);
//            }
//            $totalPaid = $bankAmount;
//        }
//        if($paymentType == 4){
//            if($cardAmount == null){
//                return response()->json(['errors' => ['error' => 'Card amount should be provided.']]);
//            }
//            if($visaBill == null){
//                return response()->json(['errors' => ['error' => 'Card No should be provided.']]);
//            }
//            if($cardAmount < $due){
//                return response()->json(['errors' => ['error' => "Payment amount is lower than due amount.please change 'PAYMENT TYPE' for add credit payments."]]);
//            }
//            if($cardAmount > $due){
//                return response()->json(['errors' => ['error' => "Card amount is grater than due amount."]]);
//            }
//            $totalPaid = $cardAmount;
//        }
//        if($paymentType == 5){
//            $chequepayment = floatval(ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->sum('amount'));
//            if($chequepayment == null || $chequepayment == 0){
//                return response()->json(['errors' => ['error' => 'At least one cheque payment should be added.']]);
//            }
//            if($chequepayment < $due){
//                return response()->json(['errors' => ['error' => "Payment amount is lower than due amount.please change 'PAYMENT TYPE' for add credit payments."]]);
//            }
//            if($chequepayment > $due){
//                return response()->json(['errors' => ['error' => "Cheque amount is grater than due amount."]]);
//            }
//            $totalPaid = $chequepayment;
//        }
//
//        if($paymentType == 6){
//            if($paid != null){
//                $totalPaid += $paid;
//            }
//            if($cardAmount != null){
//                if($visaBill == null){
//                    return response()->json(['errors' => ['error' => 'Card No should be provided.']]);
//                }
//                $totalPaid += $cardAmount;
//            }
//            $banks = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//            if($banks != null){
//                $totalPaid += $bankAmount = $banks->sum('amount');
//            }
//            $cheque  = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//            if($cheque != null){
//                $totalPaid += $chequepayment = $cheque->sum('amount');
//            }
//            if($due < $totalPaid){
//                return response()->json(['errors' => ['error' => 'Total paid amount is grater than due amount.']]);
//            }
//            $totalCredit = $due - $totalPaid;
//        }
//
//        if($paymentType == 7){
//            $totalPaid = $due;
//            $free = $due;
//        }
//
//        $order = SpecialOrder::find($id);
//        $order->paidDue += $totalPaid;
//        $order->status = 0;
//        $order->save();
//
//        $payment = new Payment();
//        $payment->Company = Auth::user()->Company;
//        $payment->payment_type_idpayment_type = $paymentType;
//        $payment->base = 3;
//        $payment->id = $id;
//        $payment->totalAmount = $totalPaid ;
//        $payment->cash	= $paid;
//        $payment->credit = $totalCredit;
//        $payment->cheque = $chequepayment;
//        $payment->bank = $bankAmount;
//        $payment->visa = $cardAmount;
//        $payment->visaBillNo = $visaBill;
//        $payment->free = $free;
//        $payment->status = 1;
//        $payment->usermaster_idUser = Auth::user()->idUser;
//        $payment->save();
//
//        ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->delete();
//        BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->delete();
//
//        return response()->json([ 'success' => 'Successfully saved','id'=>$order->idOrder]);
//    }
//
//    public function PrintSO($id = null){
//        $order = SpecialOrder::find(intval($id));
//        return view('print.printSO')->with("order",$order);
//    }
//}