<?php
///**
// * Created by PhpStorm.
// * User: Nimesh VGS
// * Date: 2/7/2020
// * Time: 1:18 PM
// */
//
//namespace App\Http\Controllers;
//
//
//use App\Http\Controllers\Controller;
//use App\PettyCash;
//use Carbon\Carbon;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Auth;
//
//class PettyCashController extends Controller
//{
//    public function petty_cash(){
//        $getLastRecord=PettyCash::where('Company',Auth::user()->Company)->where('status',1)->latest('idpetty_cash')->first();
//
//
//        $systemDate = Carbon::now()->format('y/m/d');
//        $getPettyCashDetails=PettyCash::where('date',$systemDate)->where('Company',Auth::user()->Company)->get();
//
//
//        return view('pettycash.petty_cash',['title'=>'Petty Cash','getPettyCashDetails'=>$getPettyCashDetails,'getLastRecord'=>$getLastRecord]);
//    }
//
//    public function pettyCashSearch(Request $request){
//        $getLastRecord=PettyCash::where('Company',Auth::user()->Company)->where('status',1)->latest('idpetty_cash')->first();
//
//        $endDate = $request['end'];
//        $startDate = $request['start'];
//
//        if (!empty($startDate) && !empty($endDate)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//
//            $getPettyCashDetails = PettyCash::whereBetween('date', [$startDate, $endDate])->where('Company',Auth::user()->Company)->where('status',1)->paginate(10);
//            $getPettyCashDetails->appends(array(
//                'start' => $request['start'],
//                'end' => $request['end']
//            ));
//
//            return view('petty_cash.petty_cash')->with(['getLastRecord'=>$getLastRecord,'title'=>'Petty Cash','getPettyCashDetails'=>$getPettyCashDetails]);
//        }
//        else{
//            $systemDate = Carbon::now()->format('y/m/d');
//            $getPettyCashDetails=PettyCash::where('date',$systemDate)->where('Company',Auth::user()->Company)->where('status',1)->get();
//            return view('pettycash.petty_cash',['title'=>'Petty Cash','getPettyCashDetails'=>$getPettyCashDetails,'getLastRecord'=>$getLastRecord]);
//        }
//    }
//
//
//
//}