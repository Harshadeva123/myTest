<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BinCardController extends Controller
{
    public function index(Request $request){
        return view('binCard.bin_card')->with(['title'=>'Bin Card']);
    }
}
