<?php
///**
// * Created by PhpStorm.
// * User: ishar
// * Date: 3/10/2019
// * Time: 11:14 AM
// */
//
//namespace App\Http\Controllers;
//
//use App\Item;
//use App\ItemIssueList;
//use App\ItemIssueTemp;
//use App\Package;
//use App\ProductionIssue;
//use App\ProductionOutput;
//use App\ProductionOutputTemp;
//use App\Section;
//use App\Stock;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Auth;
//use Illuminate\Support\Facades\DB;
//use App\StockType;
//
//
//class ProductionController extends Controller
//{
//    public function issueMeterials(){
//        $matirials = Item::where('status',1)->where('Item_Type',1)->get();
//        $sections = Section::where('status',1)->get();
//        $stores = StockType::where('status',1)->where('Company',Auth::user()->Company)->get();
//        return view('production.issue_meterial')->with(['sections'=>$sections,'stores'=>$stores,'items'=>$matirials,'title'=>'Issue Production']);
//    }
//
//    public function addItemIssueTemp(Request $request){
//        $validator = \Validator::make($request->all(), [
//            'item' => 'required',
//            'qty' => 'required|min:0|not_in:0',
//            'store' => 'required',
//        ], [
//            'item.required' => 'Item should be provided.',
//            'qty.required' => 'Qty should be provided',
//            'store.required' => 'Store should be provided',
//            'qty.min' => 'Qty must be grater than 0',
//            'qty.not_in' => 'Qty must be grater than 0',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $item  = $request['item'];
//        $qty  = $request['qty'];
//        $store  = $request['store'];
//
//        $isExist = ItemIssueTemp::where('base',2)->where('items_idItems',$item)->where('stock_type_idStock_Type',$store)->where('usermaster_idUser',Auth::user()->idUser)->where('status',1)->first();
//        if($isExist != null){
//            $isExist->qty += $qty;
//            $isExist->save();
//            return response()->json(['success' => 'Product qty updated.']);
//        }
//        else {
//            $temp = new ItemIssueTemp();
//            $temp->qty = $qty;
//            $temp->base = 2;
//            $temp->items_idItems = $item;
//            $temp->stock_type_idStock_Type = $store;
//            $temp->status = 1;
//            $temp->usermaster_idUser = Auth::user()->idUser;
//            $temp->save();
//            return response()->json(['success' => 'Product added to list.']);
//        }
//    }
//
//    public function availableStoreSelect(Request $request){
//        $item = $request['item'];
//        $company = Auth::user()->Company;
//
//        $deliveryId = StockType::where('type','DELIVERY SECTION STORE')->first()->idStock_Type;
//        $stores =   Stock::where(function ($query) use ($company,$item,$deliveryId){
//                        $query->Where('Company',$company)->Where('Items_idItems',$item)->Where('qty_available','>',0)->where('Stock_Type','!=',$deliveryId)->where('expDate','>=',date('Y-m-d'))->where('status',1);
//                    })->orWhere(function ($query) use ($company,$item,$deliveryId){
//                        $query->Where('Company',$company)->Where('Items_idItems',$item)->Where('qty_available','>',0)->where('Stock_Type','!=',$deliveryId)->where('expHave',0)->where('status',1);
//                    })->select('Stock_Type')->distinct()->get();
//
//        $options = "";
//        if($stores != null && $item !== null) {
//            if(count($stores) > 0){
//            $options .= "<option selected disabled value=''>Select store</option>";
//            foreach ($stores as $store) {
//                $options .= "<option value=" . $store->Stock_Type . ">" . $store->stockTypes->type . "</option>";
//            }
//            }
//            else{
//                $options .= "<option selected disabled value=''>Item not available in any store.</option>";
//            }
//        }
//        else{
//            $options .= "<option selected disabled value=''>Select Store</option>";
//        }
//        return response()->json(['store'=>$options]);
//    }
//
//    public function availibleItemsByStore(Request $request){
//        $item = $request['item'];
//        $store = $request['store'];
//        $company = Auth::user()->Company;
//        $count = Stock::where(function ($query) use ($company,$item,$store){
//            $query->where('expDate','>=',date('Y-m-d'))->where('Stock_Type',$store)->where('Company',$company)->where('Items_idItems',$item)->where('status',1);
//        })
//            ->orWhere(function ($query) use ($company,$item,$store){
//                $query->where('expHave',0)->where('Company',$company)->where('Stock_Type',$store)->where('Items_idItems',$item)->where('status',1);
//            })->sum('qty_available');
//        $measurement = Item::find($item)->measurement->mian;
//        return response()->json(['count' => $count,'measurement'=>$measurement]);
//    }
//
//    public function getItemIssueTemp(){
//
//        $temps = ItemIssueTemp::where('base',2)->where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        $tableData = "";
//        if(!empty($temps)) {
//            foreach ($temps as $temp) {
//                $tableData .= "<tr id=" . $temp->item_issue_temp_id . ">
//                                <td>
//                                " . $temp->item->itemName . "
//                                </td>
//                                <td>
//                                " . $temp->store->type . "
//                                </td>
//                                 <td>
//                                " . $temp->qty . "
//                                </td>
//                                <td style='text-align: center'>
//                                <div class='button-items'>
//                                    <button type='button'
//                                            class='btn btn-sm btn-danger  waves-effect waves-light'
//                                            data-id='" . $temp->item_issue_temp_id . "'
//                                            onclick='deleteTempIssue(this)'>
//                                            <i class='fa fa-trash'></i>
//                                     </button>
//
//                                </div>
//                                </td>
//                            </tr>";
//            }
//        }
//        return $tableData;
//    }
//
//
//    public  function deleteTempIssue(Request $request){
//        $id = $request['id'];
//        $item = ItemIssueTemp::find($id);
//        $item->delete();
//    }
//
//      public  function deleteTempProductionOut(Request $request){
//            $id = $request['id'];
//            $item = ProductionOutputTemp::find($id);
//            $item->delete();
//        }
//
////    public function addExpectedItem(Request $request){
////        $validator = \Validator::make($request->all(), [
////            'product' => 'required',
////            'expected' => 'required|min:0|not_in:0',
////        ], [
////            'product.required' => 'Expected product required',
////            'expected.required' => 'Expected Qty required',
////            'expected.min' => 'Expected Qty must be grater than 0',
////            'expected.not_in' => 'Expected Qty must be grater than 0',
////        ]);
////
////        if ($validator->fails()) {
////            return response()->json(['errors' => $validator->errors()->all()]);
////        }
////
////        $product = $request['product'];
////        $expectedQty = $request['expected'];
////
////        $isExist = ExpectedTemp::where('items_idItems',$product)->where('usermaster_idUser',Auth::user()->idUser)->where('status',1)->first();
////        if($isExist != null){
////            $isExist->qty += $expectedQty;
////            $isExist->save();
////            return response()->json(['success' => 'Expected product qty updated.']);
////        }
////        else {
////        $temp = new ExpectedTemp();
////        $temp->qty = $expectedQty;
////        $temp->items_idItems = $product;
////        $temp->usermaster_idUser = Auth::user()->idUser;
////        $temp->status = 1;
////        $temp->save();
////            return response()->json(['success' => 'Expected product added.']);
////        }
////
////    }
//
//    public  function getItemMeasurement(Request $request){
//        $measurement = Item::find($request['id']);
//        return response()->json(['measurement' => $measurement->measurement->measurement,'measurementId'=>$measurement->measurement]);
//    }
//
//    public function saveItemIssued(Request $request){
//        $section = $request['section'];
//        $validator = \Validator::make($request->all(), [
//            'section' => 'required',
//        ], [
//            'section.required' => 'Section should be provided',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//        $deliveryId = StockType::where('type','DELIVERY SECTION STORE')->first()->idStock_Type;
//
//        $company = Auth::user()->Company;
//        $user = Auth::user()->idUser;
//        $pass = true;
//        $temps = ItemIssueTemp::where('base',2)->where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        if($temps == null || empty($temps) || count($temps)==0){
//            $pass = false;
//            return response()->json(['errors' => ['error' => 'No items available.']]);
//        }
//        else{
//            foreach ($temps as $temp) {
//                $available = Stock::where('Company', $company)->where('status', 1)->where('Stock_Type',$temp->stock_type_idStock_Type)->where('Items_idItems', $temp->items_idItems)->sum('qty_available');
//
//                if (floatval($temp->qty) > floatval($available)) {
//                    $pass = false;
//                    return response()->json(['errors' => ['error' => 'Available \''.$temp->item->itemName.'\' quantity in  \''.$temp->store->type.'\' is lower than requested quantity.']]);
//                }
//            }
//        }
//
//
//        if($pass) {
//            $issue = new ProductionIssue();
//            $issue->Company = $company;
//            $issue->base = 2;
//            $issue->date = date('Y-m-d');
//            $issue->Section_idSection = $section;
//            $issue->UserMaster_idUser = Auth::user()->idUser;
//            $issue->status = 1;
//            $issue->save();
//
//
//
//            foreach ($temps as $temp) {
//                $qty = $temp->qty;
//                $stocks = Stock::where('Company', $company)->where('status', 1)->where('Stock_Type',$temp->stock_type_idStock_Type)->where('Items_idItems', $temp->items_idItems)->get();
//                foreach ($stocks as $stock) {
//
//                    $stockQty = $stock->qty_available;
//
//                    if ($qty <= $stockQty) {
//                        $stock->qty_available -= $qty;
//                        $stock->save();
//
//                        $list = new ItemIssueList();
//                        $list->idProduction_Issue = $issue->idProduction_Issue;
//                        $list->items_idItems = $temp->items_idItems;
//                        $list->qty = $qty;
//                        $list->Stock_idStock = $stock->idStock;
//                        $list->status = 1;
//                        $temp->delete();
//                        $list->save();
//
//                        if(Section::find($section)->sectionName == 'DELIVERY SECTION') {
//
//                            $stock2 = new Stock();
//                            $stock2->Stock_Type = $deliveryId;
//                            $stock2->base = 6;
//                            $stock2->GRN_id_or_Production_id = $issue->idProduction_Issue;
//                            $stock2->Company = Auth::user()->Company;
//                            $stock2->Items_idItems = $stock->Items_idItems;
//                            $stock2->qty_grn = $temp->qty;
//                            $stock2->qty_available = $temp->qty;
//                            $stock2->qty_inv_return = $stock->qty_inv_return;
//                            $stock2->qty_grn_return = 0;
//                            $stock2->binNo = $stock->binNo;
//                            $stock2->expDate = $stock->expDate;
//                            $stock2->expHave = $stock->expHave;
//                            $stock2->mnfDate = $stock->mnfDate;
//                            $stock2->bp = $stock->bp;
//                            $stock2->wp = $stock->wp;
//                            $stock2->sp = $stock->sp;
//                            $stock2->status = 1;
//                            $stock2->save();
//                        }
//                        $qty = 0;
//                        break;
//                    } else {
//                        $availableQty = $stock->qty_available;
//                        $qty -= $availableQty;
//                        $stock->qty_available = 0;
//                        $stock->save();
//
//                        if($availableQty>0) {
//                            $list = new ItemIssueList();
//                            $list->idProduction_Issue = $issue->idProduction_Issue;
//                            $list->Items_idItems = $temp->items_idItems;
//                            $list->qty = $availableQty;
//                            $list->Stock_idStock = $stock->idStock;
//                            $list->status = 1;
//                            $list->save();
//                        }
//                    }
//                }
//                if ($qty > 0) {
//                    return response()->json(['errors' => ['error' => 'Process invalid.Contact system administrator.']]);
//
//                }
//            }
//        }
//        else{
//            return response()->json(['errors' => ['error' => 'Requested quantity is grater than available quantity.']]);
//        }
//
//        return response()->json(['success' =>'Production issued successfully.']);
//
//    }
//
//    public  function issueHistory(){
//        $company = Auth::user()->Company;
//        $sections = Section::where('status',1)->get();
//        $productions = ProductionIssue::where('Company',$company)->where('base',2)->where('status',1)->latest()->paginate(10);
//        return view('production.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//
//    }
//    public  function viewIssueItemList(Request $request){
//        $id = $request['id'];
//        $items = ItemIssueList::where('idProduction_Issue',$id)->where('status',1)->get();
//        $tableData = "";
//        foreach ($items as $item){
//            $tableData .= "<tr id='$item->idItem_Issue_List'>
//                              <td>".$item->idItem_Issue_List."</td>
//                              <td>".$item->item->itemName."</td>
//                              <td>".$item->Stock_idStock."</td>
//                              <td>".$item->qty."</td>
//                         </tr>";
//        }
//        return $tableData;
//    }
////
////    public  function viewExpected(Request $request){
////        $id = $request['id'];
////        $items = Expected::where('idProduction_Issue',$id)->where('status',1)->get();
////        $tableData = "";
////        foreach ($items as $item){
////            $st = Stock::where('GRN_id_or_Production_id',$item->idProduction_Issue)->where('Items_idItems',$item->Items_idItems)->where('base',2)->first();
////            if($st != null){
////                $actual = $st->qty_grn;
////            }else{
////                $actual = 'Not yet';
////            }
////
////
////            $tableData .= "<tr id='$item->idExpected_Product'>
////                              <td >".$item->idExpected_Product."</td>
////                              <td >".$item->item->itemName."</td>
////                              <td style=\"text-align: center;\">".$item->qty."</td>
////                              <td style=\"text-align: center;\">".$actual."</td>
////                         </tr>";
////        }
////        return $tableData;
////    }
////
////   saveProductionOutput
//    public function issueListSearch(Request $request){
//
//        $id = $request['id'];
//        $endDate = $request['end'];
//        $startDate = $request['start'];
//        $list = $request['list'];
//        $company = Auth::user()->Company;
//        $sections = Section::where('status',1)->get();
//
//        if (!empty($id)) {
//            $productions = ProductionIssue::where('idProduction_Issue',intval($id))->paginate(10);
//
//            return view('production.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//
//        } else if (!empty($startDate) && !empty($endDate)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            if(empty($list)){
//                $productions = ProductionIssue::where('base',2)->whereBetween('date', [$startDate, $endDate])->latest()->latest()->paginate(10);
//            }
//            else{
//                $productions = ProductionIssue::where('base',2)->whereBetween('date', [$startDate, $endDate])->where('Section_idSection',$list)->latest()->latest()->paginate(10);
//            }
//
//            $productions->appends(array(
//                'start' => $request['start'],
//                'list' => $request['list'],
//                'end' => $request['end']
//            ));
//
//            return view('production.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//        }
//        else if (empty($startDate) && empty($endDate) && !empty($list)) {
//            $productions = ProductionIssue::where('base',2)->where('Section_idSection',intval($list))->latest()->paginate(10);
//            $productions->appends(array(
//                'start' => $request['start'],
//                'list' => $request['list'],
//                'end' => $request['end']
//            ));
//            return view('production.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//        }
//        else {
//            $productions = ProductionIssue::where('base',2)->where('Company',$company)->latest()->paginate(10);
//            return view('production.issueHistory')->with(['title'=>'Issued History','productions'=>$productions,'sections'=>$sections]);
//        }
//    }
//
//    public function onGoing(){
//        $company = Auth::user()->Company;
//        $sections = Section::where('status',1)->get();
//        $products = Item::where('Item_Type',1)->where('status',1)->get();
//        $productions = ProductionIssue::where('base',2)->where('Company',$company)->latest()->where('status',1)->paginate(10);
//        return view('production.ongoingProduction')->with(['title'=>'On-Going Production','productions'=>$productions,'sections'=>$sections,'products'=>$products]);
//    }
//
//    public function OngoingIssueListSearch(Request $request){
//
//        $id = $request['id'];
//        $endDate = $request['end'];
//        $startDate = $request['start'];
//        $list = $request['list'];
//        $company = Auth::user()->Company;
//        $sections = Section::where('status',1)->get();
//        $products = Item::where('Item_Type',1)->where('status',1)->get();
//
//
//        if (!empty($id)) {
//            $productions = ProductionIssue::where('base',2)->where('idProduction_Issue',intval($id))->where('status',1)->paginate(10);
//
//            return view('production.ongoingProduction')->with(['title'=>'On-Going Production','productions'=>$productions,'sections'=>$sections,'products'=>$products]);
//
//
//        } else if (!empty($startDate) && !empty($endDate)) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            if(empty($list)){
//                $productions = ProductionIssue::where('base',2)->whereBetween('date', [$startDate, $endDate])->latest()->where('status',1)->latest()->paginate(10);
//            }
//            else{
//                $productions = ProductionIssue::where('base',2)->whereBetween('date', [$startDate, $endDate])->where('Section_idSection',$list)->latest()->where('status',1)->latest()->paginate(10);
//            }
//
//            $productions->appends(array(
//                'start' => $request['start'],
//                'list' => $request['list'],
//                'end' => $request['end']
//            ));
//
//            return view('production.ongoingProduction')->with(['title'=>'On-Going Production','productions'=>$productions,'sections'=>$sections,'products'=>$products]);
//
//        }
//        else if (empty($startDate) && empty($endDate) && !empty($list)) {
//            $productions = ProductionIssue::where('base',2)->where('Section_idSection',intval($list))->where('status',1)->latest()->paginate(10);
//            $productions->appends(array(
//                'start' => $request['start'],
//                'list' => $request['list'],
//                'end' => $request['end']
//            ));
//            return view('production.ongoingProduction')->with(['title'=>'On-Going Production','productions'=>$productions,'sections'=>$sections,'products'=>$products]);
//
//        }
//        else {
//            $productions = ProductionIssue::where('base',2)->where('Company',$company)->latest()->where('status',1)->paginate(10);
//            return view('production.ongoingProduction')->with(['title'=>'On-Going Production','productions'=>$productions,'sections'=>$sections,'products'=>$products]);
//
//        }
//    }
//
////    public function markAsConpleted(Request $request){
////        $arrayItems = $request['AQty'];
////
////        foreach ($arrayItems as $arrayItem) {
////            $qty = $arrayItem['qty'] == null ? 0:$arrayItem['qty'];
////            $id  = $arrayItem['id'];
////            $store  = $arrayItem['store'];
////            $expd  = $arrayItem['expd'];
////            $mnf  = $arrayItem['mnf'] == null? date('Y-m-d') : date('Y-m-d', strtotime($arrayItem['mnf']));
////
////            $expected = Expected::find($id);
////            $product = $expected->Items_idItems;
////            $productionId = $expected->idProduction_Issue;
////            $production  = ProductionIssue::find($productionId);
////
////            $stock = new Stock();
////            $stock->Stock_Type = $store;
////            $stock->GRN_id_or_Production_id = $production->idProduction_Issue;
////            $stock->Company = $production->Company;
////            $stock->Items_idItems = $product;
////            $stock->qty_grn = $qty;
////            $stock->qty_available = $qty;
////            $stock->base = 2;
////            $stock->qty_inv_return = 0;
////            $stock->qty_grn_return = 0;
////            $stock->binNo = null;
////            $stock->expDate =  date('Y-m-d', strtotime($expd));
////            if($expd == null){
////                $stock->expHave = 0;
////            }else{
////                $stock->expHave = 1;
////            }
////            $stock->mnfDate = $mnf;
////            $stock->bp = 0;
////            $stock->wp = 0;
////            $stock->sp = 0;
////            $stock->status = 1;
////            $stock->save();
////        }
////        $production->status  = 2;
////        $production->save();
////    }
//
//    public function productionOutput(){
//        $stores = StockType::where('Company',Auth::user()->Company)->where('type','!=','DELIVERY SECTION STORE')->get();
//        $sections = Section::where('Company',Auth::user()->Company)->where('sectionName','!=','DELIVERY SECTION')->get();
//        $products = Item::where('status',1)->where('Item_Type','!=',2)->get();
//        return view('production.productionOutput')->with(['products'=>$products,'sections'=>$sections,'stores'=>$stores,'title'=>'Production Input']);
//
//    }
//
//    public function addItemProductionOutputTemp(Request $request){
//        $validator = \Validator::make($request->all(), [
//            'store' => 'required',
//            'qty' => 'required',
//            'item' => 'required',
//            'mFDate' => 'required',
//            'section' => 'required',
//
//        ], [
//            'item.required' => 'Product name required',
//            'section.required' => 'Section should be provided.',
//            'qty.required' => 'Qty required',
//            'mFDate.required' => 'Manufacture date required',
//            'store.required' => 'Store name must be grater than 0',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $production = new ProductionOutputTemp();
//        $production->stock_type_idStock_Type = $request['store'];
//        $production->section_idSection = $request['section'];
//        $production->companyinfomaster_idCompanyInfo = Auth::user()->Company;
//        $production->stock_type_idStock_Type = $request['store'];
//        $production->items_idItems = $request['item'];
//        $production->qty = $request['qty'];
//
//        if($request['eHave'] && !empty($request['eDate'])){
//            $production->exp = date('Y-m-d', strtotime($request['eDate']));
//            $production->expHave = 1 ;
//        }
//        else{
//            $production->exp = null;
//            $production->expHave = 0 ;
//        }
//        $production->mnf = date('Y-m-d', strtotime($request['mFDate']));
//        $production->status = 1;
//        $production->usermaster_idUser = Auth::user()->idUser;
//        $production->save();
//        return response()->json(['success' =>'Item added successfully.']);
//    }
//
//    public function getProductionOutTemp(){
//        $temps = ProductionOutputTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
//        $tableData = "";
//        if($temps != null) {
//            foreach ($temps as $temp) {
//                $tableData .= "<tr id=" . $temp->idproduction_output_temp . ">
//                                    <td>
//                                    " . $temp->item->itemName . "
//                                    </td>
//                                     <td>
//                                    " . $temp->qty . "
//                                    </td>
//                                     <td>
//                                    " . $temp->store->type . "
//                                    </td>
//                                     <td>
//                                    " . $temp->section->sectionName . "
//                                    </td>
//                                     <td>
//                                    " . $temp->mnf. "
//                                    </td>
//                                    <td>
//                                    " . $temp->exp. "
//                                    </td>
//                                    <td style='text-align: center'>
//                                        <div class='button-items'>
//                                            <button type='button'
//                                                    class='btn btn-sm btn-danger  waves-effect waves-light'
//                                                    onclick='deleteTempItem( " . $temp->idproduction_output_temp . ")'>
//                                                    <i class='fa fa-trash'></i>
//                                             </button>
//                                        </div>
//                                    </td>
//                                </tr>";
//            }
//        }
//        else{
//            $tableData = "<tr><td colspan='3'>No expected product found yet.</td> </tr>";
//        }
//        return $tableData;
//    }
//
//    public function saveProductionOutput(){
//        $items = ProductionOutputTemp::where('usermaster_idUser',Auth::user()->idUser)->get();
//        if($items != null) {
//
//            $out = new ProductionOutput();
//            $out->Company = Auth::user()->Company ;
//            $out->section_idSection = $items[0]->section_idSection ;
//            $out->usermaster_idUser =Auth::user()->idUser ;
//            $out->save();
//
//            foreach ($items as $item) {
//
//                $stock = new Stock();
//                $stock->Stock_Type = $item->stock_type_idStock_Type;
//                $stock->GRN_id_or_Production_id = $out->idProduction_Output;
//                $stock->Company = Auth::user()->Company;
//                $stock->Items_idItems = $item->items_idItems;
//                $stock->qty_grn =  $item->qty;
//                $stock->qty_available =  $item->qty;
//                $stock->base = 2;
//                $stock->qty_inv_return = 0;
//                $stock->qty_grn_return = 0;
//                $stock->binNo = null;
//                $stock->expHave = $item->expHave;
//                $stock->expDate = $item->exp;
//                $stock->mnfDate =  $item->mnf;
//                $stock->bp = 0;
//                $stock->wp = 0;
//                $stock->sp = Item::find($item->items_idItems)->unitPrice;
//                $stock->status = 1;
//                $stock->save();
//                $item->delete();
//            }
//
//        }
//        return response()->json(['success' =>'Saved successfully.']);
//    }
//
//    public function OutputHistory(Request $request){
//        $sections = Section::where('Company',Auth::user()->Company)->get();
//        $query = ProductionOutput::query();
//        if(!empty($request['id'])){
//            $query = $query->where('idProduction_Output',intval($request['id']));
//        }
//        if(!empty($request['section'])){
//            $query = $query->where('section_idSection',$request['section']);
//        }
//        if (!empty($request['start']) && !empty($request['end'])) {
//            $startDate = date('Y-m-d', strtotime($request['start']));
//            $endDate = date('Y-m-d', strtotime($request['end']));
//
//            $query = $query->whereBetween('created_at', [$startDate.' 00:00:00', $endDate.' 23:59:59']);
//        }
//
//        $productions = $query->where('Company',Auth::user()->Company)->latest()->paginate(10);
//
//        return view('production.outputHistory')->with(['title'=>'Output History','productions'=>$productions,'sections'=>$sections]);
//    }
//
//    public  function viewProductOutputItemList(Request $request){
//        $id = $request['id'];
//        $stocks = Stock::where('GRN_id_or_Production_id',$id)->where('base',2)->where('status',1)->get();
//        $tableData = "";
//        foreach ($stocks as $stock){
//            $tableData .= "<tr id='$stock->idStock'>
//                              <td>".$stock->item->itemName."</td>
//                              <td>".$stock->stockTypes->type."</td>
//                              <td>".$stock->qty_grn."</td>
//                         </tr>";
//        }
//        return $tableData;
//    }
//
//    public function deleteProductionOutAll(){
//        ProductionOutputTemp::where('usermaster_idUser',Auth::user()->idUser)->delete();
//    }
//}
//
//
