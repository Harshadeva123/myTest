<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 3/25/2019
// * Time: 10:54 PM
// */
//
//namespace App\Http\Controllers;
//
//
//use App\ItemCategory;
//
//use App\ItemType;
//use App\MainCategory;
//use App\SubCategory;
//use GuzzleHttp\Psr7\Response;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Auth;
//use Symfony\Component\Console\Input\Input;
//
//class SubCategoryController extends Controller
//{
//
//    public function __construct()
//    {
//        $this->middleware('auth');
//    }
//
//    public function searchSubCat(Request $request)
//    {
//        $paginate = 10;
//        $keyword = $request['search'];
//        $column = '';
//        $itemType = ItemType::where('status',1)->get();
//        $subCategories = SubCategory::where('status', '1')->get();
//        $mainCategories=MainCategory::where('status',1)->get();
//        $viewAllSub= SubCategory::Where('status', 1)->orderBy('created_at', 'desc')
//            ->where('Category' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orwhere('subCatName' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orderBy('idItem_Sub_Category', 'DESC')->paginate($paginate);
//        $viewAllSub->appends(array('search' => $request['search'],));
//
//        return view('sub_category', ['itemType'=>$itemType,'mainCategories'=>$mainCategories,'subCategories'=>$subCategories,'title' => 'Sub Category Management', 'viewAllSub' => $viewAllSub,'subcategories'=>$subCategories]);
//    }
//
//
//
//    public function saveSubCategory(Request $request)
//    {
//
//        $mainCat = $request['mainCat'];
//        $subCatName = $request['subCatName'];
//
//        $validator = \Validator::make($request->all(), [
//             'mainCat' => 'required',
//             'subCatName' => 'required',
//
//        ], [
//            'mainCat.required' => 'Category Type should be provided!',
//            //  'mainCat.exists' => 'Please provide property current status',
//            'subCatName.required' => 'Category Name should be provided!',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $subCatExists = SubCategory::where('subCatName', strtoupper($subCatName))
//            ->where('Category', $mainCat)
//            ->first();
//        if ($subCatExists == null) {
//            $subCat = new SubCategory();
//            $subCat->Category = $mainCat;
//            $subCat->subCatName = strtoupper($subCatName);
//            $subCat->Company = Auth::user()->Company;
//            $subCat->UserMaster_idUser = Auth::user()->idUser;
//            $subCat->isPublic='1';
//            $subCat->status = '1';
//            $subCat->save();
//
//            $subCats = SubCategory::orderBy('created_at', 'desc')->paginate(10);
//            $tableData = '';
//            foreach ($subCats as $subCat) {
//                $tableData .= "<tr>";
//                $tableData .= "<td>" . $subCat->MainCategory->catName . "</td>";
//                $tableData .= "<td>" . $subCat->subCatName . "</td>";
//                if ($subCat->status == 1) {
//
//                    $tableData .= "<td>";
//                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$subCat->idItem_Sub_Category','Item_Sub_Category') id='c" . $subCat->idItem_Sub_Category . "' checked switch='none'/>";
//                    $tableData .= "<label for='c" . $subCat->idItem_Sub_Category . "' data-on-label='On' data-off-label='Off'></label>";
//                    $tableData .= "</td>";
//                } else {
//                    $tableData .= "<td>";
//                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$subCat->idItem_Sub_Category','Item_Sub_Category') id='c" . $subCat->idItem_Sub_Category . "'  switch='none'/>";
//                    $tableData .= "<label for='c" . $subCat->idItem_Sub_Category . "' data-on-label='On' data-off-label='Off'></label>";
//                    $tableData .= "</td>";
//                }
//                $tableData .= "<td>";
//                $tableData .= " <p>";
//                $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light' data-type='$subCat->Category'
//               data-name='$subCat->subCatName' data-toggle='modal' data-id='$subCat->idItem_Sub_Category' id='subCategoryId' data-target='#updateSub'>";
//                $tableData .= "<i class='fa fa-edit'></i>";
//                $tableData .= "</button>";
//                $tableData .= " </p>";
//                $tableData .= " </td>";
//                $tableData .= "</tr>";
//            }
//            return response()->json(['tableData' => $tableData, 'success' => 'Sub Category is successfully saved']);
//
//        } else {
//            return response()->json(['errors' => ['error' => 'Category name already in database!']]);
//        }
//
//    }
//
//    public function getSubCatByID(Request $request)
//    {
//        $subCatId = $request['subCatId'];
//        $subCategory = SubCategory::find(intval($subCatId));
//        $type = $subCategory->MainCategory->ItemType->idItem_Type;
//        return response()->json(['sub'=>$subCategory,'type'=>$type]);
//    }
//
//    public function updateSubCategory(Request $request)
//    {
//        $uSubId = $request['id'];
//        $type = $request['type'];
//        $name = $request['name'];
//        $cat = $request['cat'];
//
//        $validator = \Validator::make($request->all(), [
//            'type' => 'required',
//            'name' => 'required',
//            'cat' => 'required',
//        ], [
//            'type.required' => 'Item Type should be provided!',
//            'name.required' => 'Sub Category Name should be provided!',
//            'cat.required' => 'Item Category should be provided!',
//
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $cate = SubCategory::find(intval($uSubId));
//        $cate->Category = $cat;
//        $cate->subCatName = strtoupper($name);
//        $cate->update();
//
//        $subCats = SubCategory::orderBy('created_at', 'desc')->paginate(10);
//        $tableData = '';
//        foreach ($subCats as $subCat) {
//            $tableData .= "<tr>";
//            $tableData .= "<td>" . $subCat->MainCategory->catName . "</td>";
//            $tableData .= "<td>" . $subCat->subCatName . "</td>";
//            if ($subCat->status == 1) {
//
//                $tableData .= "<td>";
//                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$subCat->idItem_Sub_Category','Item_Sub_Category') id='c" . $subCat->idItem_Sub_Category . "' checked switch='none'/>";
//                $tableData .= "<label for='c" . $subCat->idItem_Sub_Category . "' data-on-label='On' data-off-label='Off'></label>";
//                $tableData .= "</td>";
//            } else {
//                $tableData .= "<td>";
//                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$subCat->idItem_Sub_Category','Item_Sub_Category') id='c" . $subCat->idItem_Sub_Category . "'  switch='none'/>";
//                $tableData .= "<label for='c" . $subCat->idItem_Sub_Category . "' data-on-label='On' data-off-label='Off'></label>";
//                $tableData .= "</td>";
//            }
//            $tableData .= "<td>";
//            $tableData .= " <p>";
//            $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light' data-type='$subCat->Category'
//               data-name='$subCat->subCatName' data-toggle='modal' data-id='$subCat->idItem_Sub_Category' id='subCategoryId' data-target='#updateSub'>";
//            $tableData .= "<i class='fa fa-edit'></i>";
//            $tableData .= "</button>";
//            $tableData .= " </p>";
//            $tableData .= " </td>";
//            $tableData .= "</tr>";
//        }
//        return response()->json(['tableData' => $tableData, 'success' => 'Sub Category is successfully Updated']);
//    }
//
//
//    public function loadSubCategory(Request $request)
//    {
//        $itemMainCategory = $request['itemMainCategory'];
//        $subCategory = SubCategory::where('Category', intval($itemMainCategory))->get();
//        return response()->json($subCategory);
//    }
//
//
//    public function subCategoryGrn(Request $request)
//    {
//        $grnMainCategory = $request['grnMainCategory'];
//        $subCategory = SubCategory::where('Category', intval($grnMainCategory))->get();
//        return response()->json($subCategory);
//    }
//
//    public function getSubCat(Request $request){
//        $main = $request['main'];
//        $subCats = SubCategory::where('Category',$main)->where('status',1)->get();
//        $options = "<option value='' disabled selected>Select Sub Category</option>";
//        foreach ($subCats as $cat) {
//            $options .= "<option value=".$cat->idItem_Sub_Category.">".$cat->subCatName."</option>";
//        }
//        return $options;
//    }
//
//}