<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-002
// * Date: 9/9/2019
// * Time: 1:33 PM
// */
//
//namespace App\Http\Controllers;
//
//
//use App\CompanyInfo;
//use App\StockType;
//use Illuminate\Http\Request;
//
//class AgencyController extends Controller
//{
//    public function __construct()
//    {
//        $this->middleware('auth');
//    }
//
//
//    public function searchAgency(Request $request)
//    {
//        $paginate = 10;
//        $keyword = $request['search'];
//        $column = '';
//
//        $viewAllAgencies = CompanyInfo::Where('status', 1)->orderBy('created_at', 'desc')
//            ->where('companyName' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orwhere('regNo' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orwhere('addressLine1' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orwhere('city' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orwhere('email' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orwhere('contactNo1' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orwhere('contactNo2' . $column . '', 'LIKE',
//                "%$keyword%")
//            ->orderBy('idCompanyInfo', 'DESC')->paginate($paginate);
//        $viewAllAgencies->appends(array('search' => $request['search'],));
//
//        return view('agency.agency_management', ['title' => 'Agencies', 'viewAllAgencies' => $viewAllAgencies]);
//
//    }
//
//    public function saveCompany(Request $request)
//    {
//        $comName = $request['comName'];
//        $comRegNumber = $request['comRegNumber'];
//        $comAddLine1 = $request['comAddLine1'];
//        $comAddLine2 = $request['comAddLine2'];
//        $comCity = $request['comCity'];
//        $comEmail = $request['comEmail'];
//        $comNumb1 = $request['comNumb1'];
//        $comNumb2 = $request['comNumb2'];
//        $commission = $request['commission'];
//        $isShop = $request['isShop'];
//
//
//        $validator = \Validator::make($request->all(), [
//
//            'comName' => 'required',
//            'comRegNumber' => 'required',
//            'commission' => 'required',
//            'comAddLine1' => 'required',
//            'comNumb1' => 'required',
//
//        ], [
//            'comName.required' => 'Agency Name should be provided!',
//            'comRegNumber.required' => 'Agency Registration Number should be provided!',
//            'commission.required' => 'Commission rate should be provided!',
//            'comAddLine1.required' => 'Address  should be provided!',
//            'comNumb1.required' => 'Mobile Number should be provided!',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//        $comDataExist = CompanyInfo::where('companyName', strtoupper($comName))
//            ->first();
//        $comNumb1 == 0? $comNumb1 = null: $comNumb1= $comNumb1;
//        $comNumb2 == 0? $comNumb1 = null: $comNumb2= $comNumb2;
//        if ($comDataExist == null) {
//            $comData = new CompanyInfo();
//            $comData->companyName =strtoupper($comName);
//            $comData->regNo = $comRegNumber;
//            $comData->addressLine1 = $comAddLine1;
//            $comData->addressLine2 = $comAddLine2;
//            $comData->city = $comCity;
//            if($isShop == 'true'){
//
//                $comData->isShop = 1;
//            }
//            else{
//            $comData->isShop = 0;
//
//             }
//            $comData->email = $comEmail;
//            $comData->commission = $commission;
//            $comData->contactNo1 = $comNumb1;
//            $comData->contactNo2 = $comNumb2;
//            $comData->status = '1';
//            $comData->isBranch = '1';
//            $comData->save();
//
//            $store = new StockType();
//            $store->Company = $comData->idCompanyInfo;
//            $store->type = 'MAIN';
//            $store->status = 1;
//            $store->save();
//
//            $agencyMgs = CompanyInfo::orderBy('created_at', 'desc')->paginate(10);
//            $tableData = '';
//            foreach ($agencyMgs as $agencyMg) {
//                $tableData .= "<tr>";
//                $tableData .= "<td>" . $agencyMg->companyName . "</td>";
//                $tableData .= "<td>" . $agencyMg->city . "</td>";
//                $tableData .= "<td>" . $agencyMg->email . "</td>";
//                $tableData .= "<td>" . $agencyMg->contactNo1 . "</td>";
//                $tableData .= "<td>" . $agencyMg->commission . "</td>";
//                $tableData .= "<td>" . $agencyMg->commission . "</td>";
//                if ($agencyMg->status == 1) {
//
//                    $tableData .= "<td>";
//                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$agencyMg->idCompanyInfo','companyinfomaster') id='c" . $agencyMg->idCompanyInfo . "' checked switch='none'/>";
//                    $tableData .= "<label for='c" . $agencyMg->idCompanyInfo . "' data-on-label='On' data-off-label='Off'></label>";
//                    $tableData .= "</td>";
//                } else {
//                    $tableData .= "<td>";
//                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$agencyMg->idCompanyInfo','companyinfomaster') id='c" . $agencyMg->idCompanyInfo . "'  switch='none'/>";
//                    $tableData .= "<label for='c" . $agencyMg->idCompanyInfo . "' data-on-label='On' data-off-label='Off'></label>";
//                    $tableData .= "</td>";
//                }
//                $tableData .= "<td>";
//                $tableData .= " <p>";
//                $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light'
//               data-toggle='modal' data-id='$agencyMg->idCompanyInfo' id='uAgencyId' data-target='#updateAgencyModal'>";
//                $tableData .= "<i class='fa fa-edit'></i>";
//                $tableData .= "</button>";
//                $tableData .= " </p>";
//                $tableData .= " </td>";
//                $tableData .= "</tr>";
//            }
//            return response()->json(['tableData' => $tableData, 'success' => 'Agency  successfully saved.']);
//
//        } else {
//            return response()->json(['errors' => ['error' => 'Agency Name already in database!']]);
//        }
//
//    }
//
//    public function getAgencyByID(Request $request)
//    {
//        $agencyId = $request['agencyById'];
//        $agencyDetails = CompanyInfo::find(intval($agencyId));
//        return response()->json($agencyDetails);
//    }
//
//    public function updateAgency(Request $request)
//    {
//        $hiddenAgID = $request['hiddenAgID'];
//        $uComName = $request['uComName'];
//        $uComRegNumber = $request['uComRegNumber'];
//        $uComAddLine1 = $request['uComAddLine1'];
//        $uComAddLine2 = $request['uComAddLine2'];
//        $uComCity = $request['uComCity'];
//        $uComEmail = $request['uComEmail'];
//        $uComNumb1 = $request['uComNumb1'];
//        $uComNumb2 = $request['uComNumb2'];
//        $Ucommission = $request['Ucommission'];
//        $isShop = $request['isShop'];
//
//        $validator = \Validator::make($request->all(), [
//
//            'uComName' => 'required',
//            'uComRegNumber' => 'required',
//            'Ucommission' => 'required',
////            'uComNumb1' => 'required',
//
//        ], [
//            'uComName.required' => 'Company Name should be provided!',
//            'uComRegNumber.required' => 'Company Registration Number should be provided!',
//            'Ucommission.required' => 'Commission should be provided!',
////            'uComNumb1.required' => 'Mobile Number should be provided!',
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//
//            $upAgency=CompanyInfo::find(intval($hiddenAgID));
//            $upAgency->companyName = strtoupper($uComName);
//            $upAgency->regNo = $uComRegNumber;
//            $upAgency->addressLine1 = $uComAddLine1;
//            $upAgency->addressLine2 = $uComAddLine2;
//            $upAgency->city = $uComCity;
//            $upAgency->email = $uComEmail;
//            $upAgency->contactNo1 = $uComNumb1;
//            $upAgency->contactNo2 = $uComNumb2;
//            $upAgency->commission = $Ucommission;
//            if($isShop == 'true'){
//
//                $upAgency->isShop = 1;
//            }
//            else{
//                $upAgency->isShop = 0;
//
//            }
//            $upAgency->update();
//
//            $agencyMgs = CompanyInfo::orderBy('created_at', 'desc')->paginate(10);
//            $tableData = '';
//            foreach ($agencyMgs as $agencyMg) {
//                $tableData .= "<tr>";
//                $tableData .= "<td>" . $agencyMg->companyName . "</td>";
//                $tableData .= "<td>" . $agencyMg->city . "</td>";
//                $tableData .= "<td>" . $agencyMg->email . "</td>";
//                $tableData .= "<td>" . $agencyMg->contactNo1 . "</td>";
//                $tableData .= "<td>" . $agencyMg->commission . "</td>";
//                if ($agencyMg->status == 1) {
//
//                    $tableData .= "<td>";
//                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$agencyMg->idCompanyInfo','companyinfomaster') id='c" . $agencyMg->idCompanyInfo . "' checked switch='none'/>";
//                    $tableData .= "<label for='c" . $agencyMg->idCompanyInfo . "' data-on-label='On' data-off-label='Off'></label>";
//                    $tableData .= "</td>";
//                } else {
//                    $tableData .= "<td>";
//                    $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=adMethod('$agencyMg->idCompanyInfo','companyinfomaster') id='c" . $agencyMg->idCompanyInfo . "'  switch='none'/>";
//                    $tableData .= "<label for='c" . $agencyMg->idCompanyInfo . "' data-on-label='On' data-off-label='Off'></label>";
//                    $tableData .= "</td>";
//                }
//                $tableData .= "<td>";
//                $tableData .= " <p>";
//                $tableData .= "<button type='button' class='btn btn-sm btn-warning  waves-effect waves-light' data-type='$agencyMg->idCompanyInfo'
//               data-name='$agencyMg->idCompanyInfo' data-toggle='modal' data-id='$agencyMg->idCompanyInfo' id='uAgencyId' data-target='#updateAgencyModal'>";
//                $tableData .= "<i class='fa fa-edit'></i>";
//                $tableData .= "</button>";
//                $tableData .= " </p>";
//                $tableData .= " </td>";
//                $tableData .= "</tr>";
//            }
//            return response()->json(['tableData' => $tableData, 'success' => 'Agency  successfully saved']);
//
//
//    }
//
//}