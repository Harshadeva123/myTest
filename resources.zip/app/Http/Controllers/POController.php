<?php

namespace App\Http\Controllers;

use App\CompanyPaymentType;
use App\GrnItemsTemp;
use App\Item;
use App\Purchase;
use App\PurchaseOrderReg;
use App\PurchaseTempary;
use App\Stock;
use App\Store;
use App\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class POController extends Controller
{
    public function index(){
        $payments = CompanyPaymentType::where('status',1)->where('Company', intval(Auth::user()->Company))->where('po',1)->get();
        $suppliers = Supplier::where('status',1)->where('Company',Auth::user()->Company)->get();
        $items = Item::where('status',1)->where('Company',Auth::user()->Company)->get();
        return view('purchase_order.create_po')->with(['payments'=>$payments,'suppliers'=>$suppliers,'title'=>'Create Purchase Order','items'=>$items]);
    }
    public function view(Request $request){
        $suppliers = Supplier::where('status',1)->where('Company',Auth::user()->Company)->get();
        $stockTypes = Store::where('status',1)->where('Company',Auth::user()->Company)->get();
        $query = Purchase::query();
        if($request['po'] != null){
            $query = $query->where('poNo',$request['po'] );
        }
        if($request['supplier'] != null) {
            $query = $query->where('Supplier_idSupplier', $request['supplier']);
        }
        if (!empty($request['start']) && !empty($request['end'])) {
            $startDate = date('Y-m-d', strtotime($request['start']));
            $endDate = date('Y-m-d', strtotime($request['end']));

            $query = $query->whereBetween('date', [$startDate, $endDate]);
        }

        $orders = $query->where('status',1)->where('Company',Auth::user()->Company)->orderBy('idPO','DESC')->paginate(10);

        $orders->appends(array(
            'poNo' => $request['poNo'],
            'supplier' => $request['supplier'],
            'start' => $request['start'],
            'end' => $request['end']
        ));

        return view('purchase_order.po_history')->with(['suppliers'=>$suppliers,'title'=>'Purchase Orders History','orders'=>$orders,'stockTypes'=>$stockTypes]);
    }

    public function viewCancelled(Request $request){
        $suppliers = Supplier::where('status',1)->where('Company',Auth::user()->Company)->get();
        $stockTypes = Store::where('status',1)->where('Company',Auth::user()->Company)->get();
        $query = Purchase::query();
        if($request['po'] != null){
            $query = $query->where('poNo',$request['po'] );
        }
        if($request['supplier'] != null) {
            $query = $query->where('Supplier_idSupplier', $request['supplier']);
        }
        if (!empty($request['start']) && !empty($request['end'])) {
            $startDate = date('Y-m-d', strtotime($request['start']));
            $endDate = date('Y-m-d', strtotime($request['end']));

            $query = $query->whereBetween('date', [$startDate, $endDate]);
        }

        $orders = $query->where('status',0)->where('Company',Auth::user()->Company)->orderBy('idPO','DESC')->paginate(10);

        $orders->appends(array(
            'poNo' => $request['poNo'],
            'supplier' => $request['supplier'],
            'start' => $request['start'],
            'end' => $request['end']
        ));

        return view('purchase_order.cancelled-po')->with(['suppliers'=>$suppliers,'title'=>'Cancelled PO','orders'=>$orders,'stockTypes'=>$stockTypes]);
    }

    public function add(Request $request){

        $item = $request['item'];
        $bPrice = $request['bPrice'];
        $qty = $request['qty'];

        $validator = \Validator::make($request->all(), [
            'item' => 'required',
            'bPrice' => 'required',
            'qty' => 'required'
        ], [
            'item.required' => 'Item should be provided!',
            'bPrice.required' => 'Buying price should be provided!',
            'qty.required' => 'Qty should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }


        $po = new PurchaseTempary();
        $po->items_idItems= $item;
        $po->bp = $bPrice;
        $po->qty = $qty;
        $po->status = 1;
        $po->usermaster_idUser = Auth::user()->idUser;
        $po->save();

        return response()->json([ 'success' => 'Successfully saved']);
    }

    public function getTempData(){

        $tableData = "";
        $total = 0;
        $items = PurchaseTempary::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
        if($items != null){
            foreach ($items as $item){
                $total += $item->bp*$item->qty;
                $tableData .= "<tr id=".$item->idpo_temp.">
                                    <td>".$item->item->itemName."</td>
                                    <td>".$item->qty."</td>
                                    <td style='text-align: right '>".number_format($item->bp,2)."</td>
                                    <td style='text-align: right '>".number_format($item->bp*$item->qty,2)."</td>
                                    <td>
                                            <div class='button-items'>
                                                <button type='button'
                                                        class='btn btn-sm btn-danger  waves-effect waves-light'
                                                        onclick='deleteTempPurchase(".$item->idpo_temp.")'>
                                                        <i class='fa fa-trash'></i>
                                                 </button>

                                            </div>
                                    </td>
                                </tr>";
            }

        }
        else{
            $tableData= "<tr>
                        <td colspan='5'>No available items.</td>
                     </tr>";
        }
        return response()->json([ 'tableData' => $tableData,'total'=>number_format($total,2)]);

    }

    public function delete(Request $request){
        $id = $request['id'];
        $tempItemp = PurchaseTempary::find($id);
        $tempItemp->delete();

    }

    public function save(Request $request){
        $validator = \Validator::make($request->all(), [
            'supplier' => 'required',
            'date' => 'required',
            'payment' => 'required',
        ], [
            'supplier.required' => 'Supplier should be provided!',
            'date.required' => 'Date should be provided!',
            'payment.required' => 'Payment tyoe should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $items = PurchaseTempary::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
        if($items != null){
            $total = 0;
            foreach ($items as $item){
                $total += $item->bp * $item->qty;
            }
            $orderNumber = Purchase::where('Company',Auth::user()->Company)->latest()->first();
            if($orderNumber == null){
                $orderNumber = 1;
            }
            else{
                $orderNumber = $orderNumber->poNo + 1;
            }
            $purchase = new Purchase();
            $purchase->poNo = intval($orderNumber);
            $purchase->Company = Auth::user()->Company;
            $purchase->Supplier_idSupplier = $request['supplier'];
            $purchase->total = round($total,2);
            $purchase->meta_payment_type = $request['payment'];
            $purchase->date	 = date('Y-m-d', strtotime($request['date']));
            $purchase->UserMaster_idUser = Auth::user()->idUser;
            $purchase->status = 1;
            $purchase->save();

            foreach ($items as $item){
                $reg = new PurchaseOrderReg();
                $reg->items_idItems = $item->items_idItems ;
                $reg->qty = $item->qty;
                $reg-> bp= $item->bp ;
                $reg->status= 1 ;
                $reg->Purchase_Order_idPO = $purchase->idPO;
                $reg->save();
                $item->delete();
            }
            return response()->json(['success' => 'Success']);
        }
        else{
            return response()->json(['errors' => ['error' => 'No items available.']]);
        }

    }


    public function viewRegistry(Request $request){
        $id = $request['id'];
        $regs = PurchaseOrderReg::where('Purchase_Order_idPO',$id)->where('status',1)->get();
        $tableData = "";
       foreach ($regs as $reg){
           $tableData .= "<tr>
                              <td>".$reg->item->itemName."</td>
                              <td>".$reg->qty."</td>
                              <td style='text-align: right'>".number_format($reg->bp,2)."</td>
                         </tr>";
       }
        return $tableData;
    }

    public function itemChange(Request $request){
        $id = $request['id'];
        $item = Item::find(intval($id));
        $pp = $item->purchasePrice;
        $company = Auth::user()->Company;
        $available = Stock::where(function ($query) use ($company, $id) {
            $query->where('expDate', '>=', date('Y-m-d'))->where('Company', $company)->where('Items_idItems', $id)->where('status', 1);
        })->orWhere(function ($query) use ($company, $id) {
            $query->where('expHave', 0)->where('Company', $company)->where('Items_idItems', $id)->where('status', 1);
        })->sum('qty_available');

        return response()->json(['pp' =>$pp,'available'=>$available.' '.$item->measurement->mian]);
    }

    public function deletePO(Request $request){
        $id = $request['id'];
        $purchase = Purchase::find($id);
        $purchase->status = 0;
        $purchase->save();

    }

    public function transferToGrn(Request $request){
        $id = $request['id'];
        $store = $request['store'];
        $binNo = $request['bin'];

        if($request['exp'] != null ){
            $exp = date('Y-m-d', strtotime($request['exp']));
        }
        else{
            $exp = null;
        }

        $validator = \Validator::make($request->all(), [
            'store' => 'required',
            'id' => 'required',
        ], [
            'store.required' => 'Store should be provided!',
            'id.required' => 'Invalid PO!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $regs = PurchaseOrderReg::where('Purchase_Order_idPO',$id)->where('status',1)->get();
        if($regs != null){
            foreach ($regs as $reg){

                $grn = new GrnItemsTemp();
                $grn->store = $store;
                $grn->po_no = $id;
                $grn->Items_idItems = $reg->items_idItems;
                $grn->qty_grn = $reg->qty;
                $grn->binNo = $binNo;
                $grn->bp = round($reg->bp,2);
                $grn->expDate = $exp;
                if ($exp == null) {
                    $grn->expHave = '0';
                } else {
                    $grn->expHave = '1';
                }
                $grn->mnfDate = date("Y-m-d");
                $grn->status = 1;
                $grn->UserMaster_idUser = Auth::user()->idUser;
                $grn->save();
            }

            return response()->json(['success'=>'success']);
        }
        else{
            return response()->json(['errors' =>['error'=>'No items to transfer!']]);

        }

    }
}
