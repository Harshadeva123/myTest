<?php

namespace App\Http\Controllers;

use App\BankAccount;
use App\BankMeta;
use App\BankPayments;
use App\BankPaymentsTemp;
use App\ChequePayments;
use App\ChequePaymentTemp;
use App\CompanyInfo;
use App\Payment;
use App\PaymentRefference;
use App\PaymentType;
use App\StockTransfer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{
    public function getBankDetails(){
        $banks = BankMeta::where('status',1)->get();
        $options = "";
        $i = 0;
        foreach ($banks as $bank){
            if($i == 0){
                $options .= "<option selected value='" . $bank->idbank . "'>" . $bank->bank . "</option>";
            }
            else {
                $options .= "<option value='" . $bank->idbank . "'>" . $bank->bank . "</option>";
            }
            $i++;
        }

        return $options;
    }

     public function getBankAccounts(Request $request){
         $bank = $request['bank'];
         $accounts = BankAccount::where('status',1)->where('bank_idbank',$bank)->where('Company', intval(Auth::user()->Company))->get();
         $accountsOptions = "";
         foreach ($accounts as $account){
             $accountsOptions .= "<option value='".$account->idbank_meta."'>".$account->accNo.' - '.$account->branch."</option>";
         }
         return $accountsOptions;
        }

    public function addBankDetailsTemp(Request $request){
        $bank = $request['bankName'];
        $amount = $request['amount'];
        $bankAccount = $request['bankAccount'];
        $bankPaymet = new BankPaymentsTemp();
        $bankPaymet->bank_idbank = $bank;
        $bankPaymet->amount = $amount;
        $bankPaymet->bank_account = $bankAccount;
        $bankPaymet->usermaster_idUser = Auth::user()->idUser;
        $bankPaymet->status = 1;
        $bankPaymet->save();
        return response()->json([ 'tableData' => 'Item successfully returned']);

    }

    public function loadBankDetailsTemp(){
        $tableData = "";
        $banks = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
        foreach ($banks as $bank){
            $tableData .= "<tr id='".$bank->idbank_payment_temp."'>";
            $tableData .= "<td>".$bank->bank->bank."</td>";
            $tableData .= "<td>".$bank->account->accNo."</td>";
            $tableData .= "<td>".number_format($bank->amount,2)."</td>";
            $tableData .= "<td>  <div class='button-items'>
                                    <button type='button'
                                            class='btn btn-sm btn-danger  waves-effect waves-light'
                                            data-id=".$bank->idbank_payment_temp."
                                            onclick='BankPaymentsTempDelete(this)'>
                                            <i class='fa fa-trash'></i>
                                     </button>
                                </div>
                           </td>";
            $tableData .= "</tr>";

        }
        return response()->json([ 'tableData' => $tableData]);

    }

    public function addChequeDetailsTemp(Request $request){
        $bank = $request['bankName'];
        $amount = $request['chequeAmount'];
        $chequeNo = $request['chequeNo'];
        $chequeDate = date('Y-m-d',strtotime($request['chequeDate']));
        $bankAccount = $request['bankAccount'];


        $chequePayment = new ChequePaymentTemp();
        $chequePayment->bank_idbank = $bank;
        $chequePayment->amount = $amount;
        $chequePayment->usermaster_idUser = Auth::user()->idUser;
        $chequePayment->chequeNo = $chequeNo;
        $chequePayment->chequeDate = $chequeDate;
        $chequePayment->bank_account = $bankAccount;
        $chequePayment->status = 1;
        $chequePayment->save();

    }

    public function loadChequeDetailsTemp(Request $request){
        $tableData = "";
        $cheques = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
        foreach ($cheques as $cheque){
            $tableData .= "<tr id='".$cheque->idcheque_payment_temp."'>";
            $tableData .= "<td>".$cheque->bank->bank."</td>";
            $tableData .= "<td>".$cheque->bank->bank."</td>";
            $tableData .= "<td>".$cheque->account->accNo."</td>";
            $tableData .= "<td>".$cheque->chequeNo."</td>";
            $tableData .= "<td>".$cheque->chequeDate."</td>";
            $tableData .= "<td>".$cheque->amount."</td>";
            $tableData .= "<td>  <div class='button-items'>
                                    <button type='button'
                                            class='btn btn-sm btn-danger  waves-effect waves-light'
                                            data-id=".$cheque->idcheque_payment_temp."
                                            onclick='ChequePaymentTempDelete(this)'>
                                            <i class='fa fa-trash'></i>
                                     </button>
                                </div>
                           </td>";
            $tableData .= "</tr>";
        }
        return response()->json([ 'tableData' => $tableData]);

    }

    public function paymentTypeChangedDelete(){
        ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->delete();
        BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->delete();
    }

    public function BankPaymentsTempDelete(Request $request){
        $id = $request['id'];
        BankPaymentsTemp::find($id)->delete();
    }
    public function ChequePaymentTempDelete(Request $request){
        $id = $request['id'];
        ChequePaymentTemp::find($id)->delete();
    }

    public function receivePayment(Request $request){
        $query = StockTransfer::query();
        if (!empty($request->id)) {
            $query = $query->where('idStock_Transfer', $request->id);
        }
        if (!empty($request->company)) {
            $query = $query->where('Company_To', $request->company);
        }
        if (!empty($request->end) && !empty($request->str)) {
            $startDate = date('Y-m-d', strtotime($request['str']));
            $endDate = date('Y-m-d', strtotime($request['end'].' +1 day'));
            $query = $query->whereBetween('created_at', [$startDate, $endDate]);
        }
        $companies = CompanyInfo::where('status',1)->get();
        $transfers = $query->where('netTotal', '>', DB::raw('paidTotal'))->latest()->paginate(10);
        $paymentTypes = PaymentType::where('status',1)->get();
        return view('payments.receivePayment')->with(['companies'=>$companies,'paymentTypes'=>$paymentTypes,'title'=>'Receive Payment','transfers'=>$transfers]);
    }

    public function viewPaymentsTransfer(Request $request){
        $id = $request['id'];

        $payments = Payment::where('base',4)->where('id',$id)->get();
        $tableData = "";
        foreach ($payments as $payment){
            $tableData .= "<tr>";
            $tableData .= "<td style='text-align: center;'>".$payment->created_at->format('Y-m-d')."</td>";
            $tableData .= "<td style='text-align: right;'>".number_format($payment->cash,2)."</td>";
            $tableData .= "<td style='text-align: right;'>".number_format($payment->cheque,2)."</td>";
            $tableData .= "<td style='text-align: right;'>".number_format($payment->bank,2)."</td>";
            $tableData .= "<td style='text-align: right;'>".number_format($payment->visa,2)."</td>";
            $tableData .= "</tr>";
        }
        return $tableData;
    }

    public function viewPaymentModalTransfer(Request $request){
        $id =  $id = $request['id'];
        $t = StockTransfer::find($id);
        $netTotal = $t->netTotal;
        $paidTotal = $t->paidTotal;
        $dueTotal = floatval($netTotal - $paidTotal);

        return response()->json(['netTotal' => $netTotal, 'paidTotal' => $paidTotal,'dueTotal'=>$dueTotal]);

    }
    public function addPaymentTransfer(Request $request){
        $id = $request['id'];
        $cardAmount = floatval($request['cardAmount']);
        $visaBill = $request['visaBill'];
        $paid = floatval($request['paid']);
        $payment = $request['payment'];
        $paidTotal = 0;
        $transfer = StockTransfer::find($id);
        $billTotal = floatval($transfer->netTotal -  $transfer->paidTotal);



        $newPayment = new Payment();
        $newPayment->Company = Auth::user()->Company;
        $newPayment->payment_type_idpayment_type = $payment;
        $newPayment->base = 4;
        $newPayment->id = $id;
        $newPayment->status = 1;

        if($payment == 1){
            $paidTotal = $paid;
            $newPayment->cash = min($paidTotal,$billTotal);
        }
        if($payment == 3){
            $banks = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
            if($banks != null){
                $paidTotal = $banks->sum('amount');
                $newPayment->bank = min($paidTotal,$billTotal);;
            }else{
                return response()->json(['errors' => ['error' => 'Please add bank payments details.']]);
            }
        }
        if($payment == 4){
            if($visaBill == null){
                return response()->json(['errors' => ['error' => 'Card no should be provided.']]);
            }
            $paidTotal = $cardAmount;
            $newPayment->visa = min($paidTotal,$billTotal);;
            $newPayment->visaBillNo = $visaBill;
        }
        if($payment == 5){
            $cheques = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
            if($cheques != null){
                $paidTotal = $cheques->sum('amount');
                $newPayment->cheque = min($paidTotal,$billTotal);;
            }
            else{
                return response()->json(['errors' => ['error' => 'Please add cheque details.']]);
            }
        }
        if($payment == 6){
            $banks = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser);
            $cheques = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser);
            if($paid != null){
                $paidTotal += $paid;
                $newPayment->cash = $paid;
            }
            if($banks != null){
                $paidTotal += $banks->sum('amount');
                $newPayment->bank = $banks->sum('amount');
            }
            if($cheques != null){
                $paidTotal += $cheques->sum('amount');
                $newPayment->cheque = $cheques->sum('amount');
            }
            if($cardAmount != null){
                if($visaBill == null){
                    return response()->json(['errors' => ['error' => 'Card no should be provided.']]);
                }
                else{
                    $paidTotal += $cardAmount;
                    $newPayment->visa = $cardAmount;
                    $newPayment->visaBillNo = $visaBill;
                }
            }
        }

        if($paidTotal> $billTotal){
            return response()->json(['errors' => ['error' => 'Paid amount is grater than due amount.']]);

        }

        $transfer->paidTotal += min($paidTotal,$billTotal);
        $transfer->save();

        $isComplete = false;
        if($transfer->paidTotal >= $transfer->netTotal){
            $isComplete = true;
        }


        $newPayment->totalAmount = min($paidTotal,$billTotal);
        $newPayment->status = 1;
        $newPayment->isBulk = 0;
        $newPayment->usermaster_idUser = Auth::user()->idUser;
        $newPayment->save();

        if($payment == 3){
            foreach ($banks as $record) {
                $bank = new BankPayments();
                $bank->Company = Auth::user()->idUser;
                $bank->payment_idpayment = $newPayment->idpayment;
                $bank->bank_meta_idbank_meta = $record->bank_meta_idbank_meta;
                $bank->amount = $record->amount;
                $bank->status = 1;
                $bank->save();
                $record->delete();
            }

        }
        if($payment == 5){
            foreach ($cheques as $record) {
                $bank = new ChequePayments();
                $bank->Company = Auth::user()->idUser;
                $bank->payment_idpayment = $newPayment->idpayment;
                $bank->bank_meta_idbank_meta = $record->bank_meta_idbank_meta;
                $bank->chequeNo = $record->chequeNo;
                $bank->chequeDate = date('Y-m-d', strtotime($record->chequeDate));
                $bank->amount = $record->amount;
                $bank->status = 1;
                $bank->save();
                $record->delete();
            }
        }

        return response()->json(['isComplete'=>$isComplete,'id'=>$newPayment->idpayment,'success'=>'success','paidTotal'=>number_format($transfer->paidTotal,2),'isComplete'=>$isComplete]);

    }

    public function viewBulkPaymentModalTransfer(Request $request){
        $bulkPayments = $request['bulkPayments'];
        $netTotal = 0;
        $paidTotal = 0;
        $dueTotal = 0;
        $tableData = "";
        foreach ($bulkPayments as $bulkPayment) {
            $transfer = StockTransfer::find($bulkPayment);
            $netTotal += $transfer->netTotal;
            $paidTotal += $transfer->paidTotal;
            $dueTotal += floatval($transfer->netTotal - $transfer->paidTotal);

            $tableData .= "<tr>";
            $tableData .= "<td>".sprintf('%06d', $bulkPayment)."</td>";
            $tableData .= "<td>
                            <div class=\"input-group mb-2 col-md-9\">
                                <div class=\"input-group-prepend\">
                                    <div class=\"input-group-text\">RS.</div>
                                </div>
                               <input readonly id='bulkAmount-".$bulkPayment."' class='form-control' value=".number_format(floatval($transfer->netTotal - $transfer->paidTotal),2)." ></td>
                            </div>";
            $tableData .= "</tr>";

        }
        return response()->json(['tableData'=>$tableData,'netTotal' => number_format($netTotal,2), 'paidTotal' => number_format($paidTotal,2),'dueTotal'=> number_format($dueTotal,2),'dueTotalP'=> $dueTotal]);

    }

    public function bulk_addPaymentTransfer(Request $request)
    {
        $bulkPayments = $request['bulkPayments'];
        $cardAmount = floatval($request['cardAmount']);
        $visaBill = $request['visaBill'];
        $paid = floatval($request['paid']);
        $payment = $request['payment'];
        $paidTotal = 0;
        $values = [];


        $newPayment = new Payment();
        $newPayment->Company = Auth::user()->Company;
        $newPayment->base = 4;
        $newPayment->id = null;
        $newPayment->status = 1;
        $billTotal = 0;


        foreach ($bulkPayments as $id) {

            $transfer = StockTransfer::find(intval($id));
            $billTotal += $transfer->netTotal;
        }

        if($payment == 1){
            $paidTotal = $paid;
            $newPayment->cash =  min($paidTotal,$billTotal);
        }
        if($payment == 3){
            $banks = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
            if($banks != null){
                $paidTotal = $banks->sum('amount');
                $newPayment->bank =  min($paidTotal,$billTotal);
            }else{
                return response()->json(['errors' => ['error' => 'Please add bank payments details.']]);
            }
        }
        if($payment == 4){
            if($visaBill == null){
                return response()->json(['errors' => ['error' => 'Card no should be provided.']]);
            }
            $paidTotal = $cardAmount;
            $newPayment->visa =  min($paidTotal,$billTotal);
            $newPayment->visaBillNo = $visaBill;
        }
        if($payment == 5){
            $cheques = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser)->get();
            if($cheques != null){
                $paidTotal = $cheques->sum('amount');
                $newPayment->cheque =  min($paidTotal,$billTotal);
            }
            else{
                return response()->json(['errors' => ['error' => 'Please add cheque details.']]);
            }
        }
        if($payment == 6){
            $banks = BankPaymentsTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser);
            $cheques = ChequePaymentTemp::where('status',1)->where('usermaster_idUser',Auth::user()->idUser);
            if($paid != null){
                $paidTotal += $paid;
                $newPayment->cash = $paid;
            }
            if($banks != null){
                $paidTotal += $banks->sum('amount');
                $newPayment->bank = $banks->sum('amount');
            }
            if($cheques != null){
                $paidTotal += $cheques->sum('amount');
                $newPayment->cheque = $cheques->sum('amount');
            }
            if($cardAmount != null){
                if($visaBill == null){
                    return response()->json(['errors' => ['error' => 'Card no should be provided.']]);
                }
                else{
                    $paidTotal += $cardAmount;
                    $newPayment->visa = $cardAmount;
                    $newPayment->visaBillNo = $visaBill;
                }
            }
        }

        if($paidTotal> $billTotal){
            return response()->json(['errors' => ['error' => 'Paid amount is grater than due amount.']]);

        }

        $paidTotal = min($paidTotal,$billTotal);
        $newPayment->totalAmount = min($paidTotal,$billTotal);
        $newPayment->isBulk = 1;
        $newPayment->payment_type_idpayment_type = $payment;
        $newPayment->usermaster_idUser = Auth::user()->idUser;
        $newPayment->save();


        $saveToStock = floatval($paidTotal);

        foreach ($bulkPayments as $id) {

            if($saveToStock > 0) {
                $transfer = StockTransfer::find(intval($id));
                $due = floatval($transfer->netTotal) - floatval($transfer->paidTotal);

                if ($due >= $saveToStock) {
                    $transfer->paidTotal += $saveToStock;


                    $reference = new PaymentRefference();
                    $reference->payment_idpayment = $newPayment->idpayment;
                    $reference->base = 1;
                    $reference->ref_no = $transfer->idStock_Transfer;
                    $reference->amount = $saveToStock;
                    $reference->status = 1;
                    $reference->save();
                    $saveToStock = 0;

                } else {
                    $transfer->paidTotal += $due;
                    $saveToStock -= $due;


                    $reference1 = new PaymentRefference();
                    $reference1->payment_idpayment = $newPayment->idpayment;
                    $reference1->base = 1;
                    $reference1->ref_no = $transfer->idStock_Transfer;
                    $reference1->amount = floatval($due);
                    $reference1->status = 1;
                    $reference1->save();
                }
                $transfer->save();
                $isComplete = false;
                if($transfer->paidTotal >= $transfer->netTotal){
                    $isComplete = true;
                }
                $values += array($id => [number_format($transfer->paidTotal,2),$isComplete]);
            }

        }


        if($payment == 3){
            foreach ($banks as $record) {
                $bank = new BankPayments();
                $bank->Company = Auth::user()->idUser;
                $bank->payment_idpayment = $newPayment->idpayment;
                $bank->bank_meta_idbank_meta = $record->bank_meta_idbank_meta;
                $bank->amount = $record->amount;
                $bank->status = 1;
                $bank->save();
                $record->delete();
            }

        }
        if($payment == 5){
            foreach ($cheques as $record) {
                $bank = new ChequePayments();
                $bank->Company = Auth::user()->idUser;
                $bank->payment_idpayment = $newPayment->idpayment;
                $bank->bank_meta_idbank_meta = $record->bank_meta_idbank_meta;
                $bank->chequeNo = $record->chequeNo;
                $bank->chequeDate = date('Y-m-d', strtotime($record->chequeDate));
                $bank->amount = $record->amount;
                $bank->status = 1;
                $bank->save();
                $record->delete();
            }
        }


        return response()->json(['success'=>'success','paidTotal'=>$values,'id'=>$newPayment->idpayment]);

    }

    public function printTransferStockBulk($id=null)
    {
        $payment = Payment::find(intval($id));
//        $references = null;
//        if($payment->isBulk == 1) {
//            $references = PaymentRefference::where('payment_idpayment', $id)->where('status', 1)->get();
//        }

        return view('print.printTransferBulk')->with(['payment' => $payment]);
    }

    public function totalChequeAmountTemp(){
        $cheque = ChequePaymentTemp::where('usermaster_idUser',Auth::user()->idUser)->where('status',1)->sum('amount');
        return $cheque;
    }

    public function totalBankAmountTemp(){
        $bank = BankPaymentsTemp::where('usermaster_idUser',Auth::user()->idUser)->where('status',1)->sum('amount');
        return $bank;
    }

    public function paymentHistory(Request $request){
//        $query = StockTransfer::query();
//        if (!empty($request->id)) {
//            $query = $query->where('idStock_Transfer', $request->id);
//        }
//        if (!empty($request->company)) {
//            $query = $query->where('Company_To', $request->company);
//        }
//        if (!empty($request->end) && !empty($request->str)) {
//            $startDate = date('Y-m-d', strtotime($request['str']));
//            $endDate = date('Y-m-d', strtotime($request['end'].' +1 day'));
//            $query = $query->whereBetween('created_at', [$startDate, $endDate]);
//        }
        $companies = CompanyInfo::where('status',1)->get();
//        $transfers = $query->latest()->paginate(10);
        $payments = Payment::where('status',1)->latest()->paginate(10);
        $paymentTypes = PaymentType::where('status',1)->get();
        return view('payments.paymentHistory')->with(['companies'=>$companies,'paymentTypes'=>$paymentTypes,'title'=>'Payment History','payments'=>$payments]);
    }
}
