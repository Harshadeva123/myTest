<?php

namespace App\Http\Controllers;

use App\Brand;
use App\MainCategory;
use App\Stock;
use App\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DeactivatedStockController extends Controller
{
    private $take = 10;
    public function index(Request $request){

        $AuthCompany = Auth::user()->Company;
        $categories = MainCategory::where('status',1)->where('Company',$AuthCompany)->get();
        $stockTypes = Store::where('status',1)->where('Company',$AuthCompany)->get();
        $types = Brand::where('status',1)->where('Company',$AuthCompany)->get();

        $item  = $request['item'];
        $type  = $request['type'];
        $category  = $request['category'];

        $skip = isset($request['skip'])?$request['skip']:0;
        $end = false;
        $start = false;

        $stocks =  collect();

        $query = Stock::query();
        if (!empty($item)) {
            $query = $query->whereHas("item", function($q) use($item){
                $q->Where('itemName','like', '%' .  $item .'%')->orWhere('itemCode','like', '%' .  $item .'%');
            },true);
        }
        if (!empty($type)) {
            $query = $query->whereHas("item", function($q) use($type){
                $q->where("Item_Type",$type);
            },true);
        }
        if (!empty($category)) {
            $query = $query->whereHas("item", function($q) use($category){
                $q->where("mainCategory",$category);
            },true);
        }
        $stockGroups =  $query->where('Company', $AuthCompany)->where('status', 0)->select('Items_idItems')->distinct()->get();

        $last = count($stockGroups);
        if($skip+$this->take >= $last){
            $end = true;
        }
        if($skip-$this->take < 0){
            $start = true;
        }
        if($last%$this->take == 0) {
            $lastPage = (floor($last / $this->take) * $this->take)-$this->take;
        }
        else{
            $lastPage = floor($last / $this->take) * $this->take;
        }

        foreach ($stockGroups as $stockGroup) {
            $object = new \stdClass();
            $object->item = $stockGroup->item->itemName;
            $object->itemId = $stockGroup->Items_idItems;
            $object->itemCode = $stockGroup->item->itemcode;
            $object->type = $stockGroup->item->Brand->type;
            $object->rate = $stockGroup->item->unitPrice;
            $object->category = $stockGroup->Item->MainCategory->catName;
            $available = Stock::where('Company', $AuthCompany)->where('status',0)->where('Items_idItems',$stockGroup->Items_idItems)->sum('qty_available');
//            $available += Stock::where('Company', $AuthCompany)->where('status',0)->where('Items_idItems',$stockGroup->Items_idItems)->sum('qty_free');
            $object->available = $available;
            $object->measurement = $stockGroup->item->measurement->mian;
            $stocks[] = $object;
        }

        $stocks = $stocks->slice($skip, $this->take);
        $startLink = route('deactivateStock',['skip'=>0,'item'=>$item,'type'=>$type,'category'=>$category]);
        $prevLink = route('deactivateStock',['skip'=>$skip-$this->take,'item'=>$item,'type'=>$type,'category'=>$category]);
        $nextLink = route('deactivateStock',['skip'=>$skip+$this->take,'item'=>$item,'type'=>$type,'category'=>$category]);
        $lastLink = route('deactivateStock',['skip'=>$lastPage,'item'=>$item,'type'=>$type,'category'=>$category]);
        return view('stock.deactivated_stock', ['categories'=>$categories,'paginator'=>$stocks,'types'=>$types,'title' => 'Deactivated Stock','stockTypes'=>$stockTypes,'prevLink'=>$prevLink,'nextLink'=>$nextLink,'lastLink'=>$lastLink,'startLink'=>$startLink,'last'=>$last,'end'=>$end,'start'=>$start,]);

    }

    public function viewMore(Request $request){
        $id = $request['id'];

        $AuthCompany = Auth::user()->Company;

        $stocks = Stock::where('Items_idItems',$id)->where('Company',$AuthCompany)->where('status',0)->orderBy('idStock','DESC')->get();

        $tableData = "";
        foreach ($stocks as $stock){
            if($stock->qty_available > 0) {
                if($stock->expDate >= date('Y-m-d') || $stock->expHave == 0){
                    $tableData .= "<tr>";
                }
                else{
                    $tableData .= "<tr class='text-danger'>";
                }
                $tableData .= "<td>" .$stock->storeDetails->type . "</td>";
                if ($stock->base == 1) {
                    $tableData .= "<td>GRN</td>";
                } elseif ($stock->base == 2) {
                    $tableData .= "<td>PRODUCTION</td>";
                } elseif ($stock->base == 3) {
                    $tableData .= "<td>TRANSFER</td>";
                }
                elseif($stock->base == 4){
                    $tableData .= "<td>OPENING</td>";
                }elseif($stock->base == 5){
                    $tableData .= "<td>STORE CHANGE</td>";
                }elseif($stock->base == 6){
                    $tableData .= "<td>ITEM ISSUE</td>";
                }
                else{
                    $tableData .= "<td>UNKNOWN</td>";
                }

                $tableData .= "     <td>" . $stock->GRN_id_or_Production_id . "</td>";
                $tableData .= "     <td style='text-align: right;'>" . $stock->qty_available . "</td>";
                $tableData .= "     <td style=\"text-align: right;\">" . $stock->mnfDate. "</td>";
                $tableData .= "     <td style=\"text-align: right;\">" . $stock->expDate. "</td>";
                $tableData .= "     <td style=\"text-align: right;\">" . $stock->created_at. "</td>";

                $tableData .= "     <td style=\"text-align: right;\">" . number_format($stock->item->unitPrice,2) . "</td>";
                $tableData .= "      </tr>";
            }
        }

        return $tableData;
    }
}
