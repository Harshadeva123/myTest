<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/15/2019
// * Time: 2:08 PM
// */
//
//namespace App\Http\Controllers;
//
//
//
//use App\CompanyInfo;
//use App\Customer;
//use App\InvoiceReg;
//use App\InvoiceRegItems;
//use App\InvoiceTemp;
//use App\Section;
//use App\Stock;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Auth;
//use App\Invoice;
//use App\Item;
//use App\Measurement;
//use App\StockType;
//use App\Supplier;
//
//class SectionController extends Controller
//{
//    public function section(){
//
//        $sections = Section::orderBy('idSection','DESC')->paginate(10);
//        $companies = CompanyInfo::where('status',1)->get();
//        return view('section.section')->with(['title'=>'Section Management','sections'=>$sections,'companies'=>$companies]);
//    }
//
//    public function sectionStatusChange(Request $request){
//
//        $id = $request['id'];
//        $section = Section::find($id);
//        if($section->status == 0){
//            $section->status = 1;
//            $section->save();
//        }
//        else{
//            $section->status = 0;
//            $section->save();
//        }
//    }
//
//    public function addSection(Request $request){
//
//        $validator = \Validator::make($request->all(), [
//
//            'name' => 'required',
//            'company' => 'required'
//        ], [
//            'name.required' => 'Section Name should be provided!',
//            'company.required' => 'Company should be provided!',
//
//        ]);
//
//        if ($validator->fails()) {
//            return response()->json(['errors' => $validator->errors()->all()]);
//        }
//
//        $name = $request['name'];
//        $company = $request['company'];
//
//        $section = new Section();
//        $section->Company = $company;
//        $section->sectionName = strtoupper($name);
//        $section->status = 1;
//        $section->save();
//        return response()->json(['success' =>'Section saved successfully.']);
//    }
//
//    public function updateSection(Request $request){
//
//        $name = $request['name'];
//        $company = $request['company'];
//        $id = $request['id'];
//
//        $section = Section::find($id);
//        $section->Company = $company;
//        $section->sectionName = strtoupper($name);
//        $section->save();
//        return response()->json(['success' =>'Section updated successfully.']);
//    }
//    public function searchSectionName(Request $request){
//        $keyword = $request['search'];
//        $companies = CompanyInfo::where('status',1)->get();
//
//        $sections = Section::where('sectionName', 'LIKE', "%$keyword%")->orderBy('idSection','DESC')->paginate(10);
//        $sections->appends(array(
//            'search' => $request['search'],
//        ));
//        return view('section.section')->with(['title'=>'Section Management','sections'=>$sections,'companies'=>$companies]);
//    }
//
//    public function viewSectionTable(){
//        $sections = Section::orderBy('idSection','DESC')->paginate(10);
//        $tableData = "";
//        foreach ($sections as $section) {
//
//            $tableData .= " <tr id=\"$section->idSection\">
//                                <td>$section->sectionName</td>
//                                <td>".$section->company->companyName."</td>
//                                <td>".$section->created_at->format('Y-m-d')."</td>";
//
//            if ($section->status == 1) {
//
//                $tableData .= " <td>
//                                    <p>
//                                        <input type=\"checkbox\"
//                                               id='c".$section->idSection."'
//                                               data-id='$section->idSection'
//                                               onchange=\"statusChange(this)\" checked
//                                               switch=\"none\"/>
//                                        <label for='c".$section->idSection."'
//                                               data-on-label=\"On\"
//                                               data-off-label=\"Off\"></label>
//                                    </p>
//                                </td>";
//            } else {
//                $tableData .= "<td>
//                                    <p>
//                                        <input type=\"checkbox\"
//                                               id='c".$section->idSection."'
//                                               data-id='$section->idSection'
//                                               onchange=\"statusChange(this)\"
//                                               switch=\"none\"/>
//                                        <label for='c".$section->idSection."'
//                                               data-on-label=\"On\"
//                                               data-off-label=\"Off\"></label>
//                                    </p>
//                                </td>";
//            }
//            $tableData .= "<td>
//                                                <p>
//                                                    <button type=\"button\"
//                                                            class=\"btn btn-sm btn-warning  waves-effect waves-light\"
//                                                            data-toggle=\"modal\"
//                                                            data-id= $section->idSection
//                                                            data-name= $section->sectionName
//                                                            data-company= $section->Company
//                                                           onclick=\"showUpdateModal(this)\">
//                                                        <em class=\"fa fa-edit\"></em>
//                                                    </button>
//                                                </p>
//                                            </td>
//                                        </tr>";
//        }
//        return $tableData;
//
//    }
//}