<?php
//
//namespace App\Http\Controllers;
//
//use Illuminate\Http\Request;
//use App\Item;
//
//class ShopItemReturnController extends Controller
//{
//    public function itemReturn(){
//
//        $items = Item::where('status',1)->get();
//        return view('shop.itemReturn')->with(['title'=>'Item Return','items'=>$items]);
//    }
//}
