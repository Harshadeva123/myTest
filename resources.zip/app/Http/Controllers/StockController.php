<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/15/2019
 * Time: 8:04 AM
 */

namespace App\Http\Controllers;

use App\Item;
use App\Stock;
use App\Store;
use App\StoreChange;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StockController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function storeChange()
    {
        $stores = Store::where('Company', Auth::user()->Company)->where('status', 1)->get();
        return view('stock.store_change', ['stores' => $stores, 'title' => 'Store Change']);
    }

    public function getItemByStore(Request $request)
    {
        $store = $request['store'];
        $items = Stock::where(function ($query) use ($store) {
            $query->where('expDate', '>=', date('Y-m-d'))->where('store', $store)->where('Company', Auth::user()->Company)->where('status', 1)->where('qty_available', '>', 0);
        })->orWhere(function ($query) use ($store) {
            $query->where('expHave', 0)->where('Company', Auth::user()->Company)->where('store', $store)->where('status', 1)->where('qty_available', '>', 0);
        })->select('Items_idItems')->distinct()->get();

        if (count($items) > 0) {
            $optionData = "<option value='' disabled selected>Select Item</option>";
            foreach ($items as $item) {
                $optionData .= "<option value=" . $item->Items_idItems . ">
                              " . $item->item->itemcode . ' - ' . $item->item->itemName . "
                         </option>";

            }
        } else {
            $optionData = "<option value='' disabled selected>No available items </option>";
        }

        return $optionData;
    }

    public function getAvailableICountByStore(Request $request)
    {
        $store = $request['store'];
        $item = $request['item'];
        $company = Auth::user()->Company;

        return Stock::where(function ($query) use ($company, $item, $store) {
            $query->where('expDate', '>=', date('Y-m-d'))->where('store', $store)->where('Company', $company)->where('Items_idItems', $item)->where('status', 1);
        })->orWhere(function ($query) use ($company, $item, $store) {
            $query->where('expHave', 0)->where('Company', $company)->where('store', $store)->where('Items_idItems', $item)->where('status', 1);
        })->sum('qty_available');
    }

    public function getAvailableICountByItem(Request $request)
    {
        $item = $request['item'];
        $company = Auth::user()->Company;

        return Stock::where(function ($query) use ($company, $item) {
            $query->where('expDate', '>=', date('Y-m-d'))->where('Company', $company)->where('Items_idItems', $item)->where('status', 1);
        })->orWhere(function ($query) use ($company, $item) {
            $query->where('expHave', 0)->where('Company', $company)->where('Items_idItems', $item)->where('status', 1);
        })->sum('qty_available');
    }


    public function addItemStoreChange(Request $request)
    {
        $item = $request['item'];
        $qty = $request['qty'];
        $store = $request['store'];
        $toStore = $request['toStore'];


        $validator = \Validator::make($request->all(), [

            'item' => 'required',
            'store' => 'required',
            'toStore' => 'required',
            'qty' => 'required|numeric|not_in:0',

        ], [
            'qty.not_in' => 'Amount must be grater than zero (0).',
            'item.required' => 'Item Name should be provided!',
            'store.required' => 'From Store should be provided!',
            'toStore.required' => 'To Store should be provided!',
            'qty.required' => 'Qty should be provided!',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        if ($store == $toStore) {
            return response()->json(['errors' => ['error' => 'Please select different stores!']]);
        }

        if (Store::find($store)->Company != Auth::user()->Company || Store::find($toStore)->Company != Auth::user()->Company) {
            return response()->json(['errors' => ['error' => 'Stores invalid!']]);
        }

        $exist = StoreChange::where('fromStore', $store)->where('toStore', $toStore)->where('status', 2)->where('items_idItems', $item)->where('usermaster_idUser', Auth::user()->idUser)->first();
        if ($exist == null) {
            $temp = new StoreChange();
            $temp->items_idItems = $item;
            $temp->Company = Auth::user()->Company;
            $temp->qty = $qty;
            $temp->fromStore = $store;
            $temp->toStore = $toStore;
            $temp->usermaster_idUser = Auth::user()->idUser;
            $temp->status = 2;
            $temp->save();
        } else {
            $exist->qty += $qty;
            $exist->save();
        }
        return response()->json(['success' => 'success']);
    }

    public function getStoreChangeData()
    {
        $temps = StoreChange::where('status', 2)->where('usermaster_idUser', Auth::user()->idUser)->get();
        $tableData = "";
        if (count($temps)) {
            foreach ($temps as $temp) {
                $tableData .= "<tr  id=" . $temp->idstore_change_temp . ">";
                $tableData .= "<td>" . $temp->item->itemName . "</td>";
                $tableData .= "<td>" . $temp->fromStoreDetails->type . "</td>";
                $tableData .= "<td>" . $temp->toStoreDetails->type . "</td>";
                $tableData .= "<td style='text-align:right;'>" . $temp->qty . ' ' . $temp->item->measurement->mian . "</td>";
                $tableData .= " <td style='text-align:center;'>
                            <div class='button-items'>
                                <button type='button' class='btn btn-sm btn-danger  waves-effect waves-light' 
                                data-id=" . $temp->idStore_Change . " onclick='deleteTemp(this)'>
                                 <i class='fa fa-trash'></i>
                                 </button>
                            </div>
                        </td>";
                $tableData .= "</tr>";
            }
        } else {
            $tableData .= "<tr><td style='text-align: center;font-weight: 500' colspan='5'>Sorry No Results Found. </td> </tr>";
        }
        return $tableData;
    }

    public function deleteStoreChange(Request $request)
    {
        $id = $request['id'];
        StoreChange::where('idStore_Change', $id)->where('status', 2)->delete();
    }

    public function saveStoreChange(Request $request)
    {
        $items = StoreChange::where('usermaster_idUser', Auth::user()->idUser)->where('status', 2)->get();
        if ($items == null || count($items)==0) {
            return response()->json(['errors' => ['error' => 'No items in the table.']]);
        } else {

            foreach ($items as $item) {
                $stocks = Stock::where(function ($query) use ($item) {
                    $query->where('expDate', '>=', date('Y-m-d'))->where('store', $item->fromStore)->where('Company', Auth::user()->Company)->where('status', 1)->where('qty_available', '>', 0)->where('Items_idItems', $item->items_idItems);
                })->orWhere(function ($query) use ($item) {
                    $query->where('expHave', 0)->where('Company', Auth::user()->Company)->where('store', $item->fromStore)->where('status', 1)->where('qty_available', '>', 0)->where('Items_idItems', $item->items_idItems);
                })->get();

                $qty = $item->qty;
                foreach ($stocks as $stock) {
                    $stockQty = $stock->qty_available;

                    if ($qty <= $stockQty) {
                        $stock->qty_available -= $qty;
                        if ($qty == $stockQty) {
                            $stock->status = 0;
                        }
                        $stock->save();

                        $new = new Stock();
                        $new->store = $item->toStore;
                        $new->GRN_id_or_Production_id = $item->idStore_Change;
                        $new->Company = Auth::user()->Company;
                        $new->Items_idItems = $item->items_idItems;
                        $new->qty_grn = $qty;
                        $new->qty_available = $qty;
                        $new->base = 5;
                        $new->qty_inv_return = 0;
                        $new->qty_grn_return = 0;
                        $new->binNo = 0;
                        $new->expDate = $stock->expDate;
                        $new->expHave = $stock->expHave;
                        $new->mnfDate = $stock->mnfDate;
                        $new->bp = $stock->bp;
                        $new->wp = $stock->wp;
                        $new->sp = $stock->sp;
                        $new->status = 1;
                        $new->save();
                        $qty = 0;
                        break;
                    } else {

                        $newQty = $stock->qty_available;
                        $qty = floatval($qty) - floatval($stock->qty_available);
                        $stock->qty_available = 0;
                        $stock->status = 0;
                        $stock->save();

                        $new = new Stock();
                        $new->store = $item->toStore;
                        $new->GRN_id_or_Production_id = $item->idStore_Change;
                        $new->Company = Auth::user()->Company;
                        $new->Items_idItems = $item->items_idItems;
                        $new->qty_grn = $newQty;
                        $new->qty_available = $newQty;
                        $new->base = 5;
                        $new->qty_inv_return = 0;
                        $new->qty_grn_return = 0;
                        $new->binNo = 0;
                        $new->expDate = $stock->expDate;
                        $new->expHave = $stock->expHave;
                        $new->mnfDate = $stock->mnfDate;
                        $new->bp = $stock->bp;
                        $new->wp = $stock->wp;
                        $new->sp = $stock->sp;
                        $new->status = 1;
                        $new->save();
                    }
                }
                $item->status = 1;
                $item->save();

            }
        }
        return response()->json(['success' => 'success']);
    }

    public function overView(Request $request){

        $query = Stock::query();

        if($request->base != null){
            $query = $query->where('base', $request->base);
        }
        if (!empty($request->end) && !empty($request->start)) {
            $startDate = date('Y-m-d', strtotime($request['start']));
            $endDate = date('Y-m-d', strtotime($request['end'].' +1 day'));

            $query = $query->whereBetween('created_at', [$startDate, $endDate]);
        }

        $stocks = $query->where('Company',Auth::user()->Company)->where('status',1)->paginate(10);

        $stocks->appends(array(
            'start' => $request['start'],
            'end' => $request['end'],
            'base' => $request['base']
        ));
        return view('stock.stock_overview')->with(['stocks'=>$stocks,'title'=>'Stock Overview']);
    }

}