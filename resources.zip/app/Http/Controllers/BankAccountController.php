<?php

namespace App\Http\Controllers;

use App\BankAccount;
use App\BankMeta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BankAccountController extends Controller
{
    public function index(Request $request){
        $bank = $request['bank'];
        $branch = $request['Sbranch'];

        $query = BankAccount::query();
        if($bank != null){
            $query = $query->where('bank_idbank',$bank);
        }
        if($branch != null){
            $query = $query->where('branch', 'LIKE',"%$branch%");
        }
        $accounts = $query->where('Company',Auth::user()->Company)->get();
        $banks = BankMeta::where('status',1)->get();
        return view('bank_account.bank_account')->with(['banks'=>$banks,'title'=>'Bank Account','accounts'=>$accounts]);
    }

    public function getBankAccountData(Request $request){
        $accounts = BankAccount::where('Company',Auth::user()->Company)->get();
        $tableData = "";
        foreach ($accounts as $account){
            $tableData .= "<tr>";
            $tableData .= "<td>".strtoupper($account->bank->bank)."</td>";
            $tableData .= "<td>".strtoupper($account->branch)."</td>";
            $tableData .= "<td>".$account->accNo."</td>";
            if ($account->status == 1) {

                $tableData .= "<td>";
                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=\"bankAccountStatus('$account->idbank_meta')\" id='c" . $account->idbank_meta . "' checked switch='none'/>";
                $tableData .= "<label for='c" . $account->idbank_meta . "' data-on-label='On' data-off-label='Off'></label>";
                $tableData .= "</td>";
            } else {
                $tableData .= "<td>";
                $tableData .= "<input type='checkbox' class='btn  btn-sm btn-danger' onchange=\"bankAccountStatus('$account->idbank_meta')\" id='c" . $account->idbank_meta . "'  switch='none'/>";
                $tableData .= "<label for='c" . $account->idbank_meta . "' data-on-label='On' data-off-label='Off'></label>";
                $tableData .= "</td>";
            }
            $tableData .= "<td>".$account->updated_at."</td>";
            $tableData .= "<td>".$account->created_at."</td>";
            $tableData .= "<td> <div class='button-items'>
                                    <button type='button'
                                            class='btn btn-sm btn-warning  waves-effect waves-light'                                         
                                          onclick='showUpdateModal($account->idbank_meta)'><i
                                                class='fa fa-edit'></i></button>";

            $tableData .= "  </div></td>";
            $tableData .= "</tr>";
        }
        return $tableData;
    }

    public function save(Request $request)
    {
        $bank = $request['bank'];
        $account = $request['account'];
        $branch = $request['branch'];

        $validator = \Validator::make($request->all(), [
            'bank' => 'required',
            'account' => 'required',
            'branch' => 'required',
        ], [
            'bank.required' => 'Bank Name should be provided!',
            'branch.required' => 'Branch should be provided!',
            'account.required' => 'Account No should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $exist = BankAccount::where('accNo', $request->account)->where('bank_idbank', $request->bank)->where('branch', $request->branch)->where('Company', Auth::user()->Company)->first();
        if($exist == NULL){
            $bank_account = new BankAccount();
            $bank_account->accNo = $request->account;
            $bank_account->bank_idbank = $request->bank;
            $bank_account->branch = $request->branch;
            $bank_account->Company = Auth::user()->Company;
            $bank_account->status = 1;
            $bank_account->save();

            return response()->json(['success' => 'Bank Account successfully Saved']);

        }else{
            return response()->json(['errors' => ['error' => 'Same account already exist!']]);
        }

    }

    public function update(Request $request)
    {
        $id = $request['id'];

        $validator = \Validator::make($request->all(), [
            'bank' => 'required',
            'account' => 'required',
            'branch' => 'required',
            'id' => 'required',
        ], [
            'id.required' => 'ID should be provided!',
            'bank.required' => 'Bank Name should be provided!',
            'branch.required' => 'Branch should be provided!',
            'account.required' => 'Account No should be provided!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }

        $exist = BankAccount::where('idbank_meta','!=', $id)->where('accNo', $request->account)->where('bank_idbank', $request->bank)->where('branch', $request->branch)->where('Company', Auth::user()->Company)->first();
        if($exist == NULL){
            $bank = BankAccount::find($id);
            $bank->accNo = $request->account;
            $bank->bank_idbank = $request->bank;
            $bank->branch = $request->branch;
            $bank->save();

            return response()->json(['success' => 'Bank Account successfully Updated']);

        }else{
            return response()->json(['errors' => ['error' => 'Same account already exist!']]);
        }

    }


    public function getById(Request $request){
        $id = $request['id'];
        return BankAccount::find($id);
    }

    public function changeStatus(Request $request){
        $id = $request['id'];
        $acc = BankAccount::find($id);
        if($acc->status == 1){
            $acc->status = 0;

        }
        else{
            $acc->status = 1;

        }
        $acc->save();
    }
}
