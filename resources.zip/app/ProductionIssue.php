<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/8/2019
// * Time: 8:32 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class ProductionIssue extends Model
//{
//    protected $table = 'production_issue';
//    protected $primaryKey = 'idProduction_Issue';
//
//    public function company()
//    {
//        return $this->belongsTo(CompanyInfo::class,'Company');
//    }
//    public function stock()
//    {
//        return $this->belongsTo(Section::class,'Section_idSection');
//    }
//    public function section()
//    {
//        return $this->belongsTo(Section::class,'Section_idSection');
//    }
//    public function expected()
//    {
//        return $this->hasMany(Expected::class);
//    }
//    public function itemsIssue()
//    {
//        return $this->hasMany(ItemIssueList::class);
//    }
//    public function user()
//    {
//        return $this->belongsTo(User::class,'UserMaster_idUser');
//    }
//}