<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/8/2019
// * Time: 8:32 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class DailyOrder extends Model
//{
//    protected $table = 'daily_orders';
//    protected $primaryKey = 'idsales_order';
//
//
//    public function CompanyInfo()
//    {
//        return $this->belongsTo(CompanyInfo::class, 'companyinfomaster_id');
//    }
//    public function user()
//    {
//        return $this->belongsTo(User::class, 'usermaster_idUser');
//    }
//    public  function orderItems(){
//        return $this->hasMany(DailyOrderItems::class,'orders_idsales_order');
//    }
//
//
//}
