<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 5/5/2019
// * Time: 6:03 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class TransferItemTemp extends Model
//{
//    protected $table = 'transfer_item_temp';
//    protected $primaryKey = 'idtransfer_item_temp';
//
//    public function item(){
//        return $this->belongsTo(Item::class,'items_idItems');
//    }
//
//
//}