<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class ChequePaymentTemp extends Model
{
    protected $table = 'cheque_payment_temp';
    protected $primaryKey = 'idcheque_payment_temp';

    public function bank()
    {
        return $this->belongsTo(BankMeta::class, 'bank_idbank');
    }
    public function account()
    {
        return $this->belongsTo(BankAccount::class, 'bank_account');
    }
}
