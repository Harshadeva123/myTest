<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/7/2019
 * Time: 9:22 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Measurement extends Model
{
    protected $table = 'measurement';
    protected $primaryKey = 'idMeasurement';

    public function GrnItemsTemp()
    {
        return $this->belongsTo(GrnItemsTemp::class,'idMeasurement');
    }
    public function purchaseTemp(){
        return $this->hasMany(PurchaseTempary::class);
    }
    public function stocks()
    {
        return $this->hasMany(Stock::class);
    }
    public function item()
    {
        return $this->hasMany(Item::class);
    }

    public function User()
    {
        return $this->belongsTo(User::class, 'UserMaster_idUser');
    }
}