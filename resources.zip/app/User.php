<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    protected $table = 'usermaster';
    protected $primaryKey = 'idUser';


    public function returned()
    {
        return $this->hasMany(InvoiceReturn::class);
    }

    public function specials()
    {
        return $this->hasMany(SpecialOrder::class);
    }

    public function expectedTemps()
    {
        return $this->hasMany(ExpectedTemp::class);
    }

    public function stockTransfers()
    {
        return $this->hasMany(StockTransfer::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function transferReturn()
    {
        return $this->hasMany(TransferReturns::class);
    }

    public function companyInfo()
    {
        return $this->belongsTo(CompanyInfo::class, 'Company');
    }

    public function productionOutTemp()
    {
        return $this->hasMany(ProductionOutputTemp::class);
    }

    public function role()
    {
        return $this->belongsTo(UserRole::class, 'UserRole');
    }

    public function dailyOrders()
    {
        return $this->hasMany(DailyOrder::class);
    }

    public function opening()
    {
        return $this->hasMany(OpeningStock::class);
    }

    public function invoice()
    {
        return $this->hasMany(Invoice::class);
    }

    public function issue()
    {
        return $this->hasMany(ProductionIssue::class);
    }

    public function productionOutput()
    {
        return $this->hasMany(ProductionOutput::class);
    }

    public function Customer()
    {
        return $this->hasMany(Customer::class, 'UserMaster_idUser');
    }

    public function Supplier()
    {
        return $this->hasMany(Supplier::class, 'UserMaster_idUser');
    }

    public function MainCategory()
    {
        return $this->hasMany(MainCategory::class, 'UserMaster_idUser');
    }
    public function Item()
    {
        return $this->hasMany(Item::class, 'UserMaster_idUser');
    }

    public function Brand()
    {
        return $this->hasMany(Brand::class, 'UserMaster_idUser');
    }

    public function Measurement()
    {
        return $this->hasMany(Measurement::class, 'UserMaster_idUser');
    }

    public function GRN()
    {
        return $this->hasMany(GRN::class, 'UserMaster_idUser');
    }

}
