<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 3/27/2019
// * Time: 9:37 AM
// */
//
//namespace App;
//
//
//use App\Http\ItemCategory;
//use Illuminate\Database\Eloquent\Model;
//
//class SubCategory extends Model
//{
//
//    protected $table = 'item_sub_category';
//    protected $primaryKey = 'idItem_Sub_Category';
//
//    public function MainCategory(){
//        return $this->belongsTo(MainCategory::class,'Category');
//    }
//
//    public function Item(){
//
//        return $this->hasMany(Item::class);
//    }
//
//
//}
