<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class BankPaymentsTemp extends Model
{
    protected $table = 'bank_payment_temp';
    protected $primaryKey = 'idbank_payment_temp';

    public function bank()
    {
        return $this->belongsTo(BankMeta::class, 'bank_idbank');
    }

    public function account()
    {
        return $this->belongsTo(BankAccount::class, 'bank_account');
    }
}
