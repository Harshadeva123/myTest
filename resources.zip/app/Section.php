<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/8/2019
// * Time: 8:32 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class Section extends Model
//{
//    protected $table = 'section';
//    protected $primaryKey = 'idSection';
//
//    public function productionIssue()
//    {
//        return $this->hasMany(ProductionIssue::class);
//    }
//    public function company()
//    {
//        return $this->belongsTo(CompanyInfo::class,'Company');
//    }
//    public function productionOutput()
//    {
//    return $this->hasMany(ProductionOutput::class);
//    }
//    public function productionOutTemp()
//    {
//        return $this->hasMany(ProductionOutputTemp::class);
//    }
//}