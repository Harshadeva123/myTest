<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 5/5/2019
// * Time: 6:03 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class StockTransfer extends Model
//{
//    protected $table = 'stock_transfer';
//    protected $primaryKey = 'idStock_Transfer';
//
//    public function transferItems(){
//        return $this->hasMany(TransferItem::class);
//    }
//    public function pendingTransferItems(){
//        return $this->hasMany(PendingTransferItem::class);
//    }
//    public function returnItemsAdded(){
//        return $this->hasMany(ReturnItemTransferAdded::class);
//    }
//    public function ToCompany(){
//        return $this->belongsTo(CompanyInfo::class,'Company_To');
//    }
//
//    public function FromCompany(){
//        return $this->belongsTo(CompanyInfo::class,'Company_From');
//    }
//    public function payment(){
//        return $this->belongsTo(PaymentType::class,'payment_type');
//    }
//    public function user(){
//        return $this->belongsTo(User::class,'UserMaster_idUser');
//    }
//
//
//
//}