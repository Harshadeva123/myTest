<?php
///**
// * Created by PhpStorm.
// * User: Nimesh VGS
// * Date: 2/17/2020
// * Time: 2:12 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class Voucher extends Model
//{
//    protected $table='Voucher';
//    protected $primaryKey='idVoucher';
//
//    public function VoucherTypeMeta(){
//        return $this->belongsTo(VoucherTypeMeta::class,'Voucher_Type');
//    }
//
//    public function PaymentType()
//    {
//        return $this->belongsTo(PaymentType::class,'Payment_Type');
//    }
//
//    public function User(){
//        return $this->belongsTo(User::class,'Master_User');
//    }
//}