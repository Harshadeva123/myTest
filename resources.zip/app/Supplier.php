<?php
/**
 * Created by PhpStorm.
 * User: Thilina
 * Date: 5/5/2019
 * Time: 6:03 PM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $table = 'supplier';
    protected $primaryKey = 'idSupplier';

    public function grn(){
        return $this->hasMany(GRN::class);
    }
//    public function purchase(){
//        return $this->hasMany(Purchase::class);
//    }
    public function company(){
        return $this->belongsTo(CompanyInfo::class,'Company');
    }
    public function User()
    {
        return $this->belongsTo(User::class, 'UserMaster_idUser');
    }

}