<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-002
 * Date: 9/11/2019
 * Time: 3:36 PM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Store extends  Model
{
    protected $table = 'store';
    protected $primaryKey = 'idStore';

    public function CompanyInfo()
    {
        return $this->belongsTo(CompanyInfo::class,'Company');
    }

    public function stocks()
    {
        return $this->hasMany(Stock::class);
    }
    public function GrnItemsTemp()
    {
        return $this->hasMany(GrnItemsTemp::class,'store');
    }
    public function storeChange(){
        return $this->hasMany(StoreChange::class);
    }
//    public function itemIssuedTemps(){
//        return $this->hasMany(ItemIssueTemp::class);
//    }
//    public function productionOut(){
//        return $this->hasMany(ProductionOutputTemp::class);
//    }
//    public function pendingTransferItems(){
//        return $this->hasMany(PendingTransferItem::class);
//    }


}