<?php
///**
// * Created by PhpStorm.
// * User: ishar
// * Date: 3/10/2019
// * Time: 11:30 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class Package extends Model
//{
//    protected $table = 'package';
//    protected $primaryKey = 'idPackage';
//}