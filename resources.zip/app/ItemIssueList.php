<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-002
// * Date: 8/2/2019
// * Time: 11:02 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class ItemIssueList extends Model
//{
//    protected $table = 'item_issue_list';
//    protected $primaryKey = 'idItem_Issue_List';
//
//    public function item()
//    {
//        return $this->belongsTo(Item::class,'items_idItems');
//    }
//    public function issue()
//    {
//        return $this->belongsTo(ProductionIssue::class,'idProduction_Issue');
//    }
//
//}