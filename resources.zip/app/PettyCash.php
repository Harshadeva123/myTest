<?php
///**
// * Created by PhpStorm.
// * User: Nimesh VGS
// * Date: 2/7/2020
// * Time: 1:36 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class PettyCash extends Model
//{
//    protected $table='petty_cash';
//    protected $primaryKey='idpetty_cash';
//
//}