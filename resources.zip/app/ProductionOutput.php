<?php
//
//namespace App;
//
//use Illuminate\Database\Eloquent\Model;
//
//class ProductionOutput extends Model
//{
//    protected $table = 'production_output';
//    protected $primaryKey = 'idProduction_Output';
//
//    public function company()
//    {
//        return $this->belongsTo(CompanyInfo::class,'Company');
//    }
//    public function section()
//    {
//        return $this->belongsTo(Section::class,'section_idSection');
//    }
//    public function user()
//    {
//        return $this->belongsTo(User::class,'usermaster_idUser');
//    }
//}
