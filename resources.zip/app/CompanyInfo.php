<?php
/**
 * Created by PhpStorm.
 * User: ishar
 * Date: 8/22/2018
 * Time: 10:46 PM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyInfo extends Model
{
    protected $table = 'companyinfomaster';
    protected $primaryKey = 'idCompanyInfo';

    public function bankPayments()
    {
        return $this->hasMany(BankPayments::class);
    }
    public function productionOutTemp()
    {
        return $this->hasMany(ProductionOutputTemp::class);
    }
    public function StockType()
    {
        return $this->hasMany(StockType::class);
    }
    public function setting()
    {
        return $this->hasOne(MetaSetting::class,'Company');
    }
    public function cheque()
    {
        return $this->hasMany(ChequePayments::class);
    }
    public function productionOutput()
    {
        return $this->hasMany(ProductionOutput::class);
    }
    public function payments()
    {
        return $this->hasMany(Payment::class);
    }
    public function dailyOrders()
    {
        return $this->hasMany(DailyOrder::class);
    }
    public function invoice()
    {
        return $this->hasMany(Invoice::class);
    }
    public function grn(){
        return $this->hasMany(GRN::class);
    }
    public function purchase(){
        return $this->hasMany(Purchase::class);
    }
    public function transfers(){
        return $this->hasMany(StockTransfer::class);
    }
    public function stocks()
    {
        return $this->hasMany(Stock::class);
    }
    public function productionIssue()
    {
        return $this->hasMany(ProductionIssue::class);
    }
    public function sections()
    {
        return $this->hasMany(Section::class);
    }
    public function supplier(){
        return $this->hasMany(Supplier::class);
    }
    public function user(){
        return $this->hasMany(User::class);
    }
}