<?php
/**
 * Created by PhpStorm.
 * User: Thilina
 * Date: 3/15/2019
 * Time: 10:13 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class MainCategory extends Model
{

    protected $table = 'item_category';
    protected $primaryKey = 'idItem_Category';

    public function Item()
    {
        return $this->hasMany(Item::class,'mainCategory');
    }
    public function User()
    {
        return $this->belongsTo(User::class, 'UserMaster_idUser');
    }
}