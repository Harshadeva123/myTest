<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BankAccount extends Model
{
    protected $table = 'bank_account';
    protected $primaryKey = 'idbank_meta';

    public function bank()
    {
        return $this->belongsTo(BankMeta::class,'bank_idbank');
    }
}
