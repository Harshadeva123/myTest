<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 5/5/2019
// * Time: 6:03 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class TransferReturns extends Model
//{
//    protected $table = 'transfer_returns';
//    protected $primaryKey = 'idtransfer_returns';
//
//    public function item(){
//        return $this->belongsTo(Item::class,'items_idItems');
//    }
//    public function stockTransfer(){
//        return $this->belongsTo(StockTransfer::class,'stock_transfer_idStock_Transfer');
//    }
//    public function returnItemsAdded(){
//        return $this->hasMany(ReturnItemTransferAdded::class);
//    }
//    public function user(){
//        return $this->belongsTo(User::class,'usermaster_idUser');
//    }
//}