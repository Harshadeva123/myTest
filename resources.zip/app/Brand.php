<?php
/**
 * Created by PhpStorm.
 * User: Thilina
 * Date: 4/7/2019
 * Time: 3:01 PM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    protected $table = 'brand';
    protected $primaryKey = 'idItem_Type';
    
    public function Item(){

        return $this->hasMany(Item::class);
    }
    public function User()
    {
        return $this->belongsTo(User::class, 'usermaster_idUser');
    }

}