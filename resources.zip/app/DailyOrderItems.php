<?php
///**
// * Created by PhpStorm.
// * User: VGS-LAP-001
// * Date: 5/8/2019
// * Time: 8:32 AM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class DailyOrderItems extends Model
//{
//    protected $table = 'order_items';
//    protected $primaryKey = 'idorder_items';
//
//
//
//    public function item()
//    {
//        return $this->belongsTo(Item::class, 'items_idItems');
//    }
//    public function order()
//    {
//        return $this->belongsTo(DailyOrder::class, 'orders_idsales_order');
//    }
//
//
//}
