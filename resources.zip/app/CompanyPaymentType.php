<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyPaymentType extends Model
{
    protected $table = 'company_payment_type';
    protected $primaryKey = 'idpayment_type';


    public function paymentType()
    {
        return $this->belongsTo(PaymentType::class,'meta_payment_type');
    }
//  public function stockTransfers()
//    {
//        return $this->hasMany(StockTransfer::class);
//    }
//    public function invoice()
//    {
//        return $this->hasMany(Invoice::class);
//    }
//    public function grn()
//    {
//        return $this->hasMany(GRN::class);
//    }
//    public function specials()
//    {
//        return $this->hasMany(SpecialOrder::class);
//    }
//    public function payment()
//    {
//        return $this->hasMany(Payment::class);
//    }
}
