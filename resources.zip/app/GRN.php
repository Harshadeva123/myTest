<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class GRN extends Model
{
    protected $table = 'grn';
    protected $primaryKey = 'idGRN';


    public function CompanyInfo()
    {
        return $this->belongsTo(CompanyInfo::class, 'Company');
    }
    public function supplier()
    {
        return $this->belongsTo(Supplier::class, 'Supplier_idSupplier');
    }
    public function payment()
    {
        return $this->belongsTo(PaymentType::class, 'paymentType');
    }
    public function User()
    {
        return $this->belongsTo(User::class, 'UserMaster_idUser');
    }



}
