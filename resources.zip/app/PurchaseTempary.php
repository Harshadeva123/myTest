<?php
/**
 * Created by PhpStorm.
 * User: VGS-LAP-001
 * Date: 5/8/2019
 * Time: 8:32 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class PurchaseTempary extends Model
{
    protected $table = 'po_temp';
    protected $primaryKey = 'idpo_temp';



    public function item()
    {
        return $this->belongsTo(Item::class, 'items_idItems');
    }



}
