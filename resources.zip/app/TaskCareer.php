<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaskCareer extends Model
{
    protected $table = 'task_career';
    protected $primaryKey = 'idtask_career';
}
