<?php
///**
// * Created by PhpStorm.
// * User: Nimesh VGS
// * Date: 2/17/2020
// * Time: 2:12 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class VoucherTypeMeta extends Model
//{
//    protected $table='voucher_type_meta';
//    protected $primaryKey='idVoucher_Type';
//
//    public function Voucher(){
//        return $this->hasMany(Voucher::class,'Voucher_Type');
//    }
//
//}