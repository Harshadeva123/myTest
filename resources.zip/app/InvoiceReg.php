<?php
///**
// * Created by PhpStorm.
// * User: Thilina
// * Date: 4/7/2019
// * Time: 3:01 PM
// */
//
//namespace App;
//
//
//use Illuminate\Database\Eloquent\Model;
//
//class InvoiceReg extends Model
//{
//    protected $table = 'invoice_reg';
//    protected $primaryKey = 'idInvoice_Reg';
//
//    public function invoice()
//    {
//        return $this->belongsTo(Invoice::class, 'Invoice_idInvoice');
//    }
//    public function stock()
//    {
//        return $this->belongsTo(Stock::class, 'Stock_idStock');
//    }
//    public function item()
//    {
//        return $this->belongsTo(Item::class, 'items_idItems');
//    }
//
//
//}