<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaskIncome extends Model
{
    protected $table = 'task_income';
    protected $primaryKey = 'idtask_income';
}
