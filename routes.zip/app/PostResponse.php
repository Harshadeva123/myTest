<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostResponse extends Model
{
    protected $table = 'post_response';
    protected $primaryKey = 'idpost_response';
}
