<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostNationality extends Model
{
    protected $table = 'post_nationality';
    protected $primaryKey = 'idpost_nationality';
}
