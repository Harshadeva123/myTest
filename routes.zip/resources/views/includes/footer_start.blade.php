<footer class="footer">
    <p> © <?php echo date('Y') ?> Developed By<a href="http://webdeveloersl.com" target="_blank"> Harshadeva priyankara</a> in <img
                style="padding-bottom: 3px;min-height: 15px;"
                src="{{ URL::asset('assets/images/resources/flag.png') }}"/></p>
</footer>

</div>
<!-- End Right content here -->

</div>
<!-- END wrapper -->



