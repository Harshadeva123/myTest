<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaskNationality extends Model
{
    protected $table = 'task_nationality';
    protected $primaryKey = 'idtask_nationality';
}
