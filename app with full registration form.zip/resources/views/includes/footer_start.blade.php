<footer class="footer">
    <p> © <?php echo date('Y') ?> Developed By <img
                style="margin-top: 5px;padding-bottom: 3px;height: 20px;"
                src="{{ URL::asset('assets/images/resources/logo.svg') }}"/></p>
</footer>

</div>
<!-- End Right content here -->

</div>
<!-- END wrapper -->



