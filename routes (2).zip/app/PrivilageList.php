<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrivilageList extends Model
{
    protected $table = 'privilage_list';
    protected $primaryKey = 'idprivilage_list';
}
